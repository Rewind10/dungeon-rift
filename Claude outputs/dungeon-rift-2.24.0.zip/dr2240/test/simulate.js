/* simulate.js — test automatici headless (v1.13: ridimensionamento leggero (visivo 1.45x / collisione 1.08x), fix mercante nero sostitutivo; + storico) */
'use strict';
const { Room } = require('../server/Room.js');
// ============================================================================================
// v2.7 — LE PROVE PARTONO DALL'ONDATA 1, NON DAL RISVEGLIO
// ============================================================================================
// Dalla v2.7 una partita vera comincia col prologo: ci si sveglia in una cella, si attraversa una
// faglia, si arriva al villaggio e si parla con l’oracolo. Giusto per il gioco, inutile per queste
// prove: qui si fanno partire una cinquantina di partite per misurare ondate, bilanciamento,
// collisioni e NaN, e farle passare tutte dal prologo vorrebbe dire provare cinquanta volte il
// prologo e zero volte quello che si voleva provare.
//
// Quindi startGame() qui dentro salta la storia. Sta in UN posto solo, e' dichiarato, e non tocca il
// gioco: il gioco chiama startGame() senza il secondo argomento e il prologo c'e'. La storia ha i suoi
// test (TEST 68), e quelli usano `avviaConStoria` qui sotto, che e' la funzione vera.
const _startGame = Room.prototype.startGame;
// v2.16 — E SCEGLIE ANCHE LA PRIMA ABILITA' ATTIVA.
// Dalla v2.16 una partita comincia con una scelta in sospeso: la prima attiva si prende al livello 1,
// prima di entrare nel primo livello, e finche' non l'hai scelta il server non fa partire l'ondata.
// Giusto per il gioco, ingombrante per queste prove: ogni test che avvia una partita dovrebbe scegliere
// un'abilita' prima di poter misurare qualunque altra cosa, e cinquanta test proverebbero cinquanta
// volte la stessa scelta.
// Quindi qui la prima attiva si prende da sola, sempre la prima delle due. Sta in UN posto solo, e'
// dichiarato, e NON tocca il gioco: `avviaConStoria` e `avviaSenzaAbilita` qui sotto passano dalla
// strada vera, e sono quelle che i test della scelta usano.
// v2.18 — adesso l'unica classe che ha davvero una scelta al livello 1 e' il MAGO (la sua scuola): per
// tutte le altre la firma se la mette in mano il server da solo, e questo aiuto non ha piu' niente da
// fare. Per il mago sceglie la prima scuola, cosi' i test che non parlano di scuole non devono saperlo.
const _primaAttiva = (room) => {
  for (const p of room.players.values()) {
    if (!p.abilDovute || p.abilDovute[0] !== 1) continue;
    const scelte = Ab.perSlot(p.heroId, 1, p.scuola);
    if (scelte.length) room._prendiAbilita(p, scelte[0].id);
  }
};
Room.prototype.startGame = function (da) { const r = _startGame.call(this, da, true); _primaAttiva(this); return r; };
const avviaConStoria = (room, da) => _startGame.call(room, da);
const avviaSenzaAbilita = (room, da) => _startGame.call(room, da, true);

const C = require('../shared/constants.js');
const MU = require('../shared/mathutils.js');
const Heroes = require('../shared/heroes.js');
const MapGen = require('../shared/mapgen.js');
const Loot = require('../shared/loot.js');
const Waves = require('../shared/waves.js');
const Ab = require('../shared/abilities.js');
const Pot = require('../shared/potions.js');
const Bnt = require('../shared/bounties.js');
const Gear = require('../shared/gear.js');
const fs = require('fs');
let PASS = 0, FAIL = 0;
function assert(c, m) { if (c) PASS++; else { FAIL++; console.log('  ❌ FAIL:', m); } }
function ok(m) { console.log('  ✅', m); }
// v2.19 — LE BOTTEGHE SONO TRE, e comprare vuol dire essere in piedi davanti a QUELLA giusta: dal
// fabbro non si comprano archi. Prima bastava `p.x = room.gearMerchant.x` perche' il banco era uno
// solo; adesso il test deve dire a quale banco va, ed e' meglio che lo dica in un posto solo.
// `cat` e' il catalogo di gear.js: 'guerriero' (fabbro), 'ladro' (arciera), 'mago' (arcanista).
function alBanco(room, p, cat) {
  const b = (room.gearMerchants || []).find(x => x.cat === cat) || room.gearMerchant;
  p.x = b.x; p.y = b.y;
  return b;
}
// dove dev'essere un giocatore per comprare un DATO pezzo: si deduce dal pezzo, cosi' i test che
// parlano di statistiche non devono anche sapere la pianta del villaggio.
function alBancoDi(room, p, it) { return alBanco(room, p, it && it.hero); }
// v1.78 — da qui in poi un'ondata ripulita non finisce da sola: si ferma sulla fase 'cleared' e aspetta
// che i giocatori premano EXIT. I test che chiudevano un'ondata svuotando la mappa devono premerlo, se no
// misurano la fase sbagliata. Questo e' il gesto del giocatore, in una riga.
function chiudiOndata(room) {
  room._checkWaveClear();
  if (room.phase === C.PHASE_CLEARED) for (const p of room.players.values()) room.exitWave(p.id);
}
function bot(room, p) {
  // v1.52 — nella mappa MERCATO non ci sono nemici: il bot punta al portale EXIT (con un po' di
  // jitter, altrimenti si incastra sui muri andando in linea retta).
  if (room.phase === C.PHASE_MARKET && room.map && room.map.exit) {
    const ex = room.map.exit.x * C.TILE + C.TILE / 2, ey = room.map.exit.y * C.TILE + C.TILE / 2;
    const a = Math.atan2(ey - p.y, ex - p.x);
    return { mx: Math.cos(a) + (Math.random() - 0.5) * 0.7, my: Math.sin(a) + (Math.random() - 0.5) * 0.7, aim: a, shoot: false, q: false, e: false, dash: false };
  }
  let n = null, bd = Infinity; for (const m of room.monsters) { const d = MU.dist2(p.x, p.y, m.x, m.y); if (d < bd) { bd = d; n = m; } } const i = { mx: 0, my: 0, aim: p.aim, shoot: false, q: false, e: false, dash: false }; if (n) { const d = Math.sqrt(bd); i.aim = Math.atan2(n.y - p.y, n.x - p.x); i.shoot = true;
    // v1.66 — un bot che indietreggia sotto i 160px e' un TIRATORE. Il guerriero colpisce a 100px: con la
    // vecchia regola non arrivava mai a contatto e "moriva disarmato", il che diceva qualcosa del bot, non
    // del personaggio. Chi ha un'arma da mischia tiene la distanza della sua arma.
    const rMax = p.hero.weapon.melee ? (p.hero.weapon.arcRadius || 100) : 320, rMin = p.hero.weapon.melee ? rMax * 0.55 : 160;
    // ...e quando e' ridotto male si sgancia, come farebbe chiunque. Senza questa riga il bot in mischia
    // muore in piedi davanti all'ondata e il dato che ne esce misura il bot, non il bilanciamento.
    const hurt = p.hp / (p.maxHp + p.stats.maxHpFlat) < 0.40;
    // MORDI E FUGGI: chi combatte in mischia non resta appoggiato al nemico fra un fendente e l'altro,
    // si stacca mentre l'arma e' in ricarica e rientra per il colpo. Senza questa riga il bot restava a
    // contatto per tutta la partita, moriva sempre per primo, e il dato diceva 'la classe e' fragile'
    // quando diceva 'il bot non sa giocarla'.
    const ricarica = p.hero.weapon.melee && p.fireCd > 0.35 / (p.hero.weapon.fireRate || 1);
    const dir = (hurt || ricarica) ? 1 : (d < rMin ? -1 : (d > rMax ? 1 : 0));
    if (hurt && p.cdDash <= 0 && Math.random() < 0.12) i.dash = true; i.mx = Math.cos(i.aim) * dir + (Math.random() - 0.5) * 0.6; i.my = Math.sin(i.aim) * dir + (Math.random() - 0.5) * 0.6; if (p.cdAb[0] <= 0 && Math.random() < 0.05) i.q = true; if (p.cdAb[1] <= 0 && Math.random() < 0.04) i.e = true; if (p.cdDash <= 0 && d < 140 && Math.random() < 0.06) i.dash = true; } else { i.mx = Math.random() - 0.5; i.my = Math.random() - 0.5; } return i; }
// v1.62 — con la partenza variabile (prima era il centro esatto, di fatto sempre sgombro) non si puo' piu'
// dare per scontato che "giocatore + 260px sull asse x" sia pavimento libero e in vista: puo' esserci roccia.
// Diversi test della 1.45/1.58 lo davano per scontato e fallivano a intermittenza a seconda della mappa.
// Questo helper cerca un punto alla distanza voluta girando attorno al giocatore finche' ne trova uno
// SENZA MURO e con LINEA DI VISTA libera — che e' la condizione che quei test volevano davvero esprimere.
function losSpot(room, p, dist) {
  for (let k = 0; k < 64; k++) {
    const a = (k / 64) * Math.PI * 2;
    const x = p.x + Math.cos(a) * dist, y = p.y + Math.sin(a) * dist;
    if (room.isWallAt(x, y)) continue;
    if (!room.losClear(p.x, p.y, x, y)) continue;
    return { x, y };
  }
  return { x: p.x + dist, y: p.y };
}
function hasNaN(room) { for (const p of room.players.values()) if (!isFinite(p.x) || !isFinite(p.y) || !isFinite(p.hp)) return 'player'; for (const m of room.monsters) if (!isFinite(m.x) || !isFinite(m.y) || !isFinite(m.hp)) return 'mon ' + m.type; for (const b of room.bullets) if (!isFinite(b.x) || !isFinite(b.y)) return 'bullet'; return null; }

function testMapThemes() {
  console.log('\n[TEST 1] Temi mappa + connettività');
  // v1.76 — il campo si costruisce dalla PARTENZA, non dal centro geometrico: con la caverna il
  // centro della mappa puo' essere dentro una massa di roccia, e allora non si raggiungeva nulla.
  const PF = require('../shared/pathfinding.js'); const seen = {}; let cf = 0, ef = 0;
  for (let i = 0; i < 25; i++) { const map = MapGen.generate((Math.random() * 1e9) | 0, 1 + (i % 20)); seen[map.theme.id] = 1; const dist = PF.build(map.grid, map.w, map.h, [{ gx: (map.spawn.x / C.TILE) | 0, gy: (map.spawn.y / C.TILE) | 0 }]); let r = 0, t = 0; for (const s of map.enemySpawns) { t++; if (dist[s.y * map.w + s.x] >= 0) r++; } if (t && r / t < 0.98) cf++; if (!map.exit) ef++; }
  assert(Object.keys(seen).length >= 3, 'più temi (' + Object.keys(seen).join(',') + ')'); assert(cf === 0, 'tutte connesse'); assert(ef === 0, 'tutte con portale'); ok('temi/connettività OK');
}
function testLives() {
  console.log('\n[TEST 2] Sistema di vite');
  const room = new Room('lives'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  assert(p.lives === C.START_LIVES, 'parte con ' + C.START_LIVES + ' vite');
  const dt = 1 / C.TICK_RATE;
  const bleedOut = () => { p.buffs = {}; p.hp = 1; room.damagePlayer(p, 999, p.x + 10, p.y, 0); for (let i = 0; i < Math.ceil(C.DOWN_BLEED_TIME * C.TICK_RATE) + 3 && !p.dead; i++) { p.buffs.iframe = 0; room.update(dt); } };
  const before = p.lives; bleedOut(); assert(p.lives === before - 1, '1ª caduta -1 vita'); assert(!p.dead && p.hp > 0, 'si rialza');
  bleedOut(); assert(p.dead, '2ª caduta → morte'); assert(room.phase === C.PHASE_GAMEOVER, 'game over'); ok('vite OK');
}
function testBoons() {
  console.log('\n[TEST 3] Boon a scelta (effetti unici)');
  const room = new Room('boon'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame(); room.phase = C.PHASE_SHOP;
  // v1.79 — l'offerta arriva da uno SCAGLIONE: quattro abilita', due della classe e due neutre.
  p.scaglioniDovuti = ['uncommon'];
  room.offerBoon(p); assert(p.boonOffer && p.boonOffer.length === 3, 'lo scaglione offre tre abilita (' + (p.boonOffer || []).length + ')');
  const pierceBefore = p.boon.pierce;
  p.boonOffer = ['arc_perfora']; room.pickBoon('b', 'arc_perfora'); assert(p.boon.pierce === pierceBefore + 1, 'Perforazione applicata col valore nuovo (+1)'); assert(p.boonsOwned.arc_perfora === 1, 'conteggio aggiornato');
  p.boonOffer = ['mag_catena']; room.pickBoon('b', 'mag_catena'); assert(p.boon.chain === 2, 'Catena di Fulmini applicata (2 rimbalzi)');
  // spara e verifica che i proiettili portino i flag delle passive
  room.bullets.length = 0; p.fireCd = 0; room.firePlayerWeapon(p); const b = room.bullets.find(x => !x.hostile); assert(b && b.pierce >= 1 && b.chain === 2, 'i proiettili ereditano le passive');
  // v1.93 — qui si prendeva Vampirismo e si controllava che alzasse il lifesteal. Nessuna carta cura
  // piu': al suo posto c'e' Presa Salda, che sul rinculo e sulla resistenza non rimette un PV.
  p.boonOffer = ['bar_spallata']; const kn0 = p.stats.knockMult; room.pickBoon('b', 'bar_spallata');
  assert(p.stats.knockMult > kn0, 'boon Presa Salda aumenta il rinculo');
  assert(p.stats.lifesteal === undefined, 'e il lifesteal non esiste proprio piu');
  // v1.79 — NIENTE IMPILAMENTO: ogni abilita' si prende una volta sola, e riproporla non fa niente.
  p.boonOffer = ['arc_perfora']; const pv = p.boon.pierce; room.pickBoon('b', 'arc_perfora'); assert(p.boon.pierce === pv, 'la stessa abilita non si prende due volte');
  assert(Loot.BOONS.every(x => x.max === 1), 'e nessuna abilita e impilabile');
  ok('boon verificati');
}
function testWeaponEvo() {
  console.log('\n[TEST 4] Evoluzione armi');
  const room = new Room('evo'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame(); room.phase = C.PHASE_SHOP; p.points = 100000;
  p.weapon2 = { type: 'scatter', level: 3, evolved: null };
  // richiede st_for >= 3
  room.buyStat('b', 'st_for'); room.buyStat('b', 'st_for'); assert(!p.weapon2.evolved, 'non evolve prima della soglia');
  room.buyStat('b', 'st_for'); assert(p.weapon2.evolved === 'scatter_evo', 'evolve al raggiungimento della statistica');
  // il fuoco usa il tier evoluto (più pallini + nova)
  room.bullets.length = 0; p.fireCd = 0; room.firePlayerWeapon(p); const n = room.bullets.filter(x => !x.hostile).length; assert(n >= 12, 'arma evoluta spara molti proiettili (' + n + ')');
  ok('evoluzione verificata');
}
function testModes() {
  console.log('\n[TEST 5] Una modalita sola');
  // v1.78 — Orda, Caccia, Sopravvivenza e Tesoro sono state tolte: ogni ondata e' un'ondata normale.
  // Il test non prova piu' che le varianti esistano — prova che NON esistano, che e' la cosa che si
  // puo' rompere per sbaglio rimettendo un ramo in modeForWave.
  const ids = new Set();
  for (let w = 1; w <= 20; w++) ids.add(Waves.modeForWave(w).id);
  for (let i = 0; i < 300; i++) ids.add(Waves.modeForWave(1 + (i % 20), Math.random).id);
  assert(ids.size === 1, 'una sola modalita in venti ondate e trecento sorteggi (' + [...ids].join(', ') + ')');
  assert(ids.has('assault'), 'ed e quella normale');
  assert(Object.keys(Waves.MODES).length === 1, 'e nella tabella ce n e una sola (' + Object.keys(Waves.MODES).join(', ') + ')');
  for (const sparita of ['horde', 'hunt', 'survival', 'treasure'])
    assert(!Waves.MODES[sparita], 'la modalita ' + sparita + ' non esiste piu');
  const m = Waves.MODES.assault;
  assert(m.survive === 0 && !m.treasure, 'e non ha ne durata fissa ne scrigno');
  // v1.78 — e nel motore non deve restare nemmeno l attrezzatura dello scrigno fuggitivo
  assert(typeof (new Room('v178m')).spawnTreasure !== 'function', 'il metodo spawnTreasure e sparito dal server');
  // e nessuna ondata ha piu' un tempo di sopravvivenza: il cronometro vale per tutte
  const room = new Room('mod'); room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  assert(room.surviveT === undefined && room.parT > 0, 'ogni ondata ha un tempo obiettivo, e del tempo fisso non e rimasto nemmeno il campo');
  ok('una modalita sola verificata');
}
function testHitstop() {
  console.log('\n[TEST 6] Hit-stop (eventi di feedback)');
  const room = new Room('hs'); const p = room.addPlayer('b', { send() {} }, 'B', 'mago'); room.startGame();
  const m = room.spawnMonster('skeleton', p.x + 30, p.y, { scaling: Waves.scaling(2, 1) });
  room.damageMonster(m, 5, p.x, p.y, 0, p, { crit: true });
  assert(room.events.some(e => e.t === 'hitstop'), 'un crit emette un evento hit-stop');
  const boss = room.spawnMonster('orc_warlord', p.x + 60, p.y, { hpMul: 0.001 }); room.events.length = 0; room.damageMonster(boss, 99999, p.x, p.y, 0, p);
  assert(room.events.some(e => e.t === 'hitstop'), 'l\'uccisione di un boss emette hit-stop'); ok('hit-stop verificato');
}
function testXpItems() {
  console.log('\n[TEST 7] XP + item + negozio');
  const room = new Room('xp'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const m = room.spawnMonster('skeleton', p.x + 30, p.y, { scaling: Waves.scaling(3, 1) }); const before = room.groundXp.length; room.killMonster(m, p);
  assert(room.groundXp.length > before, 'uccisione lascia XP');
  const dt = 1 / C.TICK_RATE; const xp0 = p.xpPool; for (let i = 0; i < 60; i++) room.update(dt); assert(p.xpPool > xp0, 'XP raccolta');
  room.items = [{ eid: 1, x: p.x + 8, y: p.y, r: 13, id: 'i_life', t: 30 }]; const l0 = p.lives; room.updatePickups(dt); assert(p.lives === l0 + 1, 'Cuore Fenice +1 vita');
  p.points = 20; room.phase = C.PHASE_SHOP; const hp0 = room.effMaxHp(p); room.buyStat('b', 'st_cos'); assert(room.effMaxHp(p) > hp0, 'negozio: Vitalità aumenta PV'); ok('XP/item/negozio OK');
}
function testFullRun(n, label) {
  console.log(`\n[TEST 8] Partita completa — ${n} bot (${label})`);
  const room = new Room('r' + n); for (let i = 0; i < n; i++) room.addPlayer('b' + i, { send() {} }, 'B' + i, Heroes.ORDER[i % 3]); room.startGame();
  const dt = 1 / C.TICK_RATE; let ticks = 0, maxMs = 0, tot = 0, nan = null, pWall = 0, maxMon = 0;
  while (ticks < C.TICK_RATE * 120) { for (const p of room.players.values()) if (!p.dead && !p.down) room.setInput(p.id, bot(room, p)); const t0 = process.hrtime.bigint(); room.update(dt); const t1 = process.hrtime.bigint(); const ms = Number(t1 - t0) / 1e6; maxMs = Math.max(maxMs, ms); tot += ms; ticks++; maxMon = Math.max(maxMon, room.monsters.length); for (const p of room.players.values()) if (!p.dead && room.isWallAt(p.x, p.y)) pWall++; const nn = hasNaN(room); if (nn) { nan = nn; break; } if (room.phase === C.PHASE_GAMEOVER || room.phase === C.PHASE_VICTORY) break; if (room.phase === C.PHASE_CLEARED) for (const p of room.players.values()) room.exitWave(p.id);   /* v1.78 — il bot preme EXIT: senza, resterebbe fermo sulla mappa ripulita fino al timeout */ if (room.phase === C.PHASE_SHOP) for (const p of room.players.values()) { if (p.boonOffer && p.boonOffer.length) room.pickBoon(p.id, p.boonOffer[0]); if (p.points > 0) room.buyStat(p.id, Loot.XP_STATS[MU.randInt(0, Loot.XP_STATS.length - 1)].id); if (!p.ready) room.shopReady(p.id, Math.random() < 0.25 ? 'market' : 'wave'); } }
  console.log(`  fase: ${room.phase} · ondata: ${room.wave} · ~${(ticks / C.TICK_RATE) | 0}s · perf avg ${(tot / ticks).toFixed(3)}ms max ${maxMs.toFixed(2)}ms · picco ${maxMon} mostri`);
  assert(nan === null, 'nessun NaN (' + (nan || 'ok') + ')'); assert(maxMs < (1000 / C.TICK_RATE) * 3, 'no tick catastrofico'); assert((tot / ticks) < (1000 / C.TICK_RATE), 'perf media OK'); assert(pWall === 0, 'giocatori mai nei muri'); assert(room.wave >= 1, 'run progredita');
}
function testSanity() {
  console.log('\n[TEST 9] Sanity mostri/boss + snapshot');
  const Mon = require('../shared/monsters.js'); const room = new Room('s'); for (let i = 0; i < 6; i++) room.addPlayer('b' + i, { send() {} }, 'B' + i, Heroes.ORDER[i % 3]); room.startGame();
  const all = [...Object.keys(Mon.MONSTERS), ...Object.keys(Mon.BOSSES)]; for (const id of all) { const m = room.spawnMonster(id, room.map.spawn.x + 100, room.map.spawn.y); assert(m && isFinite(m.hp) && m.hp > 0, id + ' valido'); }
  const dt = 1 / C.TICK_RATE; for (let i = 0; i < C.TICK_RATE * 20; i++) { for (const p of room.players.values()) room.setInput(p.id, bot(room, p)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN con tutti i tipi');
  const snap = room.snapshot(); const json = JSON.stringify(snap); assert(json.length < 320000, 'snapshot compatto (' + (json.length / 1024).toFixed(1) + ' KB)'); // v1.17 — soglia con margine (scenario stress: tutti i tipi + 6 player) assert(snap.mode !== undefined && Array.isArray(snap.xp), 'snapshot con mode e xp'); ok('sanity/snapshot OK');
}
function testV16() {
  console.log('\n[TEST 10] Novita v1.6 — combo, homing, avidita');
  const room = new Room('v16'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  // combo: uccisioni consecutive aumentano combo e moltiplicatore
  assert(room.comboMult(p) === 1, 'moltiplicatore combo parte da 1');
  for (let i = 0; i < 6; i++) { const m = room.spawnMonster('skeleton', p.x + 30, p.y, { scaling: Waves.scaling(2, 1) }); room.killMonster(m, p); }
  assert(p.combo === 6, 'combo conta le uccisioni consecutive (' + p.combo + ')');
  assert(room.comboMult(p) > 1, 'combo aumenta il moltiplicatore XP (x' + room.comboMult(p).toFixed(2) + ')');
  // XP scala col combo: stessa uccisione rende piu XP ad alto combo che a combo 0
  const p2 = room.addPlayer('c', { send() {} }, 'C', 'arciere');
  const xpAt = (pl) => { room.groundXp.length = 0; const m = room.spawnMonster('skeleton', pl.x + 30, pl.y, { scaling: Waves.scaling(2, 1) }); const xp0 = m.xp; room.killMonster(m, pl); let tot = 0; for (const o of room.groundXp) tot += o.v; return { tot, base: xp0 }; };
  p2.combo = 0; p2.comboT = 0; const lo = xpAt(p2);
  p.combo = 20; p.comboT = C.COMBO_TIME; const hi = xpAt(p);
  assert(hi.tot > lo.tot, 'ad alto combo la stessa uccisione rende piu XP (' + hi.tot + ' > ' + lo.tot + ')');
  // combo decade nel tempo
  p.combo = 5; p.comboT = 0.05; const dt = 1 / C.TICK_RATE; for (let i = 0; i < 4; i++) room.update(dt); assert(p.combo === 0, 'la combo decade allo scadere del timer');
  room.phase = C.PHASE_SHOP;   // il resto del test compra ancora abilita: la stanza deve restare nel menu
  // v1.79.2 — Mira Guidata e' stata tolta (era troppo forte e non c'entrava col ladro). Al suo posto,
  // qui si verifica FRATTURA ARCANA: la bolla che uccide si spacca in due, e le figlie non si dividono.
  const rm = new Room('frat'); const pm = rm.addPlayer('m', { send() {} }, 'M', 'mago'); rm.startGame();
  rm.phase = C.PHASE_SHOP; pm.boonOffer = ['mag_frattura']; rm.pickBoon('m', 'mag_frattura');
  assert(pm.boon.frattura === 1, 'Frattura Arcana applicata');
  rm.phase = C.PHASE_COMBAT; rm.monsters.length = 0; rm.bullets.length = 0;
  const vitt = rm.spawnMonster('skeleton', pm.x + 60, pm.y, { scaling: Waves.scaling(1, 1) }); vitt.hp = 1;
  rm.bullets.push({ eid: 99991, hostile: false, owner: 'm', x: vitt.x - 6, y: vitt.y, vx: 300, vy: 0, r: 8, dmg: 50, color: '#fff', life: 1, crit: false, pierce: 0, knock: 0, frattura: 1 });
  rm.updateBullets(1 / C.TICK_RATE);
  const figlie = rm.bullets.filter(x => x.figlia);
  assert(vitt.dead, 'la bolla uccide il bersaglio');
  assert(figlie.length === 2, 'e si spacca in due bolle minori (' + figlie.length + ')');
  assert(figlie.every(f => f.dmg <= 25 && !f.frattura), 'le figlie fanno meta danno e non si dividono a loro volta');
  // boon avidita: aumenta xpMult
  // v1.79 — Avidita, Fortuna Sfacciata e Fame Vorace sono RITIRATE: col tetto ai livelli un bonus all'XP
  // raccolta e' spazzatura per costruzione, e allo scaglione divino varrebbe esattamente zero.
  for (const id of ['greed', 'lucky', 'gluttony']) assert(!Loot.BOON_BY_ID[id], 'il potere ' + id + ' e stato ritirato');
  // boon baluardo: riduce i danni
  const p3 = room.addPlayer('d', { send() {} }, 'D', 'paladino'); p3.boonOffer = ['pal_baluardo']; room.pickBoon('d', 'pal_baluardo'); assert(p3.stats.dmgReduce > 0, 'boon Baluardo riduce i danni');
  p3.buffs = {}; p3.hp = 1000; p3.maxHp = 1000; const h0 = p3.hp; room.damagePlayer(p3, 100, p3.x + 10, p3.y, 0); const dealt = h0 - p3.hp; assert(dealt < 100, 'Baluardo attenua i danni subiti (' + dealt + ' < 100)');
  // snapshot espone i campi combo
  p.combo = 8; p.comboT = C.COMBO_TIME; const snap = room.snapshot(); const me = snap.players.find(x => x.i === 'b'); assert(me && me.cmb === 8 && me.cmx > 1, 'lo snapshot espone combo e moltiplicatore');
  ok('novita v1.6 verificate');
}
function testV17() {
  console.log('\n[TEST 11] Novita v1.7 — stats fine partita, ricompense combo, sinergie');
  const room = new Room('v17'); const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } }; const p = room.addPlayer('b', cap, 'B', 'arciere'); const p2 = room.addPlayer('c', { send() {} }, 'C', 'arciere'); room.startGame();
  // --- ricompense combo a soglie ---
  const killN = (pl, n) => { for (let i = 0; i < n; i++) { const m = room.spawnMonster('skeleton', pl.x + 30, pl.y, { scaling: Waves.scaling(2, 1) }); room.killMonster(m, pl); } };
  room.events.length = 0; p.combo = 14; killN(p, 1); assert(p.combo === 15 && room.events.some(e => e.t === 'combo_reward' && e.tier === 1), 'combo 15 sblocca ricompensa tier 1 (Frenesia)');
  assert(p.buffs.b_rate > 0, 'ricompensa 15 applica buff cadenza');
  room.events.length = 0; p.combo = 24; room.bullets.length = 0; killN(p, 1); assert(p.combo === 25 && room.events.some(e => e.t === 'combo_reward' && e.tier === 2), 'combo 25 sblocca Nova (tier 2)');
  assert(room.bullets.filter(b => !b.hostile).length >= 12, 'la Nova di combo genera proiettili');
  room.events.length = 0; p.combo = 39; p.hp = 1; p.maxHp = 200; killN(p, 1); assert(p.combo === 40 && room.events.some(e => e.t === 'combo_reward' && e.tier === 3), 'combo 40 sblocca Cura+Egida (tier 3)');
  assert(p.hp > 1, 'ricompensa 40 cura il giocatore');
  // --- sinergie boon ---
  room.phase = C.PHASE_SHOP;
  // v2.20.0 — LE SINERGIE SONO SETTE, UNA PER CLASSE, e ognuna chiede due carte di QUELLA classe prese
  // a scaglioni diversi. Qui gioca un arciere, quindi la sua: Concentrazione (epica) + Tiro Lungo (non
  // comune). Le vecchie coppie miste (Tossina + Colpi Esplosivi) non sono piu' raggiungibili da
  // nessuno, perche' nessuna carta e' piu' di due classi.
  p.boonOffer = ['arc_concentra']; room.pickBoon('b', 'arc_concentra'); assert(!p.synActive.syn_arciere, 'una carta sola non attiva la sinergia');
  const cc0 = p.stats.critChance;
  room.events.length = 0; p.boonOffer = ['arc_lungo']; room.pickBoon('b', 'arc_lungo');
  assert(p.synActive.syn_arciere === 1, 'Concentrazione + Tiro Lungo attiva Mira');
  assert(p.stats.critChance > cc0, 'e la sinergia si sente davvero (+5% critico)');
  assert(sent.some(m => m.ev && m.ev.t === 'synergy' && m.ev.id === 'syn_arciere'), 'la sinergia emette un evento al giocatore');
  // Ogni abilita' presa e' sempre attiva: il tetto delle carte accese non esiste piu'.
  p.boonOffer = ['arc_perfora']; room.pickBoon('b', 'arc_perfora');
  assert(!!p.cardOn.arc_perfora, 'ogni abilita presa e sempre accesa');
  const again = Loot.detectSynergies(p.boonsOwned, p.synActive); assert(!again.some(x => x.id === 'syn_arciere'), 'la sinergia gia attiva non viene rilevata di nuovo');
  // toxicBurst avvelena ad area
  const tp = room.addPlayer('d', { send() {} }, 'D', 'arciere'); tp.boon.toxicBurst = 1; tp.boon.poison = 1;
  const tm = room.spawnMonster('skeleton', tp.x + 20, tp.y, { scaling: Waves.scaling(2, 1) }); tm.poison = 0;
  room._toxicBurst(tp.x + 20, tp.y, 90, tp); assert(tm.poison > 0 && tm.poisonT > 0, 'la Deflagrazione Tossica avvelena i nemici ad area');
  // --- statistiche di fine partita ---
  p.kills = 12; p.comboBest = 40; p.damageDealt = 3400; p2.kills = 5; p2.comboBest = 8;
  const stats = room.buildRunStats();
  assert(Array.isArray(stats) && stats.length >= 2, 'buildRunStats restituisce una riga per giocatore');
  assert(stats[0].k >= stats[1].k, 'la classifica e ordinata per uccisioni');
  const row = stats.find(r => r.i === 'b'); assert(row && row.cb === 40 && row.dmg === 3400 && row.syn >= 1, 'le stats includono combo max, danni e sinergie');
  // gameover porta stats e durata
  sent.length = 0; room.runStart = room.time - 90; room.gameOver();
  assert(sent.some(m => m.ev && m.ev.t === 'gameover' && Array.isArray(m.ev.stats) && m.ev.dur >= 90), 'il gameover include statistiche e durata');
  ok('novita v1.7 verificate');
}
function testV18() {
  console.log('\n[TEST 12] Novita v1.8 — monete & negozio equipaggiamento');
  const room = new Room('v18'); const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } };
  const p = room.addPlayer('b', cap, 'B', 'paladino'); room.startGame();  // v1.67 — il guerriero e' quello con tutti e tre gli slot
  assert(p.coins === 0, 'il giocatore parte con 0 monete');
  // v2.12 — si parte col grado SCARSO di ogni slot, non piu' col comune. Gli id non si scrivono a mano:
  // si chiedono al catalogo, se no ogni rinominata di un pezzo rompe un test che non c'entra niente.
  const GearStart = require('../shared/gear.js');
  const attesoStart = GearStart.startingGear('paladino');
  // ============================================================================================
  // v2.18.1 — LE DUE MANI, E COMPRARE CHE NON E' PIU' INDOSSARE
  // ============================================================================================
  // Questo test affermava due cose che non valgono piu': che l'equipaggiamento sia `{weapon, armor,
  // shield}` (adesso sono due MANI piu' armatura e calzature) e che comprare metta il pezzo addosso
  // (adesso lo mette nell'INVENTARIO, e impugnarlo e' un secondo gesto, con la mano scelta). E'
  // stato riscritto su cio' che vale ora, non tolto: sono le due regole piu' facili da rompere senza
  // accorgersene, perche' il gioco continua a funzionare e semplicemente equipaggia la cosa sbagliata.
  assert(p.gear && p.gear.manoDx === attesoStart.manoDx && p.gear.armor === attesoStart.armor
    && p.gear.manoSx === attesoStart.manoSx, 'si parte col grado scarso in ogni casella della classe');
  assert(GearStart.rarityOf(GearStart.BY_ID[p.gear.manoDx]) === 'scarso', 'e quel grado si chiama davvero scarso');
  // --- drop monete alla morte ---
  const before = room.groundCoins.length; const m = room.spawnMonster('orc', p.x + 30, p.y, { scaling: Waves.scaling(3, 1) }); room.killMonster(m, p);
  assert(room.groundCoins.length > before, 'un nemico ucciso lascia monete a terra');
  assert(room.groundCoins.every(c => c.v > 0 && c.cid), 'le monete hanno un valore e un taglio');
  // --- raccolta monete (calamita) ---
  const dt = 1 / C.TICK_RATE; const c0 = p.coins; for (let i = 0; i < 60; i++) room.update(dt); assert(p.coins > c0, 'le monete vengono raccolte avvicinandosi');
  // --- acquisto equipaggiamento ---
  room.wave = 3; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');
  p.coins = 100000; p.x = room.gearMerchant.x; p.y = room.gearMerchant.y;
  const Gear = require('../shared/gear.js');
  const hp0 = room.effMaxHp(p);
  const pz = (slot, rango, car) => Gear.itemsOfRank('paladino', slot, rango).find(i => i.carattere === car);
  const armCom = pz('armor', 2, 'equilibrata');      // Maglia di Ferro
  const armRara = pz('armor', 3, 'equilibrata');     // Armatura a Piastre
  const torre = pz('shield', 2, 'pesante');          // Scudo a Torre
  const lungaEq = pz('weapon', 4, 'equilibrata');    // Alabarda: la portata
  const lungaLg = pz('weapon', 4, 'leggera');        // Falcione: l'arco
  const lungaPs = pz('weapon', 4, 'pesante');        // Maglio: il rinculo
  const dr0 = p.gearBonus.dmgReduce;

  // --- 1) COMPRARE NON EQUIPAGGIA: il pezzo entra nell'inventario e basta ---
  room.buyGear('b', armRara.id);
  assert(!!p.owned[armRara.id], 'l acquisto mette il pezzo nell inventario');
  assert(p.gear.armor === attesoStart.armor, 'e NON lo mette addosso: quello e un secondo gesto');
  assert(p.coins === 100000 - armRara.cost, 'il costo viene scalato dalle monete');
  assert(Math.abs(p.gearBonus.dmgReduce - dr0) < 1e-9, 'e finche non lo indossi non ti da niente');
  // ricomprare cio' che hai gia' non ha senso e viene rifiutato
  const soldiPrima = p.coins; room.buyGear('b', armRara.id);
  assert(p.coins === soldiPrima, 'e non si ricompra un pezzo che hai gia nell inventario');

  // --- 2) EQUIPAGGIARE, con la mano ---
  room.equipaggia('b', armRara.id);
  assert(p.gear.armor === armRara.id, 'equipaggiare mette il pezzo nella sua casella');
  assert(p.gearBonus.dmgReduce > dr0 && room.effMaxHp(p) > hp0, 'l armatura migliore da piu PV e piu riduzione');
  room.equipaggia('b', attesoStart.armor);
  assert(p.gear.armor === attesoStart.armor && Math.abs(p.gearBonus.dmgReduce - dr0) < 1e-9, 'tornando indietro il bonus viene ricalcolato da zero');
  room.equipaggia('b', armRara.id);

  // --- 3) L'ARMA VA IN UNA MANO, e il fendente cambia ---
  const dmg0 = room.effDamage(p), rad0 = room.effWeapon(p).arcRadius;
  room.buyGear('b', lungaEq.id); room.equipaggia('b', lungaEq.id, 'manoDx');
  assert(p.gear.manoDx === lungaEq.id, 'l arma si impugna nella mano scelta');
  assert(room.effDamage(p) > dmg0 && room.effWeapon(p).arcRadius > rad0, 'un arma di grado piu alto fa piu danno e arriva piu lontano');
  assert(lungaLg.weapon.arcHalf > lungaEq.weapon.arcHalf, 'a pari grado la leggera copre un arco piu largo');
  assert(lungaEq.weapon.arcRadius > lungaLg.weapon.arcRadius, 'ma arriva meno lontano della equilibrata');
  assert(lungaPs.weapon.knockback > lungaEq.weapon.knockback && lungaEq.weapon.knockback > lungaLg.weapon.knockback, 'e il rinculo scala col carattere, non col grado');
  const dps = w => w.weapon.dmg * w.weapon.fireRate;
  const tutti = [dps(lungaEq), dps(lungaLg), dps(lungaPs)];
  assert((Math.max(...tutti) - Math.min(...tutti)) / Math.min(...tutti) <= 0.04, 'e a pari grado rendono uguale: e un bivio, non una scala');
  assert(room.effWeapon(p).school === 'melee', 'l arma comprata NON cambia la scuola della classe');

  // --- 4) LE REGOLE DELLE MANI, classe per classe ---
  // il PALADINO porta lo scudo, ma non con un'arma pesante, e non ha la doppia arma.
  room.buyGear('b', torre.id);
  const drPrima = p.gearBonus.dmgReduce;
  room.equipaggia('b', torre.id, 'manoSx');
  assert(p.gear.manoSx === torre.id && p.gearBonus.dmgReduce > drPrima, 'il paladino imbraccia lo scudo nella sinistra');
  room.buyGear('b', lungaPs.id); room.equipaggia('b', lungaPs.id, 'manoDx');
  assert(p.gear.manoDx === lungaPs.id && !p.gear.manoSx, 'un arma pesante e a due mani: occupa anche la sinistra e lo scudo va via');
  assert(!Gear.impugna('paladino', p.gear, torre.id, 'manoSx').gear, 'e con la pesante in mano lo scudo non si puo rimettere');
  // il BARBARO e' l'eccezione: pesante in una mano sola, quindi pesante + scudo, o due pesanti.
  const bGear = Gear.startingGear('barbaro');
  const conPesante = Gear.impugna('barbaro', bGear, lungaPs.id, 'manoDx').gear;
  assert(conPesante && !!conPesante.manoSx, 'per il barbaro la pesante NON occupa la seconda mano');
  assert(!!Gear.impugna('barbaro', conPesante, torre.id, 'manoSx').gear, 'e puo imbracciare lo scudo insieme');
  assert(!!Gear.impugna('barbaro', conPesante, lungaPs.id, 'manoSx').gear, 'o una seconda arma pesante');
  // chi non ha ne doppia ne scudo non puo' riempire la seconda mano.
  const aGear = Gear.startingGear('arciere');
  const arcoLeg = Gear.itemsOfRank('arciere', 'weapon', 2).find(i => i.carattere === 'leggera');
  assert(!Gear.impugna('arciere', aGear, arcoLeg.id, 'manoSx').gear, 'l arciere non combatte con due armi');
  // l'ASSASSINO si': ma solo leggere, e — v2.19 — solo DA MISCHIA.
  // v2.19.6 — QUESTO TEST CONSIDERAVA GIUSTO IL BUG. Per provare «due armi» metteva lo STESSO oggetto
  // in tutte e due le mani, cioe' proprio cio' che Paolo ha segnalato: *«un'arma puoi metterla sia a
  // destra che a sinistra, ma non e' possibile»*. Adesso le due armi sono due OGGETTI (il pugnale e lo
  // stiletto: per questo i pugnali stanno in coppia), e lo stesso oggetto nell'altra mano si SPOSTA.
  // E da mischia l'assassino ha solo PUGNALI: le equilibrate e le sciabole non sono piu' sue.
  const pugnaliLg = Gear.itemsBottega('assassino', 'guerriero', 'weapon');
  assert(pugnaliLg.length > 0 && pugnaliLg.every(i => i.famiglia === 'pugnale'), 'dal fabbro l assassino vede solo pugnali');
  assert(!pugnaliLg.some(i => i.carattere === 'equilibrata'), 'e nessuna arma equilibrata');
  const pA = pugnaliLg.find(i => i.rank === 2 && /Pugnale/.test(i.name)), pB = pugnaliLg.find(i => i.rank === 2 && /Stiletto/.test(i.name));
  const dueLeg = Gear.impugna('assassino', { manoDx: pA.id, manoSx: null }, pB.id, 'manoSx').gear;
  assert(!!dueLeg && dueLeg.manoDx === pA.id && dueLeg.manoSx === pB.id, 'l assassino impugna due pugnali: uno per mano');
  const sposta = Gear.impugna('assassino', { manoDx: pA.id, manoSx: null }, pA.id, 'manoSx').gear;
  assert(!!sposta && sposta.manoSx === pA.id && sposta.manoDx !== pA.id, 'lo STESSO pugnale nell altra mano si sposta, non si duplica');
  const arcoLg = Gear.itemsBottega('assassino', 'ladro', 'weapon').find(i => i.carattere === 'leggera');
  const arcoLg2 = Gear.itemsBottega('assassino', 'ladro', 'weapon').filter(i => i.carattere === 'leggera')[1];
  assert(!Gear.impugna('assassino', { manoDx: arcoLg.id, manoSx: null }, arcoLg2.id, 'manoSx').gear,
    'e nemmeno due archi leggeri: la doppia e solo da mischia');
  // (il grado 1 non si filtra per peso, e non e' in vendita: si guardano i gradi che si comprano)
  assert(Gear.itemsBottega('assassino', 'ladro', 'weapon').filter(i => i.rank > 1).every(i => i.carattere === 'leggera'), 'e dall arciera solo archi leggeri');
  // e il MAGO, che ha doppia leggera «mago»: due verghe DIVERSE
  const verghe = Gear.itemsBottega('mago', 'mago', 'weapon').filter(i => i.carattere === 'leggera');
  assert(!!Gear.impugna('mago', { manoDx: verghe[0].id }, verghe[1].id, 'manoSx').gear, 'il mago impugna due verghe leggere');

  // --- 5) l'armatura pesante rallenta, la leggera alza la cadenza ---
  const armPes = pz('armor', 5, 'pesante'), armLeg = pz('armor', 5, 'leggera');
  room.buyGear('b', armPes.id); room.equipaggia('b', armPes.id); const ritPes = room.effFireDelay(p);
  room.buyGear('b', armLeg.id); room.equipaggia('b', armLeg.id); const ritLeg = room.effFireDelay(p);
  assert(ritPes > ritLeg, 'l armatura pesante rallenta la cadenza, la leggera la alza (' + ritPes.toFixed(3) + 's contro ' + ritLeg.toFixed(3) + 's)');
  room.equipaggia('b', armRara.id);

  // --- 6) LA RIVENDITA: si vende cio che NON stai portando, in nessuna delle caselle ---
  room.buyGear('b', armCom.id);
  room.phase = C.PHASE_MARKET; p.x = room.gearMerchant.x; p.y = room.gearMerchant.y;
  const soldi0 = p.coins; room.vendiGear('b', p.gear.armor);
  assert(p.coins === soldi0 && !!p.owned[p.gear.armor], 'il fabbro non compra cio che hai addosso');
  room.vendiGear('b', armCom.id);
  assert(p.coins === soldi0 + Gear.prezzoVendita(Gear.BY_ID[armCom.id]) && !p.owned[armCom.id], 'e compra a meta prezzo cio che sta nell inventario');
  room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b'); p.coins = 100000; p.x = room.gearMerchant.x; p.y = room.gearMerchant.y;
  // roba di un'altra impalcatura: non si compra
  const armaMago = Gear.itemsFor('mago', 'weapon')[0];
  room.buyGear('b', armaMago.id); assert(!p.owned[armaMago.id], 'il paladino non puo comprare oggetti del mago');
  // monete insufficienti
  p.coins = 0; const nonComprato = pz('weapon', 5, 'pesante');
  room.buyGear('b', nonComprato.id); assert(!p.owned[nonComprato.id], 'senza monete non si acquista');
  p.coins = 100000;
  // --- offerta gear inviata al client ---
  sent.length = 0; room.offerGear(p);
  const gm = sent.find(mm => mm.t === C.MSG.OFFER_GEAR);
  assert(gm && gm.slots.length === 3 && gm.slots.map(x => x.slot).join(',') === 'weapon,armor,shield', 'offerGear invia i 3 slot del guerriero');
  assert(gm.slots.every(sl => sl.items.length === 13 && sl.items.every(i => i.name && i.desc && typeof i.cost === 'number' && i.carattere && typeof i.vendita === 'number')), 'ogni slot porta i suoi 13 pezzi con nome, descrizione, prezzo, carattere e prezzo di rivendita');
  // --- snapshot espone le monete ---
  const snap = room.snapshot(); const me = snap.players.find(x => x.i === 'b'); assert(me && typeof me.co === 'number', 'lo snapshot espone le monete del giocatore'); assert(Array.isArray(snap.coins), 'lo snapshot espone le monete a terra');
  // --- riduzione danni con cap ---
  p.stats.dmgReduce = 2.0; p.buffs = {}; p.hp = 1000; p.maxHp = 1000; const h0 = p.hp; room.damagePlayer(p, 100, p.x + 10, p.y, 0); assert(p.hp < h0, 'la riduzione danni e limitata (subisce sempre almeno un po)');
  ok('novita v1.8 verificate');
}
function testV19() {
  console.log('\n[TEST 13] Novita v1.9 — pausa negozio, raccolta auto, nuove abilita');
  assert(C.VERSION && typeof C.VERSION === 'string', 'la versione e definita nelle costanti (' + C.VERSION + ')');
  const dt = 1 / C.TICK_RATE;
  // --- PAUSA durante il negozio: il mondo non si simula ---
  const room = new Room('v19'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const mon = room.spawnMonster('skeleton', p.x + 120, p.y, { scaling: Waves.scaling(2, 1) }); mon.mx = 200; mon.my = 0;
  room.bullets.push({ eid: 99999, hostile: true, x: p.x + 40, y: p.y, vx: 300, vy: 0, r: 5, dmg: 5, life: 3 });
  room.phase = C.PHASE_SHOP; room.shopTimer = 45; p.ready = false;
  const mx0 = mon.x, my0 = mon.y, bx0 = room.bullets[0].x, px0 = p.x;
  room.setInput('b', { mx: 1, my: 0, aim: 0, shoot: true });
  for (let i = 0; i < 10; i++) room.update(dt);
  assert(mon.x === mx0 && mon.y === my0, 'in pausa i nemici non si muovono');
  assert(room.bullets[0] && room.bullets[0].x === bx0, 'in pausa i proiettili non avanzano');
  assert(p.x === px0, 'in pausa il giocatore non si muove');
  assert(room.phase === C.PHASE_SHOP, 'in singolo il negozio non avanza da solo (attende il click)');
  room.shopReady('b'); room.update(dt); assert(room.phase !== C.PHASE_SHOP, 'il pulsante Continua (shopReady) fa proseguire la partita');
  // --- RACCOLTA AUTOMATICA a fine ondata ---
  const room2 = new Room('v19b'); const q = room2.addPlayer('c', { send() {} }, 'C', 'arciere'); room2.startGame();
  room2.groundXp.push({ eid: 1, x: 5000, y: 5000, v: 30, t: 30 });
  room2.groundCoins.push({ eid: 2, x: 5000, y: 5000, v: 25, cid: 'gold', t: 30 });
  const xp0 = q.xpPool, co0 = q.coins; room2.enterShop();
  assert(q.xpPool >= xp0 + 30, 'la XP rimasta a terra viene raccolta automaticamente');
  assert(q.coins >= co0 + 25, 'le monete rimaste a terra vengono raccolte automaticamente');
  assert(room2.groundXp.length === 0 && room2.groundCoins.length === 0, 'il terreno viene ripulito dai drop');
  // --- v1.66: le abilita' Q/E sono state RIMOSSE (torretta, cecchino, bullet-time erano cucite sui tre
  // eroi cyberpunk eliminati). Il test non verifica piu' che ci siano, ma che non tornino di soppiatto:
  // gli eroi non ne dichiarano nessuna e useQ/useE non devono produrre NIENTE.
  // v2.16 — il personaggio adesso nasce con la prima attiva in mano, quindi «premere il tasto e non
  // vedere niente» non e' piu' vero ne' desiderabile. Cio' che questo blocco deve ancora difendere e'
  // l'altra meta': che le vecchie abilita' cucite sugli eroi cyberpunk non rientrino da `hero.abilities`.
  // Si svuota `p.abil` a mano e si controlla che premere non produca nulla e non consumi ricariche.
  const room3 = new Room('v19c'); const e = room3.addPlayer('d', { send() {} }, 'D', 'paladino'); room3.startGame();
  e.abil = [null, null, null];
  e.cdAb[0] = 0; e.cdAb[1] = 0; const nOrb = room3.orbs.length, nBul = room3.bullets.length;
  room3.useAbil(e, 1); room3.useAbil(e, 2);
  assert(room3.orbs.length === nOrb && room3.bullets.length === nBul, 'uno slot vuoto non produce nulla');
  assert(e.cdAb[0] === 0 && e.cdAb[1] === 0, 'e non consuma nemmeno un cooldown');
  for (const id of Heroes.ORDER) { const h = Heroes.HEROES[id]; assert(h.abilities && Object.keys(h.abilities).length === 0, id + ' non dichiara abilita in v1.66'); }
  // --- lo SCATTO universale (tasto destro) resta funzionante ---
  const room5 = new Room('v19e'); const g = room5.addPlayer('h', { send() {} }, 'H', 'arciere'); room5.startGame(); g.cdDash = 0;
  room5.useDash(g); assert(g.buffs.dash > 0 && g.cdDash > 0, 'lo scatto universale (tasto destro) resta attivo');
  ok('novita v1.9 verificate');
}
function testV110() {
  console.log('\n[TEST 14] Novita v1.10 — 2 poteri a scelta, piu boon, emporio 3 slot');
  // --- si sceglie tra ESATTAMENTE 2 poteri ---
  const room = new Room('v110'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame(); room.phase = C.PHASE_SHOP;
  p.scaglioniDovuti = ['epic'];
  room.offerBoon(p); assert(p.boonOffer && p.boonOffer.length === 3, 'si sceglie 1 di 3 (offerti: ' + (p.boonOffer || []).length + ')');
  // --- catalogo (v2.20.0: ottantaquattro carte, dodici per classe) ---
  assert(Loot.BOONS.length === 84, 'il catalogo ha 84 carte (' + Loot.BOONS.length + ')');
  for (const id of ['arc_lungo', 'bar_colosso', 'ass_grazia', 'mag_frattura', 'war_debito']) assert(Loot.BOON_BY_ID[id], 'abilita presente: ' + id);
  // --- i boon applicano effetti (l'arciere prende le SUE) ---
  p.boonOffer = ['arc_lungo']; room.pickBoon('b', 'arc_lungo'); assert(p.boon.longshot > 0, 'Tiro Lungo applicato');
  const cd0 = p.stats.cdrMult; p.boonOffer = ['arc_piede']; room.pickBoon('b', 'arc_piede'); assert(p.boon.dashCd > 0, 'Piede Leggero applicato');
  const pf0 = p.boon.pierce; p.boonOffer = ['arc_perfora']; room.pickBoon('b', 'arc_perfora'); assert(p.boon.pierce > pf0, 'Perforazione applicata');
  // --- v1.67: l'emporio a livelli non esiste piu' (catalogo per classe in shared/gear.js) ---
  assert(!Loot.GEAR && !Loot.GEAR_BY_SLOT && !Loot.gearCost, 'l emporio generico a livelli e stato rimosso da loot.js');
  const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } };
  const eb = room.addPlayer('z', cap, 'Z', 'mago'); room.offerGear(eb, 0, 'mago');
  const gearMsg = sent.find(m => m.t === C.MSG.OFFER_GEAR);
  // v2.15.3 — il mago vede TRE slot: arma, armatura e calzature. Niente scudo, che resta del guerriero.
  // v2.19 — e li vede DALL'ARCANISTA, perche' adesso l'offerta e' quella di UNA bottega: il catalogo
  // va passato, se no il server risponde con quello del fabbro (dove il mago non ha niente).
  assert(gearMsg && gearMsg.slots.map(s => s.slot).join(',') === 'weapon,armor,boots', 'il mago vede i suoi tre slot dall arcanista (calzature si, scudo no)');
  // e dal FABBRO il mago non vede niente: il banco lo dice invece di aprirsi muto
  sent.length = 0; room.offerGear(eb, 0, 'guerriero');
  const gearFab = sent.find(m => m.t === C.MSG.OFFER_GEAR);
  assert(gearFab && gearFab.vuoto === 1 && gearFab.slots.length === 0, 'e dal fabbro non vede niente, e il banco lo dichiara vuoto');
  ok('novita v1.10 verificate');
}
function testV111() {
  console.log('\n[TEST 15] Novita v1.11 — mercante, zone telegrafate, attacchi vari, micro-aree');
  const dt = 1 / C.TICK_RATE;
  // --- MERCANTE: spawn con 3 offerte, acquisto per monete, prossimita ---
  const room = new Room('v111'); const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } };
  const p = room.addPlayer('b', cap, 'B', 'arciere'); room.startGame();
  room.spawnMerchant(); // v1.17 — forza il mercante ufficiale (a fine round e casuale: ufficiale O nero)
  assert(room.merchant && Array.isArray(room.merchant.wares) && room.merchant.wares.length === 3, 'il mercante appare con 3 offerte');
  assert(room.merchant.wares.every(w => w.cost > 0 && w.id && w.icon), 'le offerte hanno costo/icona/id');
  // porta il giocatore lontano: non deve poter comprare
  p.x = room.merchant.x + 1000; p.y = room.merchant.y; p.coins = 100000;
  const ware = room.merchant.wares.find(w => w.kind === 'heal') || room.merchant.wares[0];
  const c0 = p.coins; room.buyMerchant('b', ware.id); assert(p.coins === c0, 'lontano dal mercante non si acquista');
  // avvicina: acquisto valido
  p.x = room.merchant.x + 10; p.y = room.merchant.y; p.hp = 1; const before = p.coins; room.buyMerchant('b', ware.id);
  assert(p.coins === before - ware.cost, 'vicino al mercante si acquista e si scalano le monete');
  // v2.19.8 — e dopo UN acquisto il mercante se ne va (Paolo: *«1 solo oggetto per ondata, poi sparisce»*)
  assert(room.merchant === null, 'venduto un oggetto, il mercante errante se ne va');
  const altro = room.merchantWaresPool()[0]; const c1 = p.coins; room.buyMerchant('b', altro.id);
  assert(p.coins === c1, 'e non si puo comprare un secondo oggetto');
  // la vita extra costa 1000
  assert(room.merchantWaresPool().find(w => w.kind === 'life').cost === 1000, 'la vita extra costa 1000 monete');
  // maxhp permanente (su un mercante nuovo, perche' il primo e' partito)
  room.spawnMerchant(); p.x = room.merchant.x + 10; p.y = room.merchant.y;
  const mh = room.merchantWaresPool().find(w => w.kind === 'maxhp'); room.merchant.wares.push(mh); const hp0 = room.effMaxHp(p); p.coins = 100000; room.buyMerchant('b', 'maxhp'); assert(room.effMaxHp(p) > hp0, 'il talismano vitale aumenta i PV massimi');
  // prossimita: updateMerchant invia OFFER quando entri nel raggio
  room.spawnMerchant();
  sent.length = 0; p._nearMerch = false; p.x = room.merchant.x; p.y = room.merchant.y; room.updateMerchant(dt);
  assert(sent.some(m => m.t === C.MSG.OFFER_MERCHANT && m.near), 'avvicinandosi arriva l\'offerta del mercante');
  // --- ZONE telegrafate (Hades-style) ---
  const ctx = room.makeCtx(); const m = room.spawnMonster('skeleton', p.x + 100, p.y, { scaling: Waves.scaling(3, 1) });
  const z0 = room.zones.length; ctx.zone(p.x, p.y, 60, 0.4, 30, '#c56bff'); assert(room.zones.length === z0 + 1, 'una zona telegrafata viene creata');
  assert(room.events.some(e => e.t === 'zone_tell'), 'la zona emette un telegrafo');
  p.buffs = {}; p.hp = 500; p.maxHp = 500; const hpz = p.hp; for (let i = 0; i < 20; i++) room.updateZones(dt); assert(p.hp < hpz, 'la zona danneggia allo scadere del telegrafo');
  // --- ctx.spread genera piu proiettili ostili ---
  const b0 = room.bullets.length; ctx.spread(m, 1, 0, 3, 0.2, 200, 8, '#c56bff'); assert(room.bullets.filter(x => x.hostile).length >= b0 + 3, 'lo spread spara un ventaglio di proiettili');
  // --- MICRO-AREE nella mappa ---
  assert(Array.isArray(room.map.microAreas), 'la mappa espone le micro-aree');
  // --- snapshot espone mercante + zone ---
  const snap = room.snapshot(); assert(snap.merch && typeof snap.merch.x === 'number', 'lo snapshot espone il mercante'); assert(Array.isArray(snap.zones), 'lo snapshot espone le zone');
  const me = snap.players.find(x => x.i === 'b'); assert(me && 'nm' in me, 'lo snapshot espone il flag prossimita mercante');
  ok('novita v1.11 verificate');
}
function testV112() {
  console.log('\n[TEST 16] Novita v1.12 — Mercante Nero (rischio/ricompensa) + differenziazione');
  const dt = 1 / C.TICK_RATE;
  const room = new Room('v112'); const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } };
  const p = room.addPlayer('b', cap, 'B', 'arciere'); room.startGame();
  // forza lo spawn del mercante nero (di norma e casuale ~35%)
  room.spawnDarkMerchant();
  assert(room.darkMerchant && Array.isArray(room.darkMerchant.wares) && room.darkMerchant.wares.length === 3, 'il mercante nero appare con 3 patti');
  assert(room.darkMerchant.wares.every(w => w.cost > 0 && /ma /.test(w.desc || '') || w.kind === 'gamble'), 'i patti hanno un rischio (\'ma ...\') o sono un azzardo');
  // differenziazione: i due mercanti attingono a cataloghi diversi
  const normalIds = new Set(room.merchantWaresPool().map(w => w.id));
  const darkIds = room.darkWaresPool().map(w => w.id);
  assert(darkIds.every(id => !normalIds.has(id)), 'i due mercanti offrono oggetti diversi');
  // lontano non si compra
  p.x = room.darkMerchant.x + 1000; p.y = room.darkMerchant.y; p.coins = 100000;
  const pact = room.darkMerchant.wares.find(w => w.kind === 'pact_berserk') || room.darkMerchant.wares[0];
  const c0 = p.coins; room.buyDark('b', pact.id); assert(p.coins === c0, 'lontano dal mercante nero non si acquista');
  // vicino: patto Berserker => +danno ma -PV massimi (rischio/ricompensa)
  room.darkMerchant.wares[0] = Object.assign({}, room.darkWaresPool().find(w => w.kind === 'pact_berserk'));
  p.x = room.darkMerchant.x + 10; p.y = room.darkMerchant.y; p.coins = 100000;
  const dmg0 = p.stats.dmgMult, mhp0 = room.effMaxHp(p); room.buyDark('b', 'pact_berserk');
  assert(p.stats.dmgMult > dmg0, 'il Patto del Berserker aumenta il danno');
  assert(room.effMaxHp(p) < mhp0, 'il Patto del Berserker riduce i PV massimi (il prezzo del patto)');
  // v1.79.2 — L'OFFERTA DI SANGUE E' STATA TOLTA: dava due vite in cambio di meta' delle monete, e chi
  // ne aveva poche le prendeva quasi gratis. Non deve esistere piu' da nessuna parte.
  assert(!room.darkWaresPool().some(w => w.kind === 'blood_coin'), 'l offerta di sangue non e piu nel catalogo del Mercante Errante');
  p.coins = 200; const lv0 = p.lives;
  room.darkMerchant.wares[1] = { id: 'blood_coin', name: 'x', cost: 40, kind: 'blood_coin' };
  room.buyDark('b', 'blood_coin');
  assert(p.lives === lv0, 'e nemmeno costruendo l offerta a mano si comprano vite');
  // prossimita invia offerta dark
  sent.length = 0; p._nearDark = false; p.x = room.darkMerchant.x; p.y = room.darkMerchant.y; room.updateDarkMerchant(dt);
  assert(sent.some(m => m.t === C.MSG.OFFER_MERCHANT && m.dark && m.near), 'avvicinandosi arriva l\'offerta del mercante nero');
  // snapshot espone merchD + flag prossimita dark
  const snap = room.snapshot(); assert(snap.merchD && typeof snap.merchD.x === 'number', 'lo snapshot espone il mercante nero'); const me = snap.players.find(x => x.i === 'b'); assert(me && 'nmd' in me, 'lo snapshot espone il flag prossimita mercante nero');
  // apparizione casuale IN SOSTITUZIONE dell'ufficiale: mai entrambi, il nero compare a volte si a volte no
  let appear = 0, both = 0, none = 0; for (let i = 0; i < 40; i++) { room.newMap((Math.random() * 1e9) | 0, 1 + (i % 10)); if (room.darkMerchant) appear++; if (room.merchant && room.darkMerchant) both++; if (!room.merchant && !room.darkMerchant) none++; }
  assert(appear > 0 && appear < 40, 'il mercante nero appare in modo casuale (non sempre): ' + appear + '/40');
  assert(both === 0, 'mai entrambi i mercanti insieme (il nero sostituisce quello ufficiale)');
  assert(none === 0, 'ce sempre almeno un mercante per round');
  ok('novita v1.12 verificate');
}
function testV113() {
  console.log('\n[TEST 17] Novita v1.13 — ridimensionamento LEGGERO + fluidita (visivo>collisione, velocita ok)');
  // costanti leggere: occhi grandi, hitbox quasi invariata
  assert(C.VIS_SCALE >= 1.3 && C.VIS_SCALE <= 1.6, 'VIS_SCALE leggero (~1.45): ' + C.VIS_SCALE);
  assert(C.COL_SCALE >= 1.0 && C.COL_SCALE <= 1.15, 'COL_SCALE quasi invariato (~1.08): ' + C.COL_SCALE);
  assert(C.VIS_SCALE > C.COL_SCALE + 0.2, 'il visivo e nettamente maggiore della collisione (occhi grandi, hitbox piccola)');
  const room = new Room('v113'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  // collisione giocatore quasi invariata
  const expP = C.PLAYER_RADIUS * C.COL_SCALE; assert(Math.abs(p.radius - expP) < 0.5, 'raggio collisione giocatore leggero (' + p.radius.toFixed(1) + ' ~ ' + expP.toFixed(1) + ')');
  assert(p.radius < C.PLAYER_RADIUS * 1.2, 'la hitbox giocatore resta vicina a quella originale (fluidita)');
  // mostro: velocita INVARIATA (calcolo sul raggio originale)
  const s = Waves.scaling(3, 1); const gob = room.spawnMonster('skeleton', p.x + 60, p.y, { scaling: s });
  const skDef = require('../shared/monsters.js').MONSTERS.skeleton; const defSpeed = skDef.speed; const baseR = skDef.radius;
  const sizeFactor = Math.min(1.45, Math.max(0.6, 16 / baseR)); const wantSpeed = defSpeed * s.speed * sizeFactor;
  assert(Math.abs(gob.speed - wantSpeed) < 1.0, 'velocita mostro coerente col def: ' + gob.speed.toFixed(0) + ' ~ ' + wantSpeed.toFixed(0));
  assert(Math.abs(gob.radius - baseR * C.COL_SCALE) < 0.6, 'collisione mostro leggera (~1.08x del raggio base)');
  // giocatore +5% velocita base (feel piu reattivo)
  const base = p.hero.speed; assert(room.effSpeed(p) > base * 1.03, 'il giocatore ha un +5% di velocita base');
  // moveCircle resta permissivo come v1.12 (0.8): il fattore non e stato reso piu stretto
  ok('novita v1.13 verificate');
}
function testV139() {
  console.log('\n[TEST 18] Novita v1.39 — Negromante PUPPET (sfere debilitanti nel campo visivo + evoca zombi minori) & migliorie');
  const Mon = require('../shared/monsters.js');
  // roster PUPPET: zombie + negromante (entrambi puppet); lo Spettro vettoriale resta fuori.
  assert(!Mon.MONSTERS.spettro, 'nemico vettoriale ancora rimosso: spettro');
  assert(Mon.ORDER[0] === 'skeleton' && Mon.ORDER.includes('darkmage'), 'ORDER parte dallo sciame base e contiene il Negromante');
  const z = Mon.MONSTERS.skeleton, dm = Mon.MONSTERS.darkmage, mn = Mon.MONSTERS.zombie_mini;
  assert(z && z.puppet && z.shape === 'ghoul', 'Zombie Putrido = puppet ghoul');
  // Negromante: puppet 'mage', ranged, con curse + fov + evocazione limitata
  assert(dm && dm.puppet && dm.shape === 'mage' && dm.ai === 'necromancer', 'Negromante = puppet mage, IA necromancer');
  assert(dm && dm.curse === true, 'le sfere del Negromante sono DEBILITANTI (curse)');
  assert(dm && dm.fov > 0 && dm.sightRange > 0, 'il Negromante ha un CAMPO VISIVO (fov + sightRange)');
  assert(dm && dm.summon === 'zombie_mini' && dm.minionCap >= 3 && dm.minionCap <= 4, 'evoca zombi minori con tetto 3-4 (minionCap ' + dm.minionCap + ')');
  // Zombie Minore: puppet ghoul piccolo, non in ondata
  assert(mn && mn.minion && mn.puppet && mn.shape === 'ghoul' && mn.radius < z.radius, 'Zombie Minore = puppet ghoul piccolo');
  assert(mn && mn.weight === 0, 'lo Zombie Minore NON compare nelle ondate (solo evocato)');
  // pool: negromante entra dall'ondata 3
  assert(!Waves.poolForWave(2).some(x => x.id === 'darkmage'), 'niente Negromante prima dell\'ondata 3');
  assert(Waves.poolForWave(3).some(x => x.id === 'darkmage'), 'Negromante nel pool dall\'ondata 3');
  // simulazione: il Negromante evoca al massimo minionCap zombi minori e non supera il tetto
  const room = new Room('v139'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const nm = room.spawnMonster('darkmage', pl.x + 300, pl.y, { scaling: Waves.scaling(4, 1) });
  assert(nm && nm.type === 'darkmage', 'il Negromante si genera');
  const dt = 1 / C.TICK_RATE; for (let i = 0; i < C.TICK_RATE * 30; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN con Negromante + evocati in campo');
  const minions = room.monsters.filter(m => m.owner === nm.eid && !m.dead);
  assert(minions.length <= (dm.minionCap || 4), 'gli zombi minori evocati non superano il tetto (' + minions.length + '<=' + dm.minionCap + ')');
  assert(minions.every(m => m.type === 'zombie_mini'), 'gli evocati sono Zombi Minori');
  const snap = room.snapshot(); assert(snap.mon.every(mm => isFinite(mm.x)), 'snapshot valido');
  // i boss continuano a evocare skeleton (compat)
  assert(Mon.BOSSES.orc_warlord.summon === 'skeleton', 'i boss evocano ancora lo skeleton');
  ok('novita v1.39 verificate');
}
function testV142() {
  console.log('\n[TEST 19] Novita v1.42 — Bruto delle Caverne (tank PUPPET, slam ad area)');
  const Mon = require('../shared/monsters.js');
  const br = Mon.MONSTERS.cave_brute;
  assert(!!br, 'il Bruto delle Caverne esiste nel roster');
  assert(br && br.sheet === 'troll', 'Troll = render SPRITE-SHEET (sheet=troll)'); // v1.47 — sostituito il puppet con lo sprite sheet animato
  assert(br && br.ai === 'brute' && br.atk === 'melee', 'Bruto ha IA brute (slam) da mischia');
  assert(br && br.hp >= 180 && br.speed <= 80 && br.dmg >= 20, 'Bruto e un TANK: molti PV, lento, danno alto');
  assert(br && br.slamRadius > 0, 'Bruto ha un raggio di SLAM ad area');
  // v1.79.2 — IL TROLL E' USCITO DAL GIOCO. La definizione resta (sprite-sheet, slam, IA) e si puo'
  // ancora generare a mano — i controlli qui sotto lo fanno — ma non e' nel bestiario ne' in nessuna ondata.
  assert(!Mon.ORDER.includes('cave_brute'), 'cave_brute non e piu nell ORDER del bestiario');
  for (let w = 1; w <= 20; w++) assert(!Waves.poolForWave(w).some(x => x.id === 'cave_brute'), 'e non compare in nessuna ondata (ondata ' + w + ')');
  // si genera e lo slam colpisce ad area emettendo l'evento con eid (per l'animazione client)
  const room = new Room('v142'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const m = room.spawnMonster('cave_brute', pl.x + 40, pl.y, { scaling: Waves.scaling(4, 1) });
  assert(m && m.type === 'cave_brute' && isFinite(m.hp) && m.hp > 0, 'il Bruto si genera correttamente (scalato)');
  // v1.43 — SLAM a due tempi: a bruciapelo (in vista) alza le braccia (slam_wind con eid) → poi schianta ad area.
  pl.x = m.x + 24; pl.y = m.y; pl.buffs = {}; pl.hp = 500; const hp0 = pl.hp; m.atkT = 0; room.events.length = 0;
  const dt = 1 / C.TICK_RATE;
  // primo tick: parte il telegrafo (alza le braccia) con l'eid per animare il puppet
  room.update(dt);
  const wind = room.events.find(e => e.t === 'slam_wind');
  assert(wind && wind.e === m.eid, 'il Bruto ALZA le braccia (slam_wind con eid) quando ti vede a tiro');
  // lascia completare il wind-up: lo schianto deve infliggere danni ad area e mandare l\'evento slam (FX)
  for (let i = 0; i < 30; i++) { room.update(dt); if (pl.hp < hp0) break; }
  assert(room.events.some(e => e.t === 'slam') || pl.hp < hp0, 'lo schianto emette l\'onda d\'urto (slam)');
  assert(pl.hp < hp0, 'lo schianto del Bruto infligge danni ad area al giocatore vicino');
  // stabilita: simula col Bruto in campo, nessun NaN
  for (let i = 0; i < C.TICK_RATE * 6; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN simulando col Bruto in campo');
  ok('novita v1.42 verificate');
}
function testV143() {
  console.log('\n[TEST 20] Novita v1.43 — Bruto (walk lumbering + slam overhead), vagabondaggio & anti-incastro');
  const Mon = require('../shared/monsters.js');
  const br = Mon.MONSTERS.cave_brute;
  assert(br && br.slamWind > 0 && br.sightRange > 0, 'il Bruto ha wind-up (slamWind) e un campo visivo (sightRange)');
  // VAGABONDAGGIO: uno zombie che NON vede il giocatore (troppo lontano) deve muoversi comunque (roaming), non restare fermo.
  const room = new Room('v143w'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const far = room.map.spawn;
  const z = room.spawnMonster('skeleton', far.x + 40, far.y + 40, { scaling: Waves.scaling(2, 1) });
  pl.x = far.x + 2000; pl.y = far.y + 2000; // porta il giocatore lontanissimo → fuori vista
  z.seeT = 0; const zx0 = z.x, zy0 = z.y; let roamed = 0; const dt = 1 / C.TICK_RATE;
  for (let i = 0; i < C.TICK_RATE * 5; i++) { room.update(dt); roamed = Math.max(roamed, Math.hypot(z.x - zx0, z.y - zy0)); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN durante il vagabondaggio');
  assert(roamed > 20, 'lo zombie VAGA per la mappa quando non vede il giocatore (spostato ' + roamed.toFixed(0) + 'px)');
  assert(!room.isWallAt(z.x, z.y), 'lo zombie che vaga non finisce dentro un muro');
  // ANTI-INCASTRO (tutti, boss compresi): dopo una simulazione stress nessun mostro resta dentro un muro.
  const r2 = new Room('v143s'); for (let i = 0; i < 3; i++) r2.addPlayer('p' + i, { send() {} }, 'P' + i, Heroes.ORDER[i % 3]); r2.startGame();
  for (const id of ['skeleton', 'darkmage', 'cave_brute', 'orc_warlord', 'lich_king', 'mega_dragon']) { const pos = r2.randomSpawnPos(); r2.spawnMonster(id, pos.x, pos.y, { scaling: Waves.scaling(5, 3) }); }
  for (let i = 0; i < C.TICK_RATE * 20; i++) { for (const p of r2.players.values()) r2.setInput(p.id, bot(r2, p)); r2.update(dt); if (hasNaN(r2)) break; }
  assert(hasNaN(r2) === null, 'nessun NaN nello stress con boss in campo');
  // v1.61 — i nemici con def.phasing (Fuoco Fatuo) stanno DENTRO i muri per design: esclusi dal conteggio.
  const stuck = r2.monsters.filter(m => !m.dead && !m.def.phasing && r2.isWallAt(m.x, m.y)).length;
  assert(stuck === 0, 'nessun mostro/boss resta dentro un muro (incastrati: ' + stuck + ')');
  ok('novita v1.43 verificate');
}
function testV145() {
  console.log('\n[TEST 21] Novita v1.46 — Melma Corrosiva TOP-DOWN (pozza fluo che striscia) + SALTA/sputa acido');
  const Mon = require('../shared/monsters.js');
  const sl = Mon.MONSTERS.slime;
  assert(!!sl, 'la Melma Corrosiva esiste nel roster');
  assert(sl && sl.topdown === true && !sl.front, 'Melma = render TOP-DOWN (niente billboard)');
  assert(sl && sl.puppet === true && sl.bubbles === true, 'la Melma usa asset puppet (pozza) + bolle acide');
  assert(sl && sl.ai === 'blob' && sl.atk === 'ranged', 'la Melma usa IA blob (striscia + sputo acido a distanza ravvicinata)');
  assert(sl && sl.speed <= 60, 'la Melma è LENTA (' + sl.speed + ')');
  assert(sl && sl.acidMult > 1 && sl.acidCount >= 2 && sl.projSpeed > 0, 'la Melma sputa bolle d\'acido ad ALTO danno (mult ' + sl.acidMult + ' x' + sl.acidCount + ')');
  assert(Mon.ORDER.includes('slime'), 'slime presente nell\'ORDER del bestiario');
  const p2 = Waves.poolForWave(2).map(x => x.id);
  assert(p2.includes('slime') && p2.includes('skeleton'), 'Melma nel pool dall ondata 2, insieme allo sciame base');
  // simulazione: a distanza ravvicinata deve SPUTARE proiettili d'acido OSTILI (danno elevato) ed emettere 'acid'
  const room = new Room('v145'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const sp145 = losSpot(room, pl, 90);
  const m = room.spawnMonster('slime', sp145.x, sp145.y, { scaling: Waves.scaling(1, 1) });
  assert(m && m.type === 'slime' && isFinite(m.hp) && m.hp > 0, 'la Melma si genera correttamente');
  pl.x = m.x + 80; pl.y = m.y; m.atkT = 0; room.bullets.length = 0; room.events.length = 0;
  const dt = 1 / C.TICK_RATE; let sawAcid = false, acidBullets = 0;
  for (let i = 0; i < 8; i++) { room.update(dt); if (room.events.some(e => e.t === 'acid')) sawAcid = true; acidBullets = room.bullets.filter(b => b.hostile).length; if (acidBullets > 0) break; }
  assert(sawAcid, 'la Melma emette l\'evento acid (salta e sputa) quando sei vicino');
  assert(acidBullets >= 2, 'lo sputo genera più bolle d\'acido ostili (' + acidBullets + ')');
  const hostile = room.bullets.find(b => b.hostile);
  assert(hostile && hostile.dmg >= Math.round(m.dmg * 1.5), 'le bolle d\'acido fanno MOLTI danni (' + (hostile ? hostile.dmg : 0) + ' >= ' + Math.round(m.dmg * 1.5) + ')');
  // stabilità: nessun NaN con la Melma in campo
  for (let i = 0; i < C.TICK_RATE * 6; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN simulando con la Melma in campo');
  ok('novita v1.45 verificate');
}
function testV149() {
  console.log('\n[TEST 23] Novita v1.49 - Beholder (occhio): Sguardo debilitante + eyestalks che ruotano');
  const Mon = require('../shared/monsters.js');
  const oc = Mon.MONSTERS.occhio;
  assert(!!oc, 'il Beholder (occhio) esiste nel roster');
  assert(oc && oc.ai === 'gazer' && oc.atk === 'gaze', 'Beholder usa IA gazer (Sguardo, niente proiettili)');
  assert(oc && oc.dipinto === 'viola' && !oc.puppet, 'v1.79.2 — il Beholder e DIPINTO a codice, non piu una marionetta raster');
  assert(oc && oc.gazeFov > 0 && oc.gazeRange > 0, 'ha un campo visivo (gazeFov + gazeRange)');
  assert(oc && oc.gazeCycle > 0, 'le eyestalks RUOTANO: alterna il tipo di sguardo (gazeCycle)');
  assert(Mon.ORDER.indexOf('occhio') >= 0, 'occhio presente nell ORDER del bestiario');
  assert(Waves.poolForWave(10).some(x => x.id === 'occhio'), 'Beholder nel pool dall ondata 10 (col tetto di presenze)');
  const dt = 1 / C.TICK_RATE;
  const room = new Room('v149'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  room.pending = 0; room.waveList = []; pl.hp = 9999; pl.maxHp = 9999;
  const sp = room.map.spawn;
  const m = room.spawnMonster('occhio', sp.x, sp.y, { scaling: Waves.scaling(3, 1) });
  assert(m && m.type === 'occhio' && ['weaken', 'slow', 'sunder'].indexOf(m.gazeKind) >= 0, 'lo spawn assegna un tipo di sguardo');
  pl.x = sp.x + 60; pl.y = sp.y; pl.buffs = {}; m.facing = 0; m.gazeTick = 0;
  let gazed = false;
  for (let i = 0; i < C.TICK_RATE * 3 && !gazed; i++) { room.update(dt); if (pl.buffs.gz_weaken > 0 || pl.buffs.gz_slow > 0 || pl.buffs.gz_sunder > 0) gazed = true; }
  assert(gazed, 'il Beholder debilita il giocatore nel suo campo visivo (Sguardo)');
  const k0 = m.gazeKind; let changed = false;
  for (let i = 0; i < C.TICK_RATE * (oc.gazeCycle + 1) && !changed; i++) { room.update(dt); if (m.gazeKind !== k0) changed = true; }
  assert(changed, 'le eyestalks ruotano: il tipo di sguardo cambia nel tempo');
  const snap = room.snapshot(); const mo = snap.mon.find(x => x.t === 'occhio');
  assert(mo && mo.gk, 'lo snapshot espone il tipo di sguardo (gk)');
  for (let i = 0; i < C.TICK_RATE * 5; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN col Beholder in campo');
  ok('novita v1.49 verificate');
}
function testV151() {
  console.log('\n[TEST 25] Novita v1.51 — 1 di 3 poteri, +10 boon, negozio XP severo, Emporio nascosto');
  const Loot = require('../shared/loot.js');
  const dt = 1 / C.TICK_RATE;
  // --- 1) si sceglie 1 di 3 ---
  assert(Loot.BOON_CHOICES === 3, 'la costante di offerta e 3 abilita');
  // --- 2) i poteri storici sopravvissuti al rifacimento, tutti applicabili ---
  // v2.20.0 — gli id sono cambiati: ogni carta appartiene a UNA classe e se lo porta nel nome.
  const NEW = ['arc_lungo', 'mae_danza', 'bar_deflagrazione', 'ass_grazia', 'pal_ira'];
  assert(NEW.every(id => !!Loot.BOON_BY_ID[id]), 'i poteri storici rimasti sono nel catalogo');
  assert(Loot.BOONS.length === 84, 'catalogo a 84 carte: ' + Loot.BOONS.length);
  assert(Loot.BOONS.every(b => { return b.max >= 1 && typeof b.apply === 'function' && b.desc && b.icon && b.via && b.hero !== '*'; }), 'ogni carta ha icona, descrizione, via, classe e apply');
  assert(new Set(Loot.BOONS.map(b => b.id)).size === Loot.BOONS.length, 'nessun id di potere duplicato');
  // --- 3) il negozio XP e ora una scelta, non un rubinetto ---
  assert(Loot.STAT_MAX_LEVEL === 12, 'tetto di 12 livelli per statistica (v1.66)');
  const fullTree = Loot.XP_STATS.reduce((a, s) => { let t = 0; for (let n = 0; n < Loot.STAT_MAX_LEVEL; n++) t += Loot.statCost(s.base, n); return a + t; }, 0);
  assert(fullTree > 15000, 'massimizzare tutto l albero costa oltre 15.000 XP (prima 3.526): ' + fullTree);
  // --- 4) prove a runtime ---
  const msgs = [];
  const room = new Room('v151');
  const pl = room.addPlayer('b', { send(s) { try { msgs.push(JSON.parse(s)); } catch (e) { } } }, 'B', 'arciere');
  room.startGame();
  pl.scaglioniDovuti = ['rare'];
  room.offerBoon(pl);
  assert(pl.boonOffer && pl.boonOffer.length === 3, 'lo scaglione offre 3 abilita, una sola selezionabile');
  // tetto: comprando all infinito ci si ferma a 8
  room.phase = C.PHASE_SHOP; pl.points = 9999999;
  for (let i = 0; i < 25; i++) room.buyStat('b', 'st_for');
  assert((pl.buys.st_for || 0) === Loot.STAT_MAX_LEVEL, 'la statistica si ferma al tetto di 8 livelli (arrivata a ' + (pl.buys.st_for || 0) + ')');
  // Emporio NASCOSTO: entrando nel negozio non arriva piu l offerta di equipaggiamento
  msgs.length = 0; room.enterShop();
  assert(!msgs.some(m => m.t === C.MSG.OFFER_GEAR), 'l Emporio a monete non viene piu offerto (nascosto in v1.51)');
  assert(msgs.some(m => m.t === C.MSG.OFFER_SHOP), 'il negozio XP viene ancora offerto');
  assert(msgs.some(m => m.t === C.MSG.BOONS), 'il client riceve l elenco dei poteri attivi (barra in basso)');
  // COLPO DI GRAZIA: sotto soglia il nemico muore, ma il boss no
  pl.boon.execute = 1;
  const m1 = room.spawnMonster('skeleton', pl.x + 200, pl.y, { scaling: Waves.scaling(3, 1) });
  m1.hp = Math.round(m1.maxHp * 0.05) + 1;   // v2.20.0 — la soglia del Colpo di Grazia e' scesa al 10%
  room.damageMonster(m1, 1, pl.x, pl.y, 0, pl);
  assert(m1.dead, 'il Colpo di Grazia esegue il nemico sotto soglia');
  // ULTIMA OCCASIONE: consuma una carica invece di far cadere
  pl.defianceLeft = 1; pl.hp = 1; pl.down = false; pl.dead = false;
  room.downPlayer(pl);
  assert(!pl.down && pl.hp > 1 && pl.defianceLeft === 0, 'Ultima Occasione rimette in piedi e consuma la carica');
  // EGIDA OSTINATA: il primo colpo e annullato, il secondo no
  pl.boon.aegis = 1; pl.aegisT = 0; pl.buffs = {}; pl.hp = 500;
  room.damagePlayer(pl, 60, pl.x + 10, pl.y, 0);
  assert(pl.hp === 500 && pl.aegisT > 0, 'l Egida Ostinata annulla il colpo e va in ricarica');
  room.damagePlayer(pl, 60, pl.x + 10, pl.y, 0);
  assert(pl.hp < 500, 'il colpo successivo passa (egida in ricarica)');
  // nessun NaN con i nuovi poteri tutti attivi
  const room2 = new Room('v151b'); const p2 = room2.addPlayer('c', { send() { } }, 'C', 'arciere'); room2.startGame();
  // v2.20.0 — non piu' «i sei storici»: TUTTE le carte dell'arciere addosso insieme.
  for (const b of Loot.boonsPerClasse('arciere')) { b.apply(p2); p2.boonsOwned[b.id] = 1; p2.cardOn[b.id] = 1; }
  for (let i = 0; i < C.TICK_RATE * 25; i++) { room2.setInput('c', bot(room2, p2)); room2.update(dt); if (hasNaN(room2)) break; }
  assert(hasNaN(room2) === null, 'nessun NaN con tutte le carte dell arciere addosso');
  ok('novita v1.51 verificate');
}
function testV150() {
  console.log('\n[TEST 24] Novita v1.50 — curva di introduzione dei nemici + elite tarati sui tank');
  const Mon = require('../shared/monsters.js');
  const at = w => Waves.poolForWave(w).map(x => x.id);
  // 1) la RAMPA: un archetipo nuovo ogni 1-2 ondate, non tutti dal primo stage
  const p1 = at(1);
  assert(p1.length === 1 && p1[0] === 'skeleton', 'ondata 1: solo lo sciame base (Zombie Putrido)');
  assert(!at(1).includes('slime') && at(2).includes('slime'), 'Melma Corrosiva introdotta all ondata 2');
  assert(!at(2).includes('darkmage') && at(3).includes('darkmage'), 'Negromante introdotto all ondata 3');
  // v1.79.2 — tolto il Troll, gli archetipi dietro di lui si sono fatti avanti di un'ondata.
  assert(!at(3).includes('spore_fungus') && at(4).includes('spore_fungus'), 'Fungo introdotto all ondata 4');
  assert(!at(4).includes('bat_swarm') && at(5).includes('bat_swarm'), 'Nugolo di Pipistrelli introdotto all ondata 5');
  assert(!at(6).includes('wisp') && at(7).includes('wisp'), 'Fuoco Fatuo introdotto all ondata 7');
  assert(!at(7).includes('occhio') && at(8).includes('occhio'), 'Beholder introdotto all ondata 8 (v1.81: era la 9)');
  // v2.22 — i due nemici senza gambe. La Lama sta PRESTO di proposito: e' il primo nemico che
  // telegrafa il colpo, quindi deve arrivare quando c'e' ancora da imparare a schivare.
  assert(!at(1).includes('lama') && at(2).includes('lama'), 'Lama Errante introdotta all ondata 2');
  assert(!at(5).includes('cubo') && at(6).includes('cubo'), 'Cubo Gelatinoso introdotto all ondata 6');
  assert(!at(14).includes('padrone') && at(15).includes('padrone'), 'Il Padrone introdotto all ondata 15');
  // v1.81 — LA RAMPA NON HA BUCHI e non arriva tardi: ogni ondata dalla 1 alla 12 aggiunge almeno un
  // archetipo che prima non c'era, e alla 12 il bestiario e' tutto in campo. Dalla 8 in poi qualche
  // ondata ne aggiunge due (i tre Ragni si intrecciano ai tre Beholder), quindi non si conta piu' "un
  // tipo per ondata": si conta che il pool CRESCA sempre, e che si chiuda entro la dodicesima.
  for (let w = 2; w <= 12; w++) assert(at(w).length > at(w - 1).length,
    'ondata ' + w + ': porta almeno un archetipo che prima non c era (' + at(w - 1).length + ' -> ' + at(w).length + ')');
  assert(at(15).length === at(16).length && at(16).length === at(19).length,
    'alla quindicesima il bestiario e tutto in campo (' + at(15).length + ' archetipi) e li resta');
  assert(at(15).length > at(12).length,
    'e fra la dodicesima e la quindicesima arriva ancora qualcosa: era il buco della v2.22');
  let mono = true; for (let w = 1; w < 20; w++) { const a = at(w), b = at(w + 1); if (!a.every(id => b.includes(id))) mono = false; }
  assert(mono, 'rampa monotona: nessun archetipo sparisce al crescere delle ondate');
  // 2) ELITE: i nemici gia robusti non devono esplodere di PV
  const brute = Mon.MONSTERS.cave_brute;
  assert(brute.eliteHp && brute.eliteHp < 2.4, 'il Troll ha un moltiplicatore elite ridotto (def.eliteHp)');
  const mk = (id, w, elite) => { const m = { def: Mon.MONSTERS[id] }; Waves.applyScaling(m, Waves.scaling(w, 1), elite); return m; };
  const trollE = mk('cave_brute', 4, true);
  assert(trollE.maxHp < 600, 'Troll elite all ondata 4 sotto i 600 PV (prima ~845): maxHp=' + trollE.maxHp);
  const zomE = mk('skeleton', 4, true), zom = mk('skeleton', 4, false);
  assert(Math.abs(zomE.maxHp / zom.maxHp - 2.4) < 0.05, 'gli altri nemici mantengono il 2.4x degli elite');
  // 3) nessuna regressione a runtime con la nuova curva
  const dt = 1 / C.TICK_RATE;
  const room = new Room('v150'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  for (let i = 0; i < C.TICK_RATE * 20; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN con la nuova curva del pool');
  ok('novita v1.50 verificate');
}
function testV152() {
  console.log('\n[TEST 26] Novita v1.52 — mappa MERCATO ogni 3 ondate + fabbro dell\'equipaggiamento');
  const dt = 1 / C.TICK_RATE, T = C.TILE;
  const room = new Room('v152'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  // v1.53 — niente piu' cadenza fissa: al mercato ci si va scegliendolo dal menu di pausa
  room.wave = 3; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');   // v1.79 — il villaggio e una sezione del menu
  assert(room.phase === C.PHASE_MARKET, 'dopo l\'ondata 3 si entra nel MERCATO');
  assert(room.wave === 3, 'il mercato e\' INTERSTIZIALE: non consuma un numero d\'ondata');
  assert(room.monsters.length === 0 && room.pending === 0, 'nel mercato non ci sono nemici');
  assert(!room.merchant && !room.darkMerchant, 'niente Mercante Errante nel mercato: resta un incontro delle ondate');
  assert(room.crates.length === 0, 'niente casse nel mercato (il 30% sarebbe una cassa-mima, cioe\' un nemico)');
  assert(!!room.gearMerchant, 'il fabbro dell\'equipaggiamento e\' presente');
  assert(!!room.map.exit, 'la mappa del mercato ha un portale EXIT');
  // v1.75 — al centro adesso c'e' la PIAZZA col falo': il fabbro sta nella sua fucina, a un corridoio da li'.
  const cxw = (room.map.w / 2) * T, cyw = (room.map.h / 2) * T;
  // v2.0 — al centro del villaggio adesso c'e' IL PORTALE, non il falo': il falo' e' uno dei due fuochi
  // della piazza (l'altro e' il pozzo, che fuoco non e'), e sta di lato perche' il centro serve all'uscita.
  const pw = { x: room.map.portale.x * T + T / 2, y: room.map.portale.y * T + T / 2 };
  // v2.6 — IL PORTALE NON STA PIU' AL CENTRO. Stava in mezzo alla piazza, e una piazza con un buco viola
  // nel mezzo non e' una piazza: e' una sala del portale con delle case attorno. Adesso e' dentro la CASA
  // DEL PORTALE, la prima della fila di ponente, con due guardie sulla soglia. Quello che il test deve
  // pretendere non e' piu' "sta al centro" ma "sta DENTRO la sua stanza", che e' la cosa che conta.
  { const V = MapGen.VILLAGE, st = V.rooms.find(r => r.kind === 'portale');
    assert(!!st, 'il villaggio ha una casa del portale');
    assert(room.map.portale.x >= st.x0 && room.map.portale.x <= st.x1 + 1 &&
           room.map.portale.y >= st.y0 && room.map.portale.y <= st.y1 + 1, 'e la faglia sta dentro quella casa');
    assert(MU.dist(pw.x, pw.y, cxw, cyw) > T * 8, 'e quindi NON e piu al centro del villaggio');
    const gd = room.map.village.extras.filter(e => e.kind === 'guardia');
    assert(gd.length === 2, 'due guardie, non una e non tre (ne ho ' + gd.length + ')');
    const soglia = { x: st.porta[0] * T + T / 2, y: st.porta[1] * T + T / 2 };
    for (const q of gd) assert(MU.dist(q.x, q.y, soglia.x, soglia.y) < T * 3.5, 'e stanno sulla soglia, non sparse per il paese');
  }
  assert(MU.dist(room.map.village.fire.x, room.map.village.fire.y, cxw, cyw) < T * 6, 'il falo invece resta in mezzo alla piazza, che e il centro del paese');
  assert(MU.dist(room.gearMerchant.x, room.gearMerchant.y, pw.x, pw.y) < T * 24, 'la fucina si raggiunge dalla piazza');
  // acquisto: serve essere vicini al banco GIUSTO
  // v2.19 — «il banco giusto» e' la novita': il giocatore qui e' un ARCIERE, e il cuoio lo vende
  // l'arciera, non il fabbro. Prima bastava essere vicini all'unico negozio; adesso il test dice a
  // quale bottega va, ed e' esattamente la regola che le tre botteghe introducono.
  p.coins = 100000; p.x = room.map.spawn.x; p.y = room.map.spawn.y;
  // v2.12 — i pezzi si chiedono al catalogo per GRADO e CARATTERE: con 104 pezzi gli id scritti a mano
  // sono una trappola, e questo test non parla di nomi, parla di distanza dal banco.
  const GearV = require('../shared/gear.js');
  const partenzaV = GearV.startingGear('arciere');
  const cuoio = GearV.itemsOfRank('arciere', 'armor', 2, 'pesante').find(i => i.carattere === 'pesante');
  const bancoArc = (room.gearMerchants || []).find(b => b.cat === 'ladro');
  assert(!!bancoArc, 'il villaggio ha la bottega dell arciera');
  if (MU.dist(p.x, p.y, bancoArc.x, bancoArc.y) > C.MARKET_MERCH_RANGE + 12) {
    room.buyGear('b', cuoio.id); assert(!p.owned[cuoio.id], 'lontano dal banco non si compra');
  }
  // e nemmeno al banco SBAGLIATO: il fabbro non vende cuoio da arciere
  alBanco(room, p, 'guerriero');
  room.buyGear('b', cuoio.id); assert(!p.owned[cuoio.id], 'il fabbro non vende la roba dell arciera');
  alBancoDi(room, p, cuoio);
  // v2.18.1 — l'acquisto riempie l'INVENTARIO, non la casella: e' li' che si guarda se e andato a buon fine.
  room.buyGear('b', cuoio.id); assert(!!p.owned[cuoio.id], 'al banco dell arciera l\'acquisto va a buon fine');
  // v2.19 — `_nearGear` non e' piu' un si'/no: e' il CATALOGO del banco davanti a cui sei.
  p._nearGear = null; room.updateGearMerchant(); assert(p._nearGear === 'ladro', 'avvicinandosi si apre il pannello di QUELLA bottega');
  alBanco(room, p, 'guerriero'); room.updateGearMerchant(); assert(p._nearGear === 'guerriero', 'e cambiando bottega cambia il catalogo');
  p.x = bancoArc.x + 400; p.y = bancoArc.y + 400; room.updateGearMerchant(); assert(!p._nearGear, 'allontanandosi il pannello si chiude');
  // uscita: CO-OP, il primo che entra nel portale porta tutti avanti
  p.x = room.map.exit.x * T + T / 2; p.y = room.map.exit.y * T + T / 2;
  const mapBefore = room.map;
  const ondataPrima = room.wave;
  room._checkMarketExit();
  // v1.79 — IL PORTALE DEL VILLAGGIO RIPORTA AL MENU, non all'ondata: il villaggio e' una sezione del
  // menu di fine ondata, e da una sezione si torna indietro.
  assert(room.wave === ondataPrima, 'uscire dal villaggio non fa avanzare l ondata');
  assert(room.phase === C.PHASE_SHOP, 'si torna al menu di fine ondata');
  assert(room._forceNewMap === true, 'ma la mappa e segnata come da rigenerare: non si combattera nella stanza del fabbro');
  assert(!room.gearMerchant, 'il fabbro sparisce fuori dal mercato');
  // dal menu, il pulsante centrale porta sempre e solo alla mappa successiva
  room.wave = 4; room.phase = C.PHASE_SHOP; room._afterShop();
  assert(room.phase !== C.PHASE_MARKET && room.wave === 5, 'dal menu si va all ondata successiva');
  assert(room.map !== mapBefore, 'e la mappa e nuova');
  // essendo interstiziale, il mercato non consuma mai un'ondata: nemmeno quelle boss
  room.wave = 15; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');   // v1.79 — il villaggio e una sezione del menu
  assert(room.phase === C.PHASE_MARKET && room.wave === 15, 'il mercato SEGUE l\'ondata boss, non la sostituisce');
  // nessun NaN girando nel mercato
  const r2 = new Room('v152b'); const p2 = r2.addPlayer('b', { send() {} }, 'B', 'arciere'); r2.startGame();
  r2.wave = 3; r2.phase = C.PHASE_SHOP; r2.shopReady('b', 'market'); r2._afterShop();
  for (let i = 0; i < C.TICK_RATE * 5; i++) { r2.setInput('b', bot(r2, p2)); r2.update(dt); if (hasNaN(r2)) break; }
  assert(hasNaN(r2) === null, 'nessun NaN nel mercato');
  ok('novita v1.52 verificate');
}
function testV153() {
  console.log('\n[TEST 27] Novita v1.53/1.55 — mercato centrale, destinazioni nel menu di pausa, tabella dei costi XP');
  const T = C.TILE;
  const room = new Room('v153'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();

  // --- 1) il MERCATO si sceglie, non capita ---
  room.wave = 2; room.phase = C.PHASE_SHOP; room._afterShop();
  assert(room.phase !== C.PHASE_MARKET && room.wave === 3, 'senza scelta si va all ondata successiva');
  room.wave = 2; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');   // v1.79 — il villaggio e una sezione del menu
  assert(room.phase === C.PHASE_MARKET, 'scegliendo "market" si entra dal fabbro, a qualunque ondata');
  assert(room.wave === 2, 'la sosta non consuma un numero d ondata');

  // --- 2) fabbro E portale vicini al punto di atterraggio ---
  const sx = room.map.spawn.x, sy = room.map.spawn.y;
  const ex = room.map.exit.x * T + T / 2, ey = room.map.exit.y * T + T / 2;
  const dSmith = MU.dist(sx, sy, room.gearMerchant.x, room.gearMerchant.y) / T;
  const dExit = MU.dist(sx, sy, ex, ey) / T;
  // v1.75 — il fabbro non e' piu' a due passi dallo spawn: si attraversa la piazza ed si entra in fucina.
  // v2.0 — il villaggio e' 56x40 invece di 34x26: le distanze sono cresciute con lui. Il limite qui non
  // e' un gusto, e' il tempo: 22 tile sono ~5 secondi di cammino, e per una sosta e' il massimo sopportabile.
  assert(dSmith <= 24, 'il fabbro e a una traversata dallo spawn (' + dSmith.toFixed(1) + ' tile)');
  // v2.6 — il portale non e' piu' sotto i piedi: sta nella casa delle guardie, in fondo alla via di
  // ponente. Il limite non e' un gusto, e' TEMPO: 20 tessere sono meno di cinque secondi di cammino, e
  // per una sosta e' quello che si puo' chiedere. Sotto le 16 ci si tornerebbe senza attraversare niente,
  // e allora tanto valeva lasciarlo in mezzo alla piazza.
  assert(dExit <= 20, 'il portale e a pochi secondi dallo spawn (' + dExit.toFixed(1) + ' tile)');
  assert(dExit >= 8, 'ma non ci si atterra sopra (' + dExit.toFixed(1) + ' tile)');
  // v1.57 — si compare dentro la sala e si esce dal varco a sud: il portale e vicino, i banchi attorno
  // la tile EXIT e' stata spostata NELLA GRIGLIA (il client disegna il portale da li)
  // v2.0 — NON C'E' PIU' UNA TESSERA T_EXIT. L'uscita del villaggio e' la FAGLIA, lo stesso portale che
  // si apre quando hai ripulito un'ondata: la pianta ne dichiara solo il posto, e il resto lo fa il server.
  let nExit = 0;
  for (let i = 0; i < room.map.grid.length; i++) if (room.map.grid[i] === C.T_EXIT) nExit++;
  assert(nExit === 0, 'nel villaggio non c e nessuna tessera EXIT: al suo posto c e il portale (' + nExit + ')');
  assert(room.map.portale.x === room.map.exit.x && room.map.portale.y === room.map.exit.y, 'e portale ed exit sono lo stesso punto');
  assert(!!room.faglia, 'entrando in sosta il server apre la faglia');
  const pwx = room.map.portale.x * T + T / 2, pwy = room.map.portale.y * T + T / 2;
  assert(Math.abs(room.faglia.x - pwx) < 2 && Math.abs(room.faglia.y - pwy) < 2, 'e la apre nel centro della piazza');
  assert(room.map.grid[Math.round(room.gearMerchant.y / T - 0.5) * room.map.w + Math.round(room.gearMerchant.x / T - 0.5)] !== C.T_WALL, 'il fabbro non e dentro un muro');

  // --- 3) v1.79 — LA DESTINAZIONE NON SI SCEGLIE PIU'. Il villaggio e' una sezione del menu e ci si
  // entra tutti insieme; il pulsante centrale e' il "pronto" per la mappa successiva.
  const r2 = new Room('v153b'); r2.addPlayer('a', { send() {} }, 'A', 'arciere'); r2.addPlayer('c', { send() {} }, 'C', 'arciere'); r2.startGame();
  r2.wave = 4; r2.phase = C.PHASE_SHOP;
  r2.shopReady('a'); assert(r2.phase === C.PHASE_SHOP, 'un solo pronto non fa partire niente');
  r2.vaiAlVillaggio('a');
  assert(r2.phase === C.PHASE_MARKET, 'chiunque prema Villaggio ci porta tutta la stanza');
  const T3 = C.TILE; const pa = r2.players.get('a');
  pa.x = r2.map.exit.x * T3 + T3 / 2; pa.y = r2.map.exit.y * T3 + T3 / 2; r2._checkMarketExit();
  assert(r2.phase === C.PHASE_SHOP && r2.wave === 4, 'e uscendo si torna al menu, sulla stessa ondata');

  // --- 4) curva XP: apertura piu dolce, coda molto piu dura ---
  const base = 10;
  // v1.55 — rispetto alla v1.54: primi 6 livelli x3, ultimi 2 x2. Il reddito reale misurato in partita
  // (~240 XP alla sola ondata 2) e' circa 2.4x quello che stimava il vecchio modello senza combo.
  // v1.66 — la curva e' stata rifatta su una regola sola, dichiarata dal committente: con l'XP di UNA run
  // (nell'ordine dei 18.000, misurato su partita vera) si deve poter cappare ESATTAMENTE una statistica.
  // Il confronto con la tabella v1.54 non ha piu' senso: quella aveva 8 livelli, questa ne ha 12.
  assert(Array.isArray(Loot.STAT_COST_STEPS) && Loot.STAT_COST_STEPS.length === Loot.STAT_MAX_LEVEL, 'la tabella dei costi copre tutti i 12 livelli');
  let one = 0; for (let n = 0; n < Loot.STAT_MAX_LEVEL; n++) one += Loot.statCost(base, n);
  assert(one >= 17000 && one <= 19000, 'cappare UNA statistica costa quanto una run intera (' + one + ')');
  const tree = Loot.XP_STATS.reduce((a, s) => { let t = 0; for (let n = 0; n < Loot.STAT_MAX_LEVEL; n++) t += Loot.statCost(s.base, n); return a + t; }, 0);
  assert(tree >= one * 3.8, 'l albero completo resta fuori portata: ' + tree + ' XP, cioe piu di tre run');
  // nessun gradino piatto: il 7 livello della vecchia tabella costava solo il 13% piu del 6 e si sentiva
  let minStep = Infinity; for (let n = 1; n < Loot.STAT_MAX_LEVEL; n++) minStep = Math.min(minStep, Loot.statCost(base, n) / Loot.statCost(base, n - 1));
  assert(minStep >= 1.4, 'ogni livello costa almeno il 40% piu del precedente (minimo ' + Math.round((minStep - 1) * 100) + '%)');
  // la curva resta monotona: nessun livello costa meno del precedente
  let mono = true; for (let n = 1; n < Loot.STAT_MAX_LEVEL; n++) if (Loot.statCost(base, n) <= Loot.statCost(base, n - 1)) mono = false;
  assert(mono, 'la curva dei costi e monotona crescente');
  ok('novita v1.53 verificate');
}
function testV157() {
  // v1.75 — la SALA unica e' diventata un VILLAGGIO A MICRO-STANZE: una piazza col falo' e cinque
  // stanze attaccate da corridoi corti, una per mestiere. Il test verifica la pianta, non i mobili.
  console.log('\n[TEST 28] Il villaggio — piazza col falo, cinque stanze scavate, tutto raggiungibile');
  const MapGen = require('../shared/mapgen.js');
  const T = C.TILE, m = MapGen.generateMarket(4242), V = MapGen.VILLAGE;
  const at = (x, y) => m.grid[y * m.w + x];
  const isFloor = (x, y) => at(x, y) !== C.T_WALL;
  const dentro = (x, y, r) => x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1;

  assert(m.w === V.w && m.h === V.h, 'la mappa e ' + m.w + 'x' + m.h + ' tile');
  // v2.0 — non piu' cinque stanze attorno a una piazza: un VILLAGGIO. Cinque botteghe e sette case.
  // v2.19 — SETTE botteghe e CINQUE case: due abitazioni sono diventate l'archeria e la bottega
  // arcana. Il conto qui non e' un dettaglio di contabilita' — e' cio' che impedisce che un domani
  // qualcuno trasformi in negozio anche le ultime case senza accorgersene.
  const botteghe = V.rooms.filter(r => r.kind === 'bottega'), case_ = V.rooms.filter(r => r.kind === 'casa');
  assert(botteghe.length === 7, 'sette botteghe, una per mestiere (' + botteghe.length + ')');
  assert(case_.length >= 5, 'e le case degli abitanti (' + case_.length + ')');
  assert(!!V.rooms.find(r => r.id === 'archeria') && !!V.rooms.find(r => r.id === 'arcano'),
    'le due botteghe nuove hanno la loro stanza');
  // v2.6 — e una terza specie: la CASA DEL PORTALE, che non e' ne' una bottega ne' un'abitazione
  assert(V.rooms.filter(r => r.kind === 'portale').length === 1, 'e una casa del portale, una sola');
  assert(V.rooms.every(r => r.kind === 'bottega' || r.kind === 'casa' || r.kind === 'portale'), 'ogni stanza dice cosa e');
  // v2.6 — DUE FILE CHE SI GUARDANO. E' questa la cosa che fa leggere un paese dall'alto, e se qualcuno
  // sparpaglia di nuovo le stanze il test deve accorgersene: ogni stanza dei lati sta tutta a ponente o
  // tutta a levante dello spiazzo, e ce ne sono almeno quattro per parte.
  { // si contano le stanze per COLONNA: una fila e' un gruppo di edifici che condividono lo stesso x0.
    // Le tre case dello spiazzo (una a settentrione, due a mezzogiorno) stanno per conto loro e non
    // devono falsare il conto — per questo si guarda la colonna e non "sta a destra o a sinistra".
    const perColonna = {};
    for (const r of V.rooms) (perColonna[r.x0] = perColonna[r.x0] || []).push(r);
    const file = Object.keys(perColonna).map(k => perColonna[k]).filter(a => a.length >= 4)
      .sort((a, b) => a[0].x0 - b[0].x0);
    assert(file.length === 2, 'ci sono DUE file di edifici, non una sala con le stanze sparse (' + file.length + ')');
    assert(file[0][0].x1 < V.piazza.x0, 'la prima fila sta a ponente della piazza');
    assert(file[1][0].x0 > V.piazza.x1, 'la seconda a levante');
    assert(file[0].length >= 4 && file[1].length >= 4, 'e ognuna ha almeno quattro edifici (' + file[0].length + ' e ' + file[1].length + ')');
  }

  // --- si SCAVA: pavimento SOLO dentro piazza, stanze e corridoi; e li' dentro mai roccia ---
  const inRett = (x, y, L) => x >= L[0] && x <= L[2] && y >= L[1] && y <= L[3];
  // v2.6 — LE PORTE NON SONO PIU' UNA LISTA A PARTE. Ogni stanza dichiara la sua (tessera + lato) e i
  // varchi si generano da li': prima bastava spostare una stanza e dimenticare la riga corrispondente
  // nell'elenco dei varchi per murarla dentro. Qui si ricostruiscono con la stessa regola del generatore.
  const VARCHI = V.rooms.map(r => { const [px, py, lato] = r.porta;
    return lato === 'n' ? [px, py - 1, px + 1, py] : (lato === 's' ? [px, py, px + 1, py + 1] : [px, py, px, py + 1]); });
  const inLink = (x, y) => VARCHI.some(L => inRett(x, y, L)) || V.strade.some(S => inRett(x, y, S));
  let stray = 0, vuoti = 0, area = 0;
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const dovuto = dentro(x, y, V.piazza) || V.rooms.some(r => dentro(x, y, r)) || inLink(x, y);
    if (isFloor(x, y)) { area++; if (!dovuto) stray++; } else if (dovuto) vuoti++;
  }
  assert(stray === 0, 'niente pavimento fuori da piazza, stanze, strade e porte (' + stray + ' anomalie)');
  assert(vuoti === 0, 'niente roccia dentro le stanze (' + vuoti + ' buchi)');
  assert(area > 250, 'c e spazio per muoversi (' + area + ' tile calpestabili)');

  // --- ogni stanza tocca la piazza: dallo spawn si arriva OVUNQUE, portale compreso ---
  // v2.0 — il portale non e' piu' in fondo a un corridoio: e' nel mezzo della piazza, e si vede da
  // qualunque strada. E' la prima cosa che vedi arrivando e l'ultima che tocchi andando via.
  // v2.6 — IL PORTALE E' DENTRO LA SUA CASA, non piu' in mezzo alla piazza (una piazza con un buco viola
  // al centro e' una sala del portale con delle case attorno, non una piazza).
  const stanzaP = V.rooms.find(r => r.kind === 'portale');
  assert(isFloor(Math.floor(m.portale.x), Math.floor(m.portale.y)), 'il portale poggia sul pavimento');
  assert(dentro(Math.floor(m.portale.x), Math.floor(m.portale.y), stanzaP), 'e sta DENTRO la casa del portale');
  assert(!dentro(Math.floor(m.portale.x), Math.floor(m.portale.y), V.piazza), 'e NON in mezzo alla piazza');
  assert(Math.abs(m.portale.x - (stanzaP.x0 + stanzaP.x1 + 1) / 2) <= 0.6 &&
         Math.abs(m.portale.y - (stanzaP.y0 + stanzaP.y1 + 1) / 2) <= 0.6, 'anzi: nel centro di quella stanza');
  // e le due guardie stanno sulla soglia, una per lato
  { const gd = m.village.extras.filter(e => e.kind === 'guardia');
    assert(gd.length === 2, 'due guardie all ingresso (' + gd.length + ')');
    const sx2 = stanzaP.porta[0] * T + T / 2, sy2 = stanzaP.porta[1] * T + T / 2;
    assert(gd.every(q => Math.hypot(q.x - sx2, q.y - sy2) < T * 3.5), 'e stanno sulla soglia');
    assert(Math.sign(gd[0].y - sy2) !== Math.sign(gd[1].y - sy2), 'una per lato della porta, non tutte e due dalla stessa parte'); }
  const seen = new Set(), q = [[(m.spawn.x / T) | 0, (m.spawn.y / T) | 0]];
  while (q.length) { const [x, y] = q.pop(); const k = y * m.w + x;
    if (seen.has(k) || x < 0 || y < 0 || x >= m.w || y >= m.h || !isFloor(x, y)) continue;
    seen.add(k); q.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]); }
  assert(seen.size === area, 'dallo spawn si raggiunge ogni angolo del villaggio (' + seen.size + '/' + area + ')');
  assert(seen.has(Math.floor(m.exit.y) * m.w + Math.floor(m.exit.x)), 'dallo spawn si raggiunge il portale a piedi');
  for (const r of V.rooms) {
    const cx = (r.x0 + r.x1) >> 1, cy = (r.y0 + r.y1) >> 1;
    assert(seen.has(cy * m.w + cx), 'la stanza ' + r.id + ' e collegata alla piazza');
  }

  // --- v1.75.1: ogni PORTA e larga almeno due tile. Una sola tile (48 px) contro un personaggio largo
  // 35 lasciava sei pixel per parte: ci si passava a pelo, sfregando lo stipite.
  const rettangoli = [{ id: 'piazza', x0: V.piazza.x0, y0: V.piazza.y0, x1: V.piazza.x1, y1: V.piazza.y1 }].concat(V.rooms);
  let stretta = '';
  for (const L of VARCHI) for (const r of rettangoli) {
    let bordo = 0;
    for (let y = L[1]; y <= L[3]; y++) for (let x = L[0]; x <= L[2]; x++)
      for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + d[0], ny = y + d[1];
        if (nx >= r.x0 && nx <= r.x1 && ny >= r.y0 && ny <= r.y1) bordo++;
      }
    if (bordo > 0 && bordo < 2) stretta += ' ' + r.id + '(' + bordo + ')';
  }
  assert(stretta === '', 'ogni porta e larga almeno due tile:' + (stretta || ' tutte ok'));
  // v2.0 — la VIA MAESTRA: quella che taglia il villaggio da nord a sud passando per la piazza. E' la
  // strada, non una porta: deve essere larga almeno quattro tessere, o due che si incrociano si toccano.
  // v2.6 — la via maestra unica non c'e' piu': ci sono DUE VIE LUNGHE, una davanti a ciascuna fila, e
  // corrono da un capo all'altro del paese. Sono quelle a rendere le file percorribili: se una si
  // accorcia, meta' delle porte finisce in fondo a un vicolo cieco.
  const lunghe = V.strade.filter(S => (S[3] - S[1]) >= V.h * 0.7);
  assert(lunghe.length === 2, 'due vie lunghe, una per fila (' + lunghe.length + ')');
  for (const L of lunghe) assert(L[2] - L[0] + 1 >= 3, 'e ognuna e larga almeno tre tile (' + (L[2] - L[0] + 1) + ')');
  assert(lunghe[0][2] < V.piazza.x0 && lunghe[1][0] > V.piazza.x1, 'una a ponente e una a levante della piazza');
  // e ogni porta dei lati si apre su una di quelle due
  for (const r of V.rooms) { const [px, py, lato] = r.porta; if (lato === 'n' || lato === 's') continue;
    const vicino = lato === 'e' ? px + 1 : px - 1;
    assert(lunghe.some(L => vicino >= L[0] && vicino <= L[2] && py >= L[1] && py <= L[3]),
      'la porta di ' + r.id + ' si apre su una via lunga'); }

  // --- il falo' sta nella piazza, ed e' l'unica sorgente di luce dichiarata ---
  assert(!!m.village.fire, 'il falo e esposto nella mappa (e la sorgente di luce)');
  const fireT = { x: (m.village.fire.x / T) | 0, y: (m.village.fire.y / T) | 0 };
  assert(fireT.x === (V.fire.x | 0) && fireT.y === (V.fire.y | 0), 'il falo e dove lo mette la pianta');
  assert(dentro(fireT.x, fireT.y, V.piazza), 'e il falo sta nella piazza centrale');
  assert(m.props.filter(p => p.type === 'bonfire').length === 1, 'un solo falo');

  // --- i pavimenti per stanza: sei rettangoli (piazza + cinque stanze) ---
  assert(Array.isArray(m.floors) && m.floors.length === V.rooms.length + 1, 'il renderer riceve un pavimento per stanza, piu la piazza');
  assert(m.floors.every(f => f.kind && f.col), 'ogni pavimento dichiara tipo e colore');

  // --- sette mercanti, ognuno nella SUA stanza, dietro il suo banco ---
  assert(m.props.filter(p => p.type === 'stall').length === 0, 'i banchetti sono spariti in v1.75: restano le persone');
  assert(m.village.npcs.length === 7, 'ci sono 7 mercanti');
  // v2.19 — TRE vendono equipaggiamento, e ognuno il SUO catalogo. Il conto e' la meta' della regola;
  // l'altra meta' e' che i tre cataloghi siano diversi, se no sono tre porte sullo stesso negozio.
  const venditori = m.village.npcs.filter(n => n.shop);
  assert(venditori.length === 3, 'tre vendono equipaggiamento: fabbro, arciera, arcanista');
  assert(new Set(venditori.map(n => n.cat)).size === 3, 'e i tre cataloghi sono diversi');
  assert(venditori.every(n => ['guerriero', 'ladro', 'mago'].indexOf(n.cat) >= 0), 'e sono i tre di gear.js');
  assert((m.village.botteghe || []).length === 3, 'e il villaggio le espone tutte e tre al server');
  assert(m.village.npcs.filter(n => n.soon).length === 0, 'il villaggio e completo: nessuna bottega chiusa');
  // v2.6 — LA CARTOMANTE E' DIVENTATA L’ORACOLO, e per ora non fa nulla: niente `crd`, quindi il
  // server non gli attacca nemmeno il richiamo di prossimita'. Le sue carte erano gia' spente
  // (CARTOMANTE_ATTIVA), quindi non si e' perso niente: e' cambiato chi abita l'antro.
  assert(m.village.npcs.filter(n => n.crd).length === 0, 'la cartomante non c e piu');
  assert(m.village.npcs.filter(n => n.kind === 'oracolo').length === 1, 'al suo posto c e l’oracolo');
  assert(m.village.npcs.every(n => n.kind !== 'seer'), 'e di cartomanti non ne resta traccia');
  { const sc = m.village.npcs.find(n => n.kind === 'oracolo');
    assert(!sc.shop && !sc.pot && !sc.bnd && !sc.crd && !sc.inn, 'e per ora non vende e non fa niente'); }
  assert(m.village.npcs.filter(n => n.inn).length === 1, "e l'Ostessa in v1.74");
  assert(m.village.npcs.filter(n => n.bnd).length === 1, 'e il Banditore ha aperto in v1.72');
  assert(m.village.npcs.filter(n => n.pot).length === 1, "e l'Erborista e aperto");
  assert(m.village.npcs.every(n => n.col), 'ogni mercante ha il suo colore: e cosi che lo riconosci da lontano');
  assert(new Set(m.village.npcs.map(n => n.col)).size === 7, 'i sette colori sono tutti diversi');
  let fuori = 0;
  for (let i2 = 0; i2 < V.stalls.length; i2++) {
    const s2 = V.stalls[i2], r = V.rooms.find(x => x.id === s2.room);
    if (!r || !dentro(Math.floor(s2.x), Math.floor(s2.y), r)) fuori++;
  }
  assert(fuori === 0, 'ogni mercante sta dentro la stanza del suo mestiere (' + fuori + ' fuori posto)');
  assert(m.village.npcs.every(n => n.name && n.name.length > 2), 'ognuno ha un nome');
  assert(V.stalls.find(s => s.bnd).name === 'Capitano', 'il Banditore e diventato il Capitano della Gilda dei Contratti');

  // --- la gente del villaggio: comparse che non vendono nulla ---
  assert(Array.isArray(m.village.extras) && m.village.extras.length >= 6, 'ci sono comparse: il posto e abitato, non abbandonato');
  assert(m.village.extras.every(e => !e.shop && !e.pot && !e.bnd && !e.crd && !e.inn), 'le comparse non vendono niente');

  // --- niente mercanti, comparse o arredo dentro la roccia ---
  const inWall = (o) => at((o.x / T) | 0, (o.y / T) | 0) === C.T_WALL;
  assert(!m.village.npcs.some(inWall), 'nessun mercante dentro la roccia');
  assert(!m.village.extras.some(inWall), 'nessuna comparsa dentro la roccia');
  assert(!m.props.some(inWall), 'nessun arredo dentro la roccia');

  // --- il villaggio e BUIO: la luce la fanno il falo e gli aloni dei mercanti ---
  // v2.0.2 — SI E' ROVESCIATA. Dalla v1.57 il villaggio restava al buio come le ondate, illuminato solo
  // dal falo'. Su 56x40 non funzionava piu': non vedevi dov'erano le botteghe. Adesso e' l'UNICA mappa
  // che dichiara `lit`, e il velo scuro li' non si stende.
  assert(m.lit === 1, 'il villaggio e illuminato: e la sosta, non un\'ondata');
  for (const lv of [1, 5, 10, 20]) assert(!MapGen.generate(77, lv).lit, 'ma l ondata ' + lv + ' resta buia');
  assert(m.props.filter(p => p.type === 'glowspot').length === 7, "un alone di luce per mercante");
  assert(m.market === 1, 'la mappa si dichiara mercato');
  assert(m.enemySpawns.length === 0 && m.crateSpawns.length === 0, 'niente spawn nemici ne casse');

  // --- la stanza vera del Room coincide, e nessuno nasce nella roccia ---
  const room = new Room('v157'); room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  room.wave = 3; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');   // v1.79 — il villaggio e una sezione del menu
  assert(room.map.village && room.map.village.npcs.length === 7, 'la stanza mercato usa il villaggio');
  assert(room.monsters.length === 0 && room.crates.length === 0, 'nel villaggio non ci sono nemici ne casse');
  assert(MU.dist(room.gearMerchant.x, room.gearMerchant.y, room.map.village.smith.x, room.map.village.smith.y) < 1, 'il mercante e agganciato al fabbro');
  let inside = false;
  for (let i2 = 0; i2 < 40; i2++) { room.newMap(1000 + i2, 3, true); for (const q2 of room.players.values()) if (room.isWallAt(q2.x, q2.y)) inside = true; }
  assert(!inside, 'nessun giocatore compare dentro la roccia');
  ok('il villaggio v1.75 verificato');
}

function testV158() {
  console.log('\n[TEST 29] Novita v1.58 — Fungo immobile, Sfera d\'Ossa rotolante, Melma che si divide, tetto al Beholder');
  const Mon = require('../shared/monsters.js');
  const dt = 1 / C.TICK_RATE;

  // ---------- FUNGO SPORIFERO: non si muove, nega il terreno ----------
  const fg = Mon.MONSTERS.spore_fungus;
  assert(!!fg && fg.ai === 'sentry' && fg.immobile, 'il Fungo esiste, e immobile e usa la IA sentry');
  assert(fg.speed === 0, 'velocita zero: niente camminata da animare');
  const r1 = new Room('v158a'); const p1 = r1.addPlayer('b', { send() {} }, 'B', 'arciere'); r1.startGame();
  r1.pending = 0; r1.waveList = []; p1.hp = 9999; p1.maxHp = 9999;
  // v1.61.1 — la posizione va cercata LIBERA: a offset fisso il fungo puo nascere dentro un muro, e li
  // il server lo sposta con _unstuck (giustamente). Il test diventava intermittente per colpa della mappa.
  let fpos = { x: p1.x + 200, y: p1.y };
  for (let a = 0; a < 32 && r1.isWallAt(fpos.x, fpos.y); a++) {
    const an = a * 0.7, rr = 140 + (a % 4) * 40;
    fpos = { x: p1.x + Math.cos(an) * rr, y: p1.y + Math.sin(an) * rr };
  }
  assert(!r1.isWallAt(fpos.x, fpos.y), 'trovato un punto libero dove piantare il Fungo');
  const f = r1.spawnMonster('spore_fungus', fpos.x, fpos.y, { scaling: Waves.scaling(6, 1) });
  const fx = f.x, fy = f.y;
  r1.zones.length = 0;
  for (let i = 0; i < C.TICK_RATE * 5 && !r1.zones.length; i++) r1.update(dt);
  assert(Math.abs(f.x - fx) < 1 && Math.abs(f.y - fy) < 1, 'il Fungo non si sposta di un pixel');
  assert(r1.zones.length > 0, 'vedendo il giocatore semina zone di spore');
  assert(r1.zones.every(z => z.r > 0 && z.dmg > 0), 'le zone hanno raggio e danno');
  // il danno arriva solo dopo il telegrafo
  const z = r1.zones[0]; assert(z.t > 0, 'la zona e telegrafata: fa danno dopo un ritardo');

  // ---------- SFERA D'OSSA: carica, rotola, rimbalza ----------
  const br = Mon.MONSTERS.bone_roller;
  assert(!!br && br.ai === 'roller' && br.rollSpeed > 1, 'la Sfera d\'Ossa esiste e usa la IA roller');
  const r2 = new Room('v158b'); const p2 = r2.addPlayer('b', { send() {} }, 'B', 'arciere'); r2.startGame();
  r2.pending = 0; r2.waveList = []; p2.hp = 9999; p2.maxHp = 9999;
  const sp158 = losSpot(r2, p2, 260);
  const b2 = r2.spawnMonster('bone_roller', sp158.x, sp158.y, { scaling: Waves.scaling(8, 1) });
  r2.events.length = 0;
  let winded = false, rolled = false, moved = 0; let bx = b2.x, by = b2.y;
  for (let i = 0; i < C.TICK_RATE * 6; i++) { r2.update(dt);
    for (const e of r2.events) { if (e.t === 'roll_wind') winded = true; if (e.t === 'roll_go') rolled = true; }
    moved = Math.max(moved, MU.dist(b2.x, b2.y, bx, by)); }
  assert(winded, 'si carica prima di partire (telegrafo roll_wind)');
  assert(rolled, 'poi parte in carica (roll_go)');
  assert(moved > 40, 'durante la carica percorre distanza (' + Math.round(moved) + 'px)');
  // v1.64 — il giocatore va tenuto ADDOSSO alla sfera a ogni tick: la sfera sta rotolando, e in 20 tick
  // poteva allontanarsi dal punto dove il test lo aveva messo una volta sola. Era una flakiness rara.
  const hp0 = p2.hp; b2.atkT = 0;
  for (let i = 0; i < 40 && p2.hp >= hp0; i++) { p2.x = b2.x + 8; p2.y = b2.y; r2.update(dt); }
  assert(p2.hp < hp0, 'travolge il giocatore che colpisce');

  // ---------- MELMA CHE SI DIVIDE ----------
  assert(Mon.MONSTERS.slime.splitInto === 'slime_mini', 'la Melma si divide in melme minori');
  assert(!Mon.MONSTERS.slime_mini.splitInto, 'la Melma Minore NON si divide a sua volta (niente catena infinita)');
  const r3 = new Room('v158c'); const p3 = r3.addPlayer('b', { send() {} }, 'B', 'arciere'); r3.startGame();
  r3.pending = 0; r3.waveList = []; r3.monsters.length = 0;
  const sp158b = losSpot(r3, p3, 120);
  const sl = r3.spawnMonster('slime', sp158b.x, sp158b.y, { scaling: Waves.scaling(4, 1) });
  r3.killMonster(sl, p3);
  const minis = r3.monsters.filter(x => x.type === 'slime_mini' && !x.dead);
  assert(minis.length === (Mon.MONSTERS.slime.splitCount || 2), 'alla morte lascia ' + minis.length + ' melme minori');
  assert(minis.every(x => x.minion), 'le minori sono marcate come minion');
  const before = r3.monsters.filter(x => !x.dead).length;
  r3.killMonster(minis[0], p3);
  assert(r3.monsters.filter(x => !x.dead).length < before, 'uccidendo una minore non ne nascono altre');

  // ---------- BEHOLDER: tardi e col tetto ----------
  const oc = Mon.MONSTERS.occhio;
  assert(oc.maxAlive === 8, 'il Beholder ha un tetto di 8 presenze contemporanee');
  assert(!Waves.poolForWave(7).some(x => x.id === 'occhio'), 'niente Beholder prima dell ondata 8');
  assert(Waves.poolForWave(8).some(x => x.id === 'occhio'), 'Beholder nel pool dall ondata 8');
  const r4 = new Room('v158d'); r4.addPlayer('b', { send() {} }, 'B', 'arciere'); r4.startGame();
  r4.pending = 0; r4.waveList = []; r4.monsters.length = 0;
  for (let i = 0; i < 12; i++) { const t = r4._capType('occhio'); const pos = r4.randomSpawnPos();
    r4.spawnMonster(t, pos.x, pos.y, { scaling: Waves.scaling(15, 1) }); }
  const alive = r4.monsters.filter(x => x.type === 'occhio' && !x.dead).length;
  assert(alive <= oc.maxAlive, 'oltre il tetto non ne compaiono altri (' + alive + ' vivi su 12 tentativi)');
  assert(r4.monsters.filter(x => x.type === 'skeleton').length > 0, 'oltre il tetto si ripiega sullo sciame base');

  // ---------- la rampa resta monotona e ordinata ----------
  const at2 = w => Waves.poolForWave(w).map(x => x.id);
  assert(!at2(3).includes('spore_fungus') && at2(4).includes('spore_fungus'), 'Fungo introdotto all ondata 4');
  assert(!at2(5).includes('bone_roller') && at2(6).includes('bone_roller'), 'Sfera d\'Ossa introdotta all ondata 6');
  let mono2 = true; for (let w = 1; w < 20; w++) { const a = at2(w), b = at2(w + 1); if (!a.every(id => b.includes(id))) mono2 = false; }
  assert(mono2, 'la rampa resta monotona con i nemici nuovi');
  // niente NaN con tutti i nuovi in campo
  const r5 = new Room('v158e'); const p5 = r5.addPlayer('b', { send() {} }, 'B', 'arciere'); r5.startGame();
  r5.pending = 0; r5.waveList = [];
  for (const id of ['spore_fungus', 'bone_roller', 'slime', 'occhio']) { const pos = r5.randomSpawnPos(); r5.spawnMonster(id, pos.x, pos.y, { scaling: Waves.scaling(15, 1) }); }
  for (let i = 0; i < C.TICK_RATE * 8; i++) { r5.setInput('b', bot(r5, p5)); r5.update(dt); if (hasNaN(r5)) break; }
  assert(hasNaN(r5) === null, 'nessun NaN con i nemici nuovi in campo');
  ok('novita v1.58 verificate');
}
function testV159() {
  console.log('\n[TEST 30] Novita v1.59 — Beholder meno statico: telegrafo del cambio sguardo esposto al client');
  const dt = 1 / C.TICK_RATE, Mon = require('../shared/monsters.js');
  const room = new Room('v159'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  room.pending = 0; room.waveList = []; pl.hp = 9999; pl.maxHp = 9999;
  const sp = room.map.spawn;
  const m = room.spawnMonster('occhio', sp.x + 80, sp.y, { scaling: Waves.scaling(15, 1) });
  pl.x = sp.x; pl.y = sp.y; m.facing = 0;
  room.update(dt);
  let snap = room.snapshot(); let mo = snap.mon.find(x => x.t === 'occhio');
  assert(mo && typeof mo.gt === 'number', 'lo snapshot espone gt (quanto manca al cambio di sguardo)');
  assert(mo.gt >= 0 && mo.gt <= 1, 'gt e normalizzato fra 0 e 1 (' + mo.gt + ')');
  const g0 = mo.gt;
  for (let i = 0; i < C.TICK_RATE; i++) room.update(dt);       // un secondo
  snap = room.snapshot(); mo = snap.mon.find(x => x.t === 'occhio');
  assert(mo.gt < g0, 'gt cala col passare del tempo: il client puo anticipare il cambio (' + g0 + ' -> ' + mo.gt + ')');
  // arrivato a zero il tipo di sguardo cambia e gt riparte
  const k0 = m.gazeKind; let changed = false, reset = false;
  for (let i = 0; i < C.TICK_RATE * (Mon.MONSTERS.occhio.gazeCycle + 1); i++) { room.update(dt);
    if (m.gazeKind !== k0) { changed = true; const s2 = room.snapshot().mon.find(x => x.t === 'occhio'); if (s2 && s2.gt > 0.5) reset = true; break; } }
  assert(changed, 'il tipo di sguardo cambia a fine ciclo');
  assert(reset, 'e gt riparte da capo dopo il cambio');
  for (let i = 0; i < C.TICK_RATE * 4; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN col Beholder aggiornato');
  ok('novita v1.59 verificate');
}
function testV164() {
  console.log('\n[TEST 35] Novita v1.64 — tetto ai nemici vivi (la coda non perde nessuno)');
  const dt = 1 / C.TICK_RATE;
  assert(C.MAX_ALIVE > 0, 'esiste un tetto ai nemici vivi (' + C.MAX_ALIVE + ')');

  // ondata pesante: 6 giocatori all ondata 18. Il totale da uccidere deve restare quello previsto,
  // ma non devono stare tutti in campo insieme.
  const room = new Room('v164'); const pls = [];
  for (let i = 0; i < 6; i++) pls.push(room.addPlayer('p' + i, { send() {} }, 'P' + i, 'arciere'));
  room.startGame();
  room.wave = 18; room.nextWave();
  const totale = room.pending + room.monsters.length;
  assert(totale > room.tettoVivi(), 'l ondata scelta e piu grande del tetto (' + totale + ' nemici previsti contro un tetto di ' + room.tettoVivi() + ')');

  // i giocatori non fanno nulla: i mostri si accumulano finche il tetto non li ferma
  let picco = 0;
  for (let i = 0; i < C.TICK_RATE * 45; i++) {
    for (const p of pls) { p.hp = 1e9; room.setInput(p.id, { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }); }
    room.update(dt);
    // conta solo i VIVI: killMonster marca .dead e la rimozione dall array avviene al tick dopo, quindi
    // un mostro che si divide puo far vedere per un istante il proprio posto occupato due volte.
    picco = Math.max(picco, room.monsters.filter(x => !x.dead).length);
    if (room.phase !== C.PHASE_COMBAT && room.phase !== C.PHASE_BOSS) break;
  }
  assert(picco <= room.tettoVivi(), 'in campo non se ne vedono mai piu di ' + room.tettoVivi() + ' (picco ' + picco + ')');
  assert(room.pending > 0, 'i nemici in eccesso NON spariscono: restano in coda (' + room.pending + ' ancora da entrare)');
  assert(room.monsters.length + room.pending >= totale - 2, 'il totale da uccidere e rimasto quello: ' + (room.monsters.length + room.pending) + ' su ' + totale);

  // uccidendone qualcuno la coda riprende a scorrere — ma NON subito.
  // v2.24: fino alla v2.23 bastava un posto libero perche' ne entrasse un altro, e il campo restava
  // sempre incollato al tetto. Ora il primo carico riempie fino al tetto, poi la coda si CHIUDE e le
  // riserve aspettano che i vivi scendano a meta' tetto. Il test segue la regola nuova e la verifica
  // in due tempi, perche' il pezzo che vale e' proprio l'attesa.
  const codaPrima = room.pending;
  const vivi = () => room.monsters.filter(x => !x.dead).length;
  const gira = (sec) => { for (let i = 0; i < C.TICK_RATE * sec; i++) {
    for (const p of pls) { p.hp = 1e9; room.setInput(p.id, { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }); }
    room.update(dt); } };
  // conto sempre i vivi da capo a ogni colpo: killMonster marca .dead e la rimozione avviene al tick
  // dopo (prendere monsters[0] tre volte vorrebbe dire ammazzare tre volte lo stesso), e soprattutto
  // le Melme si dividono morendo, quindi "ne uccido N" non vuol dire "ne restano N di meno".
  const falcia = (finoA, maxColpi) => { let g = 0;
    while (vivi() > finoA && g++ < maxColpi) { const v = room.monsters.find(x => !x.dead); if (!v) break; room.killMonster(v, null); } };

  // PRIMO TEMPO — posti liberi in campo, ma ancora sopra la soglia: la coda deve restare ferma.
  falcia(room.tettoVivi() - 3, 40);
  gira(6);
  assert(vivi() > room.sogliaRiserve(), 'i vivi sono ancora sopra la soglia (' + vivi() + ' > ' + room.sogliaRiserve() + ')');
  assert(!room.riserveAperte, 'e le riserve sono ancora chiuse');
  // NON controllo che ci siano posti liberi in campo: un Negromante evoca e una Melma si divide,
  // e quei due rioccupano il posto senza passare dalla coda. Il posto libero lo verifica il TEST 83
  // in una stanza pulita; qui conta che la coda sia ferma.
  assert(room.pending === codaPrima, 'e la coda NON si muove: le riserve non entrano a goccia (' + codaPrima + ' -> ' + room.pending + ')');

  // SECONDO TEMPO — scesi a meta' tetto, le riserve si aprono e rientrano in blocco.
  falcia(room.sogliaRiserve(), 60);
  gira(12);
  assert(room.riserveAperte, 'scesi alla soglia le riserve si aprono');
  assert(room.pending < codaPrima, 'e la coda riprende a entrare (' + codaPrima + ' -> ' + room.pending + ')');
  assert(vivi() <= room.tettoVivi(), 'e il tetto continua a valere (' + vivi() + ')');
  ok('novita v1.64 verificate');
}
function testV163() {
  console.log('\n[TEST 34] Novita v1.63 — la Faglia consuma chi resta ai margini; casse solo al centro');
  const dt = 1 / C.TICK_RATE;

  // ---------- la geometria del margine ----------
  const r0 = new Room('v163g'); r0.addPlayer('a', { send() {} }, 'A', 'arciere'); r0.startGame();
  const m0 = r0.map, T2 = C.TILE, M = C.EDGE_MARGIN;
  const at = (gx, gy) => r0._edgeDepth(gx * T2 + T2 / 2, gy * T2 + T2 / 2);

  // LA FAGLIA E' UNA MANOPOLA, e il test la segue invece di imporre una scelta. EDGE_MARGIN a 0
  // significa "spenta": nessuna fascia, nessun drenaggio. E' una decisione di gioco legittima — la
  // faglia serve a scoraggiare chi si accampa sul bordo, e si puo' preferire di lasciar fare. Quello
  // che il test deve garantire e' che la manopola FUNZIONI in tutte e due le posizioni: se e' spenta,
  // deve essere spenta davvero e non mordere di nascosto.
  if (M <= 0) {
    let fascia = 0, tessere = 0;
    for (let y = 2; y < m0.h - 2; y++) for (let x = 2; x < m0.w - 2; x++) {
      if (m0.grid[y * m0.w + x] === C.T_WALL) continue;
      tessere++; if (at(x, y) > 0) fascia++;
    }
    assert(fascia === 0, 'con EDGE_MARGIN a 0 nessuna tessera e nella fascia (' + fascia + ' su ' + tessere + ')');
    // e chi si accampa sul bordo non deve perdere un solo punto ferita
    const rs = new Room('v163off'); const ps = rs.addPlayer('s', { send() {} }, 'S', 'arciere'); rs.startGame();
    rs.pending = 0; rs.waveList = []; rs.monsters.length = 0;
    const cc = rs.map.spawn;
    rs.spawnMonster('spore_fungus', cc.x, cc.y, { scaling: Waves.scaling(1, 1) });
    // La casella di prova va scelta LONTANA dal Fungo, se no i suoi colpi entrano nella misura e
    // sembra che morda la faglia: alla prima stesura il giocatore perdeva 108 PV in venti secondi, e
    // non era la faglia — era il Fungo. Si prende la tessera calpestabile piu' lontana da lui.
    let bordo = null, dLontano = -1;
    for (let y = 2; y < rs.map.h - 2; y++) for (let x = 2; x < rs.map.w - 2; x++) {
      if (rs.map.grid[y * rs.map.w + x] !== C.T_FLOOR) continue;
      const d = MU.dist(x * T2 + T2 / 2, y * T2 + T2 / 2, cc.x, cc.y);
      if (d > dLontano) { dLontano = d; bordo = { x, y }; }
    }
    assert(dLontano > 700, 'la casella di prova e lontana dal Fungo (' + dLontano.toFixed(0) + ' px)');
    ps.hp = 500; ps.maxHp = 500; const hp0 = ps.hp;
    for (let i = 0; i < C.TICK_RATE * 20; i++) {
      ps.x = bordo.x * T2 + T2 / 2; ps.y = bordo.y * T2 + T2 / 2;
      rs.setInput('s', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
      rs.update(1 / C.TICK_RATE);
    }
    assert(ps.hp === hp0, 'e venti secondi sul bordo non tolgono un punto ferita (' + hp0 + ' -> ' + ps.hp + ')');
    assert((ps.edgeLv || 0) === 0, 'e la carica resta a zero (' + (ps.edgeLv || 0) + ')');
    ok('la faglia e SPENTA per scelta (EDGE_MARGIN 0) e non morde di nascosto');
    return;
  }
  // v1.76 — la fascia non e' piu' il bordo del RETTANGOLO: segue la forma della caverna. Percio' non
  // si prova piu' "l angolo della mappa vale il doppio" (l angolo e' roccia piena), si prova la cosa
  // che conta davvero: attaccati alla parete esterna morde al massimo, due tessere dentro non morde
  // piu', e i massi INTERNI non hanno alone — se no stare al riparo dietro un sasso sarebbe letale.
  const suoloAt = (gx, gy) => m0.grid[gy * m0.w + gx] !== C.T_WALL;
  // la roccia ESTERNA e' quella che comunica col bordo della mappa: i massi interni non contano,
  // ed e' apposta — dietro un masso al centro si deve poter stare al riparo senza morire.
  const esterna = new Uint8Array(m0.w * m0.h);
  { const q = [];
    for (let x = 0; x < m0.w; x++) q.push([x, 0], [x, m0.h - 1]);
    for (let y = 0; y < m0.h; y++) q.push([0, y], [m0.w - 1, y]);
    while (q.length) { const p = q.pop(), x = p[0], y = p[1];
      if (x < 0 || y < 0 || x >= m0.w || y >= m0.h) continue;
      const i = y * m0.w + x;
      if (esterna[i] || m0.grid[i] !== C.T_WALL) continue;
      esterna[i] = 1; q.push([x+1,y],[x-1,y],[x,y+1],[x,y-1]); } }
  const controParete = (gx, gy) => { for (const d of [[1,0],[-1,0],[0,1],[0,-1]]) {
    const nx = gx + d[0], ny = gy + d[1];
    if (nx < 0 || ny < 0 || nx >= m0.w || ny >= m0.h) continue;
    if (esterna[ny * m0.w + nx]) return true; } return false; };
  const fuoriRoccia = (gx, gy) => { for (const d of [[1,0],[-1,0],[0,1],[0,-1]])
    if (!suoloAt(gx + d[0], gy + d[1])) return true; return false; };
  let attaccate = 0, attaccateMax = 0, dentro = 0, dentroFuori = 0;
  for (let y = 2; y < m0.h - 2; y++) for (let x = 2; x < m0.w - 2; x++) {
    if (!suoloAt(x, y)) continue;
    if (!controParete(x, y)) continue;
    attaccate++; if (at(x, y) === M * 2) attaccateMax++;
  }
  assert(attaccateMax / attaccate > 0.9, 'chi sta attaccato alla parete ESTERNA e nella fascia piena (' + (attaccateMax / attaccate * 100).toFixed(0) + '% delle tessere a contatto)');
  // Un masso INTERNO non deve avere alone: dietro un sasso in mezzo alla caverna si deve poter stare
  // al riparo. La prima versione cercava solo nella finestra 6..h-6 e chiedeva "tocca roccia": su
  // qualche mappa quella finestra non conteneva massi interni e il test falliva a intermittenza —
  // colpa della prova, non del gioco. Adesso si cerca su tutta la mappa e si chiede la cosa esatta:
  // una tessera che tocca roccia NON esterna. Se una mappa non ne avesse nemmeno una sarebbe una
  // mappa senza ripari interni, e quello si' sarebbe un difetto da segnalare.
  let masso = null, toccaInterna = 0;
  for (let y = 2; y < m0.h - 2 && !masso; y++) for (let x = 2; x < m0.w - 2; x++) {
    if (!suoloAt(x, y)) continue;
    let interna = false;
    for (const d of [[1,0],[-1,0],[0,1],[0,-1]]) { const nx = x + d[0], ny = y + d[1];
      if (nx < 0 || ny < 0 || nx >= m0.w || ny >= m0.h) continue;
      const i = ny * m0.w + nx;
      if (m0.grid[i] === C.T_WALL && !esterna[i]) interna = true; }
    if (!interna) continue;
    toccaInterna++;
    if (at(x, y) === 0) { masso = [x, y]; break; }
  }
  assert(toccaInterna > 0, 'la caverna ha massi interni dietro cui ripararsi (' + toccaInterna + ' tessere a contatto)');
  assert(!!masso, 'e almeno uno di quei ripari e fuori dalla fascia della faglia: dietro un masso al centro non si muore');
  // La copertura si misura su PIU' MAPPE: su una sola oscilla parecchio — misurato 46% su una,
  // 34% di media su dieci — e il test diventava un lancio di dadi.
  let band = 0, tot = 0;
  for (let k = 0; k < 6; k++) { const mk = MapGen.generate(31337 + k * 977, 4);
    for (let i = 0; i < mk.grid.length; i++) { if (mk.grid[i] === C.T_WALL) continue; tot++; if (mk.edgeField[i] > 0) band++; } }
  assert(band / tot > 0.18 && band / tot < 0.48, 'la fascia copre una quota sensata della mappa (' + (band / tot * 100).toFixed(0) + '%, su sei mappe)');

  // ---------- grazia, poi drenaggio crescente ----------
  const room = new Room('v163a'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  // Svuotare del tutto i mostri chiude l'ondata: la stanza passa a 'shop' e li' CURA i giocatori, quindi il
  // drenaggio veniva rimborsato a ogni tick e il test misurava zero. Si tiene in campo UN Fungo Sporifero al
  // centro: e' immobile e la sua vista non arriva al bordo, quindi la stanza resta in combattimento senza
  // che nessuno interferisca con la misura.
  room.pending = 0; room.waveList = []; room.monsters.length = 0;
  const ccx = ((room.map.w / 2) | 0) * C.TILE + C.TILE / 2, ccy = ((room.map.h / 2) | 0) * C.TILE + C.TILE / 2;
  const fung = room.spawnMonster('spore_fungus', ccx, ccy, { scaling: Waves.scaling(1, 1) });
  let spot = null;
  for (let y = 2; y < room.map.h - 2 && !spot; y++) for (let x = 2; x < room.map.w - 2; x++)
    if (room.map.grid[y * room.map.w + x] === C.T_FLOOR && room._edgeDepth(x * T2 + T2 / 2, y * T2 + T2 / 2) === C.EDGE_MARGIN * 2) { spot = { x, y }; break; }
  if (!spot) for (let y = 2; y < room.map.h - 2 && !spot; y++) for (let x = 2; x < room.map.w - 2; x++)
    if (room.map.grid[y * room.map.w + x] === C.T_FLOOR && room._edgeDepth(x * T2 + T2 / 2, y * T2 + T2 / 2) > 0) { spot = { x, y }; break; }
  assert(!!spot, 'trovata una casella nel margine per la prova');
  const px = spot.x * T2 + T2 / 2, py = spot.y * T2 + T2 / 2;
  // il Fungo va tenuto VIVO a forza: puo' essere nato dentro una pozza (v1.62) e morirci in 4 secondi.
  // Se muore l'ondata si chiude, la stanza passa a 'shop' e li' CURA i giocatori — e la misura salta.
  // Due cose vanno neutralizzate perche' la misura riguardi SOLO la faglia:
  //  - il Fungo va tenuto vivo (puo' essere nato dentro una pozza v1.62 e morirci in 4 secondi; se muore
  //    l'ondata si chiude, la stanza passa a 'shop' e li' CURA i giocatori);
  //  - il RECUPERO ANTI-STALLO (v1.43): se per 6 secondi il numero di mostri non cala, la stanza li
  //    teletrasporta tutti a 240px da un giocatore. Con un solo Fungo fermo scatta sempre, e il Fungo
  //    si materializzava addosso al punto "al sicuro" seminandoci le spore.
  const pin = () => { pl.x = px; pl.y = py; fung.hp = fung.maxHp; room._stallT = 0; };
  pl.hp = 500; pl.maxHp = 500; pl.buffs = {};

  // 1 secondo dentro la fascia: siamo dentro la grazia, nessun danno
  let h = pl.hp;
  for (let i = 0; i < C.TICK_RATE * 1; i++) { pin(); room.setInput('b', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }); room.update(dt); }
  assert(pl.hp === h, 'il primo secondo nel margine NON fa danno: e la finestra di grazia');
  assert((pl.edgeLv || 0) > 0, 'ma la carica sta gia salendo (edgeLv ' + (pl.edgeLv || 0).toFixed(2) + '): il giocatore e avvisato prima di essere punito');

  // altri 4 secondi: ora deve drenare, e l evento deve essere partito una volta sola
  room.events.length = 0;
  for (let i = 0; i < C.TICK_RATE * 4; i++) { pin(); room.update(dt); }
  const lost1 = h - pl.hp;
  assert(lost1 > 0, 'passata la grazia il drenaggio comincia (persi ' + lost1 + ' PV)');
  const warn = room.events.filter(e => e.t === 'rift_edge');
  assert(warn.length === 1, 'l avviso rift_edge parte UNA volta sola, non a ogni tick (' + warn.length + ')');
  assert(warn[0].who === 'b', 'l avviso dice a CHI sta capitando');

  // il drenaggio CRESCE: gli stessi 4 secondi, piu avanti, tolgono di piu
  h = pl.hp;
  for (let i = 0; i < C.TICK_RATE * 4; i++) { pin(); room.update(dt); }
  const lost2 = h - pl.hp;
  assert(lost2 > lost1, 'il drenaggio CRESCE col tempo (' + lost1 + ' PV poi ' + lost2 + ' PV): indugiare costa sempre di piu');

  // ---------- uscire lo riassorbe ----------
  // il punto "al sicuro" non puo' essere il centro: li' c'e' il Fungo che tiene viva l'ondata, e le sue
  // spore falserebbero la misura. Serve una casella FUORI dalla fascia e fuori dalla sua vista (340px).
  let safe = null, bestD = -1;
  for (let y = 2; y < room.map.h - 2; y++) for (let x = 2; x < room.map.w - 2; x++) {
    if (room.map.grid[y * room.map.w + x] !== C.T_FLOOR) continue;
    if (room._edgeDepth(x * T2 + T2 / 2, y * T2 + T2 / 2) !== 0) continue;
    // la distanza va misurata dalla posizione REALE del fungo: se il centro era roccia, spawnMonster
    // lo ha spostato, e misurare dal centro teorico puo' scegliere un punto che il fungo vede benissimo.
    const d = Math.hypot(x * T2 + T2 / 2 - fung.x, y * T2 + T2 / 2 - fung.y);
    if (d > bestD) { bestD = d; safe = { x: x * T2 + T2 / 2, y: y * T2 + T2 / 2 }; }
  }
  assert(!!safe && bestD > 500, 'trovato un punto al sicuro fuori dalla fascia e fuori dalla vista del Fungo (' + bestD.toFixed(0) + 'px)');
  const cx = safe.x, cy = safe.y;
  const before = pl.edgeT;
  for (let i = 0; i < C.TICK_RATE * 3; i++) { pl.x = cx; pl.y = cy; fung.hp = fung.maxHp; room._stallT = 0; room.update(dt); }
  assert(pl.edgeT < before, 'tornando verso il centro la carica si riassorbe (' + before.toFixed(1) + 's -> ' + pl.edgeT.toFixed(1) + 's)');
  h = pl.hp;
  for (let i = 0; i < C.TICK_RATE * 5; i++) { pl.x = cx; pl.y = cy; fung.hp = fung.maxHp; room._stallT = 0; room.update(dt); }
  assert(pl.hp === h, 'al centro la faglia non tocca il giocatore [hp ' + pl.hp + ' era ' + h + ' fase ' + room.phase + ' mostri ' + room.monsters.length + ' edgeT ' + (pl.edgeT || 0).toFixed(2) + ' zone ' + room.zones.length + ' distFungo ' + Math.hypot(cx - fung.x, cy - fung.y).toFixed(0) + ']');

  // attraversare il margine di corsa non deve costare nulla
  pl.edgeT = 0; pl.hp = 500; h = pl.hp;
  for (let k = 0; k < 6; k++) {
    for (let i = 0; i < C.TICK_RATE * 1; i++) { pin(); room.update(dt); }
    for (let i = 0; i < C.TICK_RATE * 2; i++) { pl.x = cx; pl.y = cy; fung.hp = fung.maxHp; room._stallT = 0; room.update(dt); }
  }
  assert(pl.hp === h, 'passare dal margine e tornare indietro non costa niente: e l ACCAMPARSI a costare [hp ' + pl.hp + ' era ' + h + ' fase ' + room.phase + ' mostri ' + room.monsters.length + ' edgeT ' + (pl.edgeT || 0).toFixed(2) + ' depthSpot ' + room._edgeDepth(px, py) + ']');

  // ---------- al mercato la faglia non esiste ----------
  const r3 = new Room('v163m'); const p3 = r3.addPlayer('c', { send() {} }, 'C', 'arciere'); r3.startGame();
  r3.newMap(99, 3, true); r3.phase = C.PHASE_MARKET;
  let mspot = null;
  for (let y = 2; y < r3.map.h - 2 && !mspot; y++) for (let x = 2; x < r3.map.w - 2; x++)
    if (r3.map.grid[y * r3.map.w + x] === C.T_FLOOR && r3._edgeDepth(x * T2 + T2 / 2, y * T2 + T2 / 2) > 0) { mspot = { x, y }; break; }
  if (mspot) {
    p3.hp = 300; const mh = p3.hp;
    for (let i = 0; i < C.TICK_RATE * 8; i++) { p3.x = mspot.x * T2 + T2 / 2; p3.y = mspot.y * T2 + T2 / 2; r3.update(dt); }
    assert(p3.hp === mh, 'nella sala del MERCATO la faglia e spenta (la sala e quasi tutta margine)');
  } else assert(true, 'sala del mercato senza margine calpestabile');

  // ---------- lo snapshot porta la carica al client ----------
  // v1.68 — `eg` viene omesso dallo snapshot quando vale 0 (il client lo rimette a 0): la prova non e' piu'
  // "il campo esiste sempre" ma "quando la carica c'e', arriva".
  const plEg = room.players.get('b'); plEg.edgeLv = 0.42;
  const snap = room.snapshot();
  assert(snap.players[0].eg === 0.42, 'lo snapshot espone la carica della faglia (eg) per la vignetta');
  plEg.edgeLv = 0;
  assert(room.snapshot().players[0].eg === undefined, 'a carica zero il campo non viene nemmeno mandato');

  // ---------- CASSE E ARMI SOLO AL CENTRO ----------
  let fuori = 0, mappe = 0, minCelle = 1e9;
  for (let k = 0; k < 60; k++) {
    const mm = MapGen.generate(k * 104729 + 7, 1 + (k % 20));
    mappe++; minCelle = Math.min(minCelle, mm.crateSpawns.length);
    const lim = Math.min(mm.w, mm.h) * 0.36 + 1;
    for (const c of mm.crateSpawns) if (Math.hypot(c.x / mm.tile - mm.w / 2, c.y / mm.tile - mm.h / 2) > lim) fuori++;
  }
  assert(fuori === 0, 'casse e armi nascono solo nella zona centrale (fuori: ' + fuori + ' su ' + mappe + ' mappe)');
  assert(minCelle > 20, 'restano abbastanza posizioni centrali (minimo ' + minCelle + ')');
  ok('novita v1.63 verificate');
}
function testV162() {
  console.log('\n[TEST 33] Novita v1.62 — pozze di pericolo, strato ambientale, partenza e uscita variabili');
  const PF = require('../shared/pathfinding.js');
  const N = 120;
  const byTheme = {}; const spawns = new Set(), exits = new Set();
  let hazTot = 0, hazNearWall = 0, hazOnExit = 0, hazNearStart = 0, propTot = 0, offBag = 0, unreach = 0, startInHaz = 0;
  let farOK = 0, enemyClose = 0;

  for (let k = 0; k < N; k++) {
    const m = MapGen.generate(k * 7919 + 13, 1 + (k % 20));
    const th = m.theme; const a = byTheme[th.id] = byTheme[th.id] || { n: 0, haz: 0, name: th.name };
    a.n++;
    const sgx = (m.spawn.x / m.tile) | 0, sgy = (m.spawn.y / m.tile) | 0;
    spawns.add(sgx + ',' + sgy); if (m.exit) exits.add(m.exit.x + ',' + m.exit.y);
    if (m.grid[sgy * m.w + sgx] === C.T_HAZARD) startInHaz++;

    for (let y = 1; y < m.h - 1; y++) for (let x = 1; x < m.w - 1; x++) {
      if (m.grid[y * m.w + x] !== C.T_HAZARD) continue;
      hazTot++; a.haz++;
      // GARANZIA: mai attaccata a un muro -> si puo' sempre girarle intorno invece di incassare danno
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++)
        if (m.grid[(y + dy) * m.w + (x + dx)] === C.T_WALL) hazNearWall++;
      if (m.exit && m.exit.x === x && m.exit.y === y) hazOnExit++;
      if (Math.hypot(x - sgx, y - sgy) <= 7) hazNearStart++;
    }

    propTot += m.props.length;
    const bag = th.propMix || [];
    if (bag.length) for (const p of m.props) { /* le feature usano tipi fuori dal bag: conta solo che il bag sia USATO */ }
    if (bag.length && !m.props.some(p => bag.indexOf(p.type) >= 0)) offBag++;

    // la mappa resta percorribile DALLA NUOVA PARTENZA fino all uscita
    const d = PF.build(m.grid, m.w, m.h, [{ gx: sgx, gy: sgy }]);
    if (!m.exit || d[m.exit.y * m.w + m.exit.x] < 0) unreach++;
    if (m.exit && Math.hypot(m.exit.x - sgx, m.exit.y - sgy) > Math.min(m.w, m.h) * 0.5) farOK++;
    for (const sp of m.enemySpawns) if (Math.hypot(sp.x - sgx, sp.y - sgy) < 8) { enemyClose++; break; }
  }

  // --- POZZE (T_HAZARD): il tile era gia gestito da server e renderer, non lo generava nessuno ---
  assert(hazTot > 0, 'le mappe generano pozze di pericolo (' + hazTot + ' tessere su ' + N + ' mappe)');
  assert(hazNearWall === 0, 'NESSUNA pozza tocca un muro: si puo' + String.fromCharCode(39) + ' sempre aggirare (violazioni: ' + hazNearWall + ')');
  assert(hazOnExit === 0, 'nessuna pozza sopra il portale di uscita');
  assert(hazNearStart === 0, 'nessuna pozza entro 7 tessere dalla partenza');
  assert(startInHaz === 0, 'i giocatori non nascono mai dentro una pozza');
  // hazMul: la lava deve averne molte piu del ghiaccio
  const lava = byTheme.lava, ice = byTheme.ice;
  if (lava && ice) assert((lava.haz / lava.n) > (ice.haz / ice.n) * 1.4,
    'theme.hazMul conta davvero: lava ' + (lava.haz / lava.n).toFixed(1) + ' tessere/mappa contro ghiaccio ' + (ice.haz / ice.n).toFixed(1));
  for (const id of Object.keys(byTheme)) assert(byTheme[id].haz > 0, 'il tema ' + id + ' genera pozze');

  // --- STRATO AMBIENTALE (theme.propMix) ---
  assert(propTot / N > 30, 'oggetti per mappa oltre i 30 (media ' + (propTot / N).toFixed(1) + ', prima ~30 di sole feature)');
  assert(offBag === 0, 'ogni mappa usa il sacchetto di oggetti del suo tema (theme.propMix)');

  // --- PARTENZA E USCITA VARIABILI ---
  assert(spawns.size > 10, 'la partenza non e piu una costante: ' + spawns.size + ' posizioni distinte su ' + N + ' mappe');
  assert(exits.size > N * 0.4, 'anche l uscita varia: ' + exits.size + ' posizioni distinte su ' + N);
  assert(unreach === 0, 'l uscita resta raggiungibile dalla nuova partenza in tutte le mappe');
  assert(farOK > N * 0.85, 'l uscita resta comunque lontana: la traversata da fare non e sparita (' + farOK + '/' + N + ')');
  assert(enemyClose === 0, 'nessun punto di spawn nemici a ridosso della partenza (le distanze si misurano da li)');

  // --- NOME DELLA ZONA: era scritto nei temi e non lo vedeva nessuno ---
  for (const th of MapGen.THEMES) assert(!!th.name && th.name.length > 3, 'il tema ' + th.id + ' ha un nome da mostrare ("' + th.name + '")');
  // ==========================================================================================
  // v2.20.3 — OGNI TEMA HA LA SUA PIETRA, e nessuna e uguale a un altra
  // ==========================================================================================
  // Fino alla 2.20.2 il chiaro e lo scuro con cui `_bakeCaverna` impasta la roccia erano due costanti
  // scritte nel renderer, uguali per tutte e cinque le grotte: il colore del tema c'era e se lo
  // rimangiava la cottura. Adesso li porta il tema. Questo test non guarda il disegno — guarda che i
  // cinque abbiano DAVVERO cinque pietre diverse, perche' il giorno che qualcuno ricopia una riga per
  // fare in fretta si torna esattamente al punto di partenza, e a occhio non se ne accorge nessuno.
  {
    const ESA = /^#[0-9a-f]{6}$/i;
    const visti = {};
    for (const th of MapGen.THEMES) {
      assert(ESA.test(th.chiaro || ''), 'il tema ' + th.id + ' dice con che chiaro si schiarisce la sua pietra (' + th.chiaro + ')');
      assert(ESA.test(th.scuro || ''), 'e con che scuro la si incide (' + th.scuro + ')');
      assert(!visti[th.chiaro], 'e il chiaro del tema ' + th.id + ' non e lo stesso di ' + visti[th.chiaro]);
      visti[th.chiaro] = th.id;
    }
    // e sono DISTANTI, non cinque sfumature dello stesso grigio: almeno 40 punti di distanza fra due
    // qualunque, sui 255 di ogni canale. Sotto quella soglia, a schermo, non le distingue nessuno.
    const rgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    for (let i = 0; i < MapGen.THEMES.length; i++) for (let j = i + 1; j < MapGen.THEMES.length; j++) {
      const a2 = rgb(MapGen.THEMES[i].chiaro), b2 = rgb(MapGen.THEMES[j].chiaro);
      const d = Math.abs(a2[0] - b2[0]) + Math.abs(a2[1] - b2[1]) + Math.abs(a2[2] - b2[2]);
      assert(d >= 40, MapGen.THEMES[i].id + ' e ' + MapGen.THEMES[j].id + ' hanno pietre diverse a sufficienza (distanza ' + d + ')');
    }
    // il VILLAGGIO no: senza chiaro/scuro la cottura usa i valori di sempre, e il paese resta identico
    assert(!MapGen.VILLAGE_THEME.chiaro && !MapGen.VILLAGE_THEME.scuro, 'il villaggio non prende la pietra colorata: resta com era');
  }
  assert(!!MapGen.VILLAGE_THEME.name, 'anche il mercato ha un nome ("' + MapGen.VILLAGE_THEME.name + '")');

  // --- il pericolo del terreno FUNZIONA davvero in partita ---
  const dt = 1 / C.TICK_RATE;
  let room = null, pl = null, hc = null;
  for (let attempt = 0; attempt < 12 && !hc; attempt++) {
    room = new Room('v162_' + attempt); pl = room.addPlayer('h', { send() {} }, 'H', 'arciere'); room.startGame();
    for (let y = 2; y < room.map.h - 2 && !hc; y++) for (let x = 2; x < room.map.w - 2; x++)
      if (room.map.grid[y * room.map.w + x] === C.T_HAZARD) { hc = { x, y }; break; }
  }
  if (hc) {
    pl.x = hc.x * C.TILE + C.TILE / 2; pl.y = hc.y * C.TILE + C.TILE / 2;
    pl.hp = 200; pl.buffs = {}; const h0 = pl.hp;
    for (let i = 0; i < C.TICK_RATE * 2 && pl.hp >= h0; i++) { pl.x = hc.x * C.TILE + C.TILE / 2; pl.y = hc.y * C.TILE + C.TILE / 2; room.update(dt); }
    assert(pl.hp < h0, 'stare in una pozza fa danno al giocatore');
    const mo = room.spawnMonster('skeleton', pl.x, pl.y, { scaling: Waves.scaling(1, 1) });
    const m0 = mo.hp;
    for (let i = 0; i < C.TICK_RATE * 2 && mo.hp >= m0 && !mo.dead; i++) { mo.x = hc.x * C.TILE + C.TILE / 2; mo.y = hc.y * C.TILE + C.TILE / 2; room.update(dt); }
    assert(mo.hp < m0 || mo.dead, 'e fa danno anche ai mostri: la pozza e un alleato, non solo una trappola');
  } else { assert(false, 'trovata almeno una pozza nella mappa di prova'); }
  ok('novita v1.62 verificate');
}
function testV161() {
  console.log('\n[TEST 32] Novita v1.61 — Nugolo di Pipistrelli (sciame ondeggiante) e Fuoco Fatuo (attraversa i muri)');
  const Mon = require('../shared/monsters.js');
  const bs = Mon.MONSTERS.bat_swarm, wp = Mon.MONSTERS.wisp;
  const dt = 1 / C.TICK_RATE;

  // --- definizioni ---
  assert(bs && bs.ai === 'flock' && bs.bats && bs.swarmN >= 6, 'Nugolo: IA flock, reso come sciame di ' + (bs ? bs.swarmN : 0) + ' sagome');
  assert(wp && wp.ai === 'drifter' && wp.phasing === true, 'Fuoco Fatuo: IA drifter e attraversa i muri (phasing)');
  assert(!bs.sheet && !bs.front && !wp.sheet, 'nessuno dei due usa spritesheet o billboard: solo vettoriale');
  assert(bs.hp < 100 && bs.speed > 150, 'il Nugolo e fragile ma veloce (' + bs.hp + ' PV, ' + bs.speed + ' vel)');
  assert(wp.speed < 90 && wp.leech > 0, 'il Fatuo e lento ma drena vita (leech ' + wp.leech + ')');
  assert(Mon.ORDER.indexOf('bat_swarm') >= 0 && Mon.ORDER.indexOf('wisp') >= 0, 'entrambi presenti nel ROSTER (ORDER)');

  // --- comparsa (v1.61.1): il Nugolo dalla 6, il Fuoco Fatuo dalla 8 ---
  // Il Nugolo sta prima della Sfera d'Ossa: entrambi insegnano a mirare dove il nemico SARA, ma il
  // Nugolo lo chiede col tiro (guidare) e la Sfera coi piedi (schivare di lato).
  // Il Fuoco Fatuo sta dopo, perche' toglie una risposta che a quel punto il giocatore ha gia imparato:
  // mettersi al riparo. Arrivare prima sarebbe una regola tolta prima di averla insegnata.
  const at = w => Waves.poolForWave(w).map(x => x.id);
  assert(!at(4).includes('bat_swarm') && at(5).includes('bat_swarm'), 'il Nugolo entra dall ondata 5');
  assert(!at(6).includes('wisp') && at(7).includes('wisp'), 'il Fuoco Fatuo entra dall ondata 7');
  assert(!at(1).includes('bat_swarm') && !at(1).includes('wisp'), 'nessuno dei due e piu nell ondata 1');
  const wBat = Waves.poolForWave(6).find(x => x.id === 'bat_swarm').weight;
  const wWisp = Waves.poolForWave(8).find(x => x.id === 'wisp').weight;
  assert(wBat === 10 && wWisp === 8, 'pesi nel pool: Nugolo 10, Fuoco Fatuo 8 (sotto lo sciame base a 40)');
  assert(bs.weight === 0 && wp.weight === 0, 'peso 0 nella def: la comparsa la decide solo poolForWave');

  // --- IL FATUO ATTRAVERSA DAVVERO I MURI ---
  // Un mostro normale messo dentro un muro viene ESPULSO da _unstuck (salto secco).
  // Il fatuo invece deve proseguire di suo, passo dopo passo, e uscire da solo.
  const room = new Room('v161'); const pl = room.addPlayer('a', { send() {} }, 'A', 'arciere'); room.startGame();
  // v1.76 — prima si prendeva la PRIMA tessera di muro scandendo da (2,2): con la caverna quella e'
  // in mezzo all'anello di roccia esterno, a otto tessere dal pavimento piu' vicino, e nessun recupero
  // anti-incastro puo' tirarti fuori da li'. Ma non e' nemmeno un caso che capiti giocando. La prova
  // giusta e' una tessera di roccia che TOCCA il pavimento: quella si', ci si finisce dentro davvero.
  let wx = -1, wy = -1;
  for (let gy = 2; gy < room.map.h - 2 && wx < 0; gy++) for (let gx = 2; gx < room.map.w - 2; gx++) {
    if (room.map.grid[gy * room.map.w + gx] !== C.T_WALL) continue;
    let tocca = false;
    for (const d of [[1,0],[-1,0],[0,1],[0,-1]])
      if (room.map.grid[(gy + d[1]) * room.map.w + (gx + d[0])] !== C.T_WALL) tocca = true;
    if (tocca) { wx = gx; wy = gy; break; }
  }
  assert(wx >= 0, 'trovata una tessera di muro per la prova');
  const wcx = wx * C.TILE + C.TILE / 2, wcy = wy * C.TILE + C.TILE / 2;

  const w = room.spawnMonster('wisp', pl.x + 60, pl.y, { scaling: Waves.scaling(1, 1) });
  w.x = wcx; w.y = wcy;
  const bx0 = w.x, by0 = w.y;
  room.update(dt);
  const jump = Math.hypot(w.x - bx0, w.y - by0);
  // _unstuck riporta il mostro sul CENTRO della tessera libera piu vicina: uno scatto dell ordine della
  // tessera. Il fatuo invece avanza di suo, quindi qui deve muoversi di ben meno di mezza tessera.
  assert(jump < C.TILE * 0.5, 'il fatuo NON viene espulso dal muro (spostamento ' + jump.toFixed(2) + 'px, meno di mezza tessera)');
  assert(room.isWallAt(w.x, w.y), 'dopo un tick e ancora DENTRO la roccia: la sta attraversando, non e stato teletrasportato fuori');
  let out = false;
  for (let i = 0; i < C.TICK_RATE * 8 && !out; i++) { room.update(dt); if (!room.isWallAt(w.x, w.y)) out = true; }
  assert(out, 'il fatuo esce dalla roccia da solo (non ci resta intrappolato)');

  // confronto: uno scheletro nella stessa tessera viene rimesso fuori dal recupero anti-incastro
  const sk = room.spawnMonster('skeleton', pl.x + 60, pl.y, { scaling: Waves.scaling(1, 1) });
  sk.x = wcx; sk.y = wcy;
  let skOut = false;
  for (let i = 0; i < C.TICK_RATE * 3 && !skOut; i++) { room.update(dt); if (!room.isWallAt(sk.x, sk.y)) skOut = true; }
  assert(skOut, 'controprova: un nemico normale nel muro viene comunque rimesso fuori');

  // --- IL FATUO DRENA: danneggia e si cura ---
  const room2 = new Room('v161b'); const p2 = room2.addPlayer('b', { send() {} }, 'B', 'arciere'); room2.startGame();
  const w2 = room2.spawnMonster('wisp', p2.x + 40, p2.y, { scaling: Waves.scaling(1, 1) });
  w2.hp = Math.max(1, Math.round(w2.maxHp * 0.4)); const wh0 = w2.hp;
  p2.hp = 500; const ph0 = p2.hp; w2.atkT = 0; room2.events.length = 0;
  let drained = null;
  for (let i = 0; i < C.TICK_RATE * 3 && !drained; i++) { room2.update(dt); drained = room2.events.find(e => e.t === 'drain'); }
  assert(drained && drained.e === w2.eid, 'il fatuo emette l evento drain (il client disegna le scintille)');
  assert(p2.hp < ph0, 'il drenaggio fa danno al giocatore');
  assert(w2.hp > wh0, 'e il fatuo si cura drenando (' + wh0 + ' -> ' + w2.hp + ' PV)');
  assert(w2.hp <= w2.maxHp, 'la cura non supera i PV massimi');

  // --- IL NUGOLO ONDEGGIA: la traiettoria non e una retta verso il giocatore ---
  const room3 = new Room('v161c'); const p3 = room3.addPlayer('c', { send() {} }, 'C', 'arciere'); room3.startGame();
  const b = room3.spawnMonster('bat_swarm', p3.x + 300, p3.y, { scaling: Waves.scaling(1, 1) });
  let maxLat = 0, sgnPos = false, sgnNeg = false;
  for (let i = 0; i < C.TICK_RATE * 4; i++) {
    room3.update(dt);
    const len = Math.hypot(b.mx, b.my); if (len < 1) continue;
    const dx = p3.x - b.x, dy = p3.y - b.y, dl = Math.hypot(dx, dy) || 1;
    const cross = ((dx / dl) * (b.my / len) - (dy / dl) * (b.mx / len));   // deviazione laterale normalizzata
    if (cross > 0.12) sgnPos = true; if (cross < -0.12) sgnNeg = true;
    maxLat = Math.max(maxLat, Math.abs(cross));
  }
  assert(maxLat > 0.30, 'il nugolo devia lateralmente in modo netto (max ' + maxLat.toFixed(2) + ', il solo jitter arriverebbe a ~0.08)');
  assert(sgnPos && sgnNeg, 'e la deviazione cambia lato: serpentina, non una curva sola');

  // --- il nugolo fa danno a contatto ---
  const room4 = new Room('v161d'); const p4 = room4.addPlayer('d', { send() {} }, 'D', 'arciere'); room4.startGame();
  const b4 = room4.spawnMonster('bat_swarm', p4.x + 30, p4.y, { scaling: Waves.scaling(1, 1) });
  p4.hp = 400; const h4 = p4.hp; b4.atkT = 0;
  for (let i = 0; i < C.TICK_RATE * 3 && p4.hp >= h4; i++) room4.update(dt);
  assert(p4.hp < h4, 'il nugolo morde a contatto');

  // --- tenuta: una manciata di entrambi in campo senza NaN ---
  const room5 = new Room('v161e'); const p5 = room5.addPlayer('e', { send() {} }, 'E', 'ranger'); room5.startGame();
  for (let i = 0; i < 6; i++) room5.spawnMonster(i % 2 ? 'bat_swarm' : 'wisp', p5.x + 120 + i * 30, p5.y + i * 20, { scaling: Waves.scaling(3, 1) });
  for (let i = 0; i < C.TICK_RATE * 10; i++) { room5.setInput('e', bot(room5, p5)); room5.update(dt); if (hasNaN(room5)) break; }
  assert(hasNaN(room5) === null, 'nessun NaN con nugoli e fatui in campo');
  let inside = 0; for (const m of room5.monsters) if (m.x < 0 || m.y < 0 || m.x > room5.map.w * C.TILE || m.y > room5.map.h * C.TILE) inside++;
  assert(inside === 0, 'nessun fatuo e uscito dalla griglia attraversando il bordo');

  ok('novita v1.61 verificate');
}
function testV160() {
  console.log('\n[TEST 31] Novita v1.60 — Troll: ancora, impatto e passo allineati; Beholder dall ondata 10');
  const Mon = require('../shared/monsters.js');
  const man = JSON.parse(require('fs').readFileSync(__dirname + '/../public/assets/enemies/troll_sheet/troll.json', 'utf8'));
  const br = Mon.MONSTERS.cave_brute;

  // il manifest descrive davvero le lastre: 5x5 celle da 256 = 1280x1280
  assert(man.cols * man.cell === 1280 && man.rows * man.cell === 1280, 'la griglia del manifest copre la lastra (1280x1280)');
  assert(man.anims.idle.frames <= man.cols * man.rows && man.anims.walk.frames <= 25 && man.anims.attack.frames <= 25, 'i conteggi dei fotogrammi stanno nella griglia');

  // ANCORA: le tre animazioni devono poggiare sulla stessa linea del terreno.
  // Misurate sui PNG nuovi: piedi a y 196-199 (idle), 196-202 (walk), 215-221 (attack).
  // Prima l'attacco era ancorato a 205 e il troll "saltava" di 11px ogni volta che colpiva.
  const feet = { idle: 198, walk: 199, attack: 216 };
  for (const k of ['idle', 'walk', 'attack']) {
    assert(Math.abs(man.anims[k].ay - feet[k]) <= 3, 'ancora ' + k + ' sulla linea dei piedi (ay ' + man.anims[k].ay + ', atteso ~' + feet[k] + ')');
  }

  // IMPATTO: il fotogramma della martellata deve coincidere con l'istante in cui il server fa danno.
  assert(man.anims.attack.hitFrame != null, 'il manifest dichiara il fotogramma d impatto');
  assert(man.anims.attack.hitFrame === 15, 'l impatto e al fotogramma 15 (misurato: piedi a 221, testa a 88)');
  assert(br.slamHit > 0 && br.slamHit < 1, 'il server ha un istante di danno normalizzato (slamHit ' + br.slamHit + ')');
  // la mappatura a due tratti manda hitFrame esattamente su slamHit
  const A = man.anims.attack, hf = A.hitFrame, hp = br.slamHit;
  const frameAt = (a) => { const f = (a <= hp) ? Math.pow(a / hp, 0.72) * hf : hf + ((a - hp) / (1 - hp)) * (A.frames - 1 - hf);
    return Math.max(0, Math.min(A.frames - 1, Math.round(f))); };
  assert(frameAt(hp) === hf, 'a slamHit si vede esattamente il fotogramma d impatto');
  assert(frameAt(0) === 0 && frameAt(1) === A.frames - 1, 'la mappatura copre tutta l animazione');
  let mono = true; for (let i = 1; i <= 20; i++) if (frameAt(i / 20) < frameAt((i - 1) / 20)) mono = false;
  assert(mono, 'la mappatura non torna mai indietro');

  // PASSO AGGANCIATO AL TERRENO: il manifest dichiara quanti px copre un ciclo completo
  assert(man.anims.walk.cyclePx > 0, 'la camminata dichiara cyclePx (passo agganciato alla distanza)');
  const eff = br.speed * Math.max(0.6, Math.min(1.45, 16 / br.radius));
  const cyclesPerSec = eff / man.anims.walk.cyclePx;
  assert(cyclesPerSec > 0.1 && cyclesPerSec < 1.2, 'a velocita nominale la cadenza e plausibile (' + cyclesPerSec.toFixed(2) + ' cicli/s)');
  assert(man.blend > 0, 'e dichiarata la dissolvenza fra animazioni');

  // BEHOLDER dall ondata 10
  assert(!Waves.poolForWave(7).some(x => x.id === 'occhio'), 'niente Beholder alla 7');
  assert(Waves.poolForWave(8).some(x => x.id === 'occhio'), 'Beholder dalla 8');
  assert(Mon.MONSTERS.occhio.maxAlive === 8, 'il tetto di 8 presenze resta');
  ok('novita v1.60 verificate');
}
function testV147() {
  console.log('\n[TEST 22] Novita v1.47 — Troll delle Caverne reso con SPRITE SHEET animato (idle/walk/attack)');
  const Mon = require('../shared/monsters.js');
  const br = Mon.MONSTERS.cave_brute;
  assert(br && br.sheet === 'troll', 'il Troll usa un SPRITE SHEET (sheet=troll)');
  assert(br && !br.puppet && !br.front, 'il Troll non è più puppet/billboard');
  assert(br && br.ai === 'brute' && br.slamWind > 0 && br.slamHit > 0, 'mantiene IA brute + wind-up + istante d\'impatto');
  assert(br && br.name.indexOf('Troll') === 0, 'rinominato "Troll delle Caverne"');
  // simula lo slam a due tempi (invariato): parte il telegrafo e poi lo schianto danneggia ad area
  const room = new Room('v147'); const pl = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  const m = room.spawnMonster('cave_brute', pl.x + 40, pl.y, { scaling: Waves.scaling(4, 1) });
  assert(m && m.type === 'cave_brute' && m.hp > 0, 'il Troll si genera');
  pl.x = m.x + 26; pl.y = m.y; pl.buffs = {}; pl.hp = 500; const hp0 = pl.hp; m.atkT = 0; room.events.length = 0;
  const dt = 1 / C.TICK_RATE; room.update(dt);
  const wind = room.events.find(e => e.t === 'slam_wind');
  assert(wind && wind.e === m.eid, 'il Troll avvia il wind-up (slam_wind con eid) → anima l\'attacco dello sheet');
  for (let i = 0; i < 30; i++) { room.update(dt); if (pl.hp < hp0) break; }
  assert(pl.hp < hp0, 'lo schianto del Troll infligge danni ad area');
  for (let i = 0; i < C.TICK_RATE * 6; i++) { room.setInput('b', bot(room, pl)); room.update(dt); if (hasNaN(room)) break; }
  assert(hasNaN(room) === null, 'nessun NaN col Troll sprite-sheet in campo');
  ok('novita v1.47 verificate');
}
function testV166() {
  console.log('\n[TEST 36] Novita v1.66 — tre classi da dungeon, quattro statistiche, fendente in mischia');
  // --- 1) il roster e' cambiato: niente piu' eroi cyberpunk, niente piu' abilita' Q/E ---
  // v2.18 — IL ROSTER E' DI SETTE CLASSI, non piu' di tre eroi, e le statistiche sono cinque.
  assert(Heroes.ORDER.join(',') === 'barbaro,paladino,maestro,assassino,arciere,mago,warlock', 'il roster e di sette classi');
  assert(!Heroes.HEROES.guerriero && !Heroes.HEROES.ladro, 'guerriero e ladro non esistono piu come classi');
  // ma le IMPALCATURE restano tre, e ogni classe ne dichiara una: e' cio' che tiene in piedi gear.js,
  // il renderer e i mercenari senza riscriverli.
  const CORPI = {};
  for (const id of Heroes.ORDER) CORPI[Heroes.HEROES[id].corpo] = 1;
  assert(Object.keys(CORPI).sort().join(',') === 'guerriero,ladro,mago', 'le impalcature restano tre');
  const SCUOLE = { barbaro: 'melee', paladino: 'melee', maestro: 'melee', assassino: 'agile', arciere: 'ranged', mago: 'magic', warlock: 'pact' };
  for (const id of Heroes.ORDER) assert(Heroes.HEROES[id].weapon.school === SCUOLE[id], id + ' dichiara la scuola ' + SCUOLE[id]);
  // --- 2) CINQUE statistiche da gioco di ruolo, tetto 12 ---
  const ids = Loot.XP_STATS.map(s => s.id).join(',');
  assert(ids === 'st_for,st_cos,st_des,st_int,st_car', 'le statistiche sono Forza/Costituzione/Destrezza/Intelligenza/Carisma');
  assert(Loot.STAT_MAX_LEVEL === 12, 'il tetto per statistica e 12');
  // --- 3) ogni statistica agisce sulla SCUOLA, non su un danno generico: e' cio' che rende
  //        sensate le classi miste future (chiunque puo comprare qualunque statistica) ---
  const room = new Room('v166'); room.startGame(); room.phase = C.PHASE_SHOP;
  const gue = room.addPlayer('g', { send() {} }, 'G', 'paladino');
  const mag = room.addPlayer('m', { send() {} }, 'M', 'mago');
  const lad = room.addPlayer('l', { send() {} }, 'L', 'arciere');
  for (const p of [gue, mag, lad]) p.points = 9999999;
  const d0 = { g: room.effDamage(gue), m: room.effDamage(mag), l: room.effDamage(lad) };
  const c0 = { m: room.effFireDelay(mag), l: room.effFireDelay(lad), g: room.effFireDelay(gue) };
  room.buyStat('g', 'st_for');
  assert(room.effDamage(gue) > d0.g, 'la Forza alza il danno in mischia del guerriero');
  assert(Math.abs(room.effFireDelay(gue) - c0.g) < 1e-9, 'la Forza NON tocca la cadenza');
  room.buyStat('m', 'st_for');
  // v2.18 — il confronto si rifa' da capo: `d0.m` e' stato preso prima che il mago comprasse, e fra i due
  // momenti il ricalcolo riapplica anche il BONUS DI CLASSE (la staffa del mago). Il punto del test resta
  // lo stesso — la Forza non deve toccare la scuola magica — ma si misura sul moltiplicatore di scuola,
  // che e' la cosa che il test vuole davvero difendere.
  assert(Math.abs(mag.stats.schoolDmg.magic - (1 + 0)) < 1e-9 || mag.stats.schoolDmg.magic > 0, 'la scuola magica esiste');
  const magPrima = mag.stats.schoolDmg.magic;
  room.buyStat('m', 'st_for');
  assert(Math.abs(mag.stats.schoolDmg.magic - magPrima) < 1e-9, 'la Forza non fa nulla sulle magie del mago');
  room.buyStat('m', 'st_int');
  assert(room.effDamage(mag) > d0.m, 'l Intelligenza alza il danno delle magie');
  assert(room.effFireDelay(mag) < c0.m, 'l Intelligenza alza anche la cadenza delle magie');
  const sp0 = room.effSpeed(lad);
  room.buyStat('l', 'st_des');
  assert(room.effDamage(lad) > d0.l, 'la Destrezza alza il danno delle frecce');
  assert(room.effFireDelay(lad) < c0.l, 'la Destrezza alza la cadenza');
  assert(room.effSpeed(lad) > sp0, 'la Destrezza alza anche la velocita di movimento');
  const hp0 = room.effMaxHp(gue), dr0 = gue.stats.dmgReduce;
  room.buyStat('g', 'st_cos');
  assert(room.effMaxHp(gue) > hp0 && gue.stats.dmgReduce > dr0, 'la Costituzione da PV e riduzione dei danni');
  // il mago parte piu' LENTO dei vecchi fucilieri: e' l Intelligenza a farlo salire (richiesta esplicita)
  assert(Heroes.HEROES.mago.weapon.fireRate < 3, 'il mago parte con una cadenza bassa (' + Heroes.HEROES.mago.weapon.fireRate + '/s)');
  // --- 4) FENDENTE: nessun proiettile, danno nel settore davanti, niente alle spalle ---
  const r2 = new Room('v166b'); const p = r2.addPlayer('b', { send() {} }, 'B', 'paladino'); r2.startGame();
  // v2.12 — l'arma vera e' quella EQUIPAGGIATA, non quella scritta in heroes.js. Prima le due
  // coincidevano per caso (il pezzo di partenza copiava heroes.js); col grado scarso non coincidono
  // piu', e l'evento 'swing' che il client usa per disegnare il fendente porta i numeri dell'oggetto.
  const w = r2.effWeapon(p); assert(w.melee && w.arcRadius > 0 && w.arcHalf > 0, 'la spada dichiara raggio e apertura dell arco');
  const avanti = losSpot(r2, p, w.arcRadius * 0.6);
  p.aim = Math.atan2(avanti.y - p.y, avanti.x - p.x); p.input.aim = p.aim;
  const m1 = r2.spawnMonster('skeleton', avanti.x, avanti.y, { scaling: Waves.scaling(2, 1) });
  const dietro = { x: p.x - Math.cos(p.aim) * w.arcRadius * 0.6, y: p.y - Math.sin(p.aim) * w.arcRadius * 0.6 };
  const m2 = r2.spawnMonster('skeleton', dietro.x, dietro.y, { scaling: Waves.scaling(2, 1) });
  m1.hp = m1.maxHp = 9999; m2.hp = m2.maxHp = 9999;
  r2.bullets.length = 0; r2.events.length = 0; p.fireCd = 0; r2.firePlayerWeapon(p);
  assert(r2.bullets.filter(b => !b.hostile).length === 0, 'il guerriero non spara proiettili');
  assert(m1.hp < 9999, 'il bersaglio DAVANTI incassa il fendente');
  assert(m2.hp === 9999, 'il bersaglio ALLE SPALLE non viene toccato');
  const sw = r2.events.find(e => e.t === 'swing');
  assert(sw && sw.rad === w.arcRadius && sw.half === w.arcHalf, 'l evento porta al client il raggio e l apertura REALI dell area');
  // il fendente e' ad AREA ma limitato: il piu' vicino incassa tutto, gli altri una quota, e c'e' un tetto
  const r3 = new Room('v166c'); const q = r3.addPlayer('c', { send() {} }, 'C', 'paladino'); r3.startGame();
  const sp = losSpot(r3, q, 50); q.aim = Math.atan2(sp.y - q.y, sp.x - q.x); q.input.aim = q.aim;
  const mob = []; for (let i = 0; i < C.MELEE_MAX_TARGETS + 3; i++) {
    const off = (i - (C.MELEE_MAX_TARGETS + 2) / 2) * 0.12;
    const mm = r3.spawnMonster('skeleton', q.x + Math.cos(q.aim + off) * 55, q.y + Math.sin(q.aim + off) * 55, { scaling: Waves.scaling(2, 1) });
    if (mm) { mm.hp = mm.maxHp = 9999; mob.push(mm); }
  }
  q.fireCd = 0; r3.firePlayerWeapon(q);
  const colpiti = mob.filter(m => m.hp < 9999);
  assert(colpiti.length <= C.MELEE_MAX_TARGETS, 'un fendente colpisce al massimo ' + C.MELEE_MAX_TARGETS + ' bersagli (colpiti ' + colpiti.length + ')');
  if (colpiti.length > 1) { const danni = colpiti.map(m => 9999 - m.hp).sort((a, b) => b - a); assert(danni[danni.length - 1] < danni[0], 'i bersagli secondari incassano meno del primo'); }
  // --- 5) proiettili riconoscibili: scarica per il mago, freccia per il ladro ---
  const r4 = new Room('v166d'); const mg = r4.addPlayer('d', { send() {} }, 'D', 'mago'); r4.startGame();
  r4.bullets.length = 0; mg.fireCd = 0; r4.firePlayerWeapon(mg);
  const scar = r4.bullets.find(b => !b.hostile); assert(scar && scar.scarica && !scar.arrow, 'il mago spara scariche');
  const r5 = new Room('v166e'); const ld = r5.addPlayer('e', { send() {} }, 'E', 'arciere'); r5.startGame();
  r5.bullets.length = 0; ld.fireCd = 0; r5.firePlayerWeapon(ld);
  const frec = r5.bullets.find(b => !b.hostile); assert(frec && frec.arrow && !frec.scarica, 'il ladro spara frecce');
  const snap = r5.snapshot(); const sb = snap.bul.find(b => b.ar);
  assert(sb && sb.a != null, 'lo snapshot porta l orientamento della freccia (serve al client per disegnarla)');
  // --- 6) le armi non si raccolgono piu' dalla mappa e non si comprano ---
  const r6 = new Room('v166f'); r6.addPlayer('f', { send() {} }, 'F', 'arciere'); r6.startGame();
  assert(r6.weaponDrops.length === 0, 'nessuna arma a terra all inizio dell ondata');
  r6.spawnWeapons(); assert(r6.weaponDrops.length === 0, 'spawnWeapons e disattivata');
  assert(!r6.merchantWaresPool().some(w => w.kind === 'weapon'), 'il mercante non vende piu casse armi');
  assert(!Loot.ITEMS.some(i => i.kind === 'weapon'), 'le casse armi non escono piu dalle casse');
  ok('novita v1.66 verificate');
}
function testV167() {
  console.log('\n[TEST 37] Novita v1.67/v2.12 — il fabbro vende OGGETTI, uno per classe, con un bivio per grado');
  const Gear = require('../shared/gear.js');
  // --- 1) il catalogo e' ben formato e ogni classe ha i suoi slot ---
  assert(Object.keys(Gear.SLOTS).join(',') === 'guerriero,mago,ladro', 'gli slot sono definiti per tutte e tre le classi');
  assert(Gear.slotsFor('paladino').join(',') === 'weapon,armor,shield', 'il guerriero ha arma, armatura e scudo');
  assert(Gear.slotsFor('mago').join(',') === 'weapon,armor,boots', 'il mago ha arma, armatura e calzature');
  assert(Gear.slotsFor('arciere').join(',') === 'weapon,armor,boots', 'il ladro ha arma, armatura e calzature');
  assert(new Set(Gear.ITEMS.map(i => i.id)).size === Gear.ITEMS.length, 'nessun id di oggetto duplicato');
  // v2.15.3 — 117 e non piu' 104: il mago ha avuto le sue calzature. Il conto e' 13 per slot e TRE
  // slot per ognuna delle tre classi; finche' il mago ne aveva due, comprava una scala in meno degli
  // altri con le stesse monete.
  // v2.19.1 — il conto e' sui pezzi DI LISTINO. I pezzi di AVVIO (`avvio`) stanno nello stesso elenco
  // ma non sono merce: non si vendono, non si comprano e non entrano nella forma del listino. Oggi ce
  // n'e' uno solo — i Pugnali Sbeccati dell'assassino, che parte da mischia leggera pur avendo il
  // corpo del ladro. Il conto separato serve a questo: se domani qualcuno ne aggiunge uno per sbaglio
  // dentro il listino, qui si vede.
  // v2.19.6 — e i pezzi di una classe SOLA (`solo`: i pugnali dell'assassino) stanno fuori anche loro:
  // sono in vendita, ma non fanno parte della forma comune del listino.
  const listino = Gear.ITEMS.filter(i => !i.avvio && !i.solo), avvii = Gear.ITEMS.filter(i => i.avvio);
  const soloUno = Gear.ITEMS.filter(i => i.solo);
  assert(listino.length === 117, 'il listino comune ha 117 pezzi (13 per slot: 1 scarso + 3 per ognuno degli altri 4 gradi)');
  assert(avvii.length === 3 && avvii.every(i => i.avvio === 'assassino'),
    'tre pezzi di avvio, tutti dell assassino: i due pugnali e il giaco di cuoio');
  assert(soloUno.length === 8 && soloUno.every(i => i.famiglia === 'pugnale' && i.solo.indexOf('assassino') >= 0),
    'e otto pugnali in vendita, due per grado dal 2 al 5');
  for (let rk = 2; rk <= 5; rk++) {
    const coppia = soloUno.filter(i => i.rank === rk);
    const normale = Gear.itemsOfRank('paladino', 'weapon', rk)[0];
    assert(coppia.length === 2 && coppia.every(i => i.cost === Math.round(normale.cost / 2)),
      'grado ' + rk + ': una coppia di pugnali costa quanto un arma');
  }
  for (const it of avvii) {
    assert(Gear.puoAvere(it.avvio, it), it.id + ': lo puo avere la classe a cui e destinato');
    for (const h of ['barbaro', 'paladino', 'maestro', 'assassino', 'arciere', 'mago', 'warlock'])
      if (h !== it.avvio) assert(!Gear.puoAvere(h, it), it.id + ': e nessun altro (' + h + ')');
    for (const b of Gear.BOTTEGHE) for (const sl of ['weapon', 'armor', 'shield', 'boots'])
      assert(!Gear.itemsBottega(it.avvio, b, sl).some(x => x.id === it.id), it.id + ': e non sta su nessun banco');
  }
  for (const h of ['paladino', 'mago', 'arciere']) assert(Gear.slotsFor(h).length === 3, h + ': tre slot, come gli altri due');
  for (const it of Gear.ITEMS) {
    assert(Gear.slotsFor(it.hero).includes(it.slot), it.id + ' sta in uno slot che la sua classe possiede');
    assert(it.name && it.desc && typeof it.cost === 'number' && it.rank >= 1, it.id + ' ha nome, descrizione, prezzo e grado');
    assert(!!Gear.CARATTERI[it.carattere], it.id + ' ha un carattere fra i tre');
    assert(it.slot === 'weapon' ? !!it.weapon : !!it.bonus, it.id + ' porta un blocco arma oppure un blocco bonus');
    // v2.12 — la TINTA non e' un vezzo: il renderer la legge in _palGear per ridipingere il personaggio.
    // Senza, niente crasha e il personaggio smette di cambiare aspetto comprando — cioe' sparisce
    // esattamente la soddisfazione per cui il catalogo esiste. Un pezzo difensivo senza tinta e' rotto.
    if (it.slot !== 'weapon') assert(!!it.tinta && Object.keys(it.tinta).length > 0, it.id + ' porta la tinta che si vede addosso');
  }

  // --- 2) v2.12 — LA REGOLA NUOVA, ed e' il rovescio esatto di quella vecchia ------------------------
  // Fino alla 2.11 questo test controllava che ogni pezzo costasse e valesse piu' del PRECEDENTE NELLA
  // LISTA. Era la regola «un rango piu' alto e' sempre migliore», ed era il problema: l'equipaggiamento
  // era una scala, non una scelta. Adesso ci sono DUE regole, e vanno controllate tutte e due.
  //   FRA I GRADI  si sale: il grado dopo costa di piu' e rende di piu'.
  //   DENTRO UN GRADO  non si sale: i tre pezzi costano uguale e rendono uguale, e cambiano in COME si gioca.
  const dpsOf = w => w.dmg * w.fireRate;
  const valOf = b => (b.maxHpFlat || 0) / 10 + (b.dmgReduce || 0) * 100 + (b.frontale || 0) * 20 + Math.abs(b.speedMult || 0) * 60;
  for (const hero of Object.keys(Gear.SLOTS)) for (const slot of Gear.slotsFor(hero)) {
    const gradi = [];
    for (let r = 1; r <= Gear.maxRank(); r++) gradi.push(Gear.itemsOfRank(hero, slot, r));
    assert(gradi[0].length === 1, hero + '/' + slot + ': il grado scarso ha un pezzo solo, quello con cui parti');
    assert(gradi[0][0].cost === 0, hero + '/' + slot + ': il grado scarso costa 0, non si compra');
    for (let r = 1; r < gradi.length; r++) {
      const g = gradi[r];
      assert(g.length === 3, hero + '/' + slot + ' grado ' + (r + 1) + ': tre scelte, non una');
      assert(new Set(g.map(i => i.carattere)).size === 3, hero + '/' + slot + ' grado ' + (r + 1) + ': i tre caratteri sono tutti diversi');
      // DENTRO il grado: stesso prezzo, e per le armi stesso rendimento (entro il 4%)
      assert(new Set(g.map(i => i.cost)).size === 1, hero + '/' + slot + ' grado ' + (r + 1) + ': i tre costano uguale — se no il bivio e truccato');
      if (slot === 'weapon') {
        const d = g.map(i => dpsOf(i.weapon));
        const sc = (Math.max(...d) - Math.min(...d)) / Math.min(...d);
        assert(sc <= 0.04, hero + ' grado ' + (r + 1) + ': i tre rendono uguale entro il 4% (sono al ' + (sc * 100).toFixed(1) + '%)');
      }
      // FRA i gradi: il migliore del grado dopo batte il migliore del grado prima
      const prima = gradi[r - 1];
      assert(g[0].cost > prima[0].cost, hero + '/' + slot + ': il grado ' + (r + 1) + ' costa piu del grado ' + r);
      if (slot === 'weapon') {
        assert(Math.max(...g.map(i => dpsOf(i.weapon))) > Math.max(...prima.map(i => dpsOf(i.weapon))), hero + '/' + slot + ': il grado ' + (r + 1) + ' rende piu del grado ' + r);
      } else {
        assert(Math.max(...g.map(i => valOf(i.bonus))) > Math.max(...prima.map(i => valOf(i.bonus))), hero + '/' + slot + ': il grado ' + (r + 1) + ' vale piu del grado ' + r);
      }
    }
  }

  // --- 3) v2.12 — OGNI CARATTERE E' IL MIGLIORE IN UNA COSA E IL PEGGIORE NELLE ALTRE DUE ------------
  // Senza questo controllo il "bivio" tornerebbe a essere una scala mascherata: basta che un carattere
  // sia il migliore in due cose su tre e gli altri due non hanno piu' motivo di esistere.
  const P = 'pesante', E = 'equilibrata', L = 'leggera';
  const get = (h, s, r, c) => Gear.itemsOfRank(h, s, r).find(i => i.carattere === c);
  for (let r = 2; r <= Gear.maxRank(); r++) {
    const gp = get('paladino', 'weapon', r, P).weapon, ge = get('paladino', 'weapon', r, E).weapon, gl = get('paladino', 'weapon', r, L).weapon;
    assert(gp.knockback > ge.knockback && ge.knockback > gl.knockback, 'guerriero grado ' + r + ': il rinculo e della PESANTE');
    assert(ge.arcRadius > gp.arcRadius && ge.arcRadius > gl.arcRadius, 'guerriero grado ' + r + ': la portata e della EQUILIBRATA');
    assert(gl.arcHalf > ge.arcHalf && ge.arcHalf > gp.arcHalf, 'guerriero grado ' + r + ': l arco largo e della LEGGERA');
    // v2.19.11 — IL MAGO NON HA PIU' TRE ASSI, NE HA DUE. Paolo: *«togli dalle bacchette l'ampiezza
    // della bolla e lascia solo danno e frequenza»*. Quindi qui non si controlla piu' chi ha la bolla
    // piu' grande: si controlla che la larghezza, la velocita' e la gittata NON siano un asse —
    // devono essere identiche fra i tre caratteri — e che il bivio sia tutto su danno e cadenza.
    const mp = get('mago', 'weapon', r, P).weapon, me2 = get('mago', 'weapon', r, E).weapon, ml = get('mago', 'weapon', r, L).weapon;
    assert(mp.r === me2.r && me2.r === ml.r, 'mago grado ' + r + ': la scarica e larga uguale per tutti e tre');
    assert(mp.range === me2.range && me2.range === ml.range, 'mago grado ' + r + ': la gittata e uguale per tutti e tre');
    assert(mp.bulletSpeed === me2.bulletSpeed && me2.bulletSpeed === ml.bulletSpeed, 'mago grado ' + r + ': la scarica viaggia uguale per tutti e tre');
    assert(mp.pierce === me2.pierce && me2.pierce === ml.pierce, 'mago grado ' + r + ': la perforazione non e un asse del mago');
    assert(mp.dmg > me2.dmg && me2.dmg > ml.dmg, 'mago grado ' + r + ': il colpo che pesa e della PESANTE');
    assert(ml.fireRate > me2.fireRate && me2.fireRate > mp.fireRate, 'mago grado ' + r + ': la cadenza e della LEGGERA');
    const lp = get('arciere', 'weapon', r, P).weapon, le = get('arciere', 'weapon', r, E).weapon, ll = get('arciere', 'weapon', r, L).weapon;
    assert(lp.range > le.range && le.range > ll.range, 'ladro grado ' + r + ': la gittata e della PESANTE');
    assert(le.pierce >= lp.pierce && le.pierce > ll.pierce, 'ladro grado ' + r + ': la perforazione e della EQUILIBRATA');
    assert(ll.fireRate > le.fireRate && le.fireRate > lp.fireRate, 'ladro grado ' + r + ': la cadenza e della LEGGERA');
  }
  // la cadenza del mago: quella EQUILIBRATA resta 1,5/s a ogni grado — e' la firma della classe, e sono
  // gli altri due caratteri a scostarsene, non il grado.
  for (let r = 1; r <= Gear.maxRank(); r++) {
    const eq = get('mago', 'weapon', r, E);
    if (eq) assert(eq.weapon.fireRate === 1.5, 'mago grado ' + r + ': la bacchetta equilibrata tiene la cadenza della classe');
  }

  // --- 4) a runtime: cambio libero, ricalcolo da zero, niente roba di altre classi ---
  const room = new Room('v167'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  room.wave = 3; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');   // v1.79 — il villaggio e una sezione del menu
  p.coins = 100000; alBanco(room, p, 'ladro');
  const partenza = Gear.startingGear('arciere');
  // v2.18.1 — comprare mette solo nell'inventario. Qui interessa l'EFFETTO del pezzo addosso, non il
  // gesto dell'acquisto (provato nel TEST 12), quindi un aiuto locale fa i due passi insieme.
  // v2.19 — e prima di comprare ci si SPOSTA al banco che vende quel pezzo: con tre botteghe la
  // posizione fa parte dell'acquisto, e un aiuto che la ignora proverebbe a comprare archi dal fabbro.
  const compraEIndossa = (id, mano) => { alBancoDi(room, p, Gear.BY_ID[id]); room.buyGear('b', id); room.equipaggia('b', id, mano || 'manoDx'); };
  assert(room.effWeapon(p).name === Gear.BY_ID[partenza.manoDx].name, 'l arciere parte con l arco scarso (' + Gear.BY_ID[partenza.manoDx].name + ')');
  const sp0 = room.effSpeed(p);
  const stivali = get('arciere', 'boots', 3, E);
  compraEIndossa(stivali.id); assert(room.effSpeed(p) > sp0, 'gli stivali migliori aumentano la velocita');
  compraEIndossa(partenza.boots); assert(Math.abs(room.effSpeed(p) - sp0) < 1e-9, 'tornando alle pezze la velocita torna esatta (nessun bonus rimasto appiccicato)');
  const d0 = room.effDamage(p), v0 = room.effWeapon(p).bulletSpeed;
  const arcoLungo = get('arciere', 'weapon', 3, P);
  compraEIndossa(arcoLungo.id);
  assert(room.effDamage(p) > d0 && room.effWeapon(p).bulletSpeed > v0, 'l arco pesante fa piu danno e tira piu veloce di quello di partenza');
  assert(room.effWeapon(p).school === 'ranged', 'la scuola resta quella della classe, non dell oggetto');
  // la perforazione arriva davvero fino al PROIETTILE: e' dell'equilibrata, ed e' il suo motivo di esistere
  const arcoPerf = get('arciere', 'weapon', 3, E);
  compraEIndossa(arcoPerf.id);
  room.bullets.length = 0; p.fireCd = 0; room.firePlayerWeapon(p);
  const fr = room.bullets.find(b => !b.hostile);
  assert(fr && fr.arrow && fr.pierce >= arcoPerf.weapon.pierce, 'la freccia dell arco equilibrato perfora quanto dice la scheda (' + (fr ? fr.pierce : '?') + ')');
  // --- 5) i PV non superano mai il massimo quando si scende di armatura ---
  const q = room.addPlayer('c', { send() {} }, 'C', 'paladino');
  q.coins = 100000; q.x = room.gearMerchant.x; q.y = room.gearMerchant.y;
  const corazzona = get('paladino', 'armor', 5, P), scudino = get('paladino', 'shield', 2, E);
  const indossa2 = (id, mano) => { room.buyGear('c', id); room.equipaggia('c', id, mano || 'manoDx'); };
  indossa2(corazzona.id); q.hp = room.effMaxHp(q);
  room.equipaggia('c', Gear.startingGear('paladino').armor);
  assert(q.hp <= room.effMaxHp(q), 'togliendo l armatura i PV rientrano nel nuovo massimo');
  indossa2(scudino.id, 'manoSx');
  // --- 6) lo snapshot porta al client cio' che si vede addosso ---
  const snap = room.snapshot(); const me = snap.players.find(x => x.i === 'b');
  assert(me && me.wp === arcoPerf.id, 'lo snapshot porta l arma equipaggiata (serve a disegnare l arco)');
  const gg = snap.players.find(x => x.i === 'c');
  assert(gg && gg.sh === scudino.id, 'e lo scudo impugnato (lo scudo a torre si disegna piu grande)');
  ok('novita v1.67/v2.12 verificate');
}
function testV168() {
  console.log('\n[TEST 38] Novita v1.68 — tetto a 30 vivi con coda, e snapshot magro');
  // v2.16 — SEMINATO. Questa prova falliva circa una volta su quattro, e non per un difetto della coda:
  // se nell'ondata sorteggiata capitano delle LARVE, quelle si fanno esplodere da sole. Muoiono senza che
  // nessuno le uccida, liberano posto nell'arena e la coda ne versa altre — quindi «quanti hanno lasciato
  // la coda» supera il tetto pur restando tutto in ordine. L'invariante vera (coda + contatore coincidono,
  // arena piena fino al tetto) e' controllata due righe piu' sotto e non dipende dal sorteggio.
  // Si semina, come per le altre tre prove legate al caso della mappa, e si rimette a posto alla fine.
  const _rndVero38 = Math.random; Math.random = MU.seedRng(0x0D1C);
  // --- 1) il tetto e' 30 e l'ondata NON perde nessuno: gli altri restano in coda ---
  assert(C.MAX_ALIVE === 14, 'il tetto dei nemici vivi in solitario e 14');
  const room = new Room('v168'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  room.wave = 17; room.mode = Waves.modeForWave(17); room.phase = C.PHASE_COMBAT;
  const w = Waves.buildWave(20, 6, room.mode);      // ondata volutamente enorme: 80+ nemici
  room.waveList = w.list; room.waveScaling = w.scaling; room.pending = w.list.length; room._peakAlive = 0;
  const totale = w.list.length;
  assert(totale > room.tettoVivi(), 'la prova usa un ondata piu grande del tetto (' + totale + ')');
  // il giocatore va tenuto in piedi: 30 nemici addosso a un fermo lo ammazzano, la partita finisce e con
  // essa la generazione — misureremmo il gameover, non la coda.
  const dt = 1 / C.TICK_RATE; let picco = 0;
  for (let i = 0; i < C.TICK_RATE * 60; i++) { p.hp = room.effMaxHp(p); p.down = false; p.dead = false; room.update(dt); picco = Math.max(picco, room.monsters.length); }
  const tetto = room.tettoVivi();   // v1.96 — dall'ondata 9 in poi non e' piu' MAX_ALIVE: e' MAX_ALIVE_TARDI
  assert(picco <= tetto, 'in campo non ce ne sono mai piu di ' + tetto + ' (picco ' + picco + ')');
  // nessuno sta uccidendo, quindi l'arena resta piena e la coda NON puo' svuotarsi: la prova e' che il
  // conto torni sempre — quelli che non entrano sono in coda, non spariti.
  // NB: in campo possono essercene piu' di quanti ne ha versati la coda, perche' negromanti e melme ne
  // aggiungono di loro (evocazioni e scissioni). L'invariante che conta e' un'altra: la coda e il contatore
  // dei mancanti devono dire la stessa cosa, cioe' nessuno viene perso per strada.
  assert(room.waveList.length === room.pending, 'coda e contatore coincidono: nessuno perso (' + room.waveList.length + ' vs ' + room.pending + ')');
  assert(room.pending > 0, 'i nemici in eccesso stanno aspettando in coda (' + room.pending + ' di ' + totale + ')');
  assert(totale - room.pending <= tetto, 'e ne e uscito solo quanti ne stanno in campo');
  assert(room.monsters.length === tetto, 'l arena resta piena fino al tetto (' + tetto + ')');
  // ora si uccide: la coda deve ricominciare a versare
  for (let k = 0; k < 12; k++) { const m = room.monsters.find(x => !x.dead); if (m) room.killMonster(m, null); }
  room.monsters = room.monsters.filter(x => !x.dead);
  const inCoda = room.pending;
  for (let i = 0; i < C.TICK_RATE * 6; i++) { p.hp = room.effMaxHp(p); p.down = false; p.dead = false; room.update(dt); }
  assert(room.pending < inCoda, 'uccidendo, la coda ricomincia a versare (da ' + inCoda + ' a ' + room.pending + ')');
  assert(room.waveList.length === room.pending, 'e coda e contatore restano allineati anche dopo');
  // --- 2) due velocita' di rifornimento: salita normale, rimpiazzo quasi immediato ---
  // (si guarda il timer scelto, non il tempo reale: e' cio' che decide il ritmo)
  const r2 = new Room('v168b'); r2.addPlayer('c', { send() {} }, 'C', 'arciere'); r2.startGame();
  r2.wave = 17; r2.phase = C.PHASE_COMBAT; r2.mode = Waves.modeForWave(17);
  const w2 = Waves.buildWave(20, 6, r2.mode); r2.waveList = w2.list; r2.waveScaling = w2.scaling; r2.pending = w2.list.length; r2._peakAlive = 0;
  const q2 = r2.players.get('c');
  const tetto2 = r2.tettoVivi();
  for (let i = 0; i < C.TICK_RATE * 60 && r2.monsters.length < tetto2; i++) { q2.hp = r2.effMaxHp(q2); q2.down = false; q2.dead = false; r2.update(dt); }
  q2.hp = r2.effMaxHp(q2); q2.down = false; q2.dead = false; r2.update(dt);   // un tick in piu': il picco si registra a inizio update
  assert(r2.monsters.length === tetto2, 'l arena si riempie fino al tetto (' + tetto2 + ')');
  assert(r2._peakAlive === tetto2, 'il picco raggiunto viene ricordato');
  for (let k = 0; k < 8; k++) { const m = r2.monsters.find(x => !x.dead); if (m) r2.killMonster(m, null); }
  r2.monsters = r2.monsters.filter(x => !x.dead);
  r2.spawnTimer = 0; r2.update(dt);
  assert(r2.spawnTimer <= 0.22, 'aperto un buco, il rimpiazzo e quasi immediato (' + r2.spawnTimer.toFixed(2) + 's)');
  // --- 3) SNAPSHOT MAGRO: la parte immutabile viaggia una volta sola ---
  const r3 = new Room('v168c'); const q = r3.addPlayer('d', { send() {} }, 'D', 'mago'); r3.startGame();
  r3.phase = C.PHASE_COMBAT; r3.wave = 8;
  for (let i = 0; i < 25; i++) { const pos = r3.randomSpawnPos(); r3.spawnMonster('skeleton', pos.x, pos.y, { scaling: Waves.scaling(8, 1) }); }
  const pieno = r3.snapshot();
  assert(pieno.mon.every(m => m.t && m.mhp), 'lo snapshot PIENO porta sempre tipo e PV massimi');
  assert(pieno.players.every(x => x.n && x.h), 'e nome ed eroe di ogni giocatore');
  const primo = r3.snapshot(true);
  assert(primo.mon.every(m => m.t && m.mhp), 'il primo snapshot magro presenta i mostri per intero');
  const dopo = r3.snapshot(true);
  assert(dopo.mon.every(m => m.t === undefined && m.mhp === undefined), 'nei successivi la parte immutabile non si ripete');
  assert(dopo.mon.every(m => m.e != null && m.x != null && m.y != null && m.hp != null), 'ma posizione e PV ci sono sempre');
  assert(dopo.players.every(x => x.n === undefined), 'idem per nome ed eroe del giocatore');
  assert(JSON.stringify(dopo).length < JSON.stringify(pieno).length * 0.75, 'lo snapshot magro pesa almeno un quarto in meno');
  // un mostro che compare DOPO va presentato lo stesso
  const pos = r3.randomSpawnPos(); const nuovo = r3.spawnMonster('darkmage', pos.x, pos.y, { scaling: Waves.scaling(8, 1) });
  const terzo = r3.snapshot(true);
  const rec = terzo.mon.find(m => m.e === nuovo.eid);
  assert(rec && rec.t === 'darkmage' && rec.mhp, 'un mostro comparso dopo viene presentato quando arriva');
  assert(terzo.mon.filter(m => m.t !== undefined).length === 1, 'e solo lui: gli altri restano magri');
  // chi ENTRA adesso non ha cache, quindi deve ricevere tutto
  const nuovoGioc = r3.addPlayer('e', { send() {} }, 'E', 'arciere');
  assert(nuovoGioc._needFull === true, 'chi si collega e marcato per ricevere uno snapshot pieno');
  assert(r3.snapshot().mon.every(m => m.t), 'e lo snapshot pieno gliele ridice tutte');
  // --- 4) i flag a zero non si mandano affatto ---
  const m0 = dopo.mon[0];
  assert(m0.fl === undefined && m0.el === undefined, 'i flag che valgono 0 non occupano spazio');
  Math.random = _rndVero38;
  ok('novita v1.68 verificate');
}
function testV169() {
  console.log('\n[TEST 39] Livelli, ranghi e punti — impianto v1.79 (tetto 15, scaglioni, 18 punti)');
  const Lv = require('../shared/levels.js');
  // --- 1) IL TETTO E' 15 ---
  assert(Lv.MAX_LEVEL === 15, 'il tetto ai livelli e 15');
  assert(Lv.levelForXp(0) === 1 && Lv.levelForXp(199) === 1, 'sotto la prima soglia si resta al livello 1');
  assert(Lv.levelForXp(200) === 2, 'a 200 XP si sale al 2');
  assert(Lv.levelForXp(9470) === 15, 'a 9.470 XP si e di livello 15');
  assert(Lv.levelForXp(999999) === 15, 'e oltre non si sale piu, per quanta esperienza si raccolga');
  let cresce = true; for (let L = 3; L <= 15; L++) if (Lv.xpStep(L) <= Lv.xpStep(L - 1)) cresce = false;
  assert(cresce, 'ogni livello costa piu del precedente');
  // gli ultimi due scalini sono i piu' cari: e' cio' che tiene il livello 15 oltre l'ondata 16
  assert(Lv.xpStep(15) > Lv.xpStep(13) && Lv.xpStep(14) > Lv.xpStep(12), 'gli ultimi due scalini sono i piu ripidi');
  const pr = Lv.progress(Lv.xpForLevel(7) + 100);
  assert(pr.level === 7 && pr.frac > 0 && pr.frac < 1 && !pr.cap, 'il progresso fra due livelli e una frazione sensata');
  const prTop = Lv.progress(Lv.xpForLevel(15) + 5000);
  assert(prTop.cap === true && prTop.frac === 1 && prTop.need === 0, 'al tetto la barra e piena e non si divide per zero');

  // --- 2) LA SCALETTA (v2.16): attive a 1, 7, 13 · passive a 3, 5, 9, 11 · specializzazione al 15 ---
  // Prima le passive stavano a 3-6-9-12 e le attive a 8 e 14: misurato, voleva dire prima abilita'
  // all'ondata 12 di 20 e seconda all'ondata 18. Adesso i due elenchi si alternano sui dispari e si
  // comincia con un'abilita' in mano.
  assert(Lv.SCAGLIONI.length === 4, 'le passive restano quattro');
  assert(Lv.SCAGLIONI.map(x => x.lvl).join(',') === '3,5,9,11', 'ai livelli 3, 5, 9 e 11');
  assert(Lv.SCAGLIONI.map(x => x.tier).join(',') === 'uncommon,rare,epic,divine', 'e in ordine: non comune, raro, epico, divino');
  assert(Lv.tierForLevel(9) === 'epic' && !Lv.tierForLevel(6) && !Lv.tierForLevel(12) && !Lv.tierForLevel(15), 'solo quei quattro livelli danno una passiva');
  assert(Lv.ABIL_SLOT.map(x => x.lvl).join(',') === '1,7,13', 'le attive stanno ai livelli 1, 7 e 13');
  assert(Lv.ABIL_SLOT.map(x => x.slot).join(',') === '1,2,3', 'e gli slot si chiamano come i tasti che li attivano');
  assert(Lv.slotPerLivello(1) === 1 && Lv.slotPerLivello(7) === 2 && Lv.slotPerLivello(13) === 3 && !Lv.slotPerLivello(8) && !Lv.slotPerLivello(14),
    'la prima attiva si apre al livello 1, non all 8: prima di entrare nel primo livello');
  // I due elenchi non devono MAI cadere sullo stesso livello: chi sale di uno sceglierebbe due volte e
  // una delle due scelte sembrerebbe un errore.
  for (const s2 of Lv.SCAGLIONI) assert(!Lv.slotPerLivello(s2.lvl), 'il livello ' + s2.lvl + ' da una passiva e nient altro');
  assert(Lv.prossimaScelta(1) === 3 && Lv.prossimaScelta(3) === 5 && Lv.prossimaScelta(5) === 7 && Lv.prossimaScelta(7) === 9
      && Lv.prossimaScelta(9) === 11 && Lv.prossimaScelta(11) === 13 && Lv.prossimaScelta(13) === 0,
    'le sette scelte si alternano sui dispari: 1, 3, 5, 7, 9, 11, 13');
  // E LA SCALETTA IN ONDATE, che e' la misura da cui e' nata la v2.16: le attive arrivavano all'ondata
  // 12 e 18 di 20. Questo blocco rifa' il conto ogni volta — se qualcuno tocca l'XP o la composizione
  // delle ondate e le scelte scivolano in fondo, si rompe qui e non in partita.
  {
    const xpOnd = (w, giri) => { let t = 0; for (let k = 0; k < giri; k++) { const l = Waves.buildWave(w, 1, Waves.modeForWave(w)).list;
      for (const it of l) t += Math.round((require('../shared/monsters.js').MONSTERS[it.type].xp || 0) * (it.elite ? 2.5 : 1)); } return Math.round(t / giri); };
    let cum = 0; const onda = {};
    for (let w = 1; w <= 19; w++) { cum += Waves.isBossWave(w) ? 500 : xpOnd(w, 12);
      for (let l = 2; l <= Lv.MAX_LEVEL; l++) if (!onda[l] && cum >= Lv.xpForLevel(l)) onda[l] = w; }
    onda[1] = 1;
    assert(onda[1] === 1, 'la prima attiva e in mano dall ondata 1');
    assert(onda[7] >= 8 && onda[7] <= 13, 'la seconda attiva arriva a meta partita, non in fondo (ondata ' + onda[7] + ')');
    assert(onda[3] >= 2 && onda[3] <= 6, 'la prima passiva arriva presto (ondata ' + onda[3] + ')');
    assert(onda[11] && onda[11] <= 17, 'l ultima passiva arriva in tempo per servire (ondata ' + onda[11] + ')');
  }

  // --- 3) I RANGHI: 3/6/9/12/15, con la specializzazione in fondo ---
  assert(Lv.RANK_LEVELS.join(',') === '1,3,6,9,12,15', 'le fasce sono 1, 3, 6, 9, 12 e 15');
  assert(Lv.rankForLevel(1) === 1 && Lv.rankForLevel(2) === 1, 'ai livelli 1-2 si porta il titolo di partenza');
  assert(Lv.rankForLevel(3) === 2 && Lv.rankForLevel(12) === 5 && Lv.rankForLevel(15) === Lv.RANK_SPEC, 'e si sale di fascia a ogni scaglione');
  assert(Lv.puntiPerRango(1) === 0 && Lv.puntiPerRango(Lv.RANK_SPEC) === 0, 'la prima fascia e quella della specializzazione non danno punti');
  // v2.16 — I RANGHI SONO SOLO SCENICI: danno il titolo e basta. Deciso da Paolo sapendo il prezzo,
  // che e' -4 punti statistica su tutta la partita (da 18 a 14).
  assert([1, 2, 3, 4, 5, 6].every(r => Lv.puntiPerRango(r) === 0), 'nessuna fascia da piu punti: i ranghi sono scenici');
  // v2.18.1 — I RANGHI NON DANNO PIU' UN TITOLO. Il test affermava sei titoli per classe; adesso il
  // titolo mostrato E' IL NOME DELLA CLASSE, sempre e a ogni livello. Parole di Paolo dopo la prima
  // partita: *«la classe di partenza rimane la stessa, invece il Barbaro e diventato un Razziatore»*.
  // La tabella resta vuota e non cancellata, come CARDS e SPECS, e il test difende la regola nuova.
  assert(Object.keys(Lv.RANK_NAMES).length === 0, 'la tabella dei titoli di rango e vuota');
  for (const h of Heroes.ORDER) {
    const atteso = Heroes.HEROES[h].name;
    for (const L of [1, 3, 7, 13, 15]) {
      assert(Lv.rankName(h, L, null) === atteso, h + ': al livello ' + L + ' il titolo e ancora ' + atteso);
    }
  }


  // --- 4) I PUNTI: 18 esatti, costo fisso 1 ---
  assert(Lv.statPointCost(0) === 1 && Lv.statPointCost(11) === 1, 'ogni livello di statistica costa 1 punto, a qualunque altezza');
  assert(Lv.statPointsTo(12) === 12, 'cappare una statistica costa 12 punti');
  const budget = (Lv.MAX_LEVEL - 1) * Lv.POINTS_PER_LEVEL + [1, 2, 3, 4, 5, 6].reduce((a, r) => a + Lv.puntiPerRango(r), 0);
  assert(budget === 14, 'in tutta la run si guadagnano 14 punti (' + budget + ')');
  assert(12 + 2 === budget, 'una statistica al tetto (12) piu due punti sparsi: il bilancio non arriva a due mezze');
  assert(12 * 2 > budget, 'e cappare DUE statistiche resta impossibile');

  // --- 5) il conto vero, giocato: 18 punti in mano al livello 15 ---
  const room = new Room('v169'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  room.addXp(p, 99999);
  assert(p.level === 15, 'con esperienza a volonta si arriva al 15 (' + p.level + ')');
  assert(p.points === 14, 'e in mano ci sono 14 punti (' + p.points + ')');
  assert((p.scaglioniDovuti || []).join(',') === 'uncommon,rare,epic,divine', 'con le quattro passive in coda');
  // v2.18 — IL TERZO SLOT ADESSO ENTRA IN CODA, e questa e' la novita' della versione. Fino alla 2.17
  // restava fuori perche' era vuoto — Paolo doveva ancora decidere cosa metterci — e il livello 13
  // dava solo il punto statistica. Adesso ogni classe ha le sue due candidate anche al 13.
  //
  // La FIRMA del livello 1 invece non entra e non entrera' mai: non si sceglie, si riceve.
  assert(!!p.abil[0], 'la firma e gia in mano dal livello 1, senza averla scelta');
  assert((p.abilDovute || []).join(',') === '2,3', 'e in coda ci sono il secondo e il terzo slot');
  assert(!p.specOffer, 'e nessun bivio di specializzazione: non esistono piu');
  const xp0 = p.xpPool; room.addXp(p, 5000);
  assert(p.xpPool === xp0, 'oltre il tetto l esperienza non si accumula nemmeno');
  // spendere: una cappata piu una a 6, e non resta niente
  room.phase = C.PHASE_SHOP;
  for (let i = 0; i < 12; i++) room.buyStat('b', 'st_des');
  for (let i = 0; i < 2; i++) room.buyStat('b', 'st_cos');
  assert(p.buys.st_des === 12 && p.buys.st_cos === 2 && p.points === 0, 'una al tetto, due punti sparsi, zero avanzati');
  room.buyStat('b', 'st_for');
  assert(!p.buys.st_for, 'e senza punti non si compra piu niente');
  ok('livelli, scaglioni, ranghi e punti verificati');
}
function testV170() {
  console.log('\n[TEST 40] Novita v1.70 — tetto progressivo, XP da piu fonti, LEVEL UP');
  const Lv = require('../shared/levels.js');
  // --- 1) v1.96 — IL TETTO DEI VIVI E' DUE NUMERI: 40 fino all'ottava, 22 dalla nona ---
  // La v1.79.2 lo aveva reso uno solo e alto (40) per non tenere nascosta meta' dell'ondata. Giusto
  // finche' le ondate erano piccole: dalla nona in avanti quaranta mostri in campo non sono un
  // combattimento, sono una calca, e la mappa non si vede piu'. Il TOTALE dell'ondata non cambia —
  // l'eccesso aspetta in coda ed entra man mano che ne muore uno.
  const room = new Room('v170'); const p = room.addPlayer('b', { send() {} }, 'B', 'arciere'); room.startGame();
  // v2.24 — IL TETTO NON DIPENDE PIU' DALL'ONDATA, ma dai GIOCATORI. Era una curva (40 fino
  // all'ottava, 22 dopo); adesso e' 14 sempre, piu' 2 per ogni giocatore oltre il primo.
  assert(C.MAX_ALIVE === 14, 'il tetto in solitario e 14');
  assert(C.MAX_ALIVE_GIOC === 2, 'e cresce di 2 per ogni giocatore in piu');
  for (const w of [1, 2, 5, 8, 9, 15, 20, 30]) { room.wave = w;
    assert(room.tettoVivi() === 14, 'ondata ' + w + ': in solitario il tetto resta 14 (letto ' + room.tettoVivi() + ')'); }
  // il totale dell ondata: dalla settima in poi e FISSO, non cresce piu con l ondata
  assert(Waves.buildWave(7, 1).list.length === C.ONDATA_TOT, 'dalla settima il totale e ' + C.ONDATA_TOT);
  assert(Waves.buildWave(20, 1).list.length === C.ONDATA_TOT, 'e alla ventesima e sempre quello');
  assert(Waves.buildWave(7, 2).list.length === C.ONDATA_TOT + C.ONDATA_TOT_GIOC, 'in due diventa ' + (C.ONDATA_TOT + C.ONDATA_TOT_GIOC));
  // e resta piu grande del tetto: senza questo, le riserve non esisterebbero
  for (const w of [7, 12, 20]) if (!Waves.isBossWave(w))
    assert(Waves.buildWave(w, 1).list.length > 14, 'ondata ' + w + ': il totale supera il tetto, quindi c e una riserva');
  // --- 2) in GRUPPO le ondate crescono e l eccesso resta in coda, senza perdere nessuno ---
  const r2 = new Room('v170b'); const q = r2.addPlayer('c', { send() {} }, 'C', 'arciere'); r2.startGame();
  r2.wave = 12; r2.mode = Waves.modeForWave(12); r2.phase = C.PHASE_COMBAT;
  const w3 = Waves.buildWave(12, 6, r2.mode); r2.waveList = w3.list; r2.waveScaling = w3.scaling; r2.pending = w3.list.length; r2._peakAlive = 0;
  assert(w3.list.length > r2.tettoVivi(), 'in sei, l ondata 12 ha piu nemici del tetto (' + w3.list.length + ' contro ' + r2.tettoVivi() + ')');
  const dt = 1 / C.TICK_RATE; let picco = 0;
  for (let i = 0; i < C.TICK_RATE * 45; i++) { q.hp = r2.effMaxHp(q); q.down = false; q.dead = false; r2.update(dt); let vivi = 0; for (const m of r2.monsters) if (!m.dead) vivi++; picco = Math.max(picco, vivi); }
  assert(picco <= r2.tettoVivi(), 'in campo non se ne vedono mai piu del tetto (picco ' + picco + ' su ' + r2.tettoVivi() + ')');
  assert(picco >= Math.round(r2.tettoVivi() * 0.7), 'ma l arena si riempie davvero (picco ' + picco + ')');
  assert(r2.pending > 0 || r2.monsters.length > 0, 'e quelli in eccesso restano in coda, non spariscono');
  // --- 3) l esperienza arriva da piu fonti ---
  const r3 = new Room('v170c'); const z = r3.addPlayer('d', { send() {} }, 'D', 'mago'); r3.startGame();
  r3.wave = 4;
  const xp0 = z.xpPool;
  r3.applyItem(z, Loot.ITEMS.find(i => i.kind === 'buff'));
  assert(z.xpPool > xp0, 'raccogliere un potenziamento da esperienza');
  const xp1 = z.xpPool;
  r3.crates.length = 0; r3.crates.push({ eid: 1, x: z.x, y: z.y, r: 16, mimic: false, opened: false });
  r3.updatePickups(1 / C.TICK_RATE);
  assert(z.xpPool > xp1, 'aprire una cassa da esperienza');
  assert(C.XP_CASSA > 0 && C.XP_OGGETTO > 0, 'i valori delle fonti stanno nelle costanti, in chiaro');
  // la fonte viene raccontata al client, ma non cambia il conto
  const ev = r3.events.filter(e => e.t === 'xpfonte');
  assert(ev.length >= 2 && ev.every(e => e.k && e.v > 0), 'ogni fonte manda al client quanta XP ha dato e da dove');
  // --- 4) il LEVEL UP viene annunciato anche in mezzo all ondata ---
  const r4 = new Room('v170d'); const u = r4.addPlayer('e', { send() {} }, 'E', 'paladino'); r4.startGame();
  r4.phase = C.PHASE_COMBAT; r4.events.length = 0;
  r4.addXp(u, Lv.xpForLevel(3));
  const lu = r4.events.filter(e => e.t === 'levelup');
  assert(lu.length === 2, 'salendo di due livelli partono due annunci');
  assert(lu[0].who === 'e' && lu[0].lv === 2 && lu[1].lv === 3, 'ognuno porta chi e salito e a che livello');
  assert(lu[0].rank, 'e il titolo del rango, per la scritta sopra la testa');
  ok('novita v1.70 verificate');
}

// ===================== v1.71 — LA CINTURA (consumabili dell'Erborista) =====================
// Le regole da difendere sono quelle decise da Paolo, e ognuna ha il suo assert: tre slot, un tipo per
// slot, tre cariche, rimborso a meta' quando si cambia tipo, cariche che sopravvivono alla morte,
// cooldown CONDIVISO fra i tre slot, nessun cumulo dello stesso effetto, e i quattro moltiplicatori
// delle statistiche che arrivano davvero fino al valore effettivo.
function testV171() {
  console.log('\n[TEST 41] Novita v1.71 — la cintura: pozioni, slot, cooldown, statistiche');
  const conn = { send() {} };

  // --- 1) il banco: assegnare, comprare, i due tetti ---
  const r = new Room('v171a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
  assert(p.belt.length === Pot.SLOTS && p.belt.every(s => s === null), 'si parte con la cintura vuota');
  r.enterMarket();
  assert(!!r.herbalist, "l'Erborista ha un posto nel villaggio");
  assert(!r.map.village.npcs.find(n => n.pot).soon, "e la sua bottega non e' piu' chiusa");
  // lontano dal banco non si compra nulla
  p.x = r.herbalist.x + 900; p.y = r.herbalist.y; p.coins = 500;
  r.pickPotion('a', 0, 'p_cura');
  assert(p.belt[0] === null, 'da lontano il banco non risponde');
  p.x = r.herbalist.x; p.y = r.herbalist.y;
  r.pickPotion('a', 0, 'p_cura');
  assert(p.belt[0] && p.belt[0].id === 'p_cura' && p.belt[0].n === 0, 'assegnare un tipo non regala cariche');
  const c0 = p.coins;
  for (let i = 0; i < 6; i++) r.buyPotion('a', 0);
  assert(p.belt[0].n === Pot.MAX_CHARGES, 'lo slot si ferma a ' + Pot.MAX_CHARGES + ' cariche');
  assert(p.coins === c0 - Pot.BY_ID.p_cura.cost * Pot.MAX_CHARGES, 'e paga solo le cariche che entrano davvero');
  r.pickPotion('a', 1, 'p_cura');
  assert(p.belt[1] === null, 'lo stesso tipo non entra in due slot');
  r.pickPotion('a', 1, 'p_furia'); r.buyPotion('a', 1);
  assert(p.belt[1].id === 'p_furia' && p.belt[1].n === 1, 'un tipo diverso entra');
  // --- 2) cambio tipo: rimborso a META' delle cariche rimaste ---
  const prima = p.coins;
  r.pickPotion('a', 0, 'p_fretta');
  assert(p.coins - prima === Math.floor(Pot.BY_ID.p_cura.cost * Pot.MAX_CHARGES * 0.5), 'cambiare tipo rimborsa meta delle cariche rimaste');
  assert(p.belt[0].id === 'p_fretta' && p.belt[0].n === 0, 'e lo slot riparte vuoto col tipo nuovo');
  // senza monete non si compra
  p.coins = 0; r.buyPotion('a', 1);
  assert(p.belt[1].n === 1, 'senza monete la carica non arriva');

  // --- 3) bere: cooldown CONDIVISO, non uno per slot ---
  const r2 = new Room('v171b'); const q = r2.addPlayer('b', conn, 'B', 'mago'); r2.startGame(); r2.phase = C.PHASE_COMBAT;
  q.belt[0] = { id: 'p_cura', n: 2 }; q.belt[1] = { id: 'p_furia', n: 2 }; q.belt[2] = { id: 'p_fretta', n: 2 };
  q.hp = 10;
  assert(r2.usePotion(q, 0) === true, 'la prima bevuta passa');
  assert(q.hp > 10, 'la cura cura');
  assert(q.belt[0].n === 1, 'e consuma una carica');
  assert(r2.usePotion(q, 0) === false, 'la seconda subito dopo no');
  assert(r2.usePotion(q, 1) === false, 'e nemmeno da un ALTRO slot: il cooldown e uno solo');
  assert(q.belt[1].n === 2, 'lo slot rifiutato non perde la carica');
  q.potCd = 0;
  assert(r2.usePotion(q, 1) === true, 'passato il cooldown si ribeve');
  // slot vuoto e slot senza cariche non fanno nulla
  q.potCd = 0; q.belt[1].n = 0;
  assert(r2.usePotion(q, 1) === false, 'uno slot esaurito non beve');
  q.potCd = 0; const senza = new Room('v171c'); const z = senza.addPlayer('c', conn, 'C', 'arciere'); senza.startGame();
  assert(senza.usePotion(z, 0) === false, 'uno slot non assegnato non beve');

  // --- 4) niente cumulo: la seconda dose fa RIPARTIRE, non raddoppia ---
  q.potCd = 0; q.buffs = {}; q.belt[1] = { id: 'p_furia', n: 2 };
  r2.usePotion(q, 1); const d1 = q.buffs.po_dmg;
  r2.updatePlayers(1.0);   // un secondo di gioco: la durata cala
  assert(q.buffs.po_dmg < d1, 'la durata scende mentre giochi');
  q.potCd = 0; r2.usePotion(q, 1);
  assert(Math.abs(q.buffs.po_dmg - d1) < 0.001, 'la seconda dose riporta la durata al pieno, non al doppio');

  // --- 5) i quattro moltiplicatori arrivano fino al valore EFFETTIVO ---
  const r3 = new Room('v171d'); const g = r3.addPlayer('d', conn, 'D', 'paladino'); r3.startGame(); r3.phase = C.PHASE_COMBAT;
  const dmg0 = r3.effDamage(g), del0 = r3.effFireDelay(g), spd0 = r3.effSpeed(g);
  g.belt[0] = { id: 'p_furia', n: 9 }; g.belt[1] = { id: 'p_frenesia', n: 9 }; g.belt[2] = { id: 'p_fretta', n: 9 };
  r3.usePotion(g, 0); g.potCd = 0; r3.usePotion(g, 1); g.potCd = 0; r3.usePotion(g, 2);
  assert(Math.abs(r3.effDamage(g) / dmg0 - (1 + Pot.EFF.dmg)) < 0.01, 'la Furia alza il danno del valore dichiarato');
  assert(Math.abs(del0 / r3.effFireDelay(g) - (1 + Pot.EFF.rate)) < 0.01, 'la Frenesia alza la cadenza');
  assert(Math.abs(r3.effSpeed(g) / spd0 - (1 + Pot.EFF.speed)) < 0.01, 'la Fretta alza la velocita');
  const senzaFor = r3.effDamage(g);
  g.buys.st_for = 12;
  assert(r3.effDamage(g) > senzaFor, 'la FORZA rende la Furia piu forte');
  assert(Math.abs(r3.effDamage(g) / dmg0 - (1 + Pot.EFF.dmg * Pot.powMult(12))) < 0.01, 'esattamente del moltiplicatore dichiarato');
  // Costituzione: quanto cura
  g.buffs = {}; g.potCd = 0; g.buys.st_cos = 0; g.hp = 1; g.belt[0] = { id: 'p_cura', n: 2 };
  const mx = r3.effMaxHp(g); r3.usePotion(g, 0); const curaBase = g.hp - 1;
  g.buys.st_cos = 12; g.hp = 1; g.potCd = 0; r3.usePotion(g, 0);
  const curaAlta = g.hp - 1;
  assert(curaAlta > curaBase, 'la COSTITUZIONE fa curare di piu');
  assert(Math.abs(curaAlta / (mx * Pot.EFF.heal * Pot.healMult(12)) - 1) < 0.05, 'quanto dichiarato dal catalogo');
  // Intelligenza: quanto dura
  g.buys.st_int = 0; g.potCd = 0; g.belt[1] = { id: 'p_furia', n: 9 }; r3.usePotion(g, 1); const durBase = g.buffs.po_dmg;
  g.buys.st_int = 12; g.potCd = 0; r3.usePotion(g, 1);
  assert(g.buffs.po_dmg > durBase, "l'INTELLIGENZA allunga gli effetti");
  // Destrezza: quanto in fretta ribevi
  g.buys.st_des = 0; g.potCd = 0; r3.usePotion(g, 1); const cdBase = g.potCd;
  g.buys.st_des = 12; g.potCd = 0; r3.usePotion(g, 1);
  assert(g.potCd < cdBase, 'la DESTREZZA accorcia il cooldown');
  assert(g.potCd >= Pot.COOLDOWN * 0.6 - 0.001, 'ma non sotto il pavimento previsto');

  // --- 6) le cariche SOPRAVVIVONO alla morte (regola scelta da Paolo) ---
  const r4 = new Room('v171e'); const h = r4.addPlayer('e', conn, 'E', 'paladino'); r4.startGame(); r4.phase = C.PHASE_COMBAT;
  h.belt[0] = { id: 'p_cura', n: 2 }; h.belt[1] = { id: 'p_furia', n: 1 };
  h.down = true; h.downT = -1; h.lives = 2; r4.updatePlayers(1 / C.TICK_RATE);
  assert(h.lives === 1, 'la vita si perde');
  assert(h.belt[0].n === 2 && h.belt[1].n === 1, 'le cariche restano: quello che hai comprato e tuo finche non lo bevi');

  // --- 7) la cintura arriva al client, e compatta ---
  const snap = r4.snapshot();
  const me = snap.players.find(x => x.i === 'e');
  assert(Array.isArray(me.bt) && me.bt.length === Pot.SLOTS, 'lo snapshot porta i due slot della cintura');
  assert(Pot.SLOTS === 2, 'che dalla v2.16 sono due: i numeri sono passati alle abilita e le pozioni a Q/E');
  assert(me.bt[0][0] === Pot.BY_ID.p_cura.idx && me.bt[0][1] === 2, 'per indice e cariche, non per nome');
  // lo slot vuoto viaggia come uno zero, non come un oggetto: si svuota il secondo e si riguarda.
  h.belt[1] = null;
  assert(r4.snapshot().players.find(x => x.i === 'e').bt[1] === 0, 'e uno slot vuoto costa uno zero, non un oggetto');
  h.belt[1] = { id: 'p_furia', n: 1 };
  h.potCd = 3; h.potCdMax = 6;
  assert(Math.abs(r4.snapshot().players.find(x => x.i === 'e').pcd - 0.5) < 0.01, 'e il cooldown viaggia come frazione, per il velo');

  // --- 8) il catalogo e coerente con se stesso ---
  const ids = {};
  for (const it of Pot.POTIONS) {
    assert(!ids[it.id], 'ogni pozione ha un id suo: ' + it.id); ids[it.id] = 1;
    assert(it.cost > 0 && it.name && it.icon && it.desc, it.name + ' e completa');
    if (it.kind === 'heal') assert(it.heal > 0, it.name + ' cura una frazione dei PV');
    else assert(it.buff && it.dur > 0, it.name + ' ha una chiave di buff e una durata');
  }
  // un buff che nessuno legge non farebbe nulla e nessun test se ne accorgerebbe: qui si controlla
  const room = fs.readFileSync(require('path').join(__dirname, '..', 'server', 'Room.js'), 'utf8');
  for (const it of Pot.POTIONS) if (it.buff) assert(room.includes('p.buffs.' + it.buff), 'la chiave ' + it.buff + ' e davvero letta da Room.js');
  ok('novita v1.71 verificate');
}


// ===================== v1.72 — IL BANDITORE: magazzino e taglie =====================
// Due mestieri in uno, e ognuno cambia una regola che c'era prima: l'equipaggiamento sostituito non
// sparisce piu' (magazzino, riequipaggiabile gratis) e la partita ha per la prima volta un obiettivo
// che sopravvive alla singola ondata (la taglia).
function testV172() {
  console.log('\n[TEST 42] Novita v1.72 — Banditore: magazzino, ricompra, taglie');
  const conn = { send() {} };

  // --- 1) il magazzino ---
  const r = new Room('v172a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
  const partenza = Object.keys(p.owned);
  // v2.18.1 — le caselle sono quattro (due mani, armatura, calzature) ma non tutte piene: il guerriero
  // non ha calzature, il mago non ha scudo. Si contano i pezzi VERI, non le caselle.
  const pieni = Object.keys(p.gear).filter(k => p.gear[k]).length;
  assert(partenza.length === pieni, "l'equipaggiamento di partenza e gia nel magazzino");
  assert(partenza.every(id => Gear.BY_ID[id]), 'e sono oggetti veri');
  r.enterMarket();
  assert(!!r.bandit, 'il Banditore ha un posto nel villaggio');
  assert(!r.map.village.npcs.find(n => n.bnd).soon, "e la sua bottega non e piu chiusa");
  p.x = r.gearMerchant.x; p.y = r.gearMerchant.y; p.coins = 1000;
  // v2.12 — due armi qualunque della stessa classe, prese dal catalogo: qui si prova il MAGAZZINO,
  // non i nomi. Due gradi diversi perche' costino diverso e il conto delle monete abbia senso.
  const GearB = require('../shared/gear.js');
  const armaA = GearB.itemsOfRank('paladino', 'weapon', 2, 'pesante').find(i => i.carattere === 'pesante');
  const armaB = GearB.itemsOfRank('paladino', 'weapon', 3, 'equilibrata').find(i => i.carattere === 'equilibrata');
  r.buyGear('a', armaA.id); r.buyGear('a', armaB.id);
  // v2.18.1 — COMPRARE NON EQUIPAGGIA PIU'. Le due armi finiscono tutte e due nell'inventario, e
  // nessuna delle due va in mano da sola: e' il giocatore a decidere quale impugnare, e con che mano.
  assert(p.owned[armaA.id] && p.owned[armaB.id], 'le due comprate sono tutte e due nell inventario');
  assert(p.gear.manoDx !== armaB.id, "e l'ultima comprata NON si e messa in mano da sola");
  const c1 = p.coins;
  r.equipaggia('a', armaA.id, 'manoDx');
  assert(p.coins === c1, 'impugnare un oggetto posseduto non costa nulla');
  assert(p.gear.manoDx === armaA.id, 'ed e davvero in mano');

  // --- 2) v1.82: LA RICOMPRA NON C'E' PIU'. Il Banditore non ricompra le armi: quel posto al banco
  // adesso e' il reclutamento dei mercenari. Cio' che possiedi resta tuo e si rimette addosso gratis dal
  // Fabbro, che e' il comportamento che conta ed e' verificato qui sopra.
  assert(typeof r.sellGear !== 'function', 'la rivendita delle armi al Banditore e stata tolta');
  assert(!!p.owned[armaB.id] && !!p.owned[armaA.id], 'e cio che hai comprato resta comunque tuo');

  // --- 3) le tre offerte ---
  p.x = r.bandit.x; p.y = r.bandit.y;
  const off = r._offerteTaglie(p);
  assert(off.length === Bnt.OFFERTE, 'il banco appende ' + Bnt.OFFERTE + ' taglie');
  assert(new Set(off.map(o => o.k)).size === off.length, 'tutte di tipo diverso: si sceglie fra tre cose diverse');
  assert(off.every(o => o.n > 0 && o.pay > 0 && o.testo), 'ognuna ha bersaglio, paga e una frase leggibile');
  const stesse = r._offerteTaglie(p);
  assert(JSON.stringify(stesse) === JSON.stringify(off), 'riavvicinarsi NON rigenera le offerte (niente slot machine)');
  r.takeBounty('a', 1);
  assert(p.bounty && p.bounty.k === off[1].k, 'si accetta quella che si clicca');
  assert(p.bountyOffer === null, 'e le altre due spariscono');
  const tenuta = p.bounty.k;
  r.takeBounty('a', 0);
  assert(p.bounty.k === tenuta, 'una taglia alla volta: la seconda non entra');

  // --- 4) ogni tipo di taglia si completa DAVVERO e paga il dichiarato ---
  for (const kind of Bnt.KINDS.map(k => k.id)) {
    const rr = new Room('v172_' + kind); const q = rr.addPlayer('b', conn, 'B', 'paladino'); rr.startGame(); rr.phase = C.PHASE_COMBAT;
    q.bounty = Bnt.istanza(kind, 4, 'skeleton', 'Zombie Putrido');
    const bers = q.bounty.n, paga = q.bounty.pay, c0 = q.coins;
    for (let i = 1; i <= bers; i++) {
      if (kind === 'combo') rr.bountyTick(q, 'combo', i);
      else if (kind === 'specie') rr.bountyTick(q, 'specie', 1, 'skeleton');
      else rr.bountyTick(q, kind, 1);
    }
    assert(q.bounty === null, 'la taglia "' + kind + '" si chiude al bersaglio');
    assert(q.coins - c0 === paga, 'e paga esattamente quello che aveva promesso (' + kind + ')');
  }
  // la specie sbagliata non conta
  const rs = new Room('v172s'); const z = rs.addPlayer('c', conn, 'C', 'mago'); rs.startGame();
  z.bounty = Bnt.istanza('specie', 4, 'slime', 'Melma');
  for (let i = 0; i < 60; i++) rs.bountyTick(z, 'specie', 1, 'skeleton');
  assert(z.bounty && z.bounty.have === 0, 'il contratto mirato conta SOLO la specie giusta');
  // la combo e un record, non una somma
  z.bounty = Bnt.istanza('combo', 4);
  rs.bountyTick(z, 'combo', 5); rs.bountyTick(z, 'combo', 3);
  assert(z.bounty.have === 5, 'la combo tiene il RECORD, non somma i colpi');

  // --- 5) gli agganci veri: uccidere e aprire casse fanno salire il contatore da soli ---
  const rk = new Room('v172k'); const k = rk.addPlayer('d', conn, 'D', 'paladino'); rk.startGame(); rk.phase = C.PHASE_COMBAT;
  k.bounty = Bnt.istanza('caccia', 3);
  const m1 = rk.spawnMonster('skeleton', k.x + 60, k.y); rk.killMonster(m1, k);
  assert(k.bounty.have === 1, 'uccidere un nemico fa salire la caccia grossa');
  k.bounty = Bnt.istanza('specie', 3, 'slime', 'Melma');
  const m2 = rk.spawnMonster('skeleton', k.x + 60, k.y); rk.killMonster(m2, k);
  assert(k.bounty.have === 0, 'ma non il contratto su un altro tipo');
  const m3 = rk.spawnMonster('slime', k.x + 60, k.y); rk.killMonster(m3, k);
  assert(k.bounty.have === 1, 'quello giusto si');
  k.bounty = Bnt.istanza('elite', 3);
  const m4 = rk.spawnMonster('skeleton', k.x + 60, k.y); m4.elite = true; rk.killMonster(m4, k);
  assert(k.bounty.have === 1, 'un elite conta per le teste grosse');
  k.bounty = Bnt.istanza('casse', 3);
  rk.crates.length = 0; rk.crates.push({ eid: 1, x: k.x, y: k.y, r: 16, mimic: false, opened: false });
  rk.updatePickups(1 / C.TICK_RATE);
  assert(k.bounty.have === 1, 'aprire una cassa conta per il saccheggio');

  // --- 6) "nessun caduto": si azzera se cade qualcuno, si chiude se l'ondata finisce pulita ---
  const rn = new Room('v172n'); const w = rn.addPlayer('e', conn, 'E', 'paladino'); rn.startGame(); rn.phase = C.PHASE_COMBAT;
  w.bounty = Bnt.istanza('illeso', 3);
  assert(w.noLifeLost === true, "a inizio ondata la lavagna e pulita");
  w.down = true; w.downT = -1; w.lives = 2; rn.updatePlayers(1 / C.TICK_RATE);
  assert(w.noLifeLost === false, 'perdere una vita la sporca');
  rn.monsters.length = 0; rn.pending = 0; chiudiOndata(rn);
  assert(w.bounty && w.bounty.have === 0, "e l'ondata finita non chiude la taglia");
  // ondata nuova, questa volta pulita
  const rn2 = new Room('v172n2'); const w2 = rn2.addPlayer('f', conn, 'F', 'paladino'); rn2.startGame(); rn2.phase = C.PHASE_COMBAT;
  w2.bounty = Bnt.istanza('illeso', 3); const c5 = w2.coins;
  rn2.monsters.length = 0; rn2.pending = 0; chiudiOndata(rn2);
  assert(w2.bounty === null && w2.coins > c5, "un'ondata senza cadute la chiude e la paga");

  // --- 7) la taglia arriva al client, e si vede in partita ---
  const rc = new Room('v172c'); const y = rc.addPlayer('g', conn, 'G', 'arciere'); rc.startGame();
  y.bounty = Bnt.istanza('caccia', 5); y.bounty.have = 7;
  const me = rc.snapshot().players.find(x => x.i === 'g');
  assert(me.bo && me.bo.h === 7 && me.bo.n === y.bounty.n, 'lo snapshot porta avanzamento e bersaglio');
  assert(me.bo.t && me.bo.i, 'con la frase e l icona, per la riga in alto a sinistra');
  y.bounty = null;
  assert(rc.snapshot().players.find(x => x.i === 'g').bo === undefined, 'senza taglia non si spende un byte');

  // --- 8) ogni tipo del catalogo e DAVVERO agganciato a qualcosa in Room.js ---
  const room = fs.readFileSync(require('path').join(__dirname, '..', 'server', 'Room.js'), 'utf8');
  for (const kk of Bnt.KINDS) assert(room.includes("'" + kk.id + "'"), 'il tipo ' + kk.id + ' e agganciato in Room.js');
  ok('novita v1.72 verificate');
}


// ===================== v1.73 — LA CARTOMANTE: 5 carte accese =====================
// La novita' rischiosa non e' il tetto: e' che per la prima volta un potere si puo' TOGLIERE. Fino alla
// 1.72 le carte si sommavano dentro il personaggio e non uscivano piu'. Ora tutto si ricostruisce da zero
// (statistiche base -> statistiche comprate -> carte accese -> sinergie), e questi test difendono proprio
// quello: che spegnere e riaccendere riporti ESATTAMENTE al punto di prima, senza lasciare residui.
function testV173() {
  console.log('\n[TEST 43] La Cartomante e chiusa (v1.79) — e con lei il tetto delle carte accese');
  const conn = () => { const box = []; return { box, send(s) { box.push(JSON.parse(s)); } }; };
  // --- 1) la funzione non risponde piu, nemmeno stando addosso al banco ---
  const c1 = conn();
  const room = new Room('v173'); const p = room.addPlayer('b', c1, 'B', 'arciere'); room.startGame();
  assert(C.CARTOMANTE_ATTIVA === false, 'la manopola dice che e chiusa');
  room.phase = C.PHASE_MARKET; room.seer = { x: p.x, y: p.y };
  c1.box.length = 0;
  room.offerSeer(p, 1);
  assert(!c1.box.some(m => m.t === C.MSG.OFFER_SEER), 'il tavolo della Cartomante non si apre piu');
  assert(c1.box.some(m => m.ev && m.ev.t === 'seer_chiusa'), 'ma il gioco dice che la struttura c e e la funzione no');
  // --- 2) nemmeno un messaggio costruito a mano riapre la porta ---
  room.phase = C.PHASE_SHOP; p.scaglioniDovuti = ['uncommon'];
  room.offerBoon(p); room.pickBoon('b', p.boonOffer[0]);
  const presa = Object.keys(p.boonsOwned)[0];
  assert(!!presa, 'un abilita e stata presa');
  room.phase = C.PHASE_MARKET;
  room.toggleCard('b', presa);
  assert(p.cardOn[presa] === 1, 'e non si puo spegnere: le abilita sono sempre attive');
  // --- 3) IL TETTO DELLE CINQUE NON ESISTE PIU: quattro passive, tutte accese ---
  const r2 = new Room('v173b'); const q = r2.addPlayer('c', conn(), 'C', 'paladino'); r2.startGame(); r2.phase = C.PHASE_SHOP;
  for (const t of ['uncommon', 'rare', 'epic', 'divine']) {
    q.scaglioniDovuti = [t]; r2.offerBoon(q); r2.pickBoon('c', q.boonOffer[0]);
  }
  const prese = Object.keys(q.boonsOwned).filter(id => q.boonsOwned[id] > 0);
  assert(prese.length === 4, 'quattro abilita prese in una run (' + prese.length + ')');
  assert(prese.every(id => q.cardOn[id] === 1), 'e sono accese tutte e quattro');
  assert(r2._carteAccese(q) === 4, 'il conteggio delle attive dice quattro');
  // --- 4) il ricalcolo da zero regge lo stesso: e la rete di sicurezza di tutti i bonus ---
  const dm = q.stats.dmgMult; r2._recomputeBoons(q);
  assert(Math.abs(q.stats.dmgMult - dm) < 1e-9, 'ricalcolare da zero non cambia niente (' + dm + ' -> ' + q.stats.dmgMult + ')');
  ok('la Cartomante e chiusa e le abilita restano sempre attive');
}
function testV174() {
  console.log('\n[TEST 44] Novita v1.74 — Ostessa: riposo a pagamento, e i PV massimi non curano');
  const conn = { send() {} };
  const prendi = (r, p, id) => { p.boonOffer = [id]; r.pickBoon(p.id, id); };

  // --- 1) alzare il massimo non cura, da nessuna parte arrivi ---
  const r = new Room('v174a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame(); r.phase = C.PHASE_SHOP;
  p.hp = 100; p.points = 30; const mx0 = r.effMaxHp(p);
  r.buyStat('a', 'st_cos');
  assert(r.effMaxHp(p) === mx0 + 20, 'la Costituzione alza il massimo di 20');
  assert(p.hp === 100, 'ma NON cura: altrimenti l Ostessa non servirebbe a niente');
  for (let i = 0; i < 5; i++) r.buyStat('a', 'st_cos');
  assert(p.hp === 100, 'nemmeno sei punti di fila curano di un solo PV');
  prendi(r, p, 'bar_colosso'); assert(p.hp === 100, 'e nemmeno Colosso');
  prendi(r, p, 'pal_baluardo'); assert(p.hp === 100, 'e nemmeno Scudo Vitale');
  assert(r.effMaxHp(p) > mx0 + 100, 'il massimo pero e cresciuto davvero');

  // --- 2) v1.79 — le abilita' non si spengono piu' (Cartomante chiusa): il tetto dei PV sale e basta.
  const r2 = new Room('v174b'); const q = r2.addPlayer('b', conn, 'B', 'paladino'); r2.startGame(); r2.phase = C.PHASE_SHOP;
  const mxPrima = r2.effMaxHp(q); q.hp = mxPrima;
  prendi(r2, q, 'bar_colosso');
  assert(r2.effMaxHp(q) > mxPrima, 'Colosso alza il tetto dei PV');
  assert(q.hp === mxPrima, 'ma non cura: i PV correnti restano quelli');
  r2.toggleCard('b', 'bar_colosso');
  assert(q.cardOn.bar_colosso === 1 && r2.effMaxHp(q) > mxPrima, 'e non si puo spegnere');
  // ma il debito non restituisce piu' di quanto era stato tolto
  q.hp = 40; r2.toggleCard('b', 'bar_colosso'); r2.toggleCard('b', 'bar_colosso');
  assert(q.hp === 40, 'se non c era nulla da tagliare non c e nulla da rendere');

  // --- 3) l'Ostessa ---
  const r3 = new Room('v174c'); const g = r3.addPlayer('c', conn, 'C', 'paladino'); r3.startGame();
  r3.enterMarket();
  assert(!!r3.innkeeper, "l'Ostessa ha un posto nel villaggio");
  assert(!r3.map.village.npcs.find(n => n.inn).soon, 'e la sua bottega non e piu chiusa');
  assert(r3.map.village.npcs.every(n => !n.soon), 'con lei il villaggio e completo: nessuna bottega chiusa');
  const mx = r3.effMaxHp(g);
  g.hp = 100; g.coins = 500;
  // da lontano non risponde
  g.x = r3.innkeeper.x + 900; g.y = r3.innkeeper.y;
  r3.restAtInn('c');
  assert(g.hp === 100 && g.coins === 500, 'da lontano il focolare non risponde');
  g.x = r3.innkeeper.x; g.y = r3.innkeeper.y;
  const conto = r3._contoOstessa(g);
  assert(conto.manca === mx - 100, 'il conto sa quanti PV mancano');
  assert(conto.pieno === Math.ceil((mx - 100) * C.INN_PER_HP), 'e il prezzo e proporzionale, non forfettario');
  r3.restAtInn('c');
  assert(g.hp === mx, 'pagando si torna al massimo');
  assert(g.coins === 500 - conto.pieno, 'e si paga esattamente il conto');
  // due volte non si paga
  const c2 = g.coins; r3.restAtInn('c');
  assert(g.coins === c2, 'a PV pieni non si paga nulla');
  // cura parziale
  g.hp = 100; g.coins = 20;
  const conto2 = r3._contoOstessa(g);
  assert(conto2.curabili > 0 && conto2.curabili < conto2.manca, 'con poche monete si compra una cura parziale');
  r3.restAtInn('c');
  assert(g.hp === 100 + conto2.curabili, 'e i PV comprati arrivano tutti');
  assert(g.coins === 20 - conto2.spesa, 'pagando solo quelli');
  // senza monete
  g.coins = 0; const hp0 = g.hp; r3.restAtInn('c');
  assert(g.hp === hp0, 'senza monete non si cura nulla');
  // piu' conveniente della pozione di Cura, come da taratura
  const Pot2 = require('../shared/potions.js');
  const perPvPozione = Pot2.BY_ID.p_cura.cost / (mx * Pot2.EFF.heal);
  assert(C.INN_PER_HP < perPvPozione, 'il riposo costa meno a PV della pozione, che pero si beve fra i nemici');

  // --- 4) il riposo comprato cancella il debito, altrimenti sarebbe vita regalata ---
  const r4 = new Room('v174d'); const h = r4.addPlayer('d', conn, 'D', 'paladino'); r4.startGame(); r4.phase = C.PHASE_SHOP;
  prendi(r4, h, 'bar_colosso');
  r4.enterMarket();
  h.hp = 100;                                    // si combatte e ci si fa male
  h.x = r4.innkeeper.x; h.y = r4.innkeeper.y; h.coins = 500;
  r4.restAtInn('d');
  assert(h.hp === r4.effMaxHp(h), 'al focolare si torna al massimo');
  assert(h.hpDebt === 0, 'e i PV pagati cancellano il debito: non si viene rimborsati due volte');
  const hpPagato = h.hp;
  // v2.6 — la Cartomante non c'e' piu' (e' diventata l’oracolo, che per ora non fa nulla), quindi
  // `r4.seer` e' null: la carta si riaccende da dove si e', e la regola che conta resta la stessa.
  r4.toggleCard('d', 'bar_colosso');
  assert(h.hp === hpPagato, 'e riaccendere la carta non regala i PV gia comprati');

  // --- 5) cio' che arriva al client ---
  const inviati = []; const conn5 = { send(x) { inviati.push(JSON.parse(x)); } };
  const r5 = new Room('v174e'); const z = r5.addPlayer('e', conn5, 'E', 'arciere'); r5.startGame();
  r5.enterMarket(); z.x = r5.innkeeper.x; z.y = r5.innkeeper.y; z.hp = 30; z.coins = 120;
  inviati.length = 0; r5.offerInn(z, 1);
  const off = inviati.filter(m => m.t === C.MSG.OFFER_INN).pop();
  assert(off && off.hp === 30 && off.mx === Math.round(r5.effMaxHp(z)), 'il pannello riceve vita e massimo');
  assert(off.manca > 0 && off.pieno > 0 && off.perHp === C.INN_PER_HP, 'quanto manca, quanto costa e il prezzo al PV');
  r5.updateInn();
  const snap = r5.snapshot().players.find(x => x.i === 'e');
  assert(snap.ni === 1, 'e avvicinandosi lo snapshot dice che sei al focolare');
  ok('novita v1.74 verificate');
}


// ===================== v1.74.1 — NIENTE CURE AUTOMATICHE =====================
// Chiudere un'ondata regalava il 25% dei PV massimi: una cura gratuita, silenziosa e ripetuta ogni ondata,
// che rendeva l'Ostessa un lusso invece che un servizio. Questi test tengono chiusa quella porta e tutte
// quelle vicine: i PV salgono solo se qualcuno paga, beve, raccoglie o compie qualcosa.
function testV1741() {
  console.log('\n[TEST 45] v1.74.1 — nessuna cura automatica fra un ondata e l altra');
  const conn = { send() {} };

  // --- 1) fine ondata: i danni restano addosso ---
  const r = new Room('v1741a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
  r.phase = C.PHASE_COMBAT; p.hp = 80;
  r.monsters.length = 0; r.pending = 0; chiudiOndata(r);
  assert(r.phase === C.PHASE_SHOP, "l'ondata si chiude");
  assert(p.hp === 80, 'e i PV restano quelli con cui l hai finita: nessuna cura di fine ondata');
  // nemmeno tre ondate di fila la rimettono
  for (let w = 0; w < 3; w++) { r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 0; chiudiOndata(r); }
  assert(p.hp === 80, 'nemmeno dopo tre ondate');

  // --- 2) chi e a TERRA viene comunque rialzato: quello non e curare ---
  const r2 = new Room('v1741b'); const q = r2.addPlayer('b', conn, 'B', 'mago'); r2.startGame();
  r2.phase = C.PHASE_COMBAT; q.down = true; q.hp = 0;
  r2.monsters.length = 0; r2.pending = 0; chiudiOndata(r2);
  assert(!q.down && q.hp > 0, 'chi era a terra torna in gioco, altrimenti resterebbe fuori per sempre');

  // --- 3) le uniche vie che alzano i PV sono quelle che qualcuno ha CHIESTO ---
  const r3 = new Room('v1741c'); const g = r3.addPlayer('c', conn, 'C', 'paladino'); r3.startGame(); r3.phase = C.PHASE_COMBAT;
  const mx = r3.effMaxHp(g);
  // pozione della cintura
  g.hp = 50; g.belt[0] = { id: 'p_cura', n: 1 }; r3.usePotion(g, 0);
  assert(g.hp > 50, 'la pozione di Cura cura (l hai comprata e bevuta)');
  // oggetto raccolto a terra
  g.hp = 50; r3.applyItem(g, Loot.ITEMS.find(i => i.kind === 'heal'));
  assert(g.hp > 50, 'la Pozione di Salute raccolta a terra cura');
  // l'Ostessa
  const r4 = new Room('v1741d'); const h = r4.addPlayer('d', conn, 'D', 'arciere'); r4.startGame();
  r4.enterMarket(); h.x = r4.innkeeper.x; h.y = r4.innkeeper.y; h.hp = 50; h.coins = 500;
  r4.restAtInn('d');
  assert(h.hp > 50 && h.coins < 500, "l'Ostessa cura, e si paga");

  // --- 4) alzare il massimo non cura MAI, da nessuna porta ---
  const r5 = new Room('v1741e'); const z = r5.addPlayer('e', conn, 'E', 'paladino'); r5.startGame(); r5.phase = C.PHASE_SHOP;
  z.hp = 100; z.points = 30; z.coins = 2000;
  r5.buyStat('e', 'st_cos'); assert(z.hp === 100, 'Costituzione: no');
  z.boonOffer = ['bar_colosso']; r5.pickBoon('e', 'bar_colosso'); assert(z.hp === 100, 'carta Colosso: no');
  z.boonOffer = ['pal_baluardo']; r5.pickBoon('e', 'pal_baluardo'); assert(z.hp === 100, 'carta Scudo Vitale: no');
  // mercante errante, offerta "+PV massimi"
  r5.phase = C.PHASE_COMBAT;
  r5.merchant = { x: z.x, y: z.y, wares: [{ id: 'w1', kind: 'maxhp', val: 30, cost: 10, name: 'Talismano' }] };
  r5.buyMerchant('e', 'w1');
  assert(z.hp === 100, 'offerta del Mercante Errante che alza il massimo: no');
  assert(r5.effMaxHp(z) > 100, 'il massimo pero e salito, in tutti e quattro i casi');
  // l'equipaggiamento non ha mai curato, ma che resti cosi'
  const gearHp = z.hp; z.gear.armor = Gear.itemsFor('paladino', 'armor').slice(-1)[0].id; r5._recomputeGear(z);
  assert(z.hp === gearHp, "l'equipaggiamento non cura");

  // --- 5) il codice non deve tornare ad avere scorciatoie: nessun `p.hp +=` in giro ---
  const room = fs.readFileSync(require('path').join(__dirname, '..', 'server', 'Room.js'), 'utf8');
  assert(!/\bp\.hp \+=/.test(room), 'nessun aumento diretto dei PV sparso nel codice (si passa sempre da un min col massimo)');
  ok('novita v1.74.1 verificate');
}

console.log('=================================================='); console.log('  DUNGEON RIFT — SUITE DI TEST (v1.74.1)'); console.log('==================================================');
const T0 = Date.now();
function testV175() {
  console.log('\n[TEST 46] Novita v1.75 — arredo e persone del villaggio: nulla di invisibile, nulla nel muro');
  const MapGen = require('../shared/mapgen.js');
  const path = require('path'), fs2 = require('fs');
  const m = MapGen.generateMarket(777), T = C.TILE;
  const src = fs2.readFileSync(path.join(__dirname, '..', 'public', 'js', 'renderer.js'), 'utf8');

  // --- ogni mobile che la mappa piazza dev'essere DISEGNATO: un tipo scritto male e' un oggetto invisibile ---
  const disegnati = new Set();
  for (const mm of src.matchAll(/case '([a-z_]+)'/g)) disegnati.add(mm[1]);
  disegnati.add('glowspot'); disegnati.add('bonfire');   // non sono case: diventano luci, gestite prima dello switch
  disegnati.add('torch'); disegnati.add('focolare');     // v2.0.1 — anche queste: la fiamma la disegna _flame, viva
  const usati = [...new Set(m.props.map(p => p.type))];
  const orfani = usati.filter(t => !disegnati.has(t));
  assert(orfani.length === 0, 'il renderer sa disegnare tutti i ' + usati.length + ' tipi di arredo (orfani: ' + orfani.join(', ') + ')');

  // --- i mobili nuovi della v1.75 ci sono davvero, uno per stanza ---
  const conta = (t) => m.props.filter(p => p.type === t).length;
  assert(conta('bancone') >= 4, 'ogni mestiere ha il suo bancone (' + conta('bancone') + ')');
  assert(conta('tavolo') >= 4 && conta('panca') >= 8, 'la taverna ha i tavoli con gli sgabelli attorno');
  // v2.0 — le credenze adesso sono tante: una dietro l'ostessa e una per casa (la madia)
  assert(conta('credenza') >= 1, 'e dietro l ostessa la credenza con le bottiglie');
  assert(conta('incudine') === 1 && conta('rastrelliera') >= 4, 'la fucina ha incudine e rastrelliere');
  assert(conta('lavapool') >= 2, 'e la colata di lava in fondo');
  assert(conta('aiuola') === 3 && conta('alambicco') === 1 && conta('mortaio') === 1, 'l erborista ha le piantagioni e i suoi strumenti');
  // v2.0 — i tappeti adesso non sono piu' uno solo: anche qualche casa ne ha uno davanti al focolare
  assert(conta('tappeto') >= 1 && conta('scaffale') >= 4, 'la cartomante ha il tappeto, e ci sono scaffali in giro');
  assert(m.props.some(p => p.type === 'signpost' && p.txt === 'TAGLIE'), 'la bacheca delle taglie e nella stanza del Capitano');
  assert(conta('bones') === 0, 'niente ossa sparse: sembravano asterischi bianchi');

  // --- l'arredo sta ORDINATO nella sua stanza, non sparso a caso ---
  const V = MapGen.VILLAGE;
  const dentro = (x, y, r) => x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1;
  // v2.6 — i varchi escono dalla porta dichiarata da ogni stanza, non piu' da un elenco a parte
  const VARCHI2 = V.rooms.map(r => { const [px, py, lato] = r.porta;
    return lato === 'n' ? [px, py - 1, px + 1, py] : (lato === 's' ? [px, py, px + 1, py + 1] : [px, py, px, py + 1]); });
  const inLink2 = (x, y) => VARCHI2.concat(V.strade).some(L => x >= L[0] && x <= L[2] && y >= L[1] && y <= L[3]);
  let sparsi = 0, inCorridoio = 0;
  for (const p of m.props) {
    const tx = (p.x / T) | 0, ty = (p.y / T) | 0;
    if (['torch', 'hanging_lantern', 'glowspot'].indexOf(p.type) >= 0) continue;   // v2.0.1 — luce, non mobili
    // v2.6 — e nemmeno ragnatele e sassi sono mobili: si attraversano, e stanno agli sbocchi delle vie
    // proprio perche' il paese e' SCAVATO. La regola qui e' 'niente mobili in mezzo alla strada'.
    if (p.type === 'web' || p.type === 'rock') continue;
    // v2.5 — le BANCARELLE stanno in strada per mestiere: un banco del pane dentro una stanza chiusa non
    // e' un banco del pane. Che non tappino il passaggio lo prova la misura delle porte piu' sotto, che
    // tiene conto dei corpi solidi; qui si contano i mobili che in strada NON dovrebbero starci.
    if (p.type === 'bancarella' || (p.type === 'signpost' && p.txt && p.txt !== 'TAGLIE')) continue;
    // v2.6 — e i bracieri del giro della piazza: stanno a meno di due tessere dal battuto, e sono la luce
    if (p.type === 'brazier' && tx >= V.piazza.x0 - 2 && tx <= V.piazza.x1 + 2 && ty >= V.piazza.y0 - 2 && ty <= V.piazza.y1 + 2) continue;
    if (V.rooms.some(r => dentro(tx, ty, r)) || dentro(tx, ty, V.piazza)) continue;
    if (inLink2(tx, ty)) inCorridoio++; else sparsi++;
  }
  assert(sparsi === 0, 'ogni mobile sta in una stanza, nella piazza o lungo un corridoio (' + sparsi + ' fuori posto)');
  // v2.0.1 — le TORCE e le LANTERNE stanno per le strade apposta: sono la luce del villaggio, e non
  // ingombrano niente (la torcia e' a muro, la lanterna sul soffitto). Sopra si contano solo i MOBILI.
  // v2.6 — le TORCE della piazza stanno nello spiazzo, appena fuori dal battuto: e' il loro posto, sono
  // il giro di luce attorno alla piazza. Ingombrano poco (un braciere e' 12 px di raggio) e si contano a
  // parte; la regola vera — che per le strade ci si passi — la prova il flood fill coi corpi solidi.
  assert(inCorridoio <= 2, 'e per le strade si passa: niente mobili in mezzo (' + inCorridoio + ')');

  // --- le persone: il mercante e' un EROE ricolorato e disarmato, non piu' un ritratto frontale ---
  assert(/_vendorPal/.test(src) && /_vendorBase/.test(src), 'i mercanti nascono dalla silhouette degli eroi, con la loro tavolozza');
  assert(/civile/.test(src), 'e sono disarmati: niente elmo, scudo, arco o bastone dietro il bancone');
  assert(/village.extras/.test(src), 'e il renderer disegna anche le comparse');
  assert(m.village.extras.every(e => !e.seated), 'le comparse stanno in piedi: dall alto una figura seduta non si legge');
  ok('novita v1.75 verificate');
}
function testV1752() {
  console.log('\n[TEST 47] Novita v1.75.2 — mobili e persone hanno un corpo: ci sbatti contro, e se ci finisci dentro ti spinge fuori');
  const MapGen = require('../shared/mapgen.js');
  const T = C.TILE;

  // --- i corpi solidi esistono SOLO nel villaggio ---
  const m = MapGen.generateMarket(4242);
  assert(Array.isArray(m.solids) && m.solids.length > 30, 'il villaggio ha i suoi corpi solidi (' + (m.solids || []).length + ')');
  const dungeon = MapGen.generate(1234, 3);
  assert(!dungeon.solids || dungeon.solids.length === 0, 'nelle mappe delle ondate non ce ne sono: li' + "'" + ' in mezzo ai mostri sarebbero un rischio senza guadagno');

  // --- cosa e solido e cosa no ---
  const SOLIDI = ['tavolo', 'bancone', 'incudine', 'alambicco', 'crystal_cluster', 'barrel', 'sack', 'brazier',
                  'candelabra', 'signpost', 'mortaio', 'bonfire', 'credenza', 'scaffale', 'rastrelliera', 'aiuola', 'cratebox',
                  'pozzo', 'focolare', 'letto',   // v2.0 — i tre mobili del villaggio
                  'bancarella',                   // v2.5 — e il banco delle botteghe di contorno
                  'bersaglio'];                   // v2.19 — la balla di paglia dell'archeria
  const PASSANTI = ['tappeto', 'lavapool', 'web', 'flag', 'panca', 'skull', 'hanging_lantern', 'rock', 'glowspot'];
  for (const t of SOLIDI) assert(m.props.some(p => p.type === t), 'nel villaggio c e almeno un "' + t + '"');
  for (const t of PASSANTI) assert(m.props.some(p => p.type === t), 'e almeno un "' + t + '"');
  const persone = m.solids.filter(s2 => s2.chi);
  const nMobili = m.props.filter(p => SOLIDI.indexOf(p.type) >= 0).length;
  const nPassanti = m.props.filter(p => PASSANTI.indexOf(p.type) >= 0).length;
  assert(m.solids.length === nMobili + persone.length,
    'ha un corpo esattamente cio che deve averlo: ' + nMobili + ' mobili + ' + persone.length + ' persone = ' + m.solids.length);
  assert(nMobili + nPassanti === m.props.length,
    'e ogni oggetto del villaggio e classificato, o solido o attraversabile (' + (nMobili + nPassanti) + '/' + m.props.length + ')');
  assert(persone.length === m.village.npcs.length + m.village.extras.length, 'ogni persona del villaggio ha un corpo (' + persone.length + ')');

  // --- la stanza vera: si cammina, si arriva da tutti, e nessuna zona resta tagliata fuori ---
  const room = new Room('v1752'); room.addPlayer('b', { send() {} }, 'B', 'paladino'); room.startGame();
  room.wave = 3; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');   // v1.79 — il villaggio e una sezione del menu
  const p = [...room.players.values()][0];
  assert(!!room.solids && room.solids.length > 30, 'la stanza carica i corpi del villaggio');
  const r = p.radius * 0.8, mm = room.map;
  const libero = (x, y) => !room._blk(x, y, r);
  assert(libero(mm.spawn.x, mm.spawn.y), 'si atterra su spazio libero, non dentro un mobile');

  // riempimento fine (passo 8 px) che rispetta muri E corpi
  const STEP = 8, W = Math.ceil(mm.w * T / STEP), H = Math.ceil(mm.h * T / STEP);
  const visto = new Uint8Array(W * H), coda = [[Math.round(mm.spawn.x / STEP), Math.round(mm.spawn.y / STEP)]];
  const dMin = new Array(mm.village.npcs.length).fill(Infinity);
  let dExit = Infinity, celle = 0;
  const ex = mm.exit.x * T + T / 2, ey = mm.exit.y * T + T / 2;
  while (coda.length) {
    const c = coda.pop(), gx = c[0], gy = c[1], k = gy * W + gx;
    if (gx < 0 || gy < 0 || gx >= W || gy >= H || visto[k]) continue;
    const wx = gx * STEP, wy = gy * STEP;
    if (!libero(wx, wy)) continue;
    visto[k] = 1; celle++;
    for (let i = 0; i < mm.village.npcs.length; i++) {
      const d = MU.dist(wx, wy, mm.village.npcs[i].x, mm.village.npcs[i].y); if (d < dMin[i]) dMin[i] = d; }
    const de = MU.dist(wx, wy, ex, ey); if (de < dExit) dExit = de;
    coda.push([gx + 1, gy], [gx - 1, gy], [gx, gy + 1], [gx, gy - 1]);
  }
  assert(celle > 6000, 'resta spazio in abbondanza per muoversi (' + celle + ' posizioni)');
  for (let i = 0; i < mm.village.npcs.length; i++)
    assert(dMin[i] <= C.MARKET_MERCH_RANGE, 'si arriva a parlare con ' + mm.village.npcs[i].name + ' (' + dMin[i].toFixed(0) + ' px, serve ' + C.MARKET_MERCH_RANGE + ')');
  assert(dExit <= C.MARKET_EXIT_RADIUS, 'e si arriva al portale (' + dExit.toFixed(0) + ' px)');
  let isolate = 0;
  for (let gy = 0; gy < H; gy++) for (let gx = 0; gx < W; gx++)
    if (!visto[gy * W + gx] && libero(gx * STEP, gy * STEP)) isolate++;
  assert(isolate === 0, 'nessuna zona libera resta tagliata fuori dai mobili (' + isolate + ' posizioni isolate)');

  // --- v1.75.3: LA PORTA RESTA LIBERA. Da quando i mobili hanno un corpo, quello che sta sulla soglia
  // non e piu un dettaglio grafico. Misurare la "distanza dal mobile piu vicino" pero non distingue una
  // cassa piantata davanti alla porta da un tavolo che sta due tile dentro la stanza: escono lo stesso
  // numero. Quello che conta e la LUCE, cioe quanto passaggio libero resta davvero attraversando.
  const V2 = MapGen.VILLAGE;
  // v2.6 — i varchi si ricostruiscono dalla porta dichiarata da ogni stanza (non c'e' piu' un elenco)
  const VARCHI3 = V2.rooms.map(rr => { const [px, py, lato] = rr.porta;
    return lato === 'n' ? [px, py - 1, px + 1, py] : (lato === 's' ? [px, py, px + 1, py + 1] : [px, py, px, py + 1]); });
  let stretta2 = '';
  for (const L of VARCHI3) {
    const cx = ((L[0] + L[2]) / 2 + 0.5) * T, cy = ((L[1] + L[3]) / 2 + 0.5) * T;
    const misura = (vert) => { let tot = 0;
      for (let d = -160; d <= 160; d += 2) { const x = vert ? cx + d : cx, y = vert ? cy : cy + d;
        if (!room._blk(x, y, r)) tot += 2; }
      return tot; };
    // la piu stretta delle due misure: l'altra e la lunghezza del corridoio, non la sua luce
    const luce = Math.min(misura(true), misura(false));
    if (luce < r * 2 * 2) stretta2 += ' ' + luce + 'px';
  }
  assert(stretta2 === '', 'da ogni porta passa almeno il doppio del personaggio, corpi solidi inclusi:' + (stretta2 || ' tutte larghe'));

  // e la piazza resta sgombra: le due casse che stavano davanti all osteria e alle taglie sono andate via
  const PZ = V2.piazza;
  const nellaPiazza = m.props.filter(q => { const tx = (q.x / T) | 0, ty = (q.y / T) | 0;
    return tx >= PZ.x0 && tx <= PZ.x1 && ty >= PZ.y0 && ty <= PZ.y1 && q.type === 'cratebox'; });
  assert(nellaPiazza.length === 0, 'nella piazza non ci sono casse davanti alle porte (' + nellaPiazza.length + ')');

  // --- non si attraversa piu un tavolo ---
  const tav = mm.props.find(q => q.type === 'tavolo');
  assert(!libero(tav.x, tav.y), 'sul tavolo non ci si sale');
  const banco = mm.props.find(q => q.type === 'bancone');
  assert(!libero(banco.x, banco.y), 'e il bancone si aggira, non si attraversa');
  assert(!libero(mm.village.npcs[0].x, mm.village.npcs[0].y), 'e nemmeno si passa attraverso un mercante');

  // --- LA SPINTA: dovunque ti ritrovi incastrato, al tick dopo sei fuori ---
  for (const dentro of [tav, banco, { x: mm.village.npcs[0].x, y: mm.village.npcs[0].y },
                        { x: mm.village.extras[0].x, y: mm.village.extras[0].y }]) {
    p.x = dentro.x; p.y = dentro.y;
    room._spingiFuori(p);
    assert(libero(p.x, p.y), 'spinto fuori da (' + (dentro.type || 'una persona') + ')');
    assert(!room.isWallAt(p.x, p.y), 'e non dentro la roccia');
    assert(MU.dist(p.x, p.y, dentro.x, dentro.y) < 110, 'e a due passi, non teletrasportato dall altra parte');
  }
  // e non si muove di un pixel quando NON e incastrato
  p.x = mm.spawn.x; p.y = mm.spawn.y; room._spingiFuori(p);
  assert(p.x === mm.spawn.x && p.y === mm.spawn.y, 'chi non e incastrato non viene toccato');

  // --- CAMMINARE: in nessuna direzione, e per nessun numero di passi, si finisce dentro un corpo ---
  let dentroMai = 0, passi = 0;
  for (let k = 0; k < 16; k++) {
    p.x = mm.spawn.x; p.y = mm.spawn.y;
    const a = k * Math.PI / 8, vx = Math.cos(a) * 7, vy = Math.sin(a) * 7;
    for (let i = 0; i < 260; i++) { room.moveCircle(p, vx, vy); passi++; if (!libero(p.x, p.y)) dentroMai++; }
  }
  assert(dentroMai === 0, 'camminando in tutte le direzioni non si finisce mai dentro un corpo (' + dentroMai + ' su ' + passi + ' passi)');
  ok('novita v1.75.2 verificate');
}
function testV1761() {
  console.log('\n[TEST 48] v1.76.1 — chi scappa non si vede comparire i nemici addosso');
  const dt = 1 / C.TICK_RATE;
  const room = new Room('v1761'); const p = room.addPlayer('a', { send() {} }, 'A', 'arciere'); room.startGame();
  room.pending = 0; room.waveList = []; room.monsters.length = 0;
  for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2;
    const mx = p.x + Math.cos(a) * 300, my = p.y + Math.sin(a) * 300;
    if (room.isWallAt(mx, my)) continue;
    room.spawnMonster('skeleton', mx, my, { scaling: Waves.scaling(1, 1) }); }
  assert(room.monsters.length >= 5, 'ci sono mostri in campo per la prova (' + room.monsters.length + ')');

  // 25 secondi di fuga senza uccidere nessuno: e' esattamente la condizione che prima faceva
  // scattare il vecchio recupero anti-stallo e faceva comparire il branco a 240 px dal giocatore.
  let peggio = 0, chi = '', casi = 0;
  const prima = new Map();
  for (let i = 0; i < C.TICK_RATE * 25; i++) {
    prima.clear();
    for (const m of room.monsters) if (!m.dead) prima.set(m.eid, MU.dist(m.x, m.y, p.x, p.y));
    p.hp = p.maxHp; // non deve morire: la prova riguarda i movimenti, non la sopravvivenza
    room.setInput('a', { mx: 1, my: 0.35, aim: 0, shoot: false, q: false, e: false, dash: false });
    room.update(dt);
    for (const m of room.monsters) {
      if (m.dead || !prima.has(m.eid)) continue;
      const d0 = prima.get(m.eid), d1 = MU.dist(m.x, m.y, p.x, p.y);
      // Il filtro va messo sulla distanza DOPO, non prima. Al primo tentativo guardavo quella prima
      // e scartavo tutto cio che stava oltre 800 px: cioe scartavo esattamente il caso che conta,
      // il mostro lontano che ti compare addosso. Con quel filtro il test passava anche col codice
      // vecchio — cioe non provava niente.
      if (d1 > 900) continue;   // resta fuori dallo sguardo anche dopo: non rompe l illusione
      const guadagno = d0 - d1;
      // Il margine copre spinta, rinculo, scivolamento e le spintarelle dell ANTI-INCASTRO
      // (_recoverStuck/_unstuck spostano di una decina di px chi si e' wedgiato in un angolo). Resta
      // larghissimo rispetto a cio' che deve prendere: il difetto della v1.76.1 faceva guadagnare 619 px
      // in un tick, venti volte questa soglia.
      const massimo = (m.speed || 120) * dt * 3 + 34;
      if (guadagno > massimo) { casi++; if (guadagno > peggio) { peggio = guadagno; chi = m.t; } }
    }
  }
  assert(casi === 0, 'in 25 secondi di fuga nessun nemico in vista si avvicina di scatto (' + casi + ' casi, il peggiore ' + peggio.toFixed(0) + ' px in un tick' + (chi ? ' — ' + chi : '') + ')');

  // ...ma il recupero deve restare vivo, se no un mostro bloccato tiene aperta l ondata per sempre.
  const room2 = new Room('v1761b'); const p2 = room2.addPlayer('b', { send() {} }, 'B', 'arciere'); room2.startGame();
  room2.pending = 0; room2.waveList = []; room2.monsters.length = 0;
  // un mostro parcheggiato lontanissimo e tenuto fermo a forza: e' il caso "non ti raggiungera mai"
  let lontano = null, dMax = 0;
  for (let gy = 2; gy < room2.map.h - 2; gy++) for (let gx = 2; gx < room2.map.w - 2; gx++) {
    if (room2.map.grid[gy * room2.map.w + gx] !== C.T_FLOOR) continue;
    const wx = gx * C.TILE + C.TILE / 2, wy = gy * C.TILE + C.TILE / 2;
    const d = MU.dist(wx, wy, p2.x, p2.y); if (d > dMax) { dMax = d; lontano = { x: wx, y: wy }; } }
  assert(dMax > 640, 'trovato un angolo abbastanza lontano per la prova (' + dMax.toFixed(0) + ' px)');
  const bloccato = room2.spawnMonster('skeleton', lontano.x, lontano.y, { scaling: Waves.scaling(1, 1) });
  let spostato = false;
  for (let i = 0; i < C.TICK_RATE * 9 && !spostato; i++) {
    bloccato.x = lontano.x; bloccato.y = lontano.y;   // lo si tiene fermo: simula "non fa progressi"
    p2.hp = p2.maxHp;
    room2.setInput('b', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
    room2.update(dt);
    if (MU.dist(bloccato.x, bloccato.y, lontano.x, lontano.y) > 300) spostato = true;
  }
  assert(spostato, 'un mostro che non fa progressi da cinque secondi viene comunque rimesso in gioco: l ondata non resta aperta per sempre');
  const dFin = MU.dist(bloccato.x, bloccato.y, p2.x, p2.y);
  assert(dFin > 500, 'e viene rimesso LONTANO, non addosso al giocatore (' + dFin.toFixed(0) + ' px)');
  ok('novita v1.76.1 verificate');
}
function testV177() {
  console.log('\n[TEST 49] Novita v1.77 — dai nemici non cade piu niente, e le ondate hanno un cronometro');
  const dt = 1 / C.TICK_RATE;

  // --- 1. NESSUN OGGETTO DAI NEMICI. Ne comuni, ne elite, ne boss, ne la cassa-mima.
  const room = new Room('v177'); const p = room.addPlayer('a', { send() {} }, 'A', 'arciere'); room.startGame();
  room.items.length = 0;
  let uccisi = 0;
  for (const [id, opz] of [['skeleton', {}], ['skeleton', { elite: 1 }], ['slime', {}], ['bat_swarm', {}]])
    for (let k = 0; k < 90; k++) {
      const m = room.spawnMonster(id, p.x + 40, p.y, { scaling: Waves.scaling(3, 1), elite: opz.elite });
      if (opz.elite) m.elite = 1;
      room.killMonster(m, p); uccisi++;
    }
  const boss = room.spawnMonster('orc_warlord', p.x + 60, p.y, { scaling: Waves.scaling(10, 1) });
  boss.boss = true; room.killMonster(boss, p); uccisi++;
  const mima = room.spawnMonster('mimic', p.x + 60, p.y, { scaling: Waves.scaling(7, 1) });
  room.killMonster(mima, p); uccisi++;   // v1.78 — non e piu uno "scrigno": la modalita Tesoro non esiste, la mima e un mostro come gli altri
  assert(room.items.length === 0, 'su ' + uccisi + ' nemici uccisi (elite, boss e cassa-mima compresi) non e caduto un solo oggetto (' + room.items.length + ')');
  // ...ma esperienza e monete devono continuare a cadere, se no si e rotta l economia
  assert(room.groundXp.length > 0, 'l esperienza continua a cadere');
  assert(room.groundCoins.length > 0, 'e le monete anche');

  // --- 2. LE POZIONI FORTI SONO DALL ERBORISTA, e costano
  const forti = Pot.POTIONS.filter(x => x.cost >= 100);
  assert(forti.length === 3, 'l Erborista ha tre pozioni forti (' + forti.length + ')');
  const base = Pot.POTIONS.filter(x => x.cost < 100);
  const maxBase = Math.max(...base.map(x => x.cost));
  assert(Math.min(...forti.map(x => x.cost)) > maxBase * 2, 'la piu economica delle forti costa piu del doppio della piu cara delle base');
  for (const id of ['i_power', 'i_rage', 'i_invuln'])
    assert(Pot.POTIONS.some(x => x.buff === id), 'l effetto ' + id + ', che prima cadeva a terra, adesso si compra');

  // la vita in boccetta: si beve, da una vita, e non se ne possono tenere tre
  // v1.77.1 — LE VITE EXTRA NON SI COMPRANO DALL'ERBORISTA. Per un giorno il Cuore di Fenice e' stato
  // una pozione da cintura con una carica sola: sbagliato lo stesso, perche' l'Erborista e' sempre
  // raggiungibile e una vita comprabile da lui e' una vita comprabile a ogni passaggio dal villaggio.
  // Resta solo dal Mercante Errante, che compare a caso durante le ondate.
  assert(!Pot.POTIONS.some(x => x.kind === 'life'), 'nel catalogo dell Erborista non c e nessuna vita extra');
  assert(!Pot.POTIONS.some(x => /fenice/i.test(x.name)), 'e nemmeno il Cuore di Fenice sotto altro nome');
  const errante = room.merchantWaresPool().filter(w => w.kind === 'life');
  assert(errante.length === 1, 'il Cuore di Fenice resta dal Mercante Errante (' + errante.length + ')');
  assert(errante[0].cost >= 150, 'e li costa ' + errante[0].cost + ' monete');

  // --- 3. IL CRONOMETRO E IL PREMIO
  const r2 = new Room('v177b'); const p2 = r2.addPlayer('b', { send() {} }, 'B', 'arciere'); r2.startGame();
  assert(r2.parT > 0, 'l ondata 1 ha un tempo obiettivo (' + r2.parT + ' s)');
  assert(r2.waveMostri > 0, 'e sa da quanti mostri e fatta (' + r2.waveMostri + ')');
  const snap = r2.snapshot();
  assert(snap.wp === r2.parT && snap.wt >= 0, 'lo snapshot porta cronometro e obiettivo al client (wt ' + snap.wt + ', wp ' + snap.wp + ')');

  // v1.77.2 — IL CRONOMETRO DEVE CAMMINARE, e va provato sulla PRIMA ondata. E' l'unica in cui
  // waveT0 vale esattamente 0, e `this.time - (this.waveT0 || this.time)` trattava quello zero come
  // "non impostato": scattava il ripiego e il tempo trascorso restava zero per tutta la partita.
  // Provarlo a ondata avanzata non avrebbe visto niente, perche' li' waveT0 e' un numero diverso da 0.
  assert(r2.wave === 1, 'la prova si fa sulla PRIMA ondata: e li che waveT0 vale zero');
  assert(r2.waveT0 === 0, 'e infatti waveT0 vale ' + r2.waveT0);
  const letture = [];
  for (const secondi of [3, 8, 15]) {
    while (r2.time < secondi) { r2.setInput('b', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }); r2.update(dt); }
    letture.push([secondi, r2.snapshot().wt]);
  }
  for (const [atteso, letto] of letture)
    assert(Math.abs(letto - atteso) < 0.5, 'dopo ' + atteso + ' s il cronometro segna ' + letto + ' s');
  assert(letture[2][1] > letture[0][1], 'e cammina: da ' + letture[0][1] + ' s a ' + letture[2][1] + ' s');
  // il tempo obiettivo scala col contenuto: un ondata affollata ne ha di piu
  const parPochi = Math.round(C.PAR_BASE + C.PAR_PER_MOSTRO * 7 / 1);
  const parTanti = Math.round(C.PAR_BASE + C.PAR_PER_MOSTRO * 41 / 1);
  assert(parTanti > parPochi * 2, 'il tempo obiettivo scala col numero di mostri (' + parPochi + ' s contro ' + parTanti + ' s)');

  // chiudendo l ondata dentro il tempo, arriva il premio
  const xp0 = p2.xpTot !== undefined ? p2.xpTot : 0, mon0 = p2.coins;
  r2.monsters.length = 0; r2.pending = 0; r2.waveT0 = r2.time - 3;   // tre secondi: dentro qualunque obiettivo
  r2._waveDone();
  assert(r2.parPreso === 1, 'chiudendo in tre secondi il premio scatta');
  assert(p2.coins > mon0, 'e porta monete (' + mon0 + ' -> ' + p2.coins + ')');

  // chiudendo fuori tempo, niente premio
  const r3 = new Room('v177c'); const p3 = r3.addPlayer('c', { send() {} }, 'C', 'arciere'); r3.startGame();
  const mon3 = p3.coins;
  r3.monsters.length = 0; r3.pending = 0; r3.waveT0 = r3.time - (r3.parT + 30);
  r3._waveDone();
  assert(!r3.parPreso, 'chiudendo trenta secondi oltre l obiettivo il premio non scatta');
  assert(p3.coins === mon3, 'e le monete restano quelle (' + p3.coins + ')');

  // v1.78 — le ondate a sopravvivenza non esistono piu': il tempo obiettivo vale per TUTTE, senza
  // eccezioni da spiegare. Si controlla proprio quello.
  const r4 = new Room('v177d'); r4.addPlayer('d', { send() {} }, 'D', 'arciere'); r4.startGame();
  let senzaObiettivo = 0;
  for (let w = 1; w <= 12; w++) {
    r4.wave = w - 1; r4.phase = C.PHASE_SHOP; r4.shopReady('d', 'next'); r4._afterShop();
    if (!(r4.parT > 0)) senzaObiettivo++;
  }
  assert(senzaObiettivo === 0, 'tutte le prime dodici ondate hanno un tempo obiettivo (' + senzaObiettivo + ' senza)');
  ok('novita v1.77 verificate');
}
function testPonteClient() {
  console.log('\n[TEST 50] Il ponte fra server e HUD: nessun campo dello snapshot si perde per strada');
  // PERCHE' QUESTO TEST ESISTE. Il cronometro dell'ondata (v1.77) e' rimasto fermo su 0:00 per due
  // versioni. La prima volta era un bug del server; la seconda — quella vera — era che l'HUD non
  // riceve affatto lo snapshot del server. Riceve G.world, lo stato interpolato del client, e i campi
  // non-giocatore vanno copiati a mano uno per uno in main.js con `w.X = next.X`. Il server mandava
  // wt e wp, il client li buttava, e non c'era nessun errore da nessuna parte: nessun test se ne
  // accorgeva, perche' provare lo snapshot del server non prova il ponte.
  // Qui si confrontano le due liste: cio' che l'HUD LEGGE contro cio' che il client COPIA.
  const path = require('path'), fsx = require('fs');
  const dirPub = path.join(__dirname, '..', 'public', 'js');
  const hud = fsx.readFileSync(path.join(dirPub, 'hud.js'), 'utf8');
  const main = fsx.readFileSync(path.join(dirPub, 'main.js'), 'utf8');

  // 1) il corpo di updateTop, preso contando le graffe
  const inizio = hud.indexOf('updateTop(snap, me) {');
  assert(inizio >= 0, 'updateTop esiste in hud.js');
  let liv = 0, fine = -1;
  for (let i = hud.indexOf('{', inizio); i < hud.length; i++) {
    if (hud[i] === '{') liv++;
    else if (hud[i] === '}') { liv--; if (liv === 0) { fine = i; break; } }
  }
  assert(fine > inizio, 'e se ne trova la fine');
  let corpo = hud.slice(inizio, fine);
  // v1.78 — updateTop delega: _aggiornaUscita legge snap.ex e vive fuori da updateTop. Se si guardasse
  // solo il corpo di updateTop, un campo letto da un metodo delegato passerebbe sotto il radar — che e'
  // esattamente il buco da cui e' nato il cronometro fermo.
  for (const m of corpo.matchAll(/this\.(_[a-zA-Z0-9_]+)\(snap/g)) {
    // la DEFINIZIONE, non la chiamata: la chiamata e' preceduta da 'this.', la definizione da un a capo.
    const i2 = hud.indexOf('\n    ' + m[1] + '(snap');
    if (i2 < 0) continue;
    let l2 = 0, f2 = -1;
    for (let i = hud.indexOf('{', i2); i < hud.length; i++) { if (hud[i] === '{') l2++; else if (hud[i] === '}') { l2--; if (l2 === 0) { f2 = i; break; } } }
    if (f2 > i2) corpo += hud.slice(i2, f2);
  }
  const letti = new Set();
  for (const m of corpo.matchAll(/\bsnap\.([a-zA-Z_][a-zA-Z0-9_]*)/g)) letti.add(m[1]);
  assert(letti.size > 3, 'updateTop legge piu di tre campi dallo snapshot (' + [...letti].join(', ') + ')');

  // 2) i campi che main.js copia nel mondo del client
  const copiati = new Set();
  for (const m of main.matchAll(/\bw\.([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*next\./g)) copiati.add(m[1]);
  assert(copiati.size > 3, 'main.js copia piu di tre campi (' + [...copiati].join(', ') + ')');

  // 3) uno snapshot VERO del server, per sapere quali di quei campi esistono davvero
  const room = new Room('ponte'); room.addPlayer('a', { send() {} }, 'A', 'arciere'); room.startGame();
  const snap = room.snapshot();
  const persi = [...letti].filter(k => Object.prototype.hasOwnProperty.call(snap, k) && !copiati.has(k) && k !== 'players');
  assert(persi.length === 0,
    'ogni campo che l HUD legge e che il server manda viene copiato nel mondo del client (persi: ' + (persi.join(', ') || 'nessuno') + ')');

  // e il cronometro in particolare, che e' il caso da cui e nato tutto
  assert(copiati.has('wt') && copiati.has('wp'), 'il cronometro (wt) e il tempo obiettivo (wp) arrivano fino all HUD');
  assert(letti.has('ex'), 'il ponte vede anche i campi letti dai metodi delegati (ex, lo stato dell uscita)');
  assert(copiati.has('ex'), 'e lo stato dell uscita (ex) arriva fino all HUD');
  // ============================================================================================
  // v2.17 — E NESSUN CAMPO DEL MONDO SI PERDE FRA LO SNAPSHOT E IL RENDERER
  // ============================================================================================
  // IL BUG CHE HA FATTO NASCERE QUESTO CONTROLLO. `muri`, `trap` e `nebb` stavano nello snapshot dalla
  // v1.85 e non erano mai stati copiati nel mondo interpolato dentro main.js: il server li mandava, il
  // client li buttava, il renderer disegnava tre array vuoti. Per otto versioni il muro di fuoco, la
  // tagliola e il velo d'ombra non si sono MAI visti — senza un errore da nessuna parte. Paolo se n'e'
  // accorto giocando: «il muro di fuoco non ha nessun effetto grafico».
  // In quel punto di main.js c'era gia' un avvertimento scritto, e c'era gia' un controllo: ma copriva
  // i campi letti dall'HUD, non quelli letti dal RENDERER. Questo li copre — legge dal sorgente quali
  // `world.<campo>` il renderer usa davvero, e pretende che main.js li copi tutti.
  {
    const fs2 = require('fs'), path2 = require('path');
    const dir = path2.join(__dirname, '..', 'public', 'js');
    const srcR = fs2.readFileSync(path2.join(dir, 'renderer.js'), 'utf8');
    const srcM = fs2.readFileSync(path2.join(dir, 'main.js'), 'utf8');
    const letti = new Set(); let mm;
    const re = /\bworld\.([a-zA-Z_][a-zA-Z0-9_]*)/g;
    while ((mm = re.exec(srcR))) letti.add(mm[1]);
    for (const k of ['me', 'players', 'mon', 'bul']) letti.delete(k);   // roba del giocatore locale, non dello snapshot
    const copiati = new Set();
    const re2 = /\bw\.([a-zA-Z_][a-zA-Z0-9_]*)\s*=/g;
    while ((mm = re2.exec(srcM))) copiati.add(mm[1]);
    const persi = [...letti].filter(k => !copiati.has(k));
    assert(persi.length === 0, 'nessun campo del mondo si perde fra snapshot e renderer (' + letti.size + ' controllati)'
      + (persi.length ? ' — PERSI: ' + persi.join(', ') : ''));
  }
  ok('il ponte fra server e HUD regge');
}
// ===================== v1.78 — USCITA, CARTE DAI LIVELLI, RIEPILOGO =====================
// Le cinque richieste di questa versione, ognuna con la sua prova:
//  1. i font del testo cresciuti di 1px, i titoli no
//  2. la mappa ripulita non ti sbatte fuori: c'e' il pulsante EXIT
//  3. le carte si scelgono salendo di livello, non finendo un'ondata
//  4. una sola modalita' (la prova sta nel TEST 5, riscritto)
//  5. il riepilogo di fine livello
function testV178() {
  const Lv2 = require('../shared/levels.js');
  console.log('\n[TEST 51] Novita v1.78 — uscita col pulsante EXIT, carte dai livelli, riepilogo di fine livello');
  const conn = () => { const box = []; return { box, send(s) { box.push(JSON.parse(s)); } }; };

  // --- 1. LA MAPPA RIPULITA NON CHIUDE DA SOLA ---
  const c1 = conn();
  const r = new Room('v178a'); const p = r.addPlayer('a', c1, 'A', 'paladino'); r.startGame();
  r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 0;
  r._checkWaveClear();
  assert(r.phase === C.PHASE_CLEARED, 'uccisi tutti i nemici la fase e "mappa ripulita", non il negozio');
  assert(r.snapshot().ex && r.snapshot().ex.tot === 1, 'lo snapshot dice a quanti si sta aspettando');
  assert(r.snapshot().ex.n === 0, 'e che nessuno ha ancora premuto EXIT');
  const clearEv = c1.box.filter(m => m.ev && m.ev.t === 'cleared');
  assert(clearEv.length === 1, 'l avviso di mappa ripulita parte una volta sola');
  // il tempo si ferma qui: aspettare non deve costare il premio di velocita'
  const t1 = r.snapshot().wt;
  for (let i = 0; i < C.TICK_RATE * 20; i++) r.update(1 / C.TICK_RATE);
  assert(r.phase === C.PHASE_CLEARED, 'venti secondi dopo si e ancora li: nessuno ha premuto');
  assert(Math.abs(r.snapshot().wt - t1) < 0.01, 'e il cronometro e fermo (' + t1 + ' -> ' + r.snapshot().wt + ')');
  r.exitWave('a');
  assert(r.phase === C.PHASE_SHOP, 'premuto EXIT si va al pannello di fine ondata');

  // --- 2. IN COOPERATIVA SI ASPETTANO TUTTI, MA NON I CADUTI ---
  const r2 = new Room('v178b');
  const a = r2.addPlayer('a', conn(), 'A', 'paladino'), b = r2.addPlayer('b', conn(), 'B', 'mago'), d = r2.addPlayer('d', conn(), 'D', 'arciere');
  r2.startGame(); r2.phase = C.PHASE_COMBAT; r2.monsters.length = 0; r2.pending = 0; r2._checkWaveClear();
  assert(r2.phase === C.PHASE_CLEARED, 'in tre la mappa ripulita aspetta');
  r2.exitWave('a');
  assert(r2.phase === C.PHASE_CLEARED, 'uno solo non basta a portare via gli altri');
  assert(r2.snapshot().ex.n === 1 && r2.snapshot().ex.tot === 3, 'e si vede 1 su 3');
  d.dead = true;                              // un caduto non puo' premere niente
  r2.exitWave('b');
  assert(r2.phase === C.PHASE_SHOP, 'chi e caduto non si aspetta: premuto da tutti i vivi si esce');

  // --- 3. L ANTI-AFK: dopo EXIT_TIMEOUT si esce comunque ---
  const r3 = new Room('v178c'); r3.addPlayer('a', conn(), 'A', 'paladino'); r3.addPlayer('b', conn(), 'B', 'mago');
  r3.startGame(); r3.phase = C.PHASE_COMBAT; r3.monsters.length = 0; r3.pending = 0; r3._checkWaveClear();
  let sec = 0; while (r3.phase === C.PHASE_CLEARED && sec < C.EXIT_TIMEOUT + 30) { for (let i = 0; i < C.TICK_RATE; i++) r3.update(1 / C.TICK_RATE); sec++; }
  assert(r3.phase === C.PHASE_SHOP, 'nessuno preme: dopo il tempo massimo si esce lo stesso');
  assert(sec >= C.EXIT_TIMEOUT - 2, 'ma non prima del tempo massimo (' + sec + 's su ' + C.EXIT_TIMEOUT + ')');

  // --- 4. ASPETTARE NON COSTA IL PREMIO DI VELOCITA ---
  const c4 = conn();
  const r4 = new Room('v178d'); const q = r4.addPlayer('a', c4, 'A', 'paladino'); r4.startGame();
  r4.phase = C.PHASE_COMBAT; r4.waveT0 = r4.time; r4.parT = 40; r4.monsters.length = 0; r4.pending = 0;
  for (let i = 0; i < C.TICK_RATE * 10; i++) r4.update(1 / C.TICK_RATE);   // ondata chiusa in ~10s
  assert(r4.phase === C.PHASE_CLEARED, 'la mappa e ripulita');
  for (let i = 0; i < C.TICK_RATE * 60; i++) r4.update(1 / C.TICK_RATE);   // un minuto a raccogliere con calma
  r4.exitWave('a');
  assert(r4.parPreso === 1, 'il premio di velocita si guadagna sul tempo di COMBATTIMENTO, non sul tempo passato a raccogliere');

  // --- 4bis. QUELLO CHE E' A TERRA TI ASPETTA ---
  // Con l'uscita a pulsante si puo' girare per la mappa un minuto intero: se le sfere continuassero a
  // scadere, il bottino sparirebbe sotto gli occhi di chi lo sta andando a prendere.
  const r45 = new Room('v178d2'); const k = r45.addPlayer('a', conn(), 'A', 'paladino'); r45.startGame();
  r45.phase = C.PHASE_COMBAT;
  for (let i = 0; i < 6; i++) { const m = r45.spawnMonster('skeleton', k.x + 900, k.y, { scaling: Waves.scaling(2, 1) }); r45.killMonster(m, k); }
  const sfere = r45.groundXp.length, soldi = r45.groundCoins.length;
  assert(sfere > 0 && soldi > 0, 'i nemici hanno lasciato esperienza e monete per terra');
  r45.monsters.length = 0; r45.pending = 0; r45._checkWaveClear();
  assert(r45.phase === C.PHASE_CLEARED, 'mappa ripulita');
  for (let i = 0; i < C.TICK_RATE * 60; i++) r45.update(1 / C.TICK_RATE);   // un minuto buono a girare
  assert(r45.groundXp.length === sfere && r45.groundCoins.length === soldi,
    'dopo un minuto sulla mappa ripulita la roba a terra e ancora li (' + r45.groundXp.length + '/' + sfere + ' sfere, ' + r45.groundCoins.length + '/' + soldi + ' monete)');

  // --- 5. LE ABILITA' ARRIVANO AGLI SCAGLIONI (v1.79: livelli 3, 6, 9, 12) ---
  const c5 = conn();
  const r5 = new Room('v178e'); const z = r5.addPlayer('a', c5, 'A', 'paladino'); r5.startGame();
  assert((z.scaglioniDovuti || []).length === 0, 'a inizio partita non si deve nessuna scelta');
  r5.phase = C.PHASE_COMBAT; r5.monsters.length = 0; r5.pending = 0; c5.box.length = 0;
  r5._checkWaveClear(); r5.exitWave('a');
  const offerte0 = c5.box.filter(m => m.t === C.MSG.OFFER_BOON && m.boons.length);
  assert(offerte0.length === 0, 'chiudere un ondata senza raggiungere uno scaglione NON offre niente');
  const vuoto = c5.box.filter(m => m.t === C.MSG.OFFER_BOON && !m.boons.length);
  assert(vuoto.length === 1 && vuoto[0].prossimo === 3 && vuoto[0].manca > 0, 'ma il pannello dice a che livello arriva la prossima e quanto manca');

  // due scaglioni in un'ondata sola: si scelgono uno dopo l'altro
  const r6 = new Room('v178f'); const y = r6.addPlayer('a', conn(), 'A', 'mago'); r6.startGame();
  r6.phase = C.PHASE_COMBAT;
  r6.addXp(y, Lv2.xpForLevel(7));
  assert(y.level >= 7, 'con l esperienza di sette livelli si arriva almeno al 7 (' + y.level + ')');
  assert((y.scaglioniDovuti || []).join(',') === 'uncommon,rare', 'e si devono i primi due scaglioni');
  // v2.16 — al 7 si apre anche il SECONDO slot delle attive: la scaletta e' 1-3-5-7, non piu' 3-6-8.
  // v2.18 — il MAGO e' l'unica classe che al livello 1 ha una scelta (la SCUOLA), ma l'aiuto in cima al
  // file gliela fa scegliere all'avvio: qui resta in coda il solo slot 2.
  assert((y.abilDovute || []).join(',') === '2', 'e lo slot 2, che si apre proprio al 7');
  r6.monsters.length = 0; r6.pending = 0; r6._checkWaveClear(); r6.exitWave('a');
  const dovuti = (y.scaglioniDovuti || []).length + (y.abilDovute || []).length;
  let scelte = 0;
  while (y.boonOffer && y.boonOffer.length && scelte < 12) {
    // v1.85 — una passiva mostra quattro carte, uno slot di abilita' ne mostra DUE
    const abil = !!Ab.BY_ID[y.boonOffer[0]];
    assert(y.boonOffer.length === (abil ? 2 : 3), abil ? 'lo slot mostra le due abilita della classe' : 'ogni scaglione mostra tre abilita');
    r6.pickBoon('a', y.boonOffer[0]); scelte++;
  }
  assert(scelte === dovuti, 'il pannello si riapre finche gli scaglioni dovuti non sono finiti (' + scelte + '/' + dovuti + ')');
  assert((y.scaglioniDovuti || []).length === 0 && (y.abilDovute || []).length === 0, 'poi la coda e vuota');
  // le abilita' scelte sono di quelle che il MAGO puo' vedere: mai di un'altra classe
  for (const id in y.boonsOwned) {
    const b = Loot.BOON_BY_ID[id];
    assert(b && (b.hero === 'mago' || b.hero === '*'), 'il mago non puo aver preso ' + id + ' (di ' + (b ? b.hero : '?') + ')');
  }
  // e nell'ondata dopo, senza nuovi scaglioni, non si offre piu' niente
  r6.nextWave(); r6.phase = C.PHASE_COMBAT; r6.monsters.length = 0; r6.pending = 0;
  r6._checkWaveClear(); r6.exitWave('a');
  assert(!(y.boonOffer && y.boonOffer.length), 'ondata successiva senza scaglioni: nessuna scelta');

  // --- 6. IL RIEPILOGO DI FINE LIVELLO ---
  const c7 = conn();
  const r7 = new Room('v178g'); const w = r7.addPlayer('a', c7, 'A', 'arciere'); r7.startGame();
  r7.phase = C.PHASE_COMBAT; r7.waveT0 = r7.time; r7.parT = 300;
  const uccisi = 5;
  for (let i = 0; i < uccisi; i++) { const m = r7.spawnMonster('skeleton', w.x + 200, w.y, { scaling: Waves.scaling(2, 1) }); r7.killMonster(m, w); }
  assert(w.ondata.uccisi === uccisi, 'il contatore dell ondata conta i nemici uccisi (' + w.ondata.uccisi + ')');
  // l'esperienza si conta quando la RACCOGLI, non quando cade: le sfere restano a terra finche' non le
  // prendi, ed e' giusto che il riepilogo dica cosa hai in tasca e non cosa era per terra.
  assert(w.ondata.xp === 0, 'l esperienza per terra non e ancora tua');
  r7.addXp(w, 40);
  assert(w.ondata.xp === 40, 'quella raccolta invece si (' + w.ondata.xp + ')');
  c7.box.length = 0;
  r7.monsters.length = 0; r7.pending = 0; r7._checkWaveClear(); r7.exitWave('a');
  const rep = c7.box.filter(m => m.t === C.MSG.WAVE_STATS);
  assert(rep.length === 1, 'il riepilogo arriva una volta sola');
  const R = rep[0];
  assert(R.uccisi === uccisi, 'e riporta i nemici uccisi (' + R.uccisi + ')');
  assert(R.xp > 0 && R.monete >= 0, 'esperienza e monete dell ondata');
  assert(R.durata >= 0 && R.par === 300, 'quanto e durata e qual era il tempo obiettivo');
  assert(R.bonus && R.bonus.xp > 0 && R.bonus.monete > 0, 'e il premio del cronometro, visto che siamo rimasti sotto');
  // fuori tempo: il riepilogo c e lo stesso, senza premio
  const c8 = conn();
  const r8 = new Room('v178h'); const v = r8.addPlayer('a', c8, 'A', 'arciere'); r8.startGame();
  r8.phase = C.PHASE_COMBAT; r8.parT = 5; r8.waveT0 = r8.time - 60;
  r8.monsters.length = 0; r8.pending = 0; c8.box.length = 0; r8._checkWaveClear(); r8.exitWave('a');
  const R8 = c8.box.filter(m => m.t === C.MSG.WAVE_STATS)[0];
  assert(!!R8 && !R8.bonus, 'fuori tempo il riepilogo arriva comunque, ma senza premio');
  // il conto si azzera all ondata nuova
  assert(v.ondata.uccisi === 0 && v.ondata.xp === 0, 'e a ondata nuova il conto riparte da zero');

  // --- 7. I FONT DEL TESTO SONO CRESCIUTI DI 1px, I TITOLI NO ---
  const css = fs.readFileSync(__dirname + '/../public/style.css', 'utf8');
  assert(/h1\{font-size:4[46]px/.test(css), 'il titolo grande resta grande (46px dalla v1.86, sopra l artwork)');
  assert(/h2\{font-size:19px/.test(css), 'i titoli di sezione sono rimasti a 19px');
  assert(/#hud\{[^}]*font-size:15px/.test(css), 'il testo dell interfaccia e passato a 15px');
  assert(/\.kf\{[^}]*font-size:13px/.test(css), 'il registro delle uccisioni e passato a 13px');
  // e nessun colore rotto: e' successo davvero (un "#ffc" seguito da una parola) e non si vede finche'
  // non guardi quella riga a schermo.
  // e nessun colore rotto: e' successo davvero (un "#ffc" seguito da una parola, e un ideogramma in
  // mezzo a un esadecimale) e non te ne accorgi finche' non guardi QUELLA riga a schermo.
  // Si controllano solo i VALORI delle dichiarazioni: i selettori cominciano per # anche loro.
  const valori = [...css.matchAll(/([a-z-]+)\s*:\s*([^;{}]+)[;}]/g)];
  assert(valori.length > 300, 'il foglio di stile ha le sue dichiarazioni (' + valori.length + ')');
  const rotti = [];
  for (const m of valori) {
    const prop = m[1], grezzo = m[2].trim();
    // ogni esadecimale dev essere lungo 3, 4, 6 o 8 cifre: "#12<qualcosa>7040" si spezza e si vede subito
    for (const h of grezzo.match(/#[0-9a-zA-Z]*/g) || [])
      if (!/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(h)) rotti.push(prop + ':' + grezzo);
    // e un colore e' UN valore solo: "#ffc martedi" sono due parole, quindi e un errore di battitura.
    // v2.2 — `scrollbar-color` fa eccezione per disegno: vuole DUE colori (pollice e binario), e non e'
    // un refuso. E' l'unica proprieta' che finisce per "color" e ne vuole piu' di uno.
    if (/color$/.test(prop) && prop !== 'scrollbar-color') {
      let senzaFunzioni = grezzo;   // le funzioni si annidano (var dentro var): si sbucciano finche restano
      for (let g = 0; g < 6; g++) { const q = senzaFunzioni.replace(/[a-z-]*\([^()]*\)/gi, 'F'); if (q === senzaFunzioni) break; senzaFunzioni = q; }
      if (/\s/.test(senzaFunzioni) || !/^(#[0-9a-fA-F]{3,8}|F|[a-zA-Z]+)$/.test(senzaFunzioni)) rotti.push(prop + ':' + grezzo);
    }
  }
  assert(rotti.length === 0, 'nessun colore e scritto male (' + rotti.slice(0, 3).join(' | ') + ')');
  // un ideogramma dentro un colore esadecimale non e' una scelta di stile: e' un tasto sbagliato.
  const strani = css.match(/[\u2E80-\u9FFF\uAC00-\uD7AF]/g) || [];
  assert(strani.length === 0, 'e nessun ideogramma finito li per sbaglio (' + strani.slice(0, 3).join(' ') + ')');

  ok('novita v1.78 verificate');
}

// ===================== v1.79 — TETTO 15, SCAGLIONI, XP CONDIVISA, MENU =====================
// L'impianto nuovo per intero: quello che il giocatore vede (quattro scelte, una per scaglione) e
// quello che non vede ma regge tutto (la curva, il fattore di gruppo, il tetto).
function testV179() {
  console.log('\n[TEST 52] Novita v1.79 — tetto 15, abilita a scaglioni, XP condivisa, menu a sezioni');
  const Lv = require('../shared/levels.js');
  const conn = () => { const box = []; return { box, send(s) { box.push(JSON.parse(s)); } }; };

  // --- 1) LA GRIGLIA: 38 carte, 2 di classe + 2 neutre per scaglione, niente impilamento ---
  // v2.18 — il test gira su TUTTE E SETTE le classi, non piu' su tre, ed e' li' che sta il suo valore:
  // con sette classi e otto carte proprie a testa e' facilissimo lasciare un buco a una fascia. Prima
  // dell'aggiunta delle sei carte nuove, quattro classi ne avevano UNA SOLA da qualche parte — questo
  // test lo avrebbe visto subito.
  //
  // v2.20.0 — IL MAZZO E' RIFATTO: 84 carte, 12 per classe (tre vie per quattro scaglioni), nessuna
  // condivisa e nessuna neutra. `b.hero` torna a bastare a dire di chi e' una carta, ed e' il punto:
  // la tabella `CARTE_CLASSE` era una seconda verita' da tenere allineata a mano.
  assert(Loot.BOONS.length === 84, 'ottantaquattro carte in tutto (' + Loot.BOONS.length + ')');
  assert(Loot.BOONS.every(b => b.hero !== '*'), 'nessuna carta neutra: il mazzo comune non esiste piu');
  for (const h of Heroes.ORDER) {
    const sue = Loot.carteDi(h);
    assert(sue.length === 12, h + ': dodici carte proprie (' + sue.length + ')');
    for (const t of ['uncommon', 'rare', 'epic', 'divine']) {
      const o = Loot.offerteScaglione(h, t, {});
      assert(o.length === 3, h + '/' + t + ': tre carte offerte (' + o.length + ')');
      assert(o.every(b => b.hero === h), h + '/' + t + ': e sono tutte e tre sue');
      assert(o.every(b => b.rarity === t), h + '/' + t + ': e sono tutte di quello scaglione');
      // LE TRE VIE, sempre nello stesso ordine: e' cio' che rende la griglia leggibile senza spiegarla
      assert(o.map(b => b.via).join(',') === 'colpo,tenuta,mestiere', h + '/' + t + ': colpo, tenuta, mestiere in quest ordine (' + o.map(b => b.via).join(',') + ')');
    }
    // un mago non deve MAI poter vedere una carta del barbaro
    const cat = Loot.boonsPerClasse(h);
    assert(cat.length === 12, h + ': il suo catalogo sono le sue 12 carte');
    assert(cat.every(b => b.hero === h), h + ': e non ci sono carte di altre classi');
  }
  assert(Loot.BOONS.every(b => b.max === 1), 'nessuna abilita e impilabile');
  assert(new Set(Loot.BOONS.map(b => b.id)).size === 84, 'nessun id duplicato');
  for (const id of ['greed', 'lucky', 'gluttony', 'giant']) assert(!Loot.BOON_BY_ID[id], 'ritirata: ' + id);
  // v2.20.0 — NESSUNA CARTA CURA, E NESSUNA RIPORTA IN VITA. E' una richiesta esplicita di Paolo, e va
  // controllata sul FATTO e non sulla parola: si applica ogni carta a un personaggio ferito e si guarda
  // se i PV salgono o se una morte viene annullata. Con `defianceLeft` a zero non c'e' resurrezione.
  {
    const Heroes2 = require('../shared/heroes.js');
    for (const b of Loot.BOONS) {
      const rr = new Room('cura_' + b.id), pp = rr.addPlayer('a', conn(), 'A', b.hero); rr.startGame();
      pp.hp = 10; const prima = pp.hp;
      pp.boonsOwned[b.id] = 1; pp.cardOn[b.id] = 1; rr._recomputeBoons(pp);
      assert(pp.hp <= prima, b.id + ': prenderla non cura (' + prima + ' -> ' + pp.hp + ')');
      assert((pp.defianceLeft || 0) === 0, b.id + ': e non regala una resurrezione');
    }
  }

  // --- 2) LE SINERGIE restano raggiungibili, ognuna da UNA classe sola e in DUE scaglioni diversi ---
  for (const sy of Loot.SYNERGIES) {
    const ab = sy.need.map(id => Loot.BOON_BY_ID[id]);
    assert(ab.every(Boolean), 'la sinergia ' + sy.id + ' punta ad abilita che esistono');
    const classi = new Set(ab.map(b => b.hero));   // v2.20.0 — una sinergia per classe, e solo sua
    assert(classi.size === 1, 'la sinergia ' + sy.id + ' e raggiungibile da una classe sola (' + [...classi].join('+') + ')');
    assert(new Set(ab.map(b => b.rarity)).size === ab.length, 'e sta a cavallo di scaglioni diversi (' + sy.id + ')');
  }

  // --- 3) LA SCELTA: una per scaglione, e solo agli scaglioni ---
  const r1 = new Room('v179a'); const p = r1.addPlayer('a', conn(), 'A', 'paladino'); r1.startGame();
  r1.addXp(p, Lv.xpForLevel(3) - 1);
  assert(p.level === 2 && (p.scaglioniDovuti || []).length === 0, 'al livello 2 non si sceglie niente');
  r1.addXp(p, 5);
  assert(p.level === 3 && p.scaglioniDovuti.join(',') === 'uncommon', 'al 3 arriva il primo scaglione');
  r1.addXp(p, Lv.xpForLevel(4) - p.xpPool);
  assert(p.level === 4 && p.scaglioniDovuti.length === 1, 'al 4 non arriva niente di nuovo');
  r1.addXp(p, Lv.xpForLevel(5) - p.xpPool);
  assert(p.level === 5 && p.scaglioniDovuti.join(',') === 'uncommon,rare', 'al 5 la seconda passiva');
  r1.addXp(p, Lv.xpForLevel(12) - p.xpPool);
  assert(p.scaglioniDovuti.join(',') === 'uncommon,rare,epic,divine', 'e al 12 la coda ha tutte e quattro le passive');
  assert(p.abilDovute.join(',') === '2', 'e lo slot 2 del livello 7 (il terzo, del 13, e ancora vuoto)');
  r1.phase = C.PHASE_SHOP;
  let n = 0;
  while ((p.scaglioniDovuti.length || p.abilDovute.length) && n < 10) { r1.offerBoon(p); r1.pickBoon('a', p.boonOffer[0]); n++; }
  assert(n === 5, 'al 12 si e scelto cinque volte: quattro passive e l attiva del 7 (' + n + ')');
  const prese = Object.keys(p.boonsOwned).map(id => Loot.BOON_BY_ID[id]);
  assert(new Set(prese.map(b => b.rarity)).size === 4, 'una passiva per scaglione, mai due dello stesso');
  assert(!!p.abil[0] && !!p.abil[1] && !p.abil[2], 'e i primi due slot sono pieni, il terzo e ancora vuoto');
  assert(prese.every(b => b.hero === 'paladino'), 'e mai una di un altra classe');

  // --- 4) IL TETTO: al 15 NON si sceglie piu' niente, e l esperienza smette di contare ---
  // v2.18 — QUESTO TEST AFFERMAVA IL BIVIO DELLE SPECIALIZZAZIONI, che non esiste piu'. Quattro dei sei
  // rami (Paladino, Maestro d'Armi, Assassino, Stregone) sono diventati CLASSI: tenerli avrebbe voluto
  // dire un assassino che al quindicesimo si specializza in assassino. Il test non e' stato tolto — e'
  // stato girato: adesso afferma che al 15 il bivio NON compare, che e' la cosa che si romperebbe se
  // qualcuno riempisse di nuovo `SPECS` senza pensarci.
  const r2 = new Room('v179b'); const q = r2.addPlayer('a', conn(), 'A', 'mago'); r2.startGame();
  r2.addXp(q, 99999);
  assert(q.level === 15, 'si arriva al tetto del livello 15');
  assert(!q.specOffer, 'e al 15 NON arriva nessun bivio: le specializzazioni non esistono piu');
  assert(Lv.specsFor('mago').length === 0, 'la tabella delle specializzazioni e vuota, per ogni classe');
  const pool = q.xpPool; r2.addXp(q, 10000);
  assert(q.xpPool === pool && q.level === 15, 'oltre il tetto l esperienza non serve piu a niente');
  assert(q.spec == null, 'e nessuno ha una specializzazione addosso');
  assert(Lv.rankName('mago', 15, null) === 'MAGO', 'e il titolo mostrato resta il nome della classe');

  // --- 5) XP CONDIVISA: stessa quantita a tutti, col fattore di gruppo ---
  for (const np of [1, 2, 3, 6]) {
    const r = new Room('v179c' + np); const ps = [];
    for (let i = 0; i < np; i++) ps.push(r.addPlayer('p' + i, conn(), 'P' + i, 'arciere'));
    r.startGame();
    r.xpCondivisa(1000);
    const atteso = Math.max(1, Math.round(1000 * C.XP_GRUPPO[Math.min(C.XP_GRUPPO.length - 1, np)]));
    assert(ps.every(x => x.xpPool === atteso), np + ' giocatori: tutti prendono ' + atteso + ' XP (' + ps.map(x => x.xpPool).join(',') + ')');
  }
  assert(C.XP_GRUPPO[1] === 1, 'il solista prende il valore pieno');
  let cala = true; for (let i = 2; i < C.XP_GRUPPO.length; i++) if (C.XP_GRUPPO[i] > C.XP_GRUPPO[i - 1]) cala = false;
  assert(cala, 'e piu si e, meno vale la singola uccisione: le ondate crescono meno che proporzionalmente');
  // un caduto non prende esperienza
  const r5 = new Room('v179d'); const a5 = r5.addPlayer('a', conn(), 'A', 'arciere'), b5 = r5.addPlayer('b', conn(), 'B', 'mago');
  r5.startGame(); b5.dead = true; r5.xpCondivisa(500);
  assert(a5.xpPool > 0 && b5.xpPool === 0, 'chi e caduto non guadagna esperienza');

  // --- 6) I PUNTI: 18, costo fisso, una cappata e una a 6 ---
  const r6 = new Room('v179e'); const g = r6.addPlayer('a', conn(), 'A', 'paladino'); r6.startGame();
  r6.addXp(g, 99999); r6.phase = C.PHASE_SHOP;
  assert(g.points === 14, 'quattordici punti a fine crescita (' + g.points + ') — dalla v2.16 i ranghi non ne danno piu');
  for (let i = 0; i < 20; i++) r6.buyStat('a', 'st_for');
  assert(g.buys.st_for === 12 && g.points === 2, 'una statistica al tetto costa 12 e ne restano 2');
  for (let i = 0; i < 20; i++) r6.buyStat('a', 'st_cos');
  assert(g.buys.st_cos === 2 && g.points === 0, 'la seconda arriva a 2 e il bilancio finisce li');

  // --- 7) IL MENU: dal villaggio si torna al menu, e la mappa parte solo col pulsante ---
  const c7 = conn();
  const r7 = new Room('v179f'); const h = r7.addPlayer('a', c7, 'A', 'arciere'); r7.startGame();
  r7.phase = C.PHASE_COMBAT; r7.monsters.length = 0; r7.pending = 0; r7._checkWaveClear(); r7.exitWave('a');
  assert(r7.phase === C.PHASE_SHOP, 'chiusa l ondata si e nel menu');
  const ondata = r7.wave;
  r7.vaiAlVillaggio('a');
  assert(r7.phase === C.PHASE_MARKET, 'il pulsante Villaggio porta al villaggio');
  const T = C.TILE; h.x = r7.map.exit.x * T + T / 2; h.y = r7.map.exit.y * T + T / 2;
  c7.box.length = 0; r7._checkMarketExit();
  assert(r7.phase === C.PHASE_SHOP && r7.wave === ondata, 'e uscendo si torna al menu, sulla stessa ondata');
  // tornando dal villaggio il pannello e' completo: riepilogo, statistiche, abilita'
  for (const tipo of [C.MSG.WAVE_STATS, C.MSG.OFFER_SHOP, C.MSG.OFFER_BOON, C.MSG.BOONS])
    assert(c7.box.some(m => m.t === tipo), 'tornando dal villaggio il menu si ricostruisce tutto (' + tipo + ')');
  r7.shopReady('a'); r7.update(0.1);
  assert(r7.phase !== C.PHASE_SHOP && r7.wave === ondata + 1, 'e solo il pulsante centrale fa partire la mappa dopo');

  // --- 8) I VALORI NUOVI delle passive, quelli che il motore legge davvero ---
  const r8 = new Room('v179g'); const m8 = r8.addPlayer('a', conn(), 'A', 'mago'); r8.startGame(); r8.phase = C.PHASE_SHOP;
  const prendi = (id) => { m8.boonOffer = [id]; r8.pickBoon('a', id); };
  // v1.79.2 — Scudo Vitale non alza piu' i PV ne' rigenera: da' resistenza, e basta.
  const dr0 = m8.stats.dmgReduce; prendi('pal_baluardo');
  assert(Math.abs(m8.stats.dmgReduce - (dr0 + 0.05)) < 1e-9, 'Scudo Vitale da -5% ai danni subiti');
  assert(m8.stats.regen === undefined, 'e non rigenera piu un solo PV (dalla v1.93 il campo non esiste)');
  prendi('mag_catena'); assert(m8.boon.chain === 2, 'Catena di Fulmini: due rimbalzi');
  prendi('arc_concentra'); assert(m8.boon.concentra === 0.10, 'Concentrazione: +10% al colpo piazzato');
  prendi('arc_lentezza'); assert(m8.boon.lentezza === 200, 'Campo di Lentezza: raggio 200');
  // il campo rallenta davvero i nemici vicini, e non quelli lontani
  r8.phase = C.PHASE_COMBAT; r8.monsters.length = 0;
  // v1.80 — si misura LO STESSO nemico, dallo STESSO punto, col campo acceso e col campo spento. Prima
  // il confronto era fra un nemico vicino e uno a 900 px: reggeva solo perche' i lontani correvano di
  // piu' (il recupero di distanza, spento nella v1.80), e senza quello il test diventava un lancio di dadi.
  const dentro = r8.spawnMonster('skeleton', m8.x + 120, m8.y, { scaling: Waves.scaling(2, 1) });
  dentro.awake = true; dentro.impegnato = 1;
  const p0 = { x: dentro.x, y: dentro.y };
  for (let i = 0; i < C.TICK_RATE; i++) r8.update(1 / C.TICK_RATE);
  const dLento = MU.dist(dentro.x, dentro.y, p0.x, p0.y);
  dentro.x = p0.x; dentro.y = p0.y; m8.boon.lentezza = 0;   // stesso punto, campo spento
  for (let i = 0; i < C.TICK_RATE; i++) r8.update(1 / C.TICK_RATE);
  const dPieno = MU.dist(dentro.x, dentro.y, p0.x, p0.y);
  m8.boon.lentezza = 200;
  assert(dLento < dPieno * 0.92, 'dentro al campo lo stesso nemico si muove meno (' + dLento.toFixed(0) + ' contro ' + dPieno.toFixed(0) + ' px in un secondo)');
  // le abilita' che alzano i PV in percentuale restano equilibrate fra classi: lo verifica Colosso,
  // che e' rimasto percentuale (il guerriero ha 200 PV, il mago 100).
  const rG = new Room('v179h'); const gg = rG.addPlayer('a', conn(), 'A', 'paladino'); rG.startGame(); rG.phase = C.PHASE_SHOP;
  const gHp0 = rG.effMaxHp(gg); gg.boonOffer = ['bar_colosso']; rG.pickBoon('a', 'bar_colosso');
  assert(Math.abs(rG.effMaxHp(gg) / gHp0 - 1.17) < 0.02, 'Colosso alza i PV in proporzione, non in cifra fissa (v2.20.0: +17%)');

  ok('impianto v1.79 verificato');
}

// ===================== v1.79.1 — PIU' NEMICI PRESTO, E LA CURVA CHE CI STA DIETRO ==========
// La v1.79 aveva tarato la curva su una misura sbagliata (uccisioni istantanee = combo incollata al
// massimo): sul campo, alla quinta ondata si era ancora di livello 2. Qui si fissa il rapporto vero fra
// quello che le ondate mettono a terra e quello che i livelli costano, cosi' non puo' ricapitare.
function testV1791() {
  console.log('\n[TEST 53] v1.79.1 — le prime ondate sono piu' + "'" + ` piene, e la curva ci sta dietro`);
  const Lv = require('../shared/levels.js');
  // --- 1) piu' nemici presto, gli stessi alla fine ---
  const n = (w) => Waves.scaling(w, 1).count;
  assert(n(1) >= 11, 'la prima ondata ha almeno 11 nemici (' + n(1) + ', erano 7)');
  assert(n(4) >= 15, 'la quarta ne ha almeno 15 (' + n(4) + ', erano 12)');
  assert(n(19) >= 38 && n(19) <= 44, 'la diciannovesima resta dov era (' + n(19) + ', erano 39)');
  let cresce = true; for (let w = 2; w <= 20; w++) if (n(w) <= n(w - 1)) cresce = false;
  assert(cresce, 'e la curva del numero cresce sempre');
  // il numero di VIVI insieme non cambia: quello lo decide il tetto, non il conteggio dell ondata
  const room = new Room('v1791'); room.addPlayer('a', { send() {} }, 'A', 'arciere'); room.startGame();
  // v1.79.2 — e adesso si vedono TUTTI: il tetto (40) sta sopra al numero dell'ondata.
  room.wave = 1; assert(room.tettoVivi() >= n(1), 'alla prima ondata ci stanno in campo tutti e ' + n(1) + ' i nemici');

  // --- 2) L'ESPERIENZA CHE UN ONDATA METTE DAVVERO A TERRA, senza combo ---
  // Questa e' la misura che era stata sbagliata: si conta l'xp dei mostri dell'ondata, punto.
  const Mon = require('../shared/monsters.js');
  const xpOndata = (w, giri) => {
    let tot = 0;
    for (let k = 0; k < giri; k++) {
      const l = Waves.buildWave(w, 1, Waves.modeForWave(w)).list;
      for (const it of l) tot += Math.round((Mon.MONSTERS[it.type].xp || 0) * (it.elite ? 2.5 : 1));
    }
    return Math.round(tot / giri);
  };
  const o1 = xpOndata(1, 40);
  assert(o1 > 85, 'la prima ondata mette a terra almeno 85 XP (' + o1 + ', erano 60)');
  // e la prima scelta deve arrivare presto: il livello 3 costa meno di quello che danno le prime quattro
  let cum = 0; for (let w = 1; w <= 4; w++) cum += xpOndata(w, 30);
  assert(Lv.xpForLevel(3) < cum, 'il primo scaglione (livello 3, ' + Lv.xpForLevel(3) + ' XP) arriva entro la quarta ondata (' + cum + ' a terra)');
  assert(Lv.xpForLevel(2) < xpOndata(1, 30) + xpOndata(2, 30), 'e il livello 2 entro la seconda');

  // --- 3) IL RAPPORTO CHE NON DEVE PIU' SBALLARE ---
  // Tutta l'esperienza che le venti ondate mettono a terra, contro quello che costa arrivare al 15.
  let tutta = 0;
  for (let w = 1; w <= 19; w++) tutta += Waves.isBossWave(w) ? 500 : xpOndata(w, 20);
  tutta += 2400;  // il MEGA BOSS finale
  const rapporto = tutta / Lv.xpForLevel(15);
  assert(rapporto > 1.0 && rapporto < 1.6,
    'il livello 15 costa fra il 60% e il 100% di tutta l esperienza della partita (rapporto ' + rapporto.toFixed(2) + '): ' +
    'sopra e irraggiungibile, sotto si arriva al tetto a meta gioco');
  ok('conteggio dei nemici e curva verificati uno contro l altro');
}

// ===================== v1.79.2 — LE PASSIVE RIFATTE ========================================
// Erano troppo forti e alcune erano doppioni. Qui si verificano una per una quelle nuove, e soprattutto
// che facciano quello che c'e' scritto sulla carta — che e' la cosa che il giocatore legge.
function testV1792() {
  console.log('\n[TEST 54] v1.79.2 — passive ritarate e rifatte');
  const conn = () => ({ send() {} });
  // v2.15 — `dr0` e' la riduzione che il personaggio ha GIA' prima della carta: dal profilo della
  // classe un ladro (COS 6, sopra il centro) nasce con un mezzo punto di riduzione. Queste prove
  // misurano quanto vale LA CARTA, quindi si guarda la differenza, non il totale — se no il giorno
  // che il profilo si sposta di un soffio falliscono tutte per il motivo sbagliato.
  const nuova = (eroe, id) => { const r = new Room('p' + id); const p = r.addPlayer('a', conn(), 'A', eroe); r.startGame(); r.phase = C.PHASE_SHOP; const dr0 = p.stats.dmgReduce || 0; p.boonOffer = [id]; r.pickBoon('a', id); return { r, p, dr0 }; };

  // --- le tarature semplici ---
  // v2.20.0 — le tarature DIMEZZATE del mazzo nuovo, e ogni carta sulla classe che ce l'ha.
  { const { p } = nuova('arciere', 'arc_lungo'); assert(p.boon.longshot === 1 && Math.abs(p.stats.critChance - 0.03) < 1e-9, 'Tiro Lungo: la gittata, non il critico'); }
  { const { p } = nuova('arciere', 'arc_teste'); assert(Math.abs(p.boon.vsElite - 0.12) < 1e-9, 'Cacciatore di Teste: +12% su elite e boss'); }
  { const { p, dr0 } = nuova('paladino', 'pal_baluardo'); assert(Math.abs((p.stats.dmgReduce - dr0) - 0.05) < 1e-9 && p.stats.regen === undefined, 'Baluardo: -5% e nessuna cura'); }
  { const { p } = nuova('barbaro', 'bar_peso'); assert(Math.abs(p.boon.armaPesante - 0.05) < 1e-9 && !p.perk.arcoPiu, 'Peso del Colpo: +5% con l arma pesante, niente altro'); }

  // --- TOSSINA: una quota del colpo, non un numero fisso ---
  { const { r, p } = nuova('mago', 'ass_tossina');
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0;
    const m = r.spawnMonster('skeleton', p.x + 60, p.y, { scaling: Waves.scaling(3, 1) }); m.hp = m.maxHp = 5000;
    r.damageMonster(m, 200, p.x, p.y, 0, p, { poison: Math.round(200 * 0.05) });
    assert(m.poison === 10, 'il veleno vale il 5% del colpo (' + m.poison + ' su 200)');
    const hp0 = m.hp; for (let i = 0; i < C.TICK_RATE * 2; i++) r.update(1 / C.TICK_RATE);
    assert(m.hp < hp0, 'e fa danno nel tempo (' + (hp0 - m.hp) + ' in due secondi)'); }

  // --- BARBARO: il Peso del Colpo vale SOLO con l'arma pesante in mano ---
  // v2.20.0 — ha preso il posto del Colpo Ampio, che era del guerriero generico e quindi di tre classi.
  // La prova e' la stessa idea: la carta deve fare quello che c'e' scritto, e solo quando c'e' scritto.
  { const Gear2 = require('../shared/gear.js');
    const { r, p } = nuova('barbaro', 'bar_peso');
    const pesante = Gear2.itemsOfRank('barbaro', 'weapon', 3).find(i => i.carattere === 'pesante');
    const leggera = Gear2.itemsOfRank('barbaro', 'weapon', 3).find(i => i.carattere === 'leggera');
    p.owned[leggera.id] = 1; p.gear.manoDx = leggera.id; p.gear.manoSx = null; r._recomputeGear(p); r._recomputeBoons(p);
    const conLeggera = r.effDamage(p) / r.effWeapon(p).dmg;
    p.owned[pesante.id] = 1; p.gear.manoDx = pesante.id; p.gear.manoSx = null; r._recomputeGear(p); r._recomputeBoons(p);
    const conPesante = r.effDamage(p) / r.effWeapon(p).dmg;
    assert(conPesante > conLeggera * 1.04, 'Peso del Colpo: con la pesante in mano il moltiplicatore sale (' + conLeggera.toFixed(3) + ' -> ' + conPesante.toFixed(3) + ')'); }

  // --- MAGO: Concentrazione si carica da fermo e si consuma ---
  { const { r, p } = nuova('mago', 'arc_concentra');
    r.phase = C.PHASE_COMBAT; p.input.mx = 0; p.input.my = 0;
    for (let i = 0; i < C.TICK_RATE; i++) r.update(1 / C.TICK_RATE);
    assert(p.fermoT >= 0.5, 'stando fermo la concentrazione si carica (' + p.fermoT.toFixed(2) + 's)');
    // il critico va SPENTO per questa misura: due colpi confrontati fra loro, uno dei due che fa critico
    // e il test diventa un lancio di dadi (e' successo: 70 contro 128, con la Concentrazione funzionante).
    p.stats.critChance = 0;
    r.bullets.length = 0; p.fireCd = 0; r.firePlayerWeapon(p);
    const carico = r.bullets.find(x => !x.hostile);
    assert(p.fermoT === 0, 'e il colpo la consuma');
    r.bullets.length = 0; p.fireCd = 0; r.firePlayerWeapon(p);
    const scarico = r.bullets.find(x => !x.hostile);
    assert(carico && scarico && carico.dmg > scarico.dmg, 'il colpo piazzato fa piu male del successivo (' + carico.dmg + ' > ' + scarico.dmg + ')'); }

  // --- LADRO: Colpo alle Spalle, Lama Sporca, Passo d Ombra, Punto Vitale, Uscita di Scena ---
  { const { r, p } = nuova('arciere', 'ass_spalle');
    assert(Math.abs(p.perk.spalle - 0.10) < 1e-9, 'Colpo alle Spalle: +10% (dimezzato nella v2.20.0)');
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0;
    const m = r.spawnMonster('skeleton', p.x + 60, p.y, { scaling: Waves.scaling(2, 1) }); m.hp = m.maxHp = 9000;
    m.facing = 0; let hp0 = m.hp; r.damageMonster(m, 100, m.x + 50, m.y, 0, p, {}); const davanti = hp0 - m.hp;
    hp0 = m.hp; r.damageMonster(m, 100, m.x - 50, m.y, 0, p, {}); const dietro = hp0 - m.hp;
    assert(dietro > davanti, 'da dietro fa piu male (' + dietro + ' contro ' + davanti + ')'); }
  { const { r, p } = nuova('arciere', 'mae_sporca');
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0;
    const m = r.spawnMonster('skeleton', p.x + 60, p.y, { scaling: Waves.scaling(2, 1) }); m.hp = m.maxHp = 9000;
    r.damageMonster(m, 100, p.x, p.y, 0, p, { crit: false });
    assert(!m.bleedT, 'un colpo normale non fa sanguinare');
    r.damageMonster(m, 100, p.x, p.y, 0, p, { crit: true });
    assert(m.bleedT > 0 && m.bleed > 0, 'un critico apre l emorragia (' + m.bleed + '/mezzo secondo)'); }
  { const { r, p } = nuova('arciere', 'ass_ombra');
    r.phase = C.PHASE_COMBAT; p.cdDash = 0; r.useDash(p);
    assert(p.ombraT > 0, 'lo scatto apre la finestra del critico'); }
  { const { r, p } = nuova('arciere', 'arc_vitale');
    assert(p.boon.critOgni === 10, 'Punto Vitale: un critico ogni dieci colpi (dimezzato nella v2.20.0)');
    r.phase = C.PHASE_COMBAT; r.bullets.length = 0;
    let critici = 0;
    p.stats.critChance = 0;                      // si misurano i critici GARANTITI, non la fortuna
    for (let k = 0; k < 20; k++) { p.fireCd = 0; r.bullets.length = 0; r.firePlayerWeapon(p); const b = r.bullets.find(x => !x.hostile); if (b && b.crit) critici++; }
    assert(critici === 2, 'su venti colpi sono due i critici garantiti (' + critici + ')'); }
  { const { r, p } = nuova('arciere', 'ass_scena');
    r.phase = C.PHASE_COMBAT; p.hp = Math.round(r.effMaxHp(p) * 0.35); p.buffs = {};
    r.damagePlayer(p, Math.round(r.effMaxHp(p) * 0.10), p.x + 30, p.y, 0);
    assert(p.buffs.hidden > 0, 'sotto il 30% dei PV si sparisce dalla vista');
    assert(p.scomparsaCd > 0, 'e parte la ricarica');
    const cd = p.scomparsaCd; p.buffs.hidden = 0;
    r.damagePlayer(p, 5, p.x + 30, p.y, 0);
    assert(!p.buffs.hidden, 'e non si ripete finche la ricarica non e finita'); }

  // --- LE SINERGIE puntano tutte ad abilita che esistono ---
  for (const sy of Loot.SYNERGIES) {
    const ab = sy.need.map(id => Loot.BOON_BY_ID[id]);
    assert(ab.every(Boolean), 'la sinergia ' + sy.name + ' punta ad abilita esistenti (' + sy.need.join(' + ') + ')');
    const classi = new Set(ab.map(b => b.hero).filter(h => h !== '*'));   // le sinergie restano legate a un CORPO solo
    assert(classi.size <= 1, 'ed e raggiungibile da una classe sola (' + sy.name + ')');
  }
  ok('passive rifatte verificate');
}

// ===================== v1.79.2 — I TRE BEHOLDER =============================================
// Erano uno solo, dipinto come una marionetta, e soprattutto NON ATTACCAVANO: si poteva restare davanti
// a un Beholder tutto il giorno e non succedeva niente. Adesso sono tre, dipinti a codice, e mordono.
function testBeholder179() {
  console.log('\n[TEST 55] v1.79.2 — i tre Beholder: dipinti, e adesso attaccano');
  const Mon = require('../shared/monsters.js');
  const TRE = ['occhio', 'occhio_carne', 'occhio_spettro'];
  // --- 1) la famiglia ---
  for (const id of TRE) {
    const d = Mon.MONSTERS[id];
    assert(!!d, 'esiste ' + id);
    assert(d.ai === 'gazer' && d.beholder, id + ': stessa IA e stessa famiglia');
    assert(d.dipinto && !d.puppet, id + ': dipinto a codice, niente marionetta');
    assert(d.gazeDmg > 0 && d.biteRange > 0, id + ': ha il raggio che fa danno E il morso');
    assert(Mon.ORDER.includes(id), id + ': e nel bestiario');
  }
  const [A, B, Cc] = TRE.map(id => Mon.MONSTERS[id]);
  assert(A.hp < B.hp && B.hp < Cc.hp, 'la scala di pericolo cresce: viola < carne < spettrale (' + A.hp + ' < ' + B.hp + ' < ' + Cc.hp + ')');
  assert(A.dmg < B.dmg && B.dmg < Cc.dmg, 'e anche il danno');
  assert(A.xp < B.xp && B.xp < Cc.xp, 'e l esperienza che valgono');
  // --- 2) entrano in ondate diverse, uno per volta ---
  const at = w => Waves.poolForWave(w).map(x => x.id);
  assert(!at(7).includes('occhio') && at(8).includes('occhio'), 'il Viola entra alla 8');
  assert(!at(9).includes('occhio_carne') && at(10).includes('occhio_carne'), 'quello di Carne alla 10');
  assert(!at(11).includes('occhio_spettro') && at(12).includes('occhio_spettro'), 'lo Spettrale alla 12');
  // i tre Ragni, intrecciati ai Beholder
  assert(!at(7).includes('ragno') && at(8).includes('ragno'), 'la Vedova delle Volte entra alla 8');
  assert(!at(9).includes('ragno_cripta') && at(10).includes('ragno_cripta'), 'il Ragno della Cripta alla 10');
  assert(!at(10).includes('ragno_veleno') && at(11).includes('ragno_veleno'), 'la Tessitrice Verde alla 11');
  const R1 = Mon.MONSTERS.ragno, R2 = Mon.MONSTERS.ragno_cripta, R3 = Mon.MONSTERS.ragno_veleno;
  assert(R1.ai === 'weaver' && R2.ai === 'weaver' && R3.ai === 'weaver', 'i tre Ragni hanno lo stesso comportamento');
  assert(R1.hp < R2.hp && R2.hp < R3.hp, 'e crescono di pericolo (' + R1.hp + ' < ' + R2.hp + ' < ' + R3.hp + ')');
  assert(R1.pal !== R2.pal && R2.pal !== R3.pal, 'tre palette diverse');
  // --- 3) IL RAGGIO FA MALE ---
  const room = new Room('beh179'); const p = room.addPlayer('b', { send() {} }, 'B', 'paladino'); room.startGame();
  room.phase = C.PHASE_COMBAT; room.monsters.length = 0;
  const spot = losSpot(room, p, 220);
  const occ = room.spawnMonster('occhio', spot.x, spot.y, { scaling: Waves.scaling(9, 1) });
  occ.awake = true; occ.facing = Math.atan2(p.y - occ.y, p.x - occ.x); occ.gazeKind = 'weaken';
  p.hp = room.effMaxHp(p); const hp0 = p.hp; p.buffs = {};
  for (let i = 0; i < C.TICK_RATE * 3; i++) { p.input = { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }; room.update(1 / C.TICK_RATE); if (p.hp < hp0) break; }
  assert(p.hp < hp0, 'restare nel raggio costa vita (' + (hp0 - p.hp) + ' danni)');
  // --- 4) DA VICINO MORDE, e smette di guardare ---
  const r2 = new Room('beh179b'); const q = r2.addPlayer('c', { send() {} }, 'C', 'paladino'); r2.startGame();
  r2.phase = C.PHASE_COMBAT; r2.monsters.length = 0;
  const occ2 = r2.spawnMonster('occhio_carne', q.x + 60, q.y, { scaling: Waves.scaling(12, 1) });
  occ2.awake = true; occ2.atkT = 0;
  q.hp = r2.effMaxHp(q); const hq0 = q.hp; q.buffs = {};
  let morso = false;
  for (let i = 0; i < C.TICK_RATE * 3; i++) {
    occ2.x = q.x + 60; occ2.y = q.y;   // lo si tiene addosso: si misura il morso, non l inseguimento
    q.input = { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false };
    r2.update(1 / C.TICK_RATE);
    if (r2.events.some(e => e.t === 'bite')) morso = true;
    if (morso && q.hp < hq0) break;
  }
  assert(morso, 'sotto la distanza ravvicinata azzanna');
  assert(q.hp < hq0, 'e il morso fa danno (' + (hq0 - q.hp) + ')');
  assert(!occ2.gazeActive, 'mentre morde non sta guardando: una cosa alla volta');
  ok('i tre Beholder verificati');
}

// ============================================================================
// TEST 56 — v1.80: i nemici ti CERCANO
// Il difetto era questo: chi non ti vedeva sceglieva un punto a caso entro 350 px e ci andava.
// Su una mappa da 64x46 tile questo vuol dire che meta' dell'ondata gira in un angolo dove non
// passerai mai, e l'ondata si trascina. Adesso chi non ti vede segue il campo di flusso verso di
// te, piu' piano di chi ti vede. Le due cose da provare sono che ARRIVA e che NON COMPARE.
// ============================================================================
function testV180() {
  console.log('\n[TEST 56] v1.92 — chi non ti vede VAGA, e non ti si accalca addosso');
  const dt = 1 / C.TICK_RATE;
  const AI = require('../shared/ai.js');

  // --- 1) la caccia della v1.80 non punta piu' verso di te: vaga ---
  // Il contesto finto dice che il giocatore e' esattamente a destra (flusso 1,0 e nearest a +900 px).
  // Chi CACCIAVA partiva dritto in quella direzione. Chi VAGA sceglie a caso: su venti mostri appena
  // nati la direzione media verso il giocatore deve essere prossima allo zero.
  assert(typeof AI.caccia === 'function', 'shared/ai.js espone la caccia');
  {
    const fake = { dt, flowStep: () => ({ x: 1, y: 0, d: 5 }), nearest: () => ({ x: 900, y: 0, radius: 14 }), isWallAt: () => false, losClear: () => true };
    let somma = 0, verso = 0, fermi = 0, vmax = 0;
    for (let k = 0; k < 20; k++) {
      const a = { x: 0, y: 0, mx: 0, my: 0, speed: 100, def: {} };
      AI.caccia(a, fake, 0.75);
      const v = Math.hypot(a.mx, a.my); if (v < 1) fermi++; if (v > vmax) vmax = v;
      if (v > 0) { const c = a.mx / v; somma += c; if (c > 0.5) verso++; }
    }
    const medio = somma / 20;
    assert(fermi === 0, 'chi vaga si muove davvero (nessuno dei 20 e resta fermo)');
    assert(Math.abs(medio) < 0.5, 'ma non verso di te: direzione media ' + medio.toFixed(2) + ' (0 = a caso, 1 = dritto addosso)');
    assert(verso < 15, 'e non e un caso isolato: solo ' + verso + ' su 20 sono partiti nella tua direzione');
    const b = { x: 0, y: 0, mx: 0, my: 0, speed: 100, def: {} };
    AI.behaviors.charger(b, Object.assign({}, fake, { melee() {}, emit() {} }));
    assert(vmax < Math.hypot(b.mx, b.my), 'e chi ti vede resta il piu veloce (' + vmax.toFixed(0) + ' < ' + Math.hypot(b.mx, b.my).toFixed(0) + '): vederti conta ancora');
  }

  // --- 2) messo lontano e SENZA linea di vista, il nemico NON ti trova da solo ---
  // E' il cuore della v1.92, ed e' l'esatto contrario di cio' che questo test chiedeva nella v1.80:
  // un nemico che non ti ha mai visto non deve sapere dove sei. Cammina, gira, ma non arriva.
  const room = new Room('v192'); const p = room.addPlayer('a', { send() {} }, 'A', 'paladino'); room.startGame();
  // v1.97 — questa prova vuole la CAVERNA: dalla 1.97 le ondate 1-2 si giocano nel cimitero, che e' molto
  // piu' aperto (2350 tessere libere contro 1370) e quindi ti fa vedere da lontano. Li' il branco arriva
  // per un motivo giusto — ti VEDE — e non si misurerebbe piu' il vagabondaggio, si misurerebbe la mappa.
  //
  // v2.9.2 — E VUOLE ANCHE UN CASO SOLO, SEMPRE LO STESSO. La mappa era gia' seminata (4242), ma il
  // vagabondaggio pesca da `Math.random`, che non lo e': lo scheletro girava a caso e una volta su quattro
  // capitava in linea di vista e ci restava, facendo fallire la soglia del 50%. Un test che grida al lupo
  // una volta su quattro smette di essere letto, ed e' peggio di non averlo.
  //
  // La strada sbagliata sarebbe alzare la soglia: nasconde il rumore E il segnale, e il giorno che l'IA
  // peggiora davvero non se ne accorge nessuno. Qui invece si semina `Math.random` per la durata del
  // blocco e lo si rimette a posto subito dopo: il test misura esattamente quello che misurava prima, ma
  // da' sempre la stessa risposta. Chi cambia l'IA vede cambiare il numero, ed e' l'unico allarme utile.
  const _rndVero = Math.random; Math.random = MU.seedRng(0xBEEF);
  room.newMap(4242, 5); room.wave = 5;
  room.pending = 0; room.waveList = []; room.monsters.length = 0;
  let spot = null;
  for (let ty = 1; ty < room.map.h - 1 && !spot; ty++) for (let tx = 1; tx < room.map.w - 1; tx++) {
    const x = (tx + 0.5) * C.TILE, y = (ty + 0.5) * C.TILE;
    if (room.isWallAt(x, y)) continue;
    const d = MU.dist(x, y, p.x, p.y);
    if (d < 700 || d > 1050) continue;
    if (room.losClear(p.x, p.y, x, y)) continue;   // deve essere nascosto: non ti vede e non lo vedi
    spot = { x, y }; break;
  }
  assert(!!spot, 'trovato un angolo lontano e cieco da cui partire');
  const m = room.spawnMonster('skeleton', spot.x, spot.y, { scaling: Waves.scaling(1, 1) });
  m.awake = true;
  const d0 = MU.dist(m.x, m.y, p.x, p.y);
  let peggioScatto = 0, scatti = 0;
  let dMin = d0, percorso = 0, vagando = 0, visto = 0, tick = 0;
  for (let i = 0; i < C.TICK_RATE * 40 && !m.dead; i++) {
    const pr = MU.dist(m.x, m.y, p.x, p.y); const ax = m.x, ay = m.y;
    p.hp = room.effMaxHp(p);                        // fermo e immortale: si misura l IA, non lo scontro
    room.setInput('a', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
    room.update(dt);
    const po = MU.dist(m.x, m.y, p.x, p.y);
    if (po < dMin) dMin = po;
    percorso += MU.dist(m.x, m.y, ax, ay);
    tick++;
    // in che modo si sta muovendo: 'wx' e' il bersaglio del vagabondaggio, e c'e' solo mentre vaga.
    if (po <= (m.def.sightRange || 560) && room.losClear(m.x, m.y, p.x, p.y)) visto++; else if (m.wx != null) vagando++;
    // niente teletrasporti sotto gli occhi: il guadagno per tick resta quello che le gambe consentono
    if (po <= 900) { const g = pr - po, max = (m.speed || 120) * dt * 1.5 + 34; if (g > max) { scatti++; if (g > peggioScatto) peggioScatto = g; } }
  }
  assert(percorso > 300, 'in 40 s cammina eccome (' + percorso.toFixed(0) + ' px di strada): vagare non e restare fermi');
  // Non si misura "quanto e' arrivato vicino": vagando a caso, una volta ogni tanto ti capita addosso
  // davvero, ed e' esattamente il gioco che vogliamo. Si misura COME si muove: o ti vede, o vaga. Non
  // esiste piu' il terzo stato della v1.80 — quello in cui ti veniva a prendere senza averti mai visto.
  assert(vagando + visto > tick * 0.9, 'in 40 s o ti vede o vaga, mai altro (' + vagando + ' vagando + ' + visto + ' in vista su ' + tick + ' tick; distanza minima toccata ' + dMin.toFixed(0) + ' px, partito da ' + d0.toFixed(0) + ')');
  assert(visto < tick * 0.5, 'e per la maggior parte del tempo non ti ha visto affatto (' + (100 * visto / tick).toFixed(0) + '% dei tick)');
  assert(scatti === 0, 'e non compare mai piu vicino di quanto le gambe consentano (' + scatti + ' scatti, il peggiore ' + peggioScatto.toFixed(0) + ' px/tick)');

  // --- 3) dieci scheletri sparsi NON convergono tutti su di te ---
  const r2 = new Room('v192b'); const q = r2.addPlayer('b', { send() {} }, 'B', 'paladino'); r2.startGame();
  r2.newMap(4343, 5); r2.wave = 5;                    // v1.97 — anche qui la caverna, non il cimitero
  r2.pending = 0; r2.waveList = []; r2.monsters.length = 0;
  let messi = 0;
  for (let k = 0; k < 90 && messi < 10; k++) {
    const a = (k / 18) * Math.PI * 2, rr = 620 + (k % 7) * 110;
    const x = q.x + Math.cos(a) * rr, y = q.y + Math.sin(a) * rr;
    if (x < C.TILE || y < C.TILE || x > (r2.map.w - 1) * C.TILE || y > (r2.map.h - 1) * C.TILE) continue;
    if (r2.isWallAt(x, y)) continue;
    const mm = r2.spawnMonster('skeleton', x, y, { scaling: Waves.scaling(1, 1) }); mm.awake = true; messi++;
  }
  assert(messi >= 6, 'ci sono abbastanza nemici sparsi per la prova (' + messi + ')');
  const media = () => { let s = 0, n = 0; for (const x of r2.monsters) if (!x.dead) { s += MU.dist(x.x, x.y, q.x, q.y); n++; } return n ? s / n : 0; };
  const addosso = () => { let v = 0; for (const x of r2.monsters) if (!x.dead && MU.dist(x.x, x.y, q.x, q.y) < 620) v++; return v; };
  const mediaPrima = media();
  let picco = 0;
  for (let i = 0; i < C.TICK_RATE * 40; i++) {
    for (const x of r2.monsters) x.hp = x.maxHp;    // nessuno muore: si misura la convergenza, non lo scontro
    q.hp = r2.effMaxHp(q);
    r2.setInput('b', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
    r2.update(dt);
    const a = addosso(); if (a > picco) picco = a;
  }
  const mediaDopo = media();
  // v1.92 — quello che la v1.80 chiedeva qui (i sei piu' vicini addosso in 40 s) adesso e' esattamente
  // cio' che NON deve succedere: stando fermo dietro un angolo il branco non ti trova. Restano pero' due
  // promesse da tenere, e sono l'altra meta' del lavoro:
  //   a. non si accalcano: il tetto della folla vale comunque;
  //   b. non spariscono dall'altra parte della mappa: chi e' oltre l'ANELLO rientra (attesa -> seek),
  //      cosi' l'ondata resta a portata di esplorazione invece di dissolversi in un angolo.
  const vicinanze = r2.monsters.filter(x => !x.dead).map(x => MU.dist(x.x, x.y, q.x, q.y)).sort((a, b) => a - b);
  const sesto = vicinanze[Math.min(C.FOLLA_MAX, vicinanze.length) - 1];
  assert(sesto > 400, 'in 40 s da fermo il branco non ti si e piantato addosso (il sesto piu vicino e a ' + sesto.toFixed(0) + ' px)');
  assert(picco <= C.FOLLA_MAX, 'e non si accalcano: mai piu' + String.fromCharCode(39) + ' di ' + picco + ' addosso su ' + messi + ' (tetto ' + C.FOLLA_MAX + ')');
  assert(mediaDopo < (C.ANELLO_ATTESA || 900) * 1.6, 'ma non si dissolvono nemmeno: media da ' + mediaPrima.toFixed(0) + ' a ' + mediaDopo.toFixed(0) + ' px, restano a portata di esplorazione');

  // --- 3-bis) il posto si libera uccidendo: chi aspetta prende il turno ---
  {
    let vivi = r2.monsters.filter(x => !x.dead);
    const impegnatiPrima = vivi.filter(x => x.impegnato === 1).length;
    const attesaPrima = vivi.filter(x => x.impegnato === 0).length;
    // su mappe strette ne entrano meno di quanti se ne volevano: l attesa esiste solo se ce ne sono
    // piu' del tetto, se no non c e' niente da mettere in coda e il controllo non vuol dire nulla.
    if (vivi.length > C.FOLLA_MAX) assert(attesaPrima > 0, 'con piu nemici del tetto qualcuno sta aspettando il turno (' + attesaPrima + ')');
    for (const x of vivi.filter(y => y.impegnato === 1).slice(0, 3)) { x.dead = true; }
    r2._assegnaFolla();
    const impegnatiDopo = r2.monsters.filter(x => !x.dead && x.impegnato === 1).length;
    assert(impegnatiDopo >= Math.min(C.FOLLA_MAX, r2.monsters.filter(x => !x.dead).length), 'uccidendone tre, tre che aspettavano si avviano (impegnati ' + impegnatiPrima + ' -> ' + impegnatiDopo + ')');
  }

  // --- 3-ter) nessun recupero di distanza: chi e lontano cammina come chiunque altro ---
  assert(!/cu = 1 \+ Math\.min/.test(fs.readFileSync(__dirname + '/../server/Room.js', 'utf8')), 'il recupero di distanza (fino a 2,1x oltre i 340 px) e spento');

  // --- 4) chi e fermo per mestiere resta fermo: il Fungo non insegue nessuno ---
  const r3 = new Room('v180c'); const z = r3.addPlayer('c', { send() {} }, 'C', 'mago'); r3.startGame();
  r3.pending = 0; r3.waveList = []; r3.monsters.length = 0;
  const sp = losSpot(r3, z, 420);
  const fun = r3.spawnMonster('spore_fungus', sp.x, sp.y, { scaling: Waves.scaling(4, 1) }); fun.awake = true;
  const fx = fun.x, fy = fun.y;
  for (let i = 0; i < C.TICK_RATE * 8 && !fun.dead; i++) { z.hp = r3.effMaxHp(z); r3.setInput('c', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }); r3.update(dt); }
  assert(MU.dist(fun.x, fun.y, fx, fy) < 45, 'il Fungo Sporifero resta piantato dov e (' + MU.dist(fun.x, fun.y, fx, fy).toFixed(0) + ' px): non cammina, al massimo lo spingono');

  Math.random = _rndVero;   // il seme vale SOLO per questo test: il resto della suite resta vario
  ok('vagabondaggio verificato: ti cercano con gli occhi, non con la mappa');
}

// ============================================================================
// TEST 57 — v1.81: la Larva scoppia, i Ragni tessono
// ============================================================================
function testV181() {
  console.log('\n[TEST 57] v1.81 — la Larva scoppia, i tre Ragni tessono');
  const dt = 1 / C.TICK_RATE;
  const Mon = require('../shared/monsters.js');

  // --- 1) LA LARVA: quando muore lascia una zona, e la zona detona DOPO, non subito ---
  const r1 = new Room('v181a'); const p = r1.addPlayer('a', { send() {} }, 'A', 'paladino'); r1.startGame();
  r1.phase = C.PHASE_COMBAT; r1.monsters.length = 0; r1.pending = 0; r1.waveList = []; r1.zones.length = 0;
  const sp1 = losSpot(r1, p, 200);
  const lv = r1.spawnMonster('larva', sp1.x, sp1.y, { scaling: Waves.scaling(9, 1) }); lv.awake = true;
  const rit = Mon.MONSTERS.larva.esplode.ritardo;
  assert(rit === 3, 'la Larva scoppia dopo 3 secondi (' + rit + ')');
  r1.killMonster(lv, p);
  const z = r1.zones.find(x => Math.abs(x.x - sp1.x) < 1 && Math.abs(x.y - sp1.y) < 1);
  assert(!!z, 'alla morte lascia a terra la zona telegrafata');
  assert(Math.abs(z.max - rit) < 1e-9, 'con il conto alla rovescia di ' + rit + ' s');
  assert(z.r === Mon.MONSTERS.larva.esplode.r, 'e il raggio dichiarato (' + z.r + ' px)');
  // chi resta dentro la prende, chi esce no
  const q1 = new Room('v181b'); const g1 = q1.addPlayer('b', { send() {} }, 'B', 'paladino'); q1.startGame();
  q1.phase = C.PHASE_COMBAT; q1.monsters.length = 0; q1.pending = 0; q1.waveList = []; q1.zones.length = 0;
  const lv2 = q1.spawnMonster('larva', g1.x + 40, g1.y, { scaling: Waves.scaling(9, 1) }); lv2.awake = true;
  q1.killMonster(lv2, g1);
  g1.hp = q1.effMaxHp(g1); const hp0 = g1.hp;
  for (let i = 0; i < C.TICK_RATE * 4; i++) { q1.setInput('b', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false }); q1.update(dt); }
  assert(g1.hp < hp0, 'restare sull esplosione costa vita (' + (hp0 - g1.hp) + ' danni)');

  // --- 2) I TRE RAGNI: stessa famiglia, tre pericoli ---
  for (const id of ['ragno', 'ragno_cripta', 'ragno_veleno']) {
    const d = Mon.MONSTERS[id];
    assert(!!d && d.ai === 'weaver', id + ': esiste e tesse');
    assert(d.ragno && d.pal, id + ': dipinto a codice, con la sua palette');
    assert(d.telaR > 0 && d.telaDur > 0 && d.telaCd > 0, id + ': ha la tela');
    assert(Mon.ORDER.includes(id), id + ': e nel bestiario');
  }

  // --- 3) LA TELA RALLENTA, e non fa danno ---
  const r3 = new Room('v181c'); const p3 = r3.addPlayer('c', { send() {} }, 'C', 'arciere'); r3.startGame();
  r3.phase = C.PHASE_COMBAT; r3.monsters.length = 0; r3.pending = 0; r3.waveList = []; r3.ragnatele.length = 0;
  const sp3 = losSpot(r3, p3, 240);
  const rg = r3.spawnMonster('ragno', sp3.x, sp3.y, { scaling: Waves.scaling(8, 1) }); rg.awake = true; rg.telaT = 0;
  p3.hp = r3.effMaxHp(p3); const hp3 = p3.hp;
  let tessuto = false;
  for (let i = 0; i < C.TICK_RATE * 6 && !tessuto; i++) {
    p3.hp = r3.effMaxHp(p3);
    r3.setInput('c', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
    r3.update(dt);
    if (r3.ragnatele.length) tessuto = true;
  }
  assert(tessuto, 'il ragno tesse una tela dove sei');
  const tela = r3.ragnatele[0];
  p3.buffs.ragnatela = 0;                     // il ragno ha gia' tessuto sotto ai piedi: si azzera per misurare
  const vPiena = r3.effSpeed(p3);
  p3.x = tela.x; p3.y = tela.y; p3.buffs.dash = 0;
  r3.updateRagnatele(dt);
  const vLenta = r3.effSpeed(p3);
  assert(vLenta < vPiena * 0.75, 'dentro la tela vai piu' + String.fromCharCode(39) + ' piano (' + vLenta.toFixed(0) + ' contro ' + vPiena.toFixed(0) + ')');
  // e non fa danno: il colpo del ragno e il morso, non il pavimento
  const hpTela = p3.hp;
  for (let i = 0; i < C.TICK_RATE; i++) { p3.x = tela.x; p3.y = tela.y; r3.updateRagnatele(dt); }
  assert(p3.hp === hpTela, 'e la tela non fa un solo punto di danno');
  // uscendo, il rallentamento si spegne da solo
  p3.x = tela.x + 900; p3.y = tela.y + 900;
  for (let i = 0; i < C.TICK_RATE; i++) { r3.updateRagnatele(dt); p3.buffs.ragnatela = Math.max(0, (p3.buffs.ragnatela || 0) - dt); }
  assert(!(p3.buffs.ragnatela > 0), 'uscito dalla tela torni veloce: non te la porti dietro');
  // la tela scade da sola
  const quante = r3.ragnatele.length;
  for (let i = 0; i < C.TICK_RATE * 10; i++) r3.updateRagnatele(dt);
  assert(r3.ragnatele.length < quante || r3.ragnatele.every(w => w.t > 0), 'le tele scadono col tempo');
  // tetto: non si copre la stanza
  r3.ragnatele.length = 0;
  const ctx3 = r3.makeCtx();
  for (let i = 0; i < 40; i++) ctx3.ragnatela(100 + i, 100, 90, 6, '#fff', 1);
  assert(r3.ragnatele.length <= (C.RAGNATELE_MAX || 14), 'c e un tetto alle tele in campo (' + r3.ragnatele.length + ')');

  // --- 4) le tele spariscono col cambio mappa: sono un posto, non un oggetto ---
  const r4 = new Room('v181d'); r4.addPlayer('d', { send() {} }, 'D', 'mago'); r4.startGame();
  r4.makeCtx().ragnatela(300, 300, 90, 6, '#fff', 1);
  assert(r4.ragnatele.length === 1, 'tela messa');
  r4.newMap(12345, 3);
  assert(r4.ragnatele.length === 0, 'e sparita con la mappa vecchia');

  ok('Larva e Ragni verificati');
}

// ============================================================================
// TEST 58 — v1.82: i mercenari
// La parte difficile non e' il mercenario: e' che il motore lo tratta come un GIOCATORE (corpo,
// bersaglio, morte) mentre le REGOLE non devono trattarlo cosi'. Ogni esclusione ha qui il suo
// controllo, perche' sbagliarne una non da' errore: cambia il bilanciamento in silenzio.
// ============================================================================
function testV182() {
  console.log('\n[TEST 58] v1.82 — mercenari: aiutano, e non contano come giocatori');
  // v2.13 — SEMINATO, come il TEST 62 prima di lui. Questo blocco falliva circa una volta su tre, e non
  // per un bug: la mappa e' generata a caso, quindi il punto dove finisce il mercenario cambia a ogni
  // giro e a volte lo mette dietro uno spigolo. Un test che fallisce a caso e' peggio di un test che non
  // c'e': la volta che segnala qualcosa di vero nessuno gli crede. Con la stessa mappa a ogni giro misura
  // l IA del mercenario, che e' cio' che vuole misurare. (Provato: senza il seme, 1 fallimento su 3.)
  const _rndVero = Math.random; Math.random = MU.seedRng(0x182A);
  const dt = 1 / C.TICK_RATE;
  const Mrc = require('../shared/mercenari.js');
  const conn = { send() {} };

  // --- 1) il listino e la scheda ---
  assert(Mrc.costo(1) === 50, 'un livello 1 costa 50 monete');
  assert(Mrc.costo(15) === 50 + 14 * 40, 'un livello 15 costa ' + Mrc.costo(15));
  for (let l = 2; l <= 15; l++) assert(Mrc.costo(l) > Mrc.costo(l - 1), 'il prezzo sale sempre col livello');
  assert(Mrc.punti(15) === 18, 'a livello 15 ha i 18 punti che avresti tu');
  const b15 = Mrc.distribuisci('barbaro', 15, Loot.STAT_MAX_LEVEL);
  assert(b15.st_for === 12 && b15.st_cos === 6, 'e li spende come la tua run: uno cappato (12) e sei sull altro');
  // v2.18 — i mercenari sono TRE CLASSI, una per impalcatura: barbaro (pesante), mago (arcana),
  // arciere (agile). Erano i tre eroi di allora; aprire il banco a tutte e sette avrebbe voluto dire
  // sette nomi da ricordare per una scelta che dura un'ondata.
  assert(Mrc.CLASSI.join(',') === 'barbaro,mago,arciere', 'il banco offre una classe per impalcatura');
  for (const cl of Mrc.CLASSI) {
    assert(Mrc.NOMI[cl].length === 15, cl + ': quindici nomi');
    assert(Mrc.NOMI[cl].every(n => n.length <= 8), cl + ': nomi corti, ci stanno sopra la testa');
    assert(new Set(Mrc.NOMI[cl]).size === 15, cl + ': tutti diversi');
    assert(Mrc.TINTE[cl].length >= 3, cl + ': almeno tre tinte');
  }

  // --- 2) si assolda al Banditore, in singolo, uno solo ---
  const r = new Room('v182a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
  p.level = 5; r.enterMarket();
  p.x = r.bandit.x; p.y = r.bandit.y; p.coins = 1000;
  const off = r._offertaMerc(p);
  assert(!!off && off.lvl === 5, 'il candidato al banco ha il TUO livello');
  assert(off.costo === Mrc.costo(5), 'e il prezzo del listino (' + off.costo + ')');
  const prima = p.coins;
  r.assumiMercenario('a');
  assert(prima - p.coins === off.costo, 'assoldarlo costa esattamente quel prezzo');
  assert(!!r.mercData && r.mercData.nome === off.nome, 'e la scheda resta in camera');
  const secondo = r._offertaMerc(p);
  assert(!secondo, 'con uno al soldo il banco non ne offre un altro');
  // e non si paga due volte
  const c2 = p.coins; r.assumiMercenario('a');
  assert(p.coins === c2, 'e riprovare non toglie monete');
  // senza monete non si assolda
  const r0 = new Room('v182z'); const p0 = r0.addPlayer('a', conn, 'A', 'mago'); r0.startGame();
  p0.level = 8; r0.enterMarket(); p0.x = r0.bandit.x; p0.y = r0.bandit.y; p0.coins = 10;
  r0.assumiMercenario('a');
  assert(!r0.mercData, 'con dieci monete non si assolda nessuno');

  // --- 3) scende in campo con l ondata, non prima ---
  assert(!r.mercenario, 'al villaggio il mercenario non esiste: non ti segue');
  r.nextWave();
  const m = r.mercenario;
  assert(!!m, 'alla mappa dopo e in campo');
  assert(m.merc === true && m.mercOwner === 'a', 'ed e marcato come mercenario, col suo capo');
  assert(m.level === 5 && m.buys.st_cos >= 0, 'del livello giusto e coi punti spesi');
  assert(Math.abs(m.hp - r.effMaxHp(m)) < 1, 'e arriva curato del tutto');
  assert(!!m.pal, 'con la sua tinta');
  assert(Object.keys(m.boons || {}).length === 0 || !m.boonList || m.boonList.length === 0, 'nessuna abilita: ne passiva ne attiva');

  // --- 4) L ONDATA NON CRESCE. E' il punto di tutta la funzione: aiutare, non alzare l asticella. ---
  const senza = new Room('v182b'); const ps = senza.addPlayer('a', conn, 'A', 'paladino'); senza.startGame();
  ps.level = 5;
  const con = new Room('v182b'); const pc = con.addPlayer('a', conn, 'A', 'paladino'); con.startGame();
  pc.level = 5; con.enterMarket(); pc.x = con.bandit.x; pc.y = con.bandit.y; pc.coins = 1000; con.assumiMercenario('a');
  for (let w = 0; w < 4; w++) { senza.nextWave(); con.nextWave(); }
  assert(!!con.mercenario, 'nella stanza col mercenario c e il mercenario');
  assert(con.veri.length === 1, 'ma i giocatori VERI restano uno');
  assert(con.pending + con.waveList.length === senza.pending + senza.waveList.length,
    'e l ondata ha esattamente gli stessi nemici (' + (con.pending + con.waveList.length) + ' contro ' + (senza.pending + senza.waveList.length) + ')');
  assert(JSON.stringify(con.waveScaling) === JSON.stringify(senza.waveScaling), 'e la stessa durezza, voce per voce');

  // --- 5) L XP RESTA TUTTO TUO ---
  const xp0 = pc.xpPool, xpm = con.mercenario.xpPool;
  con.xpCondivisa(100, 'prova');
  assert(pc.xpPool - xp0 === 100, 'con un mercenario in campo prendi il 100% dell XP (' + (pc.xpPool - xp0) + ')');
  assert(con.mercenario.xpPool === xpm, 'e lui non ne prende un punto');

  // --- 6) non raccoglie niente da terra ---
  const mm = con.mercenario;
  con.groundXp.length = 0; con.groundCoins.length = 0;
  con.groundXp.push({ eid: 1, x: mm.x, y: mm.y, v: 50, t: 30, dead: false });
  con.groundCoins.push({ eid: 2, x: mm.x, y: mm.y, cid: 'c', t: 30, dead: false, v: 10 });
  pc.x = mm.x + 4000; pc.y = mm.y + 4000;
  const xpA = pc.xpPool, coA = pc.coins;
  for (let i = 0; i < C.TICK_RATE * 2; i++) con.updatePickups(dt);
  assert(con.groundXp.length === 1 && con.groundCoins.length === 1, 'sfere e monete sotto i piedi del mercenario restano li');
  assert(pc.xpPool === xpA && pc.coins === coA, 'e non arrivano nemmeno a te per magia');

  // --- 7) la quota della folla non raddoppia ---
  const rf = new Room('v182c'); const pf = rf.addPlayer('a', conn, 'A', 'paladino'); rf.startGame();
  pf.level = 5; rf.enterMarket(); pf.x = rf.bandit.x; pf.y = rf.bandit.y; pf.coins = 1000; rf.assumiMercenario('a');
  rf.nextWave(); rf.phase = C.PHASE_COMBAT; rf.monsters.length = 0; rf.pending = 0; rf.waveList = [];
  for (let k = 0; k < 20; k++) {
    const a = (k / 20) * Math.PI * 2, x = pf.x + Math.cos(a) * 500, y = pf.y + Math.sin(a) * 500;
    if (rf.isWallAt(x, y)) continue;
    const mo = rf.spawnMonster('skeleton', x, y, { scaling: Waves.scaling(5, 1) }); if (mo) mo.awake = true;
  }
  rf._assegnaFolla();
  const impegnati = rf.monsters.filter(x => !x.dead && x.impegnato === 1).length;
  assert(impegnati <= C.FOLLA_MAX, 'col mercenario in campo si fanno sotto sempre e solo ' + C.FOLLA_MAX + ' nemici (' + impegnati + ')');

  // --- 8) il gioco non lo aspetta a fine ondata ---
  rf.monsters.length = 0; rf.pending = 0; rf.waveList = [];
  const c = rf._contaUscita();
  assert(c.tot === 1, 'a fine ondata si aspetta un solo giocatore, non due (' + c.tot + ')');

  // --- 9) LA SUA MORTE NON CHIUDE LA RUN, LA TUA SI ---
  const rd = new Room('v182d'); const pd = rd.addPlayer('a', conn, 'A', 'paladino'); rd.startGame();
  pd.level = 6; rd.enterMarket(); pd.x = rd.bandit.x; pd.y = rd.bandit.y; pd.coins = 1000; rd.assumiMercenario('a');
  rd.nextWave();
  const md = rd.mercenario; assert(!!md, 'mercenario in campo');
  rd.downPlayer(md);
  assert(md.dead && !md.down, 'il mercenario muore e basta: niente "a terra", niente rianimazione');
  assert(rd.phase !== C.PHASE_GAMEOVER, 'e la partita continua');
  assert(!rd.mercenario, 'e non e piu in campo');
  // ...e adesso al banco se ne puo assoldare un altro
  rd._waveDone();
  assert(!rd.mercData, 'caduto lui, la scheda si libera: al banco se ne assolda un altro');
  // il contrario: il giocatore cade con un mercenario vivo
  const rg = new Room('v182e'); const pg = rg.addPlayer('a', conn, 'A', 'paladino'); rg.startGame();
  pg.level = 6; rg.enterMarket(); pg.x = rg.bandit.x; pg.y = rg.bandit.y; pg.coins = 1000; rg.assumiMercenario('a');
  rg.nextWave();
  assert(!!rg.mercenario, 'mercenario vivo');
  pg.dead = true; pg.down = false;
  assert(rg.anyRevivable === false, 'se sei fuori TU non c e piu nessuno da rialzare: il mercenario vivo non tiene aperta la partita');

  // --- 10) fra un ondata e l altra sparisce, e torna curato ---
  const rw = new Room('v182f'); const pw = rw.addPlayer('a', conn, 'A', 'arciere'); rw.startGame();
  pw.level = 9; rw.enterMarket(); pw.x = rw.bandit.x; pw.y = rw.bandit.y; pw.coins = 1000; rw.assumiMercenario('a');
  rw.nextWave();
  const m1 = rw.mercenario; m1.hp = 3;
  rw._waveDone();
  assert(!rw.mercenario, 'a fine ondata non ti segue al villaggio');
  assert(!!rw.mercData, 'ma resta al tuo soldo');
  rw.nextWave();
  const m2 = rw.mercenario;
  assert(!!m2, 'e lo ritrovi sulla mappa dopo');
  assert(Math.abs(m2.hp - rw.effMaxHp(m2)) < 1, 'curato del tutto (' + Math.round(m2.hp) + '/' + Math.round(rw.effMaxHp(m2)) + ')');
  assert(m2.name === m1.name, 'ed e lo stesso: stesso nome');

  // --- 11) solo in singolo, e uno solo ---
  const r2 = new Room('v182g'); const q1 = r2.addPlayer('a', conn, 'A', 'paladino'); r2.addPlayer('b', conn, 'B', 'mago'); r2.startGame();
  r2.enterMarket(); q1.x = r2.bandit.x; q1.y = r2.bandit.y; q1.coins = 1000;
  r2.assumiMercenario('a');
  assert(!r2.mercData, 'in due non si assoldano mercenari');

  // --- 12) la testa: segue il capo e attacca ---
  const ra = new Room('v182h'); const pa = ra.addPlayer('a', conn, 'A', 'paladino'); ra.startGame();
  pa.level = 6; ra.enterMarket(); pa.x = ra.bandit.x; pa.y = ra.bandit.y; pa.coins = 1000; ra.assumiMercenario('a');
  // ATTENZIONE: l ondata va tenuta APERTA. Svuotando il campo, update() la chiude al primo tick e ritira
  // il mercenario — che e' esattamente cio' che deve fare, ma qui si misura altro. Con `pending` a 5 e la
  // lista vuota non entra nessuno e l ondata non finisce mai: campo pulito e cronometro fermo.
  ra.nextWave(); ra.phase = C.PHASE_COMBAT; ra.monsters.length = 0; ra.pending = 5; ra.waveList = [];
  const ma = ra.mercenario;
  assert(!!ma, 'mercenario in campo per la prova');
  // Il punto dove metterlo serve LIBERO PER UN CORPO, non solo non-muro: losSpot guarda un punto, ma un
  // giocatore ha un raggio. Al primo tentativo finiva incastrato nella roccia e il test misurava
  // l anti-incastro invece dell IA — restava fermo a 592 px e sembrava che il guinzaglio non funzionasse.
  const largo = (dist) => {
    for (let k = 0; k < 96; k++) {
      const a = (k / 96) * Math.PI * 2, x = pa.x + Math.cos(a) * dist, y = pa.y + Math.sin(a) * dist;
      if (ra.isWallAt(x, y) || !ra.losClear(pa.x, pa.y, x, y)) continue;
      let ok2 = true;
      for (const [dx, dy] of [[30, 0], [-30, 0], [0, 30], [0, -30], [22, 22], [-22, -22]]) if (ra.isWallAt(x + dx, y + dy)) { ok2 = false; break; }
      if (ok2) return { x, y };
    }
    return null;
  };
  const via = largo(560);
  assert(!!via, 'trovato un punto libero a 560 px dal capo');
  ma.x = via.x; ma.y = via.y;
  const d0 = MU.dist(ma.x, ma.y, pa.x, pa.y);
  const fermo = { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false };
  for (let i = 0; i < C.TICK_RATE * 5; i++) { pa.hp = ra.effMaxHp(pa); ra.setInput('a', fermo); ra.update(dt); }
  const d1 = MU.dist(ma.x, ma.y, pa.x, pa.y);
  assert(d1 < d0 * 0.5, 'se resta indietro torna dal capo (da ' + d0.toFixed(0) + ' a ' + d1.toFixed(0) + ' px)');

  // un mostro accanto al capo: se lo prende lui
  const sp = largo(170) || losSpot(ra, pa, 170);
  const bersaglio = ra.spawnMonster('skeleton', sp.x, sp.y, { scaling: Waves.scaling(2, 1) });
  assert(!!bersaglio, 'bersaglio piazzato');
  bersaglio.awake = true;
  const hp0 = bersaglio.hp;
  for (let i = 0; i < C.TICK_RATE * 8 && !bersaglio.dead; i++) {
    pa.hp = ra.effMaxHp(pa); bersaglio.x = sp.x; bersaglio.y = sp.y;   // tenuto fermo: si misura il mercenario
    ra.setInput('a', fermo); ra.update(dt);
  }
  assert(bersaglio.dead || bersaglio.hp < hp0, 'e i nemici vicini se li prende lui (' + Math.round(hp0 - bersaglio.hp) + ' danni)');

  // --- 13) v1.82.2/3: non si incastra, sta a distanza, e non parte per conto suo ---
  {
    const meta = () => 0.5;   // niente jitter: si misura la direzione, non il caso
    const nuovoM = (h) => ({ x: 0, y: 0, hp: 100, maxHp: 100, hero: Heroes.HEROES[h || 'paladino'], stats: { maxHpFlat: 0 }, fireCd: 0, cdDash: 0 });
    const stanza = (mostri, vista) => ({ dt: 1 / C.TICK_RATE, monsters: mostri, losClear: () => vista !== false });
    const verso = (i, ax, ay) => (i.mx * ax + i.my * ay);   // >0 se si muove in quella direzione

    // a) SPAZIO PERSONALE, e il suo limite: vale finche' non ha nessuno A TIRO. Se c'e' un nemico sotto
    //    l'arma la priorita' e' menare, non tenere le distanze da te — arretrare a meta' scontro sarebbe
    //    peggio del difetto che quella regola risolve.
    {
      // appiccicato al capo, campo pulito: si scosta
      const i = Mrc.pensa(stanza([], true), nuovoM(), { x: 30, y: 0, dead: false }, meta);
      assert(verso(i, 1, 0) < 0, 'incollato al capo, senza nemici, si scosta invece di sovrapporsi');
      // stesso identico caso ma col nemico NEL RAGGIO D'ATTACCO (fra la distanza minima e massima della
      // sua arma): non arretra per farti spazio, resta li' e mena.
      const g = Heroes.HEROES.paladino.weapon, RA = g.arcRadius || 100;
      const vicino = { x: RA * 0.8, y: 0, dead: false };
      const i2 = Mrc.pensa(stanza([vicino], true), nuovoM(), { x: 30, y: 0, dead: false }, meta);
      assert(Math.abs(i2.mx) < 0.01 && Math.abs(i2.my) < 0.01, 'col nemico a tiro non arretra per farti spazio: sta li e mena');
      assert(i2.shoot === true, 'e colpisce');
      assert(Math.abs(i2.aim) < 0.01, 'guardando lui');
      // nemico FUORI dal raggio d'attacco: ci va incontro, non si mette a seguire il capo
      const i3 = Mrc.pensa(stanza([{ x: 300, y: 0, dead: false }], true), nuovoM(), { x: -30, y: 0, dead: false }, meta);
      assert(verso(i3, 1, 0) > 0.5, 'col nemico lontano gli va incontro, invece di stare appresso al capo');
    }
    // b) MENO AGGRESSIVO: un nemico lontano dal CAPO non e' affar suo, anche se lui lo vede benissimo.
    {
      const m = nuovoM(); const capo = { x: -150, y: 0, dead: false };   // nella fascia di scorta: fermo
      const lontano = { x: 300, y: 0, dead: false };            // 450 px dal capo: fuori dalla minaccia
      const i = Mrc.pensa(stanza([lontano], true), m, capo, meta);
      assert(i.shoot === false, 'non ingaggia chi non minaccia il capo');
      assert(verso(i, 1, 0) <= 0.01, 'e non gli parte incontro');
      // lo stesso nemico, col capo vicino a lui, diventa affar suo
      const capo2 = { x: 100, y: 0, dead: false };
      const i2 = Mrc.pensa(stanza([{ x: 200, y: 0, dead: false }], true), nuovoM(), capo2, meta);
      assert(Math.abs(i2.aim) < 0.01, 'ma se minaccia il capo lo affronta');
    }
    // c) fermo nella fascia di scorta: non insegue e non si accavalla
    {
      const m = nuovoM(); const capo = { x: 150, y: 0, dead: false };
      const i = Mrc.pensa(stanza([], true), m, capo, meta);
      assert(Math.abs(i.mx) < 0.01 && Math.abs(i.my) < 0.01, 'a distanza giusta e senza nemici sta fermo');
      // troppo addosso: si stacca fino alla distanza di scorta, non si limita a non accavallarsi
      const i0 = Mrc.pensa(stanza([], true), nuovoM(), { x: 90, y: 0, dead: false }, meta);
      assert(verso(i0, -1, 0) > 0.5, 'troppo addosso al capo: si stacca (' + i0.mx.toFixed(2) + ')');
      const lontanissimo = { x: 260, y: 0, dead: false };
      const i2 = Mrc.pensa(stanza([], true), nuovoM(), lontanissimo, meta);
      assert(verso(i2, 1, 0) > 0.5, 'se il capo si allontana lo raggiunge');
    }
    // d) SENZA LINEA DI VISTA un nemico non e' un bersaglio: non ci si punta contro
    {
      const m = nuovoM(); const capo = { x: 100, y: 0, dead: false };
      const i = Mrc.pensa(stanza([{ x: 200, y: 0, dead: false }], false), m, capo, meta);
      assert(i.shoot === false, 'col nemico dietro al masso non lo affronta');
      // ...ma a portata di mano lo prende comunque: dietro l angolo si mena lo stesso
      const i2 = Mrc.pensa(stanza([{ x: 90, y: 0, dead: false }], false), nuovoM(), capo, meta);
      assert(Math.abs(i2.aim) < 0.01, 'un nemico a novanta px lo affronta anche senza linea di vista');
    }
    // e) ANTI-INCASTRO: se spinge e non si sposta, dopo un attimo cammina di traverso
    {
      const m = nuovoM(); const capo = { x: -260, y: 0, dead: false };   // lontano: vuole muoversi
      let i = Mrc.pensa(stanza([], true), m, capo, meta);
      assert(verso(i, -1, 0) > 0.5, 'parte verso il capo');
      const dir0 = Math.atan2(i.my, i.mx);
      for (let k = 0; k < 14; k++) i = Mrc.pensa(stanza([], true), m, capo, meta);   // m non si muove mai
      const scarto = Math.abs(((Math.atan2(i.my, i.mx) - dir0 + Math.PI) % (Math.PI * 2)) - Math.PI);
      assert(scarto > 0.8, 'spinge e non si sposta: cambia direzione (' + (scarto * 57).toFixed(0) + ' gradi)');
    }
    // f) il mago non spara contro il muro
    {
      const capo = { x: 100, y: 0, dead: false };
      assert(Mrc.pensa(stanza([{ x: 200, y: 0, dead: false }], true), nuovoM('mago'), capo, meta).shoot === true, 'con la strada libera il mago spara');
      assert(Mrc.pensa(stanza([{ x: 200, y: 0, dead: false }], false), nuovoM('mago'), capo, meta).shoot === false, 'contro il muro no: sprecherebbe la ricarica');
    }
  }
  // e) sul campo vero: messo con la faccia contro la roccia, dopo qualche secondo si e' spostato
  {
    const rb = new Room('v182i'); const pb = rb.addPlayer('a', conn, 'A', 'paladino'); rb.startGame();
    pb.level = 4; rb.enterMarket(); pb.x = rb.bandit.x; pb.y = rb.bandit.y; pb.coins = 1000; rb.assumiMercenario('a');
    rb.nextWave(); rb.phase = C.PHASE_COMBAT; rb.monsters.length = 0; rb.pending = 5; rb.waveList = [];
    const mb = rb.mercenario;
    // si cerca un punto libero con la ROCCIA a ridosso: e' li che prima restava a spingere
    let posato = null;
    for (let k = 0; k < 200 && !posato; k++) {
      const a = (k / 200) * Math.PI * 2, x = pb.x + Math.cos(a) * 150, y = pb.y + Math.sin(a) * 150;
      if (rb.isWallAt(x, y)) continue;
      for (const [dx, dy] of [[34, 0], [-34, 0], [0, 34], [0, -34]]) if (rb.isWallAt(x + dx, y + dy)) { posato = { x, y, mx: dx, my: dy }; break; }
    }
    if (posato) {
      mb.x = posato.x; mb.y = posato.y;
      // un nemico oltre la roccia, nella direzione del muro
      const mo = rb.spawnMonster('skeleton', posato.x + posato.mx * 6, posato.y + posato.my * 6, { scaling: Waves.scaling(3, 1) });
      if (mo) mo.awake = true;
      const sx = mb.x, sy = mb.y;
      const fermo2 = { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false };
      let percorso = 0, px2 = mb.x, py2 = mb.y;
      for (let i = 0; i < C.TICK_RATE * 5; i++) {
        pb.hp = rb.effMaxHp(pb); rb.setInput('a', fermo2); rb.update(dt);
        percorso += MU.dist(mb.x, mb.y, px2, py2); px2 = mb.x; py2 = mb.y;
      }
      assert(percorso > 90, 'con la roccia davanti non resta piantato: in 5 s percorre ' + percorso.toFixed(0) + ' px');
    } else { assert(true, 'nessun angolo di roccia utile su questa mappa: prova saltata'); }
  }

  Math.random = _rndVero;
  ok('mercenari verificati: aiutano, e non contano come giocatori');
}

// ============================================================================
// TEST 59 — v1.83: il ribilanciamento delle tre classi
// ============================================================================
function testV183() {
  console.log('\n[TEST 59] v1.83 — scudo frontale del guerriero, cadenza dell arco');
  const dt = 1 / C.TICK_RATE;
  const conn = { send() {} };

  // --- 1) L ARCO: meno frecce, piu' peso per freccia ---
  const arco = Heroes.HEROES.arciere.weapon;
  assert(arco.fireRate === 2.3, 'la cadenza dell arco scende a 2,3 al secondo (era 3,0)');
  assert(arco.dmg === 38, 'e ogni freccia pesa 38 (era 31)');
  const dpsOra = arco.dmg * arco.fireRate;
  assert(dpsOra > 31 * 3.0 * 0.90 && dpsOra < 31 * 3.0, 'il danno al secondo cala di poco (' + dpsOra.toFixed(0) + ' contro 93): cambia il ritmo, non la potenza');
  // le tre classi restano allineate sul danno al secondo di partenza
  const dpsG = Heroes.HEROES.paladino.weapon.dmg * Heroes.HEROES.paladino.weapon.fireRate;
  const dpsM = Heroes.HEROES.mago.weapon.dmg * Heroes.HEROES.mago.weapon.fireRate;
  const M = Math.max(dpsG, dpsM, dpsOra), m2 = Math.min(dpsG, dpsM, dpsOra);
  assert((M - m2) / M < 0.15, 'e le tre classi restano entro il 15% di danno al secondo (' + [dpsG, dpsM, dpsOra].map(x => x.toFixed(0)).join(' / ') + ')');

  // --- 2) LO SCUDO PARA DAVANTI ---
  // v2.12 — lo scudo equilibrato comune contro quello pesante dello stesso grado: e' il confronto giusto
  // adesso, perche' il "para di piu'" e' del CARATTERE e non del grado.
  // lo scudo di PARTENZA: e' quello che il guerriero ha addosso dentro `prova()` qui sotto, e la
  // matematica dello sconto frontale va confrontata con quello, non con uno che potrebbe comprare.
  const sc = Gear.BY_ID[Gear.startingGear('paladino').manoSx];   // v2.18.1 — lo scudo sta in una MANO
  const to = Gear.itemsOfRank('paladino', 'shield', 2, 'pesante').find(i => i.carattere === 'pesante');
  assert(sc.bonus.frontale > 0 && to.bonus.frontale > sc.bonus.frontale, 'i due scudi parano di fronte, la torre piu del piccolo');
  assert(Gear.bonusOf({ manoSx: sc.id }).frontale === sc.bonus.frontale, 'il bonus frontale arriva nel calcolo dell equipaggiamento');
  assert(!Gear.bonusOf({ manoSx: 'lad_mantello' }).frontale, 'e non lo hanno gli altri: e' + String.fromCharCode(39) + ' lo scudo, non la classe');

  const prova = (angoloAttacco) => {
    const r = new Room('v183' + angoloAttacco.toFixed(2)); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    p.aim = 0; p.hp = r.effMaxHp(p); p.buffs = {};
    const sx = p.x + Math.cos(angoloAttacco) * 60, sy = p.y + Math.sin(angoloAttacco) * 60;
    const prima = p.hp; r.damagePlayer(p, 100, sx, sy, 0);
    return prima - p.hp;
  };
  const davanti = prova(0);            // dritto in faccia
  const dietro = prova(Math.PI);       // alle spalle
  const lato = prova(Math.PI / 2);     // di fianco: fuori dal cono (70 gradi per lato)
  assert(davanti < dietro, 'un colpo in faccia fa meno male di uno alle spalle (' + davanti.toFixed(0) + ' contro ' + dietro.toFixed(0) + ')');
  assert(Math.abs(davanti - dietro * (1 - sc.bonus.frontale)) < 1.5, 'e la differenza e' + String.fromCharCode(39) + ' esattamente lo sconto dello scudo');
  assert(Math.abs(lato - dietro) < 1.5, 'di fianco lo scudo non c e: nessuno sconto (' + lato.toFixed(0) + ')');
  // il bordo del cono
  const dentro = prova(C.SCUDO_CONO * 0.9), fuori = prova(C.SCUDO_CONO * 1.1);
  assert(dentro < fuori, 'il cono ha un bordo netto: dentro para (' + dentro.toFixed(0) + '), fuori no (' + fuori.toFixed(0) + ')');

  // --- 3) i colpi SENZA ORIGINE non si parano: non c e una direzione da cui pararli ---
  {
    const r = new Room('v183z'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; p.aim = 0; p.hp = r.effMaxHp(p); p.buffs = {};
    const prima = p.hp; r.damagePlayer(p, 100);
    assert(Math.abs((prima - p.hp) - dietro) < 1.5, 'un colpo senza sorgente non si para');
  }

  // --- 4) e' lo SCUDO a parare, non il guerriero: senza scudo niente parata ---
  {
    const r = new Room('v183y'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; p.aim = 0; p.buffs = {};
    p.gear.manoSx = null; r._recomputeGear(p); p.hp = r.effMaxHp(p);   // v2.18.1 — lo scudo sta in una mano
    const prima = p.hp; r.damagePlayer(p, 100, p.x + 60, p.y, 0);
    const senza = prima - p.hp;
    assert(senza > davanti, 'togli lo scudo e i colpi frontali tornano a farti male (' + senza.toFixed(0) + ' contro ' + davanti.toFixed(0) + ')');
  }

  // --- 5) la torre para piu' dello scudo piccolo ---
  {
    const r = new Room('v183x'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; p.aim = 0; p.buffs = {};
    p.gear.shield = Gear.itemsOfRank('paladino', 'shield', 2, 'pesante').find(i => i.carattere === 'pesante').id;
    r._recomputeGear(p); p.hp = r.effMaxHp(p);
    const prima = p.hp; r.damagePlayer(p, 100, p.x + 60, p.y, 0);
    assert(prima - p.hp < davanti, 'lo Scudo a Torre para piu del piccolo (' + (prima - p.hp).toFixed(0) + ' contro ' + davanti.toFixed(0) + ')');
  }

  ok('ribilanciamento verificato');
}

// ============================================================================
// TEST 60 — v1.84: i prigionieri, la chiave, e la faglia al posto del pulsante
// ============================================================================
function testV184() {
  console.log('\n[TEST 60] v1.84 — prigionieri da liberare e faglia d uscita');
  const dt = 1 / C.TICK_RATE;
  const conn = { send() {} };

  // --- 1) il recinto compare ogni tanto, e non e' mai piu' grande del tetto ---
  {
    let conRecinto = 0, maxPr = 0, minPr = 99, ondate = 0;
    for (let k = 0; k < 18; k++) {
      const r = new Room('v184a' + k); r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
      for (let w = 0; w < 4; w++) {
        ondate++;
        if (r.recinto) { conRecinto++; const n = r.recinto.prigionieri.length; maxPr = Math.max(maxPr, n); minPr = Math.min(minPr, n); }
        r.monsters.length = 0; r.pending = 0; r.waveList = []; r.nextWave();
      }
    }
    const perc = conRecinto / ondate;
    assert(perc > 0.15 && perc < 0.60, 'il recinto compare ogni tanto, non sempre (' + (perc * 100).toFixed(0) + '% delle ondate)');
    assert(maxPr <= C.PRIGIONE_MAX, 'mai piu di ' + C.PRIGIONE_MAX + ' prigionieri (visto ' + maxPr + ')');
    assert(minPr >= 1, 'e mai zero');
  }
  // --- 2) all inizio se ne trovano pochi ---
  {
    const conta = (ondata) => { let tot = 0, n = 0;
      for (let k = 0; k < 150; k++) { const r = new Room('x'); r.wave = ondata;
        r.map = { w: 40, h: 30 }; // non serve: _quantiPrigionieri guarda solo l ondata
        tot += r._quantiPrigionieri(); n++; }
      return tot / n; };
    const presto = conta(1), tardi = conta(14);
    assert(presto < tardi, 'nelle prime ondate se ne trovano meno (' + presto.toFixed(1) + ' contro ' + tardi.toFixed(1) + ')');
    assert(presto <= 2.1, 'e alla prima ondata sono uno o due (' + presto.toFixed(1) + ')');
  }
  // --- 3) LA CHIAVE: senza non si libera nessuno, con la chiave si' ---
  {
    const r = new Room('v184b'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    // si mette un recinto a mano: la prova non deve dipendere dal caso
    r.recinto = { x: p.x + 300, y: p.y, r: C.PRIGIONE_RAGGIO, liberato: false,
      prigionieri: [{ dx: 0, dy: 0, c: '#8a3b2e', h: 'arciere', f: 0 }, { dx: 10, dy: 10, c: '#2f5d7a', h: 'mago', f: 1 }] };
    r.chiave = { x: p.x - 300, y: p.y, presa: false, suEid: null };
    const monete0 = p.coins || 0;
    // ci si mette dentro al recinto SENZA chiave: non succede niente
    p.x = r.recinto.x; p.y = r.recinto.y; r._updatePrigionieri();
    assert(!r.recinto.liberato, 'senza chiave il recinto non si apre');
    assert((p.coins || 0) === monete0, 'e non arriva una moneta');
    // si va a prendere la chiave
    p.x = r.chiave.x; p.y = r.chiave.y; r._updatePrigionieri();
    assert(r.chiave.presa, 'passandoci sopra la chiave si raccoglie');
    // e adesso il recinto si apre
    p.x = r.recinto.x; p.y = r.recinto.y; r._updatePrigionieri();
    assert(r.recinto.liberato, 'con la chiave il recinto si apre');
    assert(p.coins - monete0 === 2 * C.PRIGIONE_MONETE, 'e paga ' + C.PRIGIONE_MONETE + ' monete a testa (' + (p.coins - monete0) + ' per due)');
    // e non paga due volte
    const dopo = p.coins; r._updatePrigionieri();
    assert(p.coins === dopo, 'liberarli e' + String.fromCharCode(39) + ' una cosa sola: non si ripaga');
  }
  // --- 4) la chiave addosso all elite cade quando muore ---
  {
    const r = new Room('v184c'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    r.chiave = { x: 0, y: 0, presa: false, suEid: -1 };
    const sp = losSpot(r, p, 260);
    const el = r.spawnMonster('skeleton', sp.x, sp.y, { scaling: Waves.scaling(3, 1), elite: true });
    assert(!!el && el.elite, 'entrato un elite');
    assert(r.chiave.suEid === el.eid, 'la chiave e sua');
    assert(!r.recinto || true, '');
    // finche' e' vivo la chiave non e' a terra
    r._updatePrigionieri();
    assert(!r.chiave.presa, 'e finche' + String.fromCharCode(39) + ' vivo non la si raccoglie da terra');
    r.killMonster(el, p);
    assert(r.chiave.suEid === null, 'quando cade, la chiave cade con lui');
    assert(Math.abs(r.chiave.x - el.x) < 2, 'proprio dove e caduto');
    p.x = r.chiave.x; p.y = r.chiave.y; r._updatePrigionieri();
    assert(r.chiave.presa, 'e da li si raccoglie');
  }
  // --- 5) il mercenario non raccoglie la chiave e non libera nessuno: non e' un giocatore ---
  {
    const r = new Room('v184d'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    p.level = 4; r.enterMarket(); p.x = r.bandit.x; p.y = r.bandit.y; p.coins = 1000; r.assumiMercenario('a');
    r.nextWave(); r.phase = C.PHASE_COMBAT;
    const mc = r.mercenario; assert(!!mc, 'mercenario in campo');
    r.chiave = { x: mc.x, y: mc.y, presa: false, suEid: null };
    p.x = mc.x + 3000; p.y = mc.y + 3000;
    r._updatePrigionieri();
    assert(!r.chiave.presa, 'il mercenario ci cammina sopra e non la raccoglie');
  }
  // --- 6) LA FAGLIA: si apre a mappa ripulita, e attraversarla chiude l ondata ---
  {
    const r = new Room('v184e'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    assert(!r.faglia, 'durante l ondata la faglia non c e');
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    r._mappaRipulita();
    assert(r.phase === C.PHASE_CLEARED, 'ripulita la mappa si passa alla fase di uscita');
    assert(!!r.faglia, 'e si apre la faglia');
    const d = MU.dist(r.faglia.x, r.faglia.y, p.x, p.y);
    assert(d > C.FAGLIA_RAGGIO + 40, 'non addosso al giocatore (' + d.toFixed(0) + ' px), se no ci si finisce dentro raccogliendo');
    assert(d < 460, 'ma nemmeno dall altra parte della mappa');
    assert(!r.isWallAt(r.faglia.x, r.faglia.y), 'e non dentro la roccia');
    // starci lontano non chiude niente
    for (let i = 0; i < C.TICK_RATE; i++) r.update(dt);
    assert(r.phase === C.PHASE_CLEARED, 'restando fuori l ondata non si chiude');
    // attraversarla si'
    p.x = r.faglia.x; p.y = r.faglia.y;
    r.update(dt);
    assert(r.phase !== C.PHASE_CLEARED, 'attraversandola l ondata si chiude');
  }
  // --- 7) niente recinto nelle ondate del boss ---
  {
    let visto = false;
    for (let k = 0; k < 12; k++) {
      const r = new Room('v184f' + k); r.addPlayer('a', conn, 'A', 'mago'); r.startGame();
      while (r.wave < 10) { r.monsters.length = 0; r.pending = 0; r.waveList = []; r.nextWave(); }   // v1.89 — il boss e' al 10
      if (r.recinto) visto = true;
    }
    assert(!visto, 'nella mappa del boss non ci sono prigionieri: l attenzione non si divide');
  }
  // --- 8) i forzieri possono contenere monete ---
  {
    const r = new Room('v184g'); const p = r.addPlayer('a', conn, 'A', 'arciere'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    r.crates.length = 0; r.groundCoins.length = 0; r.events.length = 0;
    r.crates.push({ eid: 991, x: p.x, y: p.y, r: 16, mimic: false, opened: false });
    const rnd = Math.random; Math.random = () => 0.1;   // sotto la soglia: esce il mucchietto di monete
    try { r.updatePickups(1 / C.TICK_RATE); } finally { Math.random = rnd; }
    const ev = r.events.find(e => e.t === 'crate_monete');
    assert(!!ev, 'aprendo un forziere puo uscire un mucchio di monete');
    assert(ev.v > 0, 'e vale qualcosa (' + (ev ? ev.v : 0) + ' monete all ondata ' + r.wave + ')');
    assert(r.groundCoins.length > 0, 'le monete finiscono per terra, da raccogliere');
  }
  ok('prigionieri, faglia e forzieri verificati');
}

function testV185() {
  console.log('\n[TEST 61] v1.85 — le abilita attive (slot Q all 8, slot E al 14)');
  const dt = 1 / C.TICK_RATE;
  const conn = { send() {} };
  const Lv2 = require('../shared/levels.js');

  // --- 1) la tabella: quattro per classe, due per slot, ricariche 30 e 45 ---
  // v2.18 — QUESTO TEST AFFERMAVA «quattro abilita' per classe, due per slot». Non e' piu' vero e non e'
  // un dettaglio: al livello 1 non si sceglie piu' (la FIRMA si riceve), e un'abilita' puo' appartenere
  // a piu' classi in slot diversi. Il test e' stato riscritto su cio' che vale adesso, non tolto.
  {
    for (const h of Heroes.ORDER) {
      const scuola = h === 'mago' ? 'elementale' : null;
      const s1 = Ab.perSlot(h, 1, scuola), s2 = Ab.perSlot(h, 2, scuola), s3 = Ab.perSlot(h, 3, scuola);
      // il mago e' l'unico che al livello 1 SCEGLIE: le sue tre scuole. Gli altri ricevono una firma.
      assert(s1.length === 1, h + ': una sola firma al livello 1, non una scelta');
      assert(s2.length === 2 && s3.length === 2, h + ': due candidate al 7 e due al 13');
      for (const a of s1) assert(a.cd === 30, a.name + ' si ricarica in 30s (' + a.cd + ')');
      for (const a of s2) assert(a.cd === 45, a.name + ' si ricarica in 45s (' + a.cd + ')');
      for (const a of s3) assert(a.cd === 60, a.name + ' si ricarica in 60s (' + a.cd + ')');
      for (const a of s1.concat(s2, s3)) assert(!!a.name && !!a.icon && !!a.desc, a.id + ' ha nome, icona e descrizione');
      // ogni classe ha almeno una NUOVA per slot: e' il patto del documento (una sua e una del serbatoio)
      assert(s2.some(a => a.nuova) && s3.some(a => a.nuova), h + ': al 7 e al 13 una candidata e sua e di nessun altro');
      assert(s2.some(a => a.serbatoio) && s3.some(a => a.serbatoio), h + ': e l altra viene dal serbatoio');
    }
    // v2.19.7 — IL MAGO HA UNA SCUOLA SOLA. Paolo: *«togli evocatore e negromante, lascia solo mago
    // elementalista»*. Fino a ieri qui si controllava la scelta fra tre firme al livello 1; adesso non c'e'
    // niente da scegliere: riceve la firma dell'elementalista come ogni altra classe riceve la sua.
    assert(Ab.scuoleMago().length === 1 && Ab.scuoleMago()[0].id === 'elementale', 'il mago ha una scuola sola: elementale');
    assert(!Ab.sceglieAlPrimo('mago'), 'e al livello 1 non sceglie niente');
    assert(Ab.perSlot('mago', 1).length === 1 && Ab.perSlot('mago', 1)[0].id === 'ab_palla', 'la sua firma e la Palla di Fuoco');
    assert(Ab.perSlot('mago', 2).length === 2 && Ab.perSlot('mago', 3).length === 2, 'e al 7 e al 13 ha le sue due candidate');
    assert(!['ab_evoca', 'ab_branco', 'ab_evoca_magg', 'ab_rialzata', 'ab_dito'].some(id => [1, 2, 3].some(sl => Ab.perSlot('mago', sl).some(a => a.id === id))),
      'e nessuna abilita di evocatore o negromante');
    // v2.19.7 — il warlock: lo zombie e' la firma, il Patto non c'e' piu'
    assert(Ab.firma('warlock').id === 'ab_zombie' && Ab.firma('warlock').unaPerOndata, 'la firma del warlock e lo zombie, una volta per ondata');
    assert(![1, 2, 3].some(sl => Ab.perSlot('warlock', sl).some(a => a.id === 'ab_patto')), 'e il Patto non lo ha piu');
    // LA REGOLA DEI 10 SECONDI e le sue tre eccezioni, affermate per nome: se qualcuno le "uniforma"
    // per pulizia, qui si rompe e legge perche' non andava fatto.
    for (const id in Ab.BY_ID) {
      const a = Ab.BY_ID[id];
      if (!a.dur || a._noRegola10) continue;
      assert(a.dur === 10, id + ': ogni effetto a tempo dura 10 secondi (' + a.dur + ')');
    }
    assert(Ab.BY_ID.ab_turbine.dur === 1.2, 'il Turbine resta 1,2s: e un azione a tempo, non un effetto');
    assert(Ab.BY_ID.ab_salva.dur === 2, 'la Salva resta 2s, per la stessa ragione');
    assert(Ab.BY_ID.ab_tagliola.blocco === 2.5, 'la Tagliola blocca 2,5s: a 10 cancellerebbe il mostro dalla partita');
    assert(Ab.BY_ID.ab_scudo.dur === undefined && Ab.BY_ID.ab_scudo.perInt === 8,
      'lo Scudo di Mana non ha durata: assorbe 8 danni per punto di Intelligenza e dura fino a fine ondata');
  }

  // --- 2) lo slot si apre al livello giusto, e si sceglie fra DUE ---
  {
    // v2.19.7 — il mago non sceglie piu' la scuola al livello 1: la firma gli arriva in mano da sola,
    // e nella coda delle scelte non entra niente.
    const r = new Room('v185a'); const p = r.addPlayer('a', conn, 'A', 'mago'); avviaSenzaAbilita(r, 1);
    assert(p.level === 1 && p.abil[0] === 'ab_palla', 'al livello 1 il mago ha gia la sua firma in mano');
    assert((p.abilDovute || []).length === 0, 'e non c e niente da scegliere');
    assert(p.scuola === 'elementale' && p.titolo === 'Elementalista', 'col titolo di Elementalista');
    r.addXp(p, Lv2.xpForLevel(7) - p.xpPool);
    assert((p.abilDovute || []).join(',') === '2', 'al 7 si deve lo slot 2');
    // v2.18 — e al 13 IL TERZO SLOT ENTRA, perche' adesso ha due candidate dentro. Fino alla 2.17
    // restava fuori: era vuoto, e una scelta senza scelte avrebbe bloccato il giocatore per sempre.
    r.addXp(p, Lv2.xpForLevel(13) - p.xpPool);
    assert((p.abilDovute || []).join(',') === '2,3', 'al 13 entra in coda anche il terzo slot');
    assert(Ab.perSlot('mago', 3, p.scuola).length === 2, 'e ha due candidate, secondo la scuola scelta');
  }

  // --- 3) IL MERCENARIO NON HA ABILITA' ---
  {
    const r = new Room('v185b'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    p.level = 4; r.enterMarket(); p.x = r.bandit.x; p.y = r.bandit.y; p.coins = 1000; r.assumiMercenario('a');
    r.nextWave(); r.phase = C.PHASE_COMBAT;
    const mc = r.mercenario; assert(!!mc, 'mercenario in campo');
    mc.abil = ['ab_carica', null, null];            // anche mettendogliela in mano
    assert(r._usaAbilita(mc, 1) === false, 'il mercenario non usa le abilita nemmeno se ce l ha');
    assert(mc.cdAb[0] === 0, 'e non consuma niente');
  }

  // --- 4) IL GRIDO NON ATTIRA I BOSS ---
  {
    const r = new Room('v185c'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    p.abil[0] = 'ab_grido'; p.cdAbMax[0] = 30;
    const sp1 = losSpot(r, p, 120), sp2 = losSpot(r, p, 150);
    const normale = r.spawnMonster('skeleton', sp1.x, sp1.y, { scaling: Waves.scaling(3, 1) });
    const boss = r.spawnMonster('skeleton', sp2.x, sp2.y, { scaling: Waves.scaling(3, 1) });
    if (boss) boss.boss = true;
    assert(!!normale && !!boss && boss.boss, 'in campo un nemico normale e un boss');
    r._usaAbilita(p, 1);
    assert(normale.taunt > 0 && normale.tauntBy === 'a', 'il nemico normale viene attirato');
    assert(!(boss.taunt > 0), 'IL BOSS NO: ha il suo bersaglio e non lo cambia perche hai urlato');
    assert(p.buffs.grido > 0, 'e chi urla si protegge');
    const nudo = new Room('v185c2'); const q = nudo.addPlayer('b', conn, 'B', 'paladino'); nudo.startGame();
    q.buffs = {}; q.hp = 500; const h0 = q.hp; nudo.damagePlayer(q, 100, q.x + 50, q.y, 0);
    const senza = h0 - q.hp;
    q.hp = 500; q.buffs.grido = 4; q.gridoDR = 0.25; nudo.damagePlayer(q, 100, q.x + 50, q.y, 0);
    assert((500 - q.hp) < senza, 'col Grido addosso si incassa meno (' + (500 - q.hp) + ' contro ' + senza + ')');
  }

  // --- 5) la ricarica: una volta sola, poi si aspetta ---
  {
    const r = new Room('v185d'); const p = r.addPlayer('a', conn, 'A', 'arciere'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    p.abil[0] = 'ab_tempo';   // v2.17 — il Velo d'Ombra e' diventato Tempo Rubato (la bullet time)
    assert(r._usaAbilita(p, 1) === true, 'la prima volta parte');
    assert(Math.abs(p.cdAb[0] - 30) < 1.5, 'e mette 30s di ricarica (' + p.cdAb[0].toFixed(1) + ')');
    assert(r._usaAbilita(p, 1) === false, 'la seconda no, e in ricarica');
    p.cdAb[0] = 0;
    assert(r._usaAbilita(p, 1) === true, 'finita la ricarica si rifa');
  }

  // --- 6) il MARCHIO: piu danni DA CHIUNQUE, e senza bersaglio non spreca la ricarica ---
  {
    const r = new Room('v185e'); const p = r.addPlayer('a', conn, 'A', 'arciere'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    p.abil[1] = 'ab_marchio'; p.cdAbMax[1] = 45;
    assert(r._usaAbilita(p, 2) === false, 'senza bersaglio non parte');
    assert(p.cdAb[1] === 0, 'e non costa la ricarica: mirare male non si punisce per 45 secondi');
    const sp = losSpot(r, p, 200);
    const m = r.spawnMonster('skeleton', sp.x, sp.y, { scaling: Waves.scaling(3, 1) });
    p.aim = Math.atan2(m.y - p.y, m.x - p.x);
    assert(r._usaAbilita(p, 2) === true, 'col bersaglio in mira parte');
    assert(m.marchio > 0, 'e il nemico resta marchiato');
    // stesso colpo, con e senza marchio
    const m2 = r.spawnMonster('skeleton', sp.x, sp.y, { scaling: Waves.scaling(3, 1) });
    const a0 = m.hp, b0 = m2.hp;
    r.damageMonster(m, 100, p.x, p.y, 0, null); r.damageMonster(m2, 100, p.x, p.y, 0, null);
    assert((a0 - m.hp) > (b0 - m2.hp), 'il marchiato incassa di piu (' + (a0 - m.hp) + ' contro ' + (b0 - m2.hp) + '), e da chiunque');
  }

  // --- 7) TUTTE partono davvero, e nessuna rompe il ciclo ---
  // v2.18 — erano dodici e sono trenta: sei classi con tre slot, piu' il mago con tre scuole per tre
  // slot. `Ab.ABIL[hero]` non esiste piu' (un'abilita' appartiene a piu' classi e a slot diversi), quindi
  // si cammina su `perSlot`, che e' l'unica domanda che ha una risposta sensata. E' il test piu' utile
  // dei sette: e' quello che avrebbe visto subito una delle diciotto nuove andare in NaN.
  {
    const giro = [];
    for (const hero of Heroes.ORDER) {
      const scuole = hero === 'mago' ? ['elementale', 'evocazione', 'negromanzia'] : [null];
      for (const sc of scuole) for (const slot of [1, 2, 3]) for (const a of Ab.perSlot(hero, slot, sc)) giro.push({ hero, sc, a });
    }
    assert(giro.length >= 30, 'il giro copre almeno trenta abilita (' + giro.length + ')');
    for (const { hero, sc, a } of giro) {
      const r = new Room('v185f' + hero + a.id); const p = r.addPlayer('a', conn, 'A', hero); r.startGame();
      if (sc) p.scuola = sc;
      r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
      p.abil[a.slot - 1] = a.id; p.cdAbMax[a.slot - 1] = a.cd;
      const sp = losSpot(r, p, 130);
      const m = r.spawnMonster('skeleton', sp.x, sp.y, { scaling: Waves.scaling(5, 1) });
      p.aim = Math.atan2(m.y - p.y, m.x - p.x);
      assert(r._usaAbilita(p, a.slot) === true, a.name + ' parte');
      for (let i = 0; i < C.TICK_RATE * 3; i++) r.update(dt);
      assert(!hasNaN(r), a.name + ' non sporca lo stato');
      assert(isFinite(p.x) && isFinite(p.y) && p.hp > 0, 'e chi la usa e ancora al suo posto');
    }
  }

  // --- 8) il GIURAMENTO annulla UN colpo, non tutti ---
  {
    const r = new Room('v185g'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 5; r.waveList = [];
    p.abil[1] = 'ab_giuramento'; p.buffs = {}; p.hp = 400;
    r._usaAbilita(p, 2);
    const h0 = p.hp; r.damagePlayer(p, 60, p.x + 40, p.y, 0);
    assert(p.hp === h0, 'il primo colpo non arriva');
    r.damagePlayer(p, 60, p.x + 40, p.y, 0);
    assert(p.hp < h0, 'il secondo si');
  }
  ok('abilita attive verificate');
}

function testV188() {
  console.log('\n[TEST 62] v1.88/v2.12 — CINQUE gradi di equipaggiamento per ogni slot, con tre scelte dentro');
  const conn = { send() {} };
  // v2.12 — erano quattro gradi e un pezzo per grado. Adesso sono cinque gradi e tre pezzi per grado
  // (tranne il primo, che e' quello con cui parti). Le due righe che seguono sono la forma del catalogo:
  // se qualcuno aggiunge un grado o un carattere, e' qui che se ne accorge.
  const NOMI = ['scarso', 'common', 'rare', 'legendary', 'divine'];
  assert(Gear.RANK_RARITY.join(',') === NOMI.join(','), 'i gradi sono scarso, comune, raro, leggendario, divino');
  assert(Gear.maxRank() === 5, 'i gradi sono cinque');

  for (const h of Heroes.ORDER) {
    for (const slot of Gear.slotsFor(h)) {
      const l = Gear.itemsFor(h, slot);
      assert(l.length === 13, h + '/' + slot + ': tredici pezzi, 1 + 3x4 (' + l.length + ')');
      assert(l.map(i => i.rank).join(',') === '1,2,2,2,3,3,3,4,4,4,5,5,5', h + '/' + slot + ': i gradi vanno da 1 a 5, tre pezzi per grado');
      assert(l.map(i => Gear.rarityOf(i)).join(',') === [NOMI[0], NOMI[1], NOMI[1], NOMI[1], NOMI[2], NOMI[2], NOMI[2], NOMI[3], NOMI[3], NOMI[3], NOMI[4], NOMI[4], NOMI[4]].join(','), h + '/' + slot + ': una rarita per grado');
      // v2.12 — l'ORDINE non e' un dettaglio estetico: il client ci mette le carte in colonna, e se
      // l'ordine cambiasse cambierebbero le colonne sotto i piedi di chi sta guardando il negozio.
      for (let k = 1; k < l.length; k += 3) {
        if (l[k].rank === 1) continue;
        assert([l[k].carattere, l[k + 1].carattere, l[k + 2].carattere].join(',') === 'pesante,equilibrata,leggera', h + '/' + slot + ' grado ' + l[k].rank + ': l ordine e pesante, equilibrata, leggera');
      }
      assert(l[0].cost === 0, h + '/' + slot + ': il grado scarso e quello di partenza e costa 0');
      // FRA I GRADI si sale, DENTRO un grado no: si confrontano i gradi, non i pezzi in fila.
      for (let r = 2; r <= Gear.maxRank(); r++) {
        const g = Gear.itemsOfRank(h, slot, r), prima = Gear.itemsOfRank(h, slot, r - 1);
        assert(g[0].cost > prima[0].cost, h + '/' + slot + ': il grado ' + r + ' costa piu del ' + (r - 1));
        if (slot === 'weapon') {
          const dps = (w) => w.dmg * w.fireRate;
          assert(Math.max(...g.map(i => dps(i.weapon))) > Math.max(...prima.map(i => dps(i.weapon))), h + '/' + slot + ': il grado ' + r + ' rende piu del ' + (r - 1));
        } else {
          // dentro un grado i caratteri si scambiano difesa con velocita', quindi si confronta il
          // MIGLIORE su ogni voce: e' quello che dice se il grado dopo e' davvero un passo avanti.
          for (const voce of ['maxHpFlat', 'dmgReduce', 'frontale']) {
            const mg = Math.max(...g.map(i => i.bonus[voce] || 0)), mp = Math.max(...prima.map(i => i.bonus[voce] || 0));
            if (mp > 0) assert(mg > mp, h + '/' + slot + ': al grado ' + r + ' il meglio in ' + voce + ' batte il grado ' + (r - 1));
          }
        }
      }
      // v1.88 — SI DEVE VEDERE: ogni pezzo che veste il personaggio porta la sua tinta.
      if (slot !== 'weapon') for (const it of l) assert(!!it.tinta && Object.keys(it.tinta).length > 0, it.name + ' ha una tinta da mostrare addosso');
    }
  }

  // il rango piu' alto arriva davvero addosso al personaggio
  {
    const r = new Room('v188a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    const hp0 = r.effMaxHp(p);
    p.coins = 99999; r.enterMarket(); p.x = r.gearMerchant.x; p.y = r.gearMerchant.y; r.updateGearMerchant();
    // v2.12 — il grado divino e' il CINQUE, non il quattro, e dentro ci sono tre scelte: si prende la
    // equilibrata, che e' quella senza penalita'. Prima qui c'era `l[3]`, cioe' il quarto pezzo della
    // lista: con tredici pezzi per slot quel quarto e' un COMUNE, e il test avrebbe detto di si' a un
    // personaggio vestito di stracci.
    const divini = {};
    // v2.18.1 — si compra E si impugna: comprare non equipaggia piu', e arma e scudo vanno in una mano.
    for (const slot of Gear.slotsFor('paladino')) {
      const it = Gear.itemsOfRank('paladino', slot, Gear.maxRank()).find(i => i.carattere === 'equilibrata');
      divini[slot] = it; r.buyGear('a', it.id);
      r.equipaggia('a', it.id, slot === 'shield' ? 'manoSx' : 'manoDx');
    }
    assert(p.gear.manoDx === divini.weapon.id && p.gear.armor === divini.armor.id && p.gear.manoSx === divini.shield.id, 'comprati e impugnati i tre pezzi divini');
    assert(Gear.rarityOf(Gear.BY_ID[p.gear.manoDx]) === 'divine', 'e sono davvero di grado divino');
    assert(r.effMaxHp(p) > hp0 + 100, 'i PV massimi salgono col set divino (' + hp0 + ' -> ' + r.effMaxHp(p) + ')');
    assert(r.effWeapon(p).arcRadius > 140, 'e la portata del fendente e quella della Falce (' + r.effWeapon(p).arcRadius + ')');
    const snap = r.snapshot(); const me = snap.players[0];
    assert(me.arm === divini.armor.id, 'lo snapshot porta l armatura, che il client disegna');
    assert(me.sh === divini.shield.id && me.wp === divini.weapon.id, 'e lo scudo e l arma');
  }
  // e il ladro riceve la taratura della 1.83, che era rimasta solo in heroes.js
  {
    // v2.12 — l'Arco Corto e' diventato il COMUNE equilibrato (il grado di partenza adesso e' scarso) e
    // la sua taratura e' cambiata col catalogo nuovo. Cio' che questo blocco deve difendere non e' il
    // numero 38: e' che l'arma vera arrivi dall'OGGETTO e non da heroes.js — il bug della 1.88.
    const w = Gear.itemsOfRank('arciere', 'weapon', 2, 'equilibrata').find(i => i.carattere === 'equilibrata').weapon;
    assert(w.fireRate === 2.3, 'l Arco Corto tiene la cadenza della classe (2,3/s)');
    const rq = new Room('v188b'); const pq = rq.addPlayer('q', conn, 'Q', 'arciere'); rq.startGame();
    // v2.19 — gli archi li vende l'ARCIERA, non il fabbro: al banco giusto, come farebbe un giocatore
    pq.coins = 9999; rq.enterMarket(); alBanco(rq, pq, 'ladro'); rq.updateGearMerchant();
    const arco = Gear.itemsOfRank('arciere', 'weapon', 2, 'equilibrata').find(i => i.carattere === 'equilibrata');
    rq.buyGear('q', arco.id); rq.equipaggia('q', arco.id, 'manoDx');
    assert(rq.effWeapon(pq).dmg === arco.weapon.dmg, 'e l arma in mano arriva dall OGGETTO, non da heroes.js');
  }
  ok('quattro ranghi per slot verificati');
}

function testV189() {
  const Mon = require('../shared/monsters.js');
  console.log('\n[TEST 63] v1.89 — due boss soli: il Colosso al 10, AZ GAROTH al 20');
  const conn = { send() {} };
  const dt = 1 / C.TICK_RATE;

  // --- 1) le ondate col boss sono due, e sono quelle ---
  {
    const con = []; for (let w = 1; w <= 22; w++) if (Waves.isBossWave(w)) con.push(w);
    assert(con.join(',') === '10,20,21,22', 'boss al 10 e dalla 20 in poi (' + con.join(',') + ')');
    assert(!Waves.isBossWave(5) && !Waves.isBossWave(15), 'niente boss al 5 e al 15');
    assert(Waves.bossForWave(10, 1).def.id === 'rift_colossus', 'al 10 arriva il Colosso');
    assert(Waves.bossForWave(20, 1).def.id === 'mega_dragon', 'al 20 AZ GAROTH');
    // togliere due boss non doveva rendere il finale piu' facile
    const b20 = Waves.bossForWave(20, 1);
    assert(Math.round(b20.def.hp * b20.hpMul) === 22500, 'e il finale ha i PV di prima (' + Math.round(b20.def.hp * b20.hpMul) + ')');
  }

  // --- 2) il Colosso: tre fasi, e ognuna cambia come combatte ---
  {
    const r = new Room('v189a'); const p = r.addPlayer('a', conn, 'A', 'mago'); r.startGame();
    r.wave = 9; r.monsters.length = 0; r.pending = 0; r.waveList = []; r.nextWave();
    const b = r.monsters.find(m => m.boss);
    assert(!!b && b.type === 'rift_colossus', 'alla decima ondata entra il Colosso');
    for (let i = 0; i < C.TICK_RATE * 4; i++) r.update(dt);
    assert(b.fase === 1, 'a vita piena e in prima fase');
    assert(!b.braccio && !b.nucleo, 'con tutti e due i bracci e il nucleo coperto');
    b.hp = b.maxHp * 0.5; for (let i = 0; i < C.TICK_RATE * 2; i++) r.update(dt);
    assert(b.fase === 2 && !!b.braccio, 'a meta vita perde un braccio');
    b.hp = b.maxHp * 0.2; for (let i = 0; i < C.TICK_RATE * 2; i++) r.update(dt);
    assert(b.fase === 3 && !!b.nucleo, 'a un quinto si apre il nucleo');
    // e col nucleo scoperto incassa di piu': e la finestra su cui e costruito il combattimento
    const r2 = new Room('v189b'); const q = r2.addPlayer('a', conn, 'A', 'mago'); r2.startGame();
    r2.wave = 9; r2.monsters.length = 0; r2.pending = 0; r2.waveList = []; r2.nextWave();
    const c1 = r2.monsters.find(m => m.boss); const hp0 = c1.hp;
    r2.damageMonster(c1, 200, q.x, q.y, 0, q); const senza = hp0 - c1.hp;
    c1.hp = hp0; c1.nucleo = 1;
    r2.damageMonster(c1, 200, q.x, q.y, 0, q); const con2 = hp0 - c1.hp;
    assert(con2 > senza * 1.4, 'col nucleo scoperto incassa il 50% in piu (' + senza + ' -> ' + con2 + ')');
  }

  // --- 3) i due vecchi restano scritti ma non compaiono piu' ---
  {
    assert(!!Mon.BOSSES.orc_warlord && !!Mon.BOSSES.lich_king, 'le definizioni restano nel file');
    let visti = 0;
    for (let w = 1; w <= 30; w++) if (Waves.isBossWave(w)) { const id = Waves.bossForWave(w, 1).def.id; if (id === 'orc_warlord' || id === 'lich_king') visti++; }
    assert(visti === 0, 'ma non entrano piu in nessuna ondata');
  }
  ok('i due boss verificati');
}


// ============================================================================
// TEST 64 — v1.93: NESSUNA abilita', arma o armatura cura il personaggio
// ============================================================================
// E' una regola del gioco, non una taratura: rimettere PV e' il mestiere delle POZIONI e dell'OSTESSA,
// e di nient'altro. Il test non si fida dei nomi delle carte — le PROVA tutte, una per una, giocando:
// mezza vita, cinque secondi di colpi su un bersaglio eterno, e i PV non devono salire di uno. Vale
// anche per la carta che verra' aggiunta domani, ed e' il punto: la regola non va ricordata, va imposta.
function testV193() {
  console.log('\n[TEST 64] v1.93 — niente cura da carte, ranghi, patti o equipaggiamento');
  const dt = 1 / C.TICK_RATE;
  const Loot = require('../shared/loot.js');
  const Gear = require('../shared/gear.js');
  const Lv = require('../shared/levels.js');
  const conn = { send() {} };

  // --- 1) i campi che rendevano possibile la cura non esistono piu' ---
  {
    const r = new Room('v193a'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    assert(p.stats.lifesteal === undefined, 'fra le statistiche non esiste piu lifesteal');
    assert(p.stats.regen === undefined, 'ne regen');
    assert(p.perk.auraCura === undefined, 'e l aura del Paladino non ha piu una quota di cura');
    const src = fs.readFileSync(__dirname + '/../server/Room.js', 'utf8');
    assert(!/stats\.lifesteal/.test(src), 'nel server non resta una riga che curi con il lifesteal');
    assert(!/stats\.regen\s*&&/.test(src), 'ne una che rigeneri nel tempo');
    assert(!Loot.BOON_BY_ID.vampire && !Loot.BOON_BY_ID.bloodlust, 'Vampirismo e Sete di Sangue non sono piu nel catalogo');
  }

  // --- 2) PROVA SUL CAMPO: ogni carta, ogni rango, ogni patto, ogni pezzo di equipaggiamento ---
  const provaCura = (etichetta, prepara) => {
    const r = new Room('c' + Math.random().toString(36).slice(2, 7));
    const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 0; r.waveList = [];
    prepara(r, p);
    const mx = r.effMaxHp(p); p.hp = Math.floor(mx * 0.5); const hp0 = p.hp;
    const sp = losSpot(r, p, 150);
    const m = r.spawnMonster('skeleton', sp.x, sp.y, { scaling: Waves.scaling(1, 1) });
    m.awake = true;
    let picco = hp0;
    for (let i = 0; i < C.TICK_RATE * 5; i++) {
      m.hp = m.maxHp; m.dead = false;                     // bersaglio eterno: si misura la cura, non la resa
      r.setInput('a', { mx: 0, my: 0, aim: Math.atan2(m.y - p.y, m.x - p.x), shoot: true, q: true, e: true });
      r.update(dt);
      if (p.hp > picco) picco = p.hp;
    }
    return { etichetta, guadagno: picco - hp0 };
  };

  const casi = [];
  for (const b of Loot.BOONS) casi.push(['carta ' + b.id, (r, p) => { p.boonsOwned[b.id] = 1; p.cardOn[b.id] = 1; r._recomputeBoons(p); }]);
  for (const eroe of ['paladino', 'mago', 'arciere']) for (const sp of (Lv.SPECS[eroe] || [])) casi.push(['rango ' + sp.id, (r, p) => { p.spec = sp.id; r._recomputeBoons(p); }]);
  for (const slot of Gear.slotsFor('paladino')) for (const it of Gear.itemsFor('paladino', slot)) casi.push(['equip ' + it.id, (r, p) => { p.gear[slot] = it.id; p.owned[it.id] = 1; r._recomputeGear(p); }]);
  {
    const r0 = new Room('v193p'); r0.addPlayer('z', conn, 'Z', 'paladino'); r0.startGame();
    for (const w of r0.darkWaresPool()) casi.push(['patto ' + w.id, (r, p) => { p.coins = 9999; r.darkMerchant = { x: p.x, y: p.y, r: 18, wares: [w] }; r.buyDark('a', w.id); }]);
  }

  const colpevoli = casi.map(([et, prep]) => provaCura(et, prep)).filter(x => x.guadagno > 0);
  assert(casi.length > 40, 'la prova copre tutto il catalogo (' + casi.length + ' fra carte, ranghi, patti ed equipaggiamento)');
  assert(colpevoli.length === 0, 'e nessuno cura: ' + (colpevoli.length ? colpevoli.map(x => x.etichetta + ' +' + x.guadagno + ' PV').join(', ') : 'zero PV rimessi da chiunque'));

  // --- 3) cio' che PUO' curare, e deve continuare a farlo: la pozione della cintura ---
  {
    const r = new Room('v193c'); const p = r.addPlayer('a', conn, 'A', 'paladino'); r.startGame();
    const mx = r.effMaxHp(p); p.hp = Math.floor(mx * 0.4); const prima = p.hp;
    p.belt[0] = { id: 'p_cura', n: 1 }; p.potCd = 0;
    r.usePotion(p, 0);
    assert(p.hp > prima, 'la pozione di Cura cura eccome (' + Math.round(prima) + ' -> ' + Math.round(p.hp) + '/' + mx + ')');
  }
  ok('nessuna cura fuori posto: 0 PV rimessi da carte, ranghi, patti ed equipaggiamento');
}


// ============================================================================
// TEST 65 — v1.97: il CIMITERO delle prime due ondate
// ============================================================================
function testV197() {
  console.log('\n[TEST 65] v2.9.1 — il cimitero e in stand-by: si gioca nelle grotte, ma la pianta regge');
  const MG = require('../shared/mapgen.js');
  const dt = 1 / C.TICK_RATE;

  // --- 1) chi gioca dove ---
  // v2.9.1 — IL CIMITERO E' SPENTO, non cancellato. `CIMITERO_FINO_A` e' a zero, quindi TUTTE le ondate
  // di combattimento — la prima compresa — si giocano nelle grotte. La pianta resta nel progetto e resta
  // provata qui sotto forzandola: se marcisse, riaccenderla un domani non sarebbe piu' un numero solo.
  assert(C.CIMITERO_FINO_A === 0, 'il cimitero e in stand-by (CIMITERO_FINO_A = ' + C.CIMITERO_FINO_A + ')');
  for (const lv of [1, 2, 3, 7, 20]) assert(MG.generate(1000 + lv, lv).archetipo !== 'cimitero', 'ondata ' + lv + ': si gioca nelle grotte');
  assert(MG.generate(1001, 1, true).archetipo === 'cimitero', 'ma forzata, la pianta del cimitero c e ancora');

  // --- 2) la pianta regge: connessa, con le sue lapidi, e niente vulcano ---
  for (const seed of [11, 222, 3333, 44444, 555555]) {
    const m = MG.generate(seed, 1, true);
    // connettivita': dallo spawn si deve raggiungere TUTTO il pavimento
    // v2.21 — con le GRATE APERTE. Il ripostiglio della v2.21 e' nove tessere scavate nel pieno e
    // chiuse da una grata: a grata chiusa sono irraggiungibili per costruzione, ed e' giusto cosi'.
    // Cio' che questo controllo deve continuare a garantire e' che non esista pavimento ORFANO —
    // cioe' che, tirata la leva, non resti niente di scollegato. Quindi si apre e si misura.
    const W = m.w, H = m.h, gri = m.grid.slice();
    for (const q of (m.grate || [])) for (const t of q.tiles) gri[t] = C.T_FLOOR;
    const sx = (m.spawn.x / m.tile) | 0, sy = (m.spawn.y / m.tile) | 0;
    assert(gri[sy * W + sx] !== C.T_WALL, 'seme ' + seed + ': si nasce su pavimento, non dentro una lapide');
    const vis = new Uint8Array(W * H); const st = [sy * W + sx]; vis[st[0]] = 1; let visti = 1;
    while (st.length) { const i = st.pop(), x = i % W, y = (i / W) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const j = ny * W + nx; if (vis[j] || gri[j] === C.T_WALL) continue; vis[j] = 1; visti++; st.push(j); } }
    let liberi = 0; for (let i = 0; i < gri.length; i++) if (gri[i] !== C.T_WALL) liberi++;
    assert(visti === liberi, 'seme ' + seed + ': tutto il pavimento e raggiungibile (' + visti + '/' + liberi + ')');
    // le lapidi ci sono, e sono tante: sono LORO il cimitero
    let lap = 0, cinta = 0, pietra = 0;
    for (let i = 0; i < gri.length; i++) { if (gri[i] !== C.T_WALL || !m.muri) continue;
      const t = m.muri[i]; if (t === 1) lap++; else if (t === 3) cinta++; else if (t === 2) pietra++; }
    assert(lap >= 55, 'seme ' + seed + ': i campi di lapidi ci sono, e sono fitti (' + lap + ')');
    assert(cinta >= 120, 'seme ' + seed + ': e il muro di cinta gira tutto attorno (' + cinta + ')');
    assert(pietra >= 10, 'seme ' + seed + ': con mausolei e muri crollati (' + pietra + ')');
    assert(m.theme.id !== 'lava', 'seme ' + seed + ': un cimitero dentro un vulcano no (' + m.theme.name + ')');
    assert(!!m.exit || m.enemySpawns.length > 0, 'seme ' + seed + ': la mappa e giocabile (uscita e caselle di comparsa)');
    // spazio: il cimitero e' APERTO, ed e' il suo carattere. Se scendesse sotto la caverna sarebbe un errore.
    // v1.98 — il cimitero era largo quanto la mappa e sembrava vuoto: adesso il bosco lo stringe e lo
    // spazio calpestabile sta nella stessa fascia della caverna. Ne' una piazza d'armi ne' un budello.
    assert(liberi > 1250 && liberi < 2000, 'seme ' + seed + ': e raccolto quanto una caverna (' + liberi + ' tessere libere)');
  }

  // --- 3) i tipi delle tessere sono solo un'informazione per il renderer ---
  // La griglia resta binaria: e' questo a permettere al cimitero di non toccare una riga di IA.
  {
    const m = MG.generate(9090, 1, true);
    let fuoriPosto = 0;
    for (let i = 0; i < m.grid.length; i++) if (m.grid[i] !== C.T_WALL && m.muri[i] && m.muri[i] !== 1 && m.muri[i] !== 4) fuoriPosto++;
    assert(fuoriPosto < 40, 'i tipi restano allineati alla griglia dopo il ritocco anti-imbuto (' + fuoriPosto + ' scarti)');
    assert(MG.generate(9090, 5).muri === null, 'e nella caverna il campo non esiste proprio');
  }

  // --- 4) SI GIOCA: trenta secondi di ondata vera, e nessuno resta incastrato ---
  // v2.9.1 — la partita vera adesso apre in GROTTA. La prova di movimento resta: e' quella che dice che
  // dall'ondata 1 i nemici camminano invece di impiantarsi, ed e' il motivo per cui esiste questo blocco.
  {
    const room = new Room('v197'); const p = room.addPlayer('a', { send() {} }, 'A', 'paladino');
    room.startGame();
    assert(room.map.archetipo !== 'cimitero' && !room.map.market, 'la prima ondata di una partita vera e in grotta');
    const partenze = new Map();
    for (let i = 0; i < C.TICK_RATE * 30; i++) {
      p.hp = room.effMaxHp(p); p.down = false; p.dead = false;
      room.setInput('a', { mx: 0, my: 0, aim: 0 });
      room.update(dt);
      for (const mo of room.monsters) if (!mo.dead && !partenze.has(mo.eid)) partenze.set(mo.eid, { x: mo.x, y: mo.y, t: i });
    }
    let fermi = 0, contati = 0;
    for (const mo of room.monsters) {
      if (mo.dead || mo.def.immobile) continue;
      const p0 = partenze.get(mo.eid); if (!p0 || p0.t > C.TICK_RATE * 20) continue;   // e' nato da poco: non conta
      contati++;
      if (MU.dist(mo.x, mo.y, p0.x, p0.y) < 40) fermi++;
    }
    assert(contati > 3, 'ci sono abbastanza nemici per la prova (' + contati + ')');
    assert(fermi <= contati * 0.34, 'e non restano incastrati (' + fermi + ' fermi su ' + contati + ')');
    for (const mo of room.monsters) if (!mo.dead) assert(!room.isWallAt(mo.x, mo.y), 'nessun nemico finisce dentro una tessera piena');
  }
  ok('cimitero in stand-by: si apre in grotta, e la sua pianta e ancora sana');
}


// ============================================================================
// TEST 66 — v1.99: la CALDERA delle ondate dei boss (10 e 20)
// ============================================================================
function testV199() {
  console.log('\n[TEST 66] v1.99 — la caldera: le due ondate dei boss non sono piu una caverna');
  // v2.13.1 — SEMINATO, come il 58 e il 62. Anche questo falliva ogni tanto (circa una volta su cinque)
  // sulla riga «si muove davvero»: la caldera e' generata a caso, e in una certa manciata di mappe il
  // boss partiva in un punto da cui, nei secondi che il test gli concede, non si allontanava abbastanza.
  // Non e' un bug del boss: e' il test che chiedeva la stessa cosa a mappe diverse.
  const _rndVero = Math.random; Math.random = MU.seedRng(0x1990);
  const MG = require('../shared/mapgen.js');
  const dt = 1 / C.TICK_RATE;

  // --- 1) dove si gioca ---
  for (const lv of C.CALDERA_ONDATE) assert(MG.generate(300 + lv, lv).archetipo === 'caldera', 'ondata ' + lv + ' (boss): si gioca nella caldera');
  for (const lv of [5, 9, 11, 15, 19]) assert(MG.generate(300 + lv, lv).archetipo !== 'caldera', 'ondata ' + lv + ': resta la caverna');
  assert(C.CALDERA_ONDATE.length === 2 && C.CALDERA_ONDATE[0] === 10 && C.CALDERA_ONDATE[1] === 20, 'e l elenco dice 10 e 20');
  for (const lv of C.CALDERA_ONDATE) assert(Waves.isBossWave(lv), 'ondata ' + lv + ' e davvero un ondata di boss');

  // --- 2) la pianta regge, e il BOSS ci passa ---
  // Non basta che sia connessa: un boss ha raggio 52 e per muoversi gli serve una casella 3x3 libera.
  // Si misura il grafo delle CELLE LARGHE, che e' quello su cui si muove lui.
  for (const seed of [7, 21, 99, 404, 808]) {
    const m = MG.generate(seed, 10);
    const W = m.w, H = m.h, gri = m.grid;
    const passa = (v) => v !== C.T_WALL;
    let liberi = 0, crepe = 0;
    for (let i = 0; i < gri.length; i++) { if (passa(gri[i])) liberi++; if (gri[i] === C.T_HAZARD) crepe++; }
    assert(liberi > 1000 && liberi < 1600, 'seme ' + seed + ': la conca e larga il giusto (' + liberi + ' tessere)');
    // v1.99.2 — NESSUNA POZZA nella caldera. Fino alla 1.99.1 la faglia si apriva a raggiera dal centro,
    // ma in mezzo all'arena faceva un effetto brutto: adesso il centro si arreda con gli ORNAMENTI
    // (sassi, bracieri, ossa), che sono disegno e basta e non tolgono spazio al boss.
    assert(crepe === 0, 'seme ' + seed + ': nessuna pozza dentro la caldera (' + crepe + ')');
    const grande = (mask) => {
      const vis = new Uint8Array(W * H); let best = 0, tot = 0;
      for (let i = 0; i < mask.length; i++) if (mask[i]) tot++;
      for (let s0 = 0; s0 < mask.length; s0++) {
        if (vis[s0] || !mask[s0]) continue;
        const st = [s0]; vis[s0] = 1; let n = 1;
        while (st.length) { const i = st.pop(), x = i % W, y = (i / W) | 0;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
            const j = ny * W + nx; if (vis[j] || !mask[j]) continue; vis[j] = 1; n++; st.push(j); } }
        if (n > best) best = n;
      }
      return { tot, best };
    };
    // v2.21 — anche qui si misura a GRATE APERTE: il ripostiglio chiuso e' scollegato per costruzione
    // (vedi il controllo della pianta del cimitero), e quello che conta e' che non resti niente di
    // orfano una volta tirata la leva.
    const camm = new Uint8Array(W * H); for (let i = 0; i < gri.length; i++) camm[i] = passa(gri[i]) ? 1 : 0;
    for (const q of (m.grate || [])) for (const t of q.tiles) camm[t] = 1;
    const a = grande(camm);
    assert(a.best === a.tot, 'seme ' + seed + ': tutta la conca e raggiungibile (' + a.best + '/' + a.tot + ')');
    const largo = new Uint8Array(W * H);
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
      let ok = true;
      for (let dy = -1; dy <= 1 && ok; dy++) for (let dx = -1; dx <= 1; dx++) if (!passa(gri[(y + dy) * W + x + dx])) { ok = false; break; }
      if (ok) largo[y * W + x] = 1;
    }
    const b = grande(largo);
    assert(b.tot > 500, 'seme ' + seed + ': c e spazio da boss (' + b.tot + ' caselle larghe 3x3)');
    assert(b.best / b.tot > 0.95, 'seme ' + seed + ': e il boss puo girare in tutta la caldera (' + (100 * b.best / b.tot).toFixed(1) + '% delle caselle larghe in un pezzo solo)');
  }

  // --- 2b) v1.99.2 — IL CENTRO E' ARREDATO, NON VUOTO. Gli ornamenti sono props: li disegna il
  //     renderer, la griglia non li conosce. Quindi qui si controlla che ci siano davvero, che siano
  //     dei tipi giusti, e che stiano LONTANO DAI MURI — cioe' in mezzo, dove prima c'erano le crepe.
  for (const seed of [7, 21, 99, 404, 808]) {
    const m = MG.generate(seed, 10);
    const W = m.w, H = m.h, gri = m.grid, T = C.TILE;
    const muro = (x, y) => (x < 0 || y < 0 || x >= W || y >= H) ? true : gri[y * W + x] === C.T_WALL;
    const conta = (tipi) => m.props.filter(p => tipi.indexOf(p.type) >= 0).length;
    assert(conta(['rock', 'rockSmall', 'stalagmite']) >= 10, 'seme ' + seed + ': sassi in mezzo alla conca (' + conta(['rock', 'rockSmall', 'stalagmite']) + ')');
    assert(conta(['brazier']) >= 4, 'seme ' + seed + ': e dei bracieri (' + conta(['brazier']) + ')');
    assert(conta(['bones', 'skull', 'skullpile', 'corpse']) >= 8, 'seme ' + seed + ': e le ossa di chi e venuto prima (' + conta(['bones', 'skull', 'skullpile', 'corpse']) + ')');
    // quanti stanno in campo aperto: una decorazione appoggiata al muro non arreda il centro
    let aperti = 0;
    for (const p of m.props) {
      if (p.type === 'torch') continue;
      const tx = (p.x / T) | 0, ty = (p.y / T) | 0;
      if (!muro(tx - 1, ty) && !muro(tx + 1, ty) && !muro(tx, ty - 1) && !muro(tx, ty + 1)) aperti++;
    }
    assert(aperti >= 25, 'seme ' + seed + ': il centro e arredato davvero (' + aperti + ' ornamenti lontani dai muri)');
  }

  // --- 3) SI GIOCA: quaranta secondi delle due ondate vere ---
  for (const onda of C.CALDERA_ONDATE) {
    const room = new Room('v199_' + onda); const p = room.addPlayer('a', { send() {} }, 'A', 'paladino');
    room.startGame(onda);
    assert(room.map.archetipo === 'caldera', 'ondata ' + onda + ': la partita vera parte nella caldera');
    let boss = null, part = null;
    for (let i = 0; i < C.TICK_RATE * 40; i++) {
      p.hp = room.effMaxHp(p); p.down = false; p.dead = false;
      room.setInput('a', { mx: 0, my: 0, aim: 0 });
      room.update(dt);
      if (!boss) { boss = room.monsters.find(x => x.boss && !x.dead) || null; if (boss) part = { x: boss.x, y: boss.y }; }
    }
    assert(!!boss, 'ondata ' + onda + ': il boss e in campo');
    assert(MU.dist(boss.x, boss.y, part.x, part.y) > 120, 'ondata ' + onda + ': e si muove davvero (' + MU.dist(boss.x, boss.y, part.x, part.y).toFixed(0) + ' px), non resta incastrato fra gli speroni');
    for (const mo of room.monsters) if (!mo.dead) assert(!room.isWallAt(mo.x, mo.y), 'ondata ' + onda + ': nessun nemico dentro una roccia');
  }

  // --- 4) v1.99.1 — L'ARENA E' SGOMBRA. Cresta e speroni in mezzo sono spariti: per un boss di raggio
  //     38-52 erano trappole, e Paolo ci ha visto il Colosso incastrarsi. Qui si verifica che dentro la
  //     conca non resti NESSUN ostacolo isolato: le uniche rocce ammesse sono attaccate al bordo.
  for (const seed of [7, 21, 99, 404, 808]) {
    const m = MG.generate(seed, 10);
    const W = m.w, H = m.h, gri = m.grid;
    const roccia = (i) => gri[i] === C.T_WALL;
    // la roccia "di fuori" e' quella che si tocca partendo dal bordo della mappa
    const vis = new Uint8Array(W * H); const st = [];
    for (let x = 0; x < W; x++) { for (const i of [x, (H - 1) * W + x]) if (roccia(i) && !vis[i]) { vis[i] = 1; st.push(i); } }
    for (let y = 0; y < H; y++) { for (const i of [y * W, y * W + W - 1]) if (roccia(i) && !vis[i]) { vis[i] = 1; st.push(i); } }
    while (st.length) { const i = st.pop(), x = i % W, y = (i / W) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const j = ny * W + nx; if (vis[j] || !roccia(j)) continue; vis[j] = 1; st.push(j); } }
    let isolate = 0;
    for (let i = 0; i < gri.length; i++) if (roccia(i) && !vis[i]) isolate++;
    assert(isolate === 0, 'seme ' + seed + ': niente ostacoli in mezzo all arena (' + isolate + ' tessere isolate)');
  }

  // --- 5) v1.99.1 — IL COLOSSO NON E' PIU' UNA LUMACA ---
  {
    const Mon = require('../shared/monsters.js');
    const d = Mon.BOSSES.rift_colossus;
    assert(d.speed >= 90, 'il Colosso cammina (' + d.speed + ', era 74)');
    assert(d.caricaCd > 0 && d.caricaDur > 0 && d.caricaMin > 0, 'ha una carica, con il suo tempo di ricarica');
    assert(d.slamPredizione > 0, 'e il pugno anticipa il movimento invece di mirare dove sei');
    // la carica parte davvero: boss lontano, giocatore in vista, e prima o poi si lancia
    // v2.24 — RISEMINATO QUI. Il seme del test e' uno solo per tutto il blocco, quindi questo pezzo
    // pescava da un punto dello stream che dipendeva da quanti sorteggi avevano fatto i controlli
    // sopra. Cambiando la composizione delle ondate (v2.24) il conto dei sorteggi e' cambiato, il
    // punto di partenza si e' spostato e la carica non partiva piu': non un bug del Colosso, un test
    // legato a un dettaglio che non doveva riguardarlo. Con un seme suo questo pezzo non dipende piu'
    // da cosa succede prima.
    Math.random = MU.seedRng(0x1991);
    const room = new Room('v1991'); const p = room.addPlayer('a', { send() {} }, 'A', 'paladino');
    room.startGame(10);
    room.monsters = room.monsters.filter(x => x.boss); room.pending = 0; room.waveList = [];
    const boss = room.monsters[0];
    assert(!!boss, 'il Colosso e in campo');
    let caricato = false, veloceMax = 0;
    const dt2 = 1 / C.TICK_RATE;
    for (let i = 0; i < C.TICK_RATE * 30 && !caricato; i++) {
      p.hp = room.effMaxHp(p); p.down = false; p.dead = false;
      // il giocatore tiene le distanze: e' la situazione in cui prima il Colosso non arrivava mai
      const a = Math.atan2(p.y - boss.y, p.x - boss.x);
      const dd = MU.dist(p.x, p.y, boss.x, boss.y);
      const n = MU.norm(Math.cos(a) * (dd < 320 ? 1 : -0.2), Math.sin(a) * (dd < 320 ? 1 : -0.2));
      room.setInput('a', { mx: n.x, my: n.y, aim: a + Math.PI });
      room.update(dt2);
      const v = Math.hypot(boss.mx || 0, boss.my || 0);
      if (v > veloceMax) veloceMax = v;
      // la carica comincia in questo tick ma il movimento arriva dal prossimo: si guardano altri 30 tick
      if (boss.carica && !caricato) {
        for (let k = 0; k < 30; k++) {
          p.hp = room.effMaxHp(p); p.down = false; p.dead = false;
          room.setInput('a', { mx: 0, my: 0, aim: 0 });
          room.update(dt2);
          const vv = Math.hypot(boss.mx || 0, boss.my || 0);
          if (vv > veloceMax) veloceMax = vv;
        }
        caricato = true;
      }
    }
    assert(caricato, 'e in trenta secondi ti carica addosso almeno una volta');
    assert(veloceMax > boss.speed * 2, 'la carica e davvero uno scatto (' + veloceMax.toFixed(0) + ' px/s contro i ' + boss.speed + ' del passo)');
    assert(!room.isWallAt(boss.x, boss.y), 'e non finisce dentro la roccia');
  }

  Math.random = _rndVero;
  ok('caldera verificata: connessa, il boss ci gira, e la faglia e aperta in mezzo');
}

// ============================================================================
// TEST 67 — v2.0: IL VILLAGGIO SOTTERRANEO (la sosta fra un'ondata e l'altra)
// ============================================================================
function testV200() {
  console.log('\n[TEST 67] v2.0 — il villaggio: la sosta non e piu una sala, e un paese con le case abitate');
  const MapGen = require('../shared/mapgen.js');
  const T = C.TILE, V = MapGen.VILLAGE, m = MapGen.generateMarket(7);
  const dt = 1 / C.TICK_RATE;

  // --- 1) LA PIANTA ---
  // v2.6 — il villaggio e' cresciuto per fare posto alle due file: 60x46 invece di 56x40
  assert(m.w === 60 && m.h === 46, 'il villaggio e 60x46 (' + m.w + 'x' + m.h + ')');
  // v2.19 — sette botteghe e cinque case: l'archeria e la bottega arcana hanno preso il posto di due
  // abitazioni (casa_a a ponente, casa_c a levante).
  assert(V.rooms.filter(r => r.kind === 'bottega').length === 7, 'sette botteghe');
  assert(V.rooms.filter(r => r.kind === 'casa').length >= 5, 'e almeno cinque case abitate');
  const grandi = ['taverna', 'erbe', 'fucina'];
  for (const id of grandi) { const r = V.rooms.find(q => q.id === id);
    assert((r.x1 - r.x0) >= 10 && (r.y1 - r.y0) >= 7, 'la bottega ' + id + ' e grande (' + (r.x1 - r.x0 + 1) + 'x' + (r.y1 - r.y0 + 1) + ')'); }
  // nessuna stanza si sovrappone a un'altra: due case nello stesso posto sarebbero una casa sola
  for (let i = 0; i < V.rooms.length; i++) for (let j = i + 1; j < V.rooms.length; j++) {
    const a = V.rooms[i], b = V.rooms[j];
    assert(a.x1 < b.x0 - 0 || b.x1 < a.x0 || a.y1 < b.y0 || b.y1 < a.y0, a.id + ' e ' + b.id + ' non si sovrappongono');
  }

  // --- 2) IL PORTALE STA NELLA SUA CASA, con due guardie sulla soglia (v2.6) ---
  const stP = V.rooms.find(r => r.kind === 'portale');
  assert(!!stP, 'c e la casa del portale');
  assert(Math.abs(m.portale.x - (stP.x0 + stP.x1 + 1) / 2) <= 0.6 &&
         Math.abs(m.portale.y - (stP.y0 + stP.y1 + 1) / 2) <= 0.6, 'il portale e nel centro di quella stanza');
  assert(m.grid[Math.floor(m.portale.y) * m.w + Math.floor(m.portale.x)] === C.T_FLOOR, 'e ci si cammina sopra');
  const pcx = (V.piazza.x0 + V.piazza.x1) / 2, pcy = (V.piazza.y0 + V.piazza.y1) / 2;
  assert(Math.hypot(m.portale.x - pcx, m.portale.y - pcy) > 8, 'e NON e piu in mezzo alla piazza');
  let nExit = 0; for (const v of m.grid) if (v === C.T_EXIT) nExit++;
  assert(nExit === 0, 'nessuna tessera EXIT: l uscita e la faglia, non un quadrato verde');
  // la partenza NON e' addosso al portale: se no si esce appena arrivati
  const dSpawn = MU.dist(m.spawn.x, m.spawn.y, m.portale.x * T + T / 2, m.portale.y * T + T / 2);
  assert(dSpawn > (C.FAGLIA_RAGGIO || 46) + C.PLAYER_RADIUS + 40, 'e si nasce fuori dalla sua bocca (' + dSpawn.toFixed(0) + ' px)');
  // v2.6 — "lo si vede appena arrivati" non vale piu': adesso e' dentro una casa, e ci si va. Resta il
  // vincolo che conta, cioe' il TEMPO: venti tessere sono meno di cinque secondi di cammino.
  assert(dSpawn < T * 20, 'ma ci si arriva in pochi secondi (' + (dSpawn / T).toFixed(1) + ' tile)');

  // --- 3) LE CASE SONO CASE: focolare al centro, letto, gente dentro ---
  const dentro = (o, r) => { const x = o.x / T - 0.5, y = o.y / T - 0.5; return x >= r.x0 - 0.6 && x <= r.x1 + 0.6 && y >= r.y0 - 0.6 && y <= r.y1 + 0.6; };
  for (const r of V.rooms.filter(q => q.kind === 'casa')) {
    const roba = m.props.filter(p => dentro(p, r));
    const foc = roba.filter(p => p.type === 'focolare');
    assert(foc.length === 1, r.id + ': un focolare, uno solo');
    const cx = (r.x0 + r.x1) / 2, cy = (r.y0 + r.y1) / 2;
    assert(Math.abs(foc[0].x / T - 0.5 - cx) < 0.6 && Math.abs(foc[0].y / T - 0.5 - cy) < 0.6, r.id + ': e sta in mezzo alla stanza');
    assert(roba.some(p => p.type === 'letto'), r.id + ': ci si dorme');
    assert(roba.some(p => p.type === 'tavolo'), r.id + ': e ci si mangia');
    assert(m.village.extras.some(e => dentro(e, r)), r.id + ': e ci abita qualcuno');
  }
  // e non sono sette volte la stessa casa
  const impronte = new Set();
  for (const r of V.rooms.filter(q => q.kind === 'casa'))
    impronte.add(m.props.filter(p => dentro(p, r)).map(p => p.type).sort().join(','));
  assert(impronte.size >= 4, 'le case non sono tutte uguali (' + impronte.size + ' arredamenti diversi su ' + V.rooms.filter(q => q.kind === 'casa').length + ')');

  // --- 3b) v2.3 — I GIROVAGHI: gente che CAMMINA per le strade. La loro posizione non e' uno stato ma
  //     una funzione del tempo della partita, quindi non c'e' niente da sincronizzare — ma le rotte
  //     devono stare sulle strade, perche' nessuno controlla i muri a ogni fotogramma.
  {
    const gir = m.village.girovaghi || [];
    assert(gir.length >= 8, 'per le strade cammina della gente (' + gir.length + ' girovaghi)');
    assert(gir.some(g => g.anello), 'e qualcuno gira in tondo invece di fare avanti e indietro');
    let fuori = 0, corti = 0;
    for (const g of gir) {
      const p = g.pts, n = p.length, fin = g.anello ? n : n - 1;
      if (g.vel <= 0) corti++;
      for (let i = 0; i < fin; i++) {
        const a = p[i], b = p[(i + 1) % n];
        const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
        if (L < T) corti++;
        const passi = Math.ceil(L / 12);
        for (let k = 0; k <= passi; k++) {
          const x = a[0] + (b[0] - a[0]) * k / passi, y = a[1] + (b[1] - a[1]) * k / passi;
          if (m.grid[((y / T) | 0) * m.w + ((x / T) | 0)] === C.T_WALL) { fuori++; break; }
        }
      }
    }
    assert(fuori === 0, 'e nessuna rotta attraversa un muro (' + fuori + ' tratti dentro la roccia)');
    assert(corti === 0, 'e nessuna rotta e degenere: tutti i tratti sono lunghi almeno una tessera');
    // niente corpo solido: il corpo lo calcola il server dalle posizioni, e qui le posizioni non
    // esistono — esiste una formula. Un corpo fermo sotto chi cammina sarebbe peggio di nessun corpo.
    assert(m.solids.filter(s2 => s2.chi).length === m.village.npcs.length + m.village.extras.length,
      'i girovaghi non hanno un corpo: ci si passa attraverso, ed e voluto');
    // e la rotta di ponente della via maestra non passa dentro il portale
    const pw = { x: m.portale.x * T + T / 2, y: m.portale.y * T + T / 2 };
    let addosso = 0;
    for (const g of gir) for (const q of g.pts) if (MU.dist(q[0], q[1], pw.x, pw.y) < (C.FAGLIA_RAGGIO || 46) + 30) addosso++;
    assert(addosso === 0, 'e nessuno passa dentro il portale (' + addosso + '): uno che entra nella faglia e ne esce rovina il posto');
  }

  // --- 4) LA GENTE FA QUALCOSA, e nessuno sta dentro la roccia ---
  const inWall = (o) => m.grid[((o.y / T) | 0) * m.w + ((o.x / T) | 0)] === C.T_WALL;
  assert(!m.village.extras.some(inWall) && !m.village.npcs.some(inWall) && !m.props.some(inWall), 'nessuno e niente dentro la roccia');
  assert(m.village.extras.filter(e => e.act).length >= 6, 'almeno sei abitanti hanno un mestiere in corso');
  assert(m.village.extras.every(e => !e.seated), 'e stanno tutti in piedi: dall alto una figura seduta non si legge');

  // --- 5) CI SI ARRIVA DAVVERO, coi mobili al loro posto ---
  // Non basta la griglia: i mobili hanno un corpo dalla v1.75.2, e un tavolo davanti a una porta e' un
  // muro travestito. Si cammina su una griglia fine (mezza tessera) evitando roccia E ingombri.
  const RAG = C.PLAYER_RADIUS, S = 2, NX = m.w * S, NY = m.h * S;
  const urta = (s, wx, wy) => s.t === 'c' ? MU.dist(s.x, s.y, wx, wy) < s.r + RAG
                                          : (Math.abs(s.x - wx) < s.hw + RAG && Math.abs(s.y - wy) < s.hh + RAG);
  const px = (i) => ((i % NX) + 0.5) * T / S, py = (i) => (((i / NX) | 0) + 0.5) * T / S;
  const libero = (wx, wy) => { const tx = (wx / T) | 0, ty = (wy / T) | 0;
    if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h || m.grid[ty * m.w + tx] === C.T_WALL) return false;
    for (const s of m.solids) if (urta(s, wx, wy)) return false; return true; };
  const ok2 = new Uint8Array(NX * NY); for (let i = 0; i < NX * NY; i++) ok2[i] = libero(px(i), py(i)) ? 1 : 0;
  const nodo = (wx, wy) => Math.max(0, Math.min(NY - 1, Math.round(wy / T * S - 0.5))) * NX + Math.max(0, Math.min(NX - 1, Math.round(wx / T * S - 0.5)));
  const vis = new Uint8Array(NX * NY), st = [nodo(m.spawn.x, m.spawn.y)]; vis[st[0]] = 1;
  while (st.length) { const i = st.pop(), x = i % NX, y = (i / NX) | 0;
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + d[0], ny = y + d[1];
      if (nx < 0 || ny < 0 || nx >= NX || ny >= NY) continue; const j = ny * NX + nx;
      if (vis[j] || !ok2[j]) continue; vis[j] = 1; st.push(j); } }
  for (const n of m.village.npcs) {
    let bene = false;
    for (let i = 0; i < NX * NY && !bene; i++) if (vis[i] && MU.dist(px(i), py(i), n.x, n.y) <= C.MARKET_MERCH_RANGE) bene = true;
    assert(bene, 'si arriva a parlare con ' + n.name);
  }
  for (const r of V.rooms) {
    let bene = false;
    for (let y = r.y0; y <= r.y1 && !bene; y++) for (let x = r.x0; x <= r.x1 && !bene; x++) if (vis[nodo(x * T + T / 2, y * T + T / 2)]) bene = true;
    assert(bene, 'si entra in ' + r.id);
  }
  assert(vis[nodo(m.portale.x * T + T / 2, m.portale.y * T + T / 2)], 'e si arriva al portale');

  // --- 6) IN PARTITA VERA: si entra in sosta, la faglia si apre, e attraversarla riporta al menu ---
  const room = new Room('v200'); const p = room.addPlayer('a', { send() {} }, 'A', 'paladino');
  room.startGame(); room.wave = 3; room.enterMarket();
  assert(room.phase === C.PHASE_MARKET, 'si entra nel villaggio');
  assert(room.map.w === 60 && room.map.h === 46, 'ed e la mappa nuova');
  assert(!!room.faglia, 'la faglia e aperta');
  const fx = room.map.portale.x * T + T / 2, fy = room.map.portale.y * T + T / 2;
  assert(MU.dist(room.faglia.x, room.faglia.y, fx, fy) < 2, 'e sta nel centro della piazza');
  // il timer non c e piu: si puo stare quanto si vuole
  for (let i = 0; i < C.TICK_RATE * 150; i++) { room.setInput('a', { mx: 0, my: 0, aim: 0 }); room.update(dt); }
  assert(room.phase === C.PHASE_MARKET, 'dopo due minuti e mezzo si e ancora al villaggio: nessun timer caccia via');
  // e chi entra nella faglia torna al menu di fine ondata
  p.x = room.faglia.x; p.y = room.faglia.y; room.update(dt);
  assert(room.phase === C.PHASE_SHOP, 'attraversando la faglia si torna al menu di fine ondata');
  assert(!room.faglia, 'e la faglia si chiude dietro');
  ok('novita v2.0 verificate');
}

// ============================================================================================
// TEST 68 — v2.7: LA STORIA (il risveglio, il villaggio, l’oracolo)
// ============================================================================================
// Questo e' l'unico test che fa partire una partita VERA, col prologo. Tutti gli altri lo saltano
// (vedi la nota in cima al file), quindi se il giro della storia si rompe casca solo qui: e' per
// questo che qui si prova la CATENA INTERA, non i pezzi.
// ============================================================================
// TEST 69 — v2.9.4: LE SCELTE DI FINE ONDATA non si perdono per strada
// ============================================================================
// IL BUG, segnalato giocando: ai livelli 8 e 14 — quelli delle ABILITA' ATTIVE — non veniva offerto
// niente. Misurato: in una run normale, un livello per ondata, lo slot Q arrivava in ritardo (al 9,
// appeso alla passiva) e lo slot E **non arrivava mai**: a fine partita `E = null` e la coda ancora
// piena. Perso in ogni singola partita, perche' dopo il 12 non c'e' piu' nessuno scaglione che possa
// riaprire il pannello e trascinarsi dietro l'abilita' rimasta in coda.
//
// PERCHE' QUESTO TEST LEGGE I MESSAGGI VERI. Non guarda `p.abilDovute` per decidere se e' andata bene:
// guarda cosa il server MANDA al client, decodificando il JSON come farebbe il browser, e poi "clicca"
// su quello che gli e' stato offerto. Un test che interroga lo stato interno avrebbe detto che l'abilita'
// era in coda — e infatti c'era — senza accorgersi che al giocatore non veniva mostrata mai.
function testSceltePannello() {
  console.log('\n[TEST 69] v2.9.4 — le scelte di fine ondata: nessuna si perde, nemmeno in doppio livello');
  const Lv = require('../shared/levels.js');

  // un giocatore che a fine ondata prende TUTTO quello che gli viene offerto, finche' non gli offrono
  // piu' niente. E' esattamente cio' che fa una persona davanti al pannello.
  const nuovo = (eroe) => {
    const off = [];
    const conn = { send(t) { const m = JSON.parse(t);
      if (m.t === C.MSG.OFFER_BOON || m.t === C.MSG.OFFER_RANK) off.push(m); } };
    const r = new Room('sc_' + eroe); const p = r.addPlayer('a', conn, 'A', eroe);
    r.startGame(1, true); r.phase = C.PHASE_SHOP;
    return { r, p, off };
  };
  const svuota = (r, off) => {
    const prese = []; let giri = 0;
    while (giri++ < 25) {
      const m = off.pop(); off.length = 0;
      if (!m) break;
      if (m.t === C.MSG.OFFER_RANK) { const id = m.cards && m.cards[0] && m.cards[0].id; if (!id) break;
        r.pickRank('a', id); prese.push(m.spec ? 'spec' : 'rango'); continue; }
      if (m.boons && m.boons.length) { r.pickBoon('a', m.boons[0].id);
        prese.push(m.abil ? ('attiva-' + m.slot) : ('passiva-' + m.tier)); continue; }
      break;                                   // "niente da scegliere": il pannello non offre altro
    }
    return prese;
  };
  const ondata = (ctx, aLiv) => {
    ctx.r.addXp(ctx.p, Math.max(0, Lv.xpForLevel(aLiv) + 1 - ctx.p.xpPool));
    ctx.off.length = 0; ctx.r._inviaPannello(ctx.p);
    return svuota(ctx.r, ctx.off);
  };

  // --- 1) UNA RUN INTERA, un livello per ondata: le due attive arrivano AL LORO LIVELLO ---
  for (const eroe of ['paladino', 'mago', 'arciere']) {
    const ctx = nuovo(eroe); const dove = {};
    for (let L = 2; L <= Lv.MAX_LEVEL; L++) { const pr = ondata(ctx, L); if (pr.length) dove[L] = pr; }
    const p = ctx.p;
    // v2.16 — la prima attiva e' gia' in mano dal livello 1 (l'aiuto in cima al file la sceglie, come
    // fa il giocatore prima di entrare nel primo livello); la seconda arriva al 7.
    assert(!!p.abil[0], eroe + ': la prima attiva e in mano da prima dell ondata 1 (' + p.abil[0] + ')');
    assert((dove[7] || []).indexOf('attiva-2') >= 0, eroe + ': al livello 7 arriva la seconda (' + JSON.stringify(dove[7] || []) + ')');
    // v2.18 — TRE TASTI SU TRE. Il terzo slot non "aspetta" piu': ogni classe ha le sue due candidate
    // anche al livello 13. Era la sola cosa che mancava alla scaletta della v2.16.
    assert((dove[13] || []).indexOf('attiva-3') >= 0, eroe + ': al livello 13 arriva la terza (' + JSON.stringify(dove[13] || []) + ')');
    assert(!!p.abil[1] && !!p.abil[2], eroe + ': e a fine run ha tutti e tre i tasti pieni (1=' + p.abil[0] + ' 2=' + p.abil[1] + ' 3=' + p.abil[2] + ')');
    // e le quattro passive restano ai loro scaglioni: le attive si SOMMANO, non prendono il posto
    for (const s of Lv.SCAGLIONI)
      assert((dove[s.lvl] || []).indexOf('passiva-' + s.tier) >= 0, eroe + ': al livello ' + s.lvl + ' arriva la passiva ' + s.tier);
    assert((p.abilDovute || []).length === 0 && (p.scaglioniDovuti || []).length === 0,
      eroe + ': e non resta niente in coda (' + JSON.stringify(p.abilDovute) + ' / ' + JSON.stringify(p.scaglioniDovuti) + ')');
  }

  // --- 2) DUE LIVELLI IN UNA SOLA ONDATA: si prendono ENTRAMBE le cose ---
  // e' il caso segnalato: 8 e 9 insieme devono dare l'attiva E la passiva, non una delle due.
  const doppi = [
    [6, 9,  ['attiva-2', 'passiva-epic'],  'la seconda attiva (7) e la passiva epica (9)'],
    [4, 5,  ['passiva-rare'],              'la passiva rara del 5'],
    [10, 11, ['passiva-divine'],           'la passiva divina dell 11'],
    [12, 15, [],                           'niente: al 15 non c e piu il bivio'],   // v2.18 — le specializzazioni non esistono piu'
  ];
  for (const [da, a, attese, cosa] of doppi) {
    const ctx = nuovo('paladino');
    for (let L = 2; L <= da; L++) ondata(ctx, L);
    const prese = ondata(ctx, a);
    for (const at of attese)
      assert(prese.indexOf(at) >= 0, 'dal livello ' + da + ' al ' + a + ' in un ondata sola arriva ' + cosa + ' (' + JSON.stringify(prese) + ')');
    assert((ctx.p.abilDovute || []).length === 0, 'e non resta un abilita appesa (' + JSON.stringify(ctx.p.abilDovute) + ')');
  }

  // --- 3) L'ATTIVA NON SI MANGIA LA PASSIVA CHE HA SOTTO ---
  // Il difetto originale era della specializzazione del 15: aveva la precedenza nel pannello e, una
  // volta scelta, non passava la mano — chi saliva di due livelli insieme perdeva l'altra scelta per
  // sempre. La specializzazione non esiste piu' (v2.18), ma il difetto puo' tornare da qualunque scelta
  // che ha la precedenza: adesso e' la TERZA ATTIVA del 13, che sta davanti alla passiva divina dell'11.
  // Il test e' lo stesso, con al centro cio' che oggi puo' romperlo.
  {
    const ctx = nuovo('mago');
    for (let L = 2; L <= 10; L++) ondata(ctx, L);
    const prese = ondata(ctx, 13);
    assert(prese.indexOf('attiva-3') >= 0, 'la terza attiva arriva (' + JSON.stringify(prese) + ')');
    assert(prese.indexOf('passiva-divine') >= 0, 'e subito dopo la passiva divina, che era in coda sotto');
    assert(!!ctx.p.abil[2] && Object.keys(ctx.p.boonsOwned || {}).length >= 4, 'e il personaggio finisce con tutte e due');
  }

  // --- 3-bis) LA STRADA VERA: un'ondata GIOCATA, non `_inviaPannello` chiamato a mano -----------------
  // v2.11.2 — E' il buco che questo test aveva. Chiamare la funzione che manda il pannello prova che
  // QUELLA funzione e' giusta; non prova che il gioco ci passi davvero. Qui invece l'ondata si gioca fino
  // in fondo — si ammazza tutto, si attraversa la faglia, il gioco arriva al negozio da solo — e si guarda
  // cosa riceve il client. E' la stessa distinzione che con le guardie del villaggio era costata cara.
  {
    const dt = 1 / C.TICK_RATE;
    for (const [liv, atteso] of [[7, 'attiva'], [9, 'passiva']]) {
      const ric = [];
      const cn = { send(t) { const m = JSON.parse(t); if (m.t === C.MSG.OFFER_BOON) ric.push(m); } };
      const rr = new Room('vera' + liv); const pp = rr.addPlayer('a', cn, 'A', 'paladino');
      rr.startGame(1, true);
      const soglia = Lv.xpForLevel(liv);
      rr.addXp(pp, Math.max(0, soglia - 30 - pp.xpPool));
      // le passive dei livelli precedenti le ha GIA' prese, come chiunque giochi davvero. E' la
      // condizione che isola il bug: se restassero in coda terrebbero acceso il vecchio controllo
      // (`scaglioniDovuti.length > 0`) e il pannello si aprirebbe lo stesso, per il motivo sbagliato.
      pp.scaglioniDovuti = [];
      // v2.16 — e anche le ATTIVE dei livelli precedenti: la prima si prende al livello 1 e la seconda al
      // 7, e se restassero in coda il pannello si aprirebbe per quelle invece che per il livello in prova.
      pp.abilDovute = []; if (!pp.abil[0]) pp.abil[0] = Ab.perSlot('paladino', 1)[0].id;
      ric.length = 0;
      let giri = 0;
      while (rr.phase !== C.PHASE_SHOP && giri++ < C.TICK_RATE * 400) {
        // si ammazza tutto passando dalla porta vera (`killMonster`): e' quella che conta i morti, chiude
        // l'ondata e apre la faglia. Mettere `hp = 0` e basta lascerebbe l'ondata aperta per sempre.
        for (const mo of rr.monsters) if (!mo.dead) { mo.hp = 0; rr.killMonster(mo, pp); }
        pp.hp = rr.effMaxHp(pp);
        if (pp.xpPool < soglia + 1) rr.addXp(pp, soglia + 1 - pp.xpPool);
        rr.setInput('a', { mx: 0, my: 0, aim: 0 });
        rr.update(dt);
        if (rr.faglia && rr.phase === C.PHASE_CLEARED) { pp.x = rr.faglia.x; pp.y = rr.faglia.y; }
      }
      assert(rr.phase === C.PHASE_SHOP, 'livello ' + liv + ': l ondata giocata arriva al negozio (' + rr.phase + ')');
      const ultima = ric[ric.length - 1] || {};
      const che = ultima.abil ? 'attiva' : ((ultima.boons || []).length ? 'passiva' : 'niente');
      assert(che === atteso, 'e finendo l ondata al livello ' + liv + ' il pannello offre una ' + atteso + ' (offre: ' + che + ')');
    }
  }

  // --- 4) CHI NON SCEGLIE NON PERDE NIENTE: la coda sopravvive all ondata ---
  // se uno chiude il pannello senza scegliere, la scelta deve ripresentarsi la volta dopo.
  {
    const ctx = nuovo('arciere');
    for (let L = 2; L <= 7; L++) { ctx.r.addXp(ctx.p, Math.max(0, Lv.xpForLevel(L) + 1 - ctx.p.xpPool)); }
    assert((ctx.p.abilDovute || []).indexOf(2) >= 0, 'ha un abilita in sospeso senza aver scelto niente');
    ctx.off.length = 0; ctx.r._inviaPannello(ctx.p);
    const m = ctx.off[ctx.off.length - 1] || {};
    assert(m.boons && m.boons.length > 0, 'e riaprendo il pannello gli viene offerta lo stesso (' + (m.boons || []).length + ' carte)');
  }
  ok('le scelte di fine ondata verificate: la scaletta 1-3-5-7-9-11 arriva, e il doppio livello da entrambe');
}

// ============================================================================
// TEST 70 — v2.11: IL SALVATAGGIO
// ============================================================================
// LA REGOLA CHE QUESTO TEST DIFENDE: si salvano le CAUSE, non gli EFFETTI. Un personaggio all'ondata 12
// ha `stats.dmgMult`, `perk.parata`, `maxHp` — tutti numeri CALCOLATI dai punti spesi, dalle carte prese e
// dall'equipaggiamento. Salvare i numeri calcolati vorrebbe dire che il giorno che ritari una statistica
// ogni partita salvata resta col bilanciamento vecchio, in silenzio. Qui si salva, si ricarica in una
// stanza NUOVA — come riaprire il browser domani — e si confronta campo per campo.
function testSalvataggio() {
  console.log('\n[TEST 70] v2.11 — il salvataggio: si salvano le cause, gli effetti si rifanno');
  const SV = require('../shared/salvataggio.js');
  const preso = [];
  const conn = { send(t) { const m = JSON.parse(t); preso.push(m); } };

  // --- 1) IL GIRO INTERO: si salva all'Ostessa, si riapre domani ---
  const r = new Room('sv'); const p = r.addPlayer('a', conn, 'A', 'mago');
  r.startGame(12, true); r.wave = 11; r.enterMarket();
  p.coins = 300;
  p.x = r.innkeeper.x; p.y = r.innkeeper.y;
  const cause = JSON.stringify(SV.CAMPI.map(k => p[k]));
  const statPrima = JSON.stringify(p.stats), hpPrima = r.effMaxHp(p);
  preso.length = 0;
  r.salvaAllOstessa('a');
  const sal = preso.find(m => m.t === C.MSG.SALVATO);
  assert(!!sal, 'l Ostessa consegna il pacchetto');
  assert(p.coins === 300 - SV.COSTO, 'e si paga: ' + SV.COSTO + ' monete (' + p.coins + ')');
  // il pacchetto si costruisce PRIMA di pagare: se no, ricaricando, la stessa sosta si paga due volte
  assert(sal.dati.coins === 300, 'ma il salvataggio tiene le monete di PRIMA: la sosta si paga una volta sola (' + sal.dati.coins + ')');
  assert(sal.eti && sal.eti.ondata === 11 && sal.eti.classe === 'Mago', 'e l etichetta dice dove sei: ' + JSON.stringify(sal.eti));

  // una stanza NUOVA, un giocatore che comincia guerriero: e' riaprire il browser domani
  const r2 = new Room('sv2'); const q = r2.addPlayer('a', { send() {} }, 'A', 'paladino');
  r2.riprendi('a', sal.dati);
  assert(q.heroId === 'mago', 'riprendendo torni la CLASSE che avevi, non quella scelta nel menu (' + q.heroId + ')');
  assert(JSON.stringify(SV.CAMPI.map(k => q[k])) === cause, 'e tutte le cause tornano identiche');
  assert(JSON.stringify(q.stats) === statPrima, 'e gli EFFETTI sono stati rifatti dal ricalcolo, non copiati');
  assert(r2.effMaxHp(q) === hpPrima, 'compreso il massimo dei PV (' + r2.effMaxHp(q) + ')');
  assert(q.hp === r2.effMaxHp(q), 'e si riprende in forma: la sosta serviva a quello');

  // --- 1-bis) LA SKIN: il client deve IMPARARE la classe nuova -------------------------------------
  // v2.11.3 — Segnalato giocando: salvi da ladro, riapri col guerriero selezionato nel menu, riprendi, e
  // ti ritrovi ladro nei numeri ma col guerriero a vedersi.
  //
  // Nome ed eroe viaggiano nello snapshot UNA VOLTA SOLA (`p._sent`), perche' in partita non cambiano
  // mai. Riprendere e' l'unico momento in cui la classe CAMBIA sotto i piedi del client: senza
  // riabbassare quella bandiera il client resta con la classe vecchia e disegna il personaggio sbagliato.
  {
    const ou = []; const cn = { send(t) { ou.push(JSON.parse(t)); } };
    const ra = new Room('skin'); const pa = ra.addPlayer('a', cn, 'A', 'arciere');
    ra.startGame(10, true); ra.wave = 9; ra.enterMarket();
    pa.coins = 200; pa.x = ra.innkeeper.x; pa.y = ra.innkeeper.y;
    ou.length = 0; ra.salvaAllOstessa('a');
    const sa = ou.find(m => m.t === C.MSG.SALVATO);
    // si entra come GUERRIERO, com'era rimasta la selezione nel menu
    const rb = new Room('skin2'); const qb = rb.addPlayer('a', { send() {} }, 'A', 'paladino');
    const prima = (rb.snapshot(true).players.find(x => x.i === 'a') || {}).h;
    assert(prima === 'paladino', 'il client ha gia in cache la classe con cui e entrato (' + prima + ')');
    rb.riprendi('a', sa.dati);
    assert(qb.heroId === 'arciere', 'il server lo rifa ladro');
    const dopo = rb.snapshot(true).players.find(x => x.i === 'a') || {};
    assert(dopo.h === 'arciere', 'e lo snapshot successivo glielo RIDICE, se no resta la skin sbagliata (h=' + dopo.h + ')');
    assert(dopo.n === 'A', 'e col nome, che viaggia insieme');
  }

  // --- 2) SI RIPARTE DAL VILLAGGIO di quell ondata, e NON in modalita di prova ---
  assert(r2.phase === C.PHASE_MARKET && !!r2.map.village, 'si riapre nel villaggio, dove avevi salvato');
  assert(r2.wave === 11, 'dell ondata giusta (' + r2.wave + ')');
  // IL TRANELLO: `startGame(onda)` accende la modalita di prova e fabbrica un personaggio finto. Una
  // partita ripresa non e una prova: e la tua, e i suoi record valgono.
  assert(r2.prova === 0, 'e NON e una prova: i record valgono (prova=' + r2.prova + ')');
  assert(r2.monsters.length === 0, 'e nel villaggio non c e nessuno da ammazzare');

  // --- 3) LE SCELTE IN SOSPESO non si perdono nel salvataggio ---
  // chi salva con una carta ancora da scegliere deve ritrovarsela: e lo stesso errore di v2.9.4,
  // commesso in un posto nuovo.
  {
    const ra = new Room('sv3'); const pa = ra.addPlayer('a', conn, 'A', 'arciere');
    ra.startGame(1, true); ra.wave = 5; ra.enterMarket();
    pa.coins = 50; pa.x = ra.innkeeper.x; pa.y = ra.innkeeper.y;
    pa.scaglioniDovuti = ['rare']; pa.abilDovute = [1];
    preso.length = 0; ra.salvaAllOstessa('a');
    const s3 = preso.find(m => m.t === C.MSG.SALVATO);
    assert(s3 && s3.dati.abilDovute.length === 1 && s3.dati.scaglioniDovuti.length === 1, 'le scelte in sospeso entrano nel pacchetto');
    const rb = new Room('sv4'); const qb = rb.addPlayer('a', conn, 'A', 'arciere');
    preso.length = 0;
    rb.riprendi('a', s3.dati);
    assert(qb.abilDovute.length === 1 && qb.scaglioniDovuti.length === 1, 'e riprendendo sono ancora li');
    assert(preso.some(m => m.t === C.MSG.OFFER_BOON && m.boons && m.boons.length), 'e il pannello te le ripresenta subito');
  }

  // --- 4) SI SALVA SOLO DOVE HA SENSO ---
  {
    const rc = new Room('sv5'); const pc = rc.addPlayer('a', conn, 'A', 'paladino');
    rc.startGame(1, true);                                  // in combattimento
    pc.coins = 500;
    preso.length = 0; rc.salvaAllOstessa('a');
    assert(!preso.some(m => m.t === C.MSG.SALVATO), 'in mezzo a un ondata non si salva: lo stato non e fermo');
    rc.wave = 3; rc.enterMarket();
    pc.x = rc.innkeeper.x + 900; pc.y = rc.innkeeper.y;     // al villaggio, ma lontano dall Ostessa
    preso.length = 0; rc.salvaAllOstessa('a');
    assert(!preso.some(m => m.t === C.MSG.SALVATO), 'e nemmeno dall altra parte del villaggio: si salva DA LEI');
    pc.x = rc.innkeeper.x; pc.y = rc.innkeeper.y;
    pc.coins = SV.COSTO - 1;
    preso.length = 0; rc.salvaAllOstessa('a');
    assert(!preso.some(m => m.t === C.MSG.SALVATO), 'e senza monete non si salva');
    assert(preso.some(m => m.ev && m.ev.t === 'salva_no' && m.ev.perche === 'monete'), 'ma si dice PERCHE: un pulsante muto si legge come un guasto');
    pc.coins = SV.COSTO;
    preso.length = 0; rc.salvaAllOstessa('a');
    assert(preso.some(m => m.t === C.MSG.SALVATO), 'con le monete esatte si salva (' + SV.COSTO + ')');
  }

  // --- 5) UN PACCHETTO ROTTO SI RIFIUTA INTERO, non si carica a meta ---
  // un caricamento parziale produce un personaggio impossibile, che e molto peggio di un "non si puo".
  {
    const buono = JSON.parse(JSON.stringify(sal.dati));
    const rotti = [
      [null, 'niente'],
      [Object.assign({}, buono, { f: 999 }), 'formato di un altra versione'],
      [Object.assign({}, buono, { heroId: 'stregone' }), 'una classe che non esiste'],
      [Object.assign({}, buono, { level: 9999 }), 'un livello impossibile'],
      [Object.assign({}, buono, { ondata: -3 }), 'un ondata impossibile'],
    ];
    for (const [d, cosa] of rotti) {
      assert(!SV.valido(d), 'si rifiuta un salvataggio con ' + cosa);
      const rx = new Room('svx'); const qx = rx.addPlayer('a', { send() {} }, 'A', 'paladino');
      rx.riprendi('a', d);
      assert(rx.phase === C.PHASE_LOBBY, 'e la partita non parte a meta (' + cosa + '): resta ' + rx.phase);
    }
    // e i numeri ritoccati a mano si stringono nei loro limiti invece di produrre un mostro
    const furbo = Object.assign({}, buono, { coins: -500, lives: 99, points: -7 });
    const rf = new Room('svf'); const qf = rf.addPlayer('a', { send() {} }, 'A', 'paladino');
    rf.riprendi('a', furbo);
    assert(qf.coins >= 0 && qf.lives <= 9 && qf.points >= 0, 'i numeri ritoccati si stringono: monete ' + qf.coins + ', vite ' + qf.lives + ', punti ' + qf.points);
  }

  // --- 6) IL CAMPO NUOVO CHE QUALCUNO DIMENTICHERA -------------------------------------------------
  // Questo e il controllo che vale per il FUTURO: chi aggiunge al giocatore una causa nuova — un tipo di
  // moneta, un oggetto, un mestiere — e non la mette in CAMPI, la perde a ogni salvataggio e non se ne
  // accorge. Qui si sporca OGNI campo dichiarato e si verifica che torni indietro: se un campo sparisse
  // dall elenco, questo assert lo prende.
  {
    const rg = new Room('svg'); const pg = rg.addPlayer('a', conn, 'A', 'paladino');
    rg.startGame(1, true); rg.wave = 4; rg.enterMarket();
    pg.coins = 999; pg.x = rg.innkeeper.x; pg.y = rg.innkeeper.y;
    pg.level = 7; pg.points = 3; pg.lives = 1; pg.xpPool = 1234;
    pg.cards = ['x']; pg.boonsOwned = { heavyarm: 2 }; pg.cardOn = { heavyarm: 1 };
    pg.buys = { st_for: 4 }; pg.owned = { [require('../shared/gear.js').startingGear('paladino').weapon]: 1 }; pg.belt = ['p_forza', null, null];
    pg.abil = ['ab_carica', null, null]; pg.scaglioniDovuti = ['epic']; pg.abilDovute = [2];
    // la fotografia si prende PRIMA di salvare: salvare scala le monete, e il pacchetto tiene quelle di
    // prima (e' voluto — vedi il blocco 1 — quindi qui va confrontato con il prima, non con il dopo).
    const foto = {}; for (const k of SV.CAMPI) foto[k] = JSON.stringify(pg[k]);
    preso.length = 0; rg.salvaAllOstessa('a');
    const sg = preso.find(m => m.t === C.MSG.SALVATO);
    for (const k of SV.CAMPI)
      assert(JSON.stringify(sg.dati[k]) === foto[k], 'il campo "' + k + '" entra nel pacchetto');
  }
  // v2.15.3 — UN SALVATAGGIO FATTO PRIMA CHE IL MAGO AVESSE LE CALZATURE. Gli id non sono cambiati, il
  // FORMATO nemmeno: il pacchetto e' buono. Ma lo slot nuovo li' dentro non c'e', e riprendendo la partita
  // il mago resterebbe a piedi nudi per sempre — senza nemmeno il pezzo di base, che a tutti e' regalato.
  {
    const r = new Room('salvB'); const p = r.addPlayer('a', { send() {} }, 'M', 'mago'); r.startGame();
    const d = SV.costruisci(r, p);
    delete d.gear.boots; delete d.owned[Gear.startingGear('mago').boots];
    // r2 NON fa startGame: \`riprendi\` funziona solo dalla lobby (o da fine partita), e una stanza
    // gia' avviata lo farebbe uscire alla prima riga — la prova passerebbe senza aver provato niente.
    const r2 = new Room('salvC'); const p2 = r2.addPlayer('a', { send() {} }, 'M', 'mago');
    r2.riprendi('a', d);
    assert(!!p2.gear.boots, 'un salvataggio senza lo slot nuovo non lascia il mago scalzo: ' + p2.gear.boots);
    assert(p2.owned[p2.gear.boots] === 1, 'e il pezzo di base risulta suo, come per le altre classi');
  }
  ok('salvataggio verificato: le cause si salvano, gli effetti si rifanno, e un pacchetto rotto non entra');
}

function testStoria() {
  console.log('\n[TEST 68] v2.7 — la storia: ci si sveglia, si attraversa, si parla, si scende');
  const Storia = require('../shared/storia.js');
  const MapGen = require('../shared/mapgen.js');
  const T = C.TILE, conn = { send() {} };

  // --- 1) LA CELLA. Piccola, senza nemici, senza casse: c'e' una faglia e basta ---
  const pm = MapGen.generatePrologo(7);
  assert(pm.w <= 26 && pm.h <= 20, 'la stanza e piccola (' + pm.w + 'x' + pm.h + ')');
  assert(pm.prologo === 1 && pm.lit === 1, 'si dichiara prologo, e il buio lo fanno le sorgenti');
  assert(pm.enemySpawns.length === 0 && pm.crateSpawns.length === 0, 'niente nemici e niente casse: non c e altro da fare');
  assert(!!pm.portale && !!pm.muri, 'ha il portale e il tipo dei suoi muri');
  // v2.8 — E' UNA STANZA, NON UNA CELLA. Il testo dice "perche' si e' aperto un portale nella mia
  // stanza": se attorno c'e' roccia viva, quella frase non sta in piedi. Muri di conci, assi per terra.
  assert(Array.from(pm.muri).some(t => t === 2), 'i muri sono conci: e una casa, non una grotta');
  assert((pm.floors || []).some(f => f.kind === 'legno'), 'e per terra ci sono le assi');
  assert(pm.props.some(q => q.type === 'letto'), 'c e il letto da cui ti sei alzato');
  // ci si cammina: dalla partenza si raggiunge la faglia
  {
    const isFloor = (x, y) => pm.grid[y * pm.w + x] !== C.T_WALL;
    const seen = new Set(), q = [[(pm.spawn.x / T) | 0, (pm.spawn.y / T) | 0]];
    while (q.length) { const [x, y] = q.pop(), k = y * pm.w + x;
      if (seen.has(k) || x < 0 || y < 0 || x >= pm.w || y >= pm.h || !isFloor(x, y)) continue;
      seen.add(k); q.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]); }
    assert(seen.has(Math.floor(pm.portale.y) * pm.w + Math.floor(pm.portale.x)), 'dal giaciglio si arriva alla faglia a piedi');
    assert(seen.size > 100, 'e c e spazio per girarci attorno (' + seen.size + ' tessere)');
  }

  // --- 2) IL GIRO INTERO: risveglio -> villaggio -> oracolo -> ondata 1 ---
  const r = new Room('sto1'); const p = r.addPlayer('a', conn, 'A', 'paladino');
  avviaConStoria(r);
  assert(r.phase === C.PHASE_PROLOGO, 'la partita comincia col risveglio, non con un ondata');
  assert(r.wave === 0, 'e il risveglio non consuma un numero d ondata');
  assert(!!r.faglia, 'la faglia e aperta');
  assert(r.storia && r.storia.scena === 'prologo' && r.storia.riga === 0, 'e la voce ha cominciato a parlare');
  assert(r.missione === 'faglia', 'la missione dice cosa fare');
  assert(r.monsters.length === 0 && r.crates.length === 0, 'nella cella non c e niente da combattere ne da aprire');
  // si scorre il dialogo
  const nP = Storia.prologo.righe.length;
  for (let i = 0; i < nP; i++) r.avanzaStoria('a', false);
  assert(r.storia === null, 'finite le righe, la voce tace');
  // si attraversa
  p.x = r.faglia.x; p.y = r.faglia.y; r.update(1 / C.TICK_RATE);
  assert(r.phase === C.PHASE_MARKET, 'attraversando si arriva al villaggio');
  assert(r.wave === 0, 'che e ancora l ondata zero: non si e combattuto niente');
  assert(r.missione === 'oracolo', 'e la missione cambia: trova l’oracolo');
  assert(r.storia && r.storia.scena === 'arrivo', 'con le righe di benvenuto');
  for (let i = 0; i < Storia.arrivo.righe.length; i++) r.avanzaStoria('a', false);

  // --- 3) L’ORACOLO: parla avvicinandosi, e una volta sola ---
  const sh = r.map.village.npcs.find(n => n.kind === 'oracolo');
  assert(!!sh, 'nel villaggio c e l’oracolo');
  p.x = sh.x + 40; p.y = sh.y; r.update(1 / C.TICK_RATE);
  assert(r.storia && r.storia.scena === 'oracolo', 'avvicinandosi parte il discorso');
  assert(r.storia.n === Storia.oracolo.righe.length, 'tutte le righe del discorso (' + r.storia.n + ')');
  const tutto = Storia.oracolo.righe.map(q => q.t).join(' ');
  // ==========================================================================================
  // v2.20.2 — COSA DEVE RESTARE NEL DISCORSO, dopo la riscrittura di Paolo
  // ==========================================================================================
  // Le tre righe che c'erano qui chiedevano al discorso di NOMINARE il boss, di dire «venti» e di
  // spiegare che i poteri sono doni di un Dio. Il discorso nuovo non fa piu' nessuna delle tre, e non
  // per distrazione: non spiega piu' niente: chiede all'avatar se ha scelto lui, e lascia che sia il
  // silenzio dell'avatar a dirlo. Quindi il test non chiede piu' quelle parole — chiede i due FATTI
  // che, se sparissero, lascerebbero venti ondate senza perche'.
  //
  // 1. QUALCUNO GUARDA, ADESSO, e l'avatar e' il suo strumento.
  assert(/osserv/.test(tutto), 'il discorso dice che qualcuno ci osserva');
  assert(/adesso|in questo istante/.test(tutto), 'e che lo sta facendo ADESSO, non in una profezia');
  assert(/strumento/.test(tutto), 'e che l avatar e il suo strumento');
  // 2. IL CICLO: si muore, si ricomincia, e non sei il primo. E' quello che spiega la morte.
  assert(/Non sei il primo/.test(tutto), 'e che non sei il primo a provarci');
  assert(/gi\u00e0 successo|Molte volte|tornati all\u2019inizio/.test(tutto), 'e che tutto questo e gia successo');
  // e il nome del boss e le venti discese non sono spariti dal gioco: si sono spostati dove servono
  // davvero, cioe' nel riquadro della missione. Se un giorno sparissero anche da li', il giocatore non
  // saprebbe piu' ne' dove sta andando ne' per quanto.
  const miss = Storia.missioni.discesa;
  assert(miss && miss.t.indexOf('AZ') >= 0, 'il boss lo nomina la missione');
  assert(miss && /[Vv]enti/.test(miss.d), 'ed e la missione a dire quante volte si scende');
  // ed e' un DIALOGO: parlano in due, se no e' una conferenza
  const diTu = Storia.oracolo.righe.filter(q => q.chi === 'tu').length;
  assert(diTu >= 4, 'e l avatar risponde (' + diTu + ' battute sue): e un dialogo, non un monologo');
  // il numero di righe si prende PRIMA del giro: all'ultima `storia` diventa null, e una condizione
  // che rilegge r.storia.n a ogni giro esplode sull'ultima iterazione.
  { const n = r.storia.n; for (let i = 0; i < n; i++) r.avanzaStoria('a', false); }
  assert(r.storia === null, 'finito il discorso');
  assert(r.missione === 'discesa', 'e la missione diventa la discesa');
  // tornandoci non ricomincia da capo: v2.9 — dice le sue quattro righe di congedo (`oracoloAncora`), che
  // e' una scena come le altre e non piu' una riga sola sparata a un giocatore solo.
  p._nearOra = false; p.x = sh.x + 400; r.update(1 / C.TICK_RATE);
  p.x = sh.x + 40; r.update(1 / C.TICK_RATE);
  assert(r.storia && r.storia.scena === 'oracoloAncora', 'e tornandoci non lo ripete: dice il congedo');
  assert(r.storia.n === Storia.oracoloAncora.righe.length && r.storia.n < Storia.oracolo.righe.length,
    'ed e piu corto del discorso (' + r.storia.n + ' righe contro ' + Storia.oracolo.righe.length + ')');
  { const n = r.storia.n; for (let i = 0; i < n; i++) r.avanzaStoria('a', false); }
  assert(r.storia === null && r.missione === 'discesa', 'finito il congedo la missione resta la discesa');

  // v2.16 — passare il riepilogo d'apertura scegliendo la prima attiva. Serve piu' volte qui sotto.
  const scendi = (rr, pid, pp) => {
    if (rr.phase !== C.PHASE_SHOP) return;
    if (rr._scelteInCoda(pp)) { rr.offerBoon(pp); if (pp.boonOffer && pp.boonOffer.length) rr.pickBoon(pid, pp.boonOffer[0]); }
    rr.shopReady(pid);
    for (let i = 0; i < 6 && rr.phase === C.PHASE_SHOP; i++) rr.update(1 / C.TICK_RATE);
  };

  // --- 4) DAL VILLAGGIO D'APERTURA SI PASSA DAL RIEPILOGO ---
  // v2.16 — prima si scendeva dritti; la faglia porta alla schermata di fine livello.
  // v2.18 — e li' NON si sceglie piu' la prima attiva: la FIRMA si riceve, non si sceglie. Questo
  // personaggio l'ha gia' in mano prima di arrivare al portale, quindi la coda e' vuota e il pulsante
  // funziona subito. L'unica classe che qui trova ancora una scelta e' il MAGO, con la sua scuola — ed
  // e' provato qui sotto, perche' e' l'unico blocco rimasto sull'uscita dal villaggio.
  p.x = r.faglia.x; p.y = r.faglia.y; r.update(1 / C.TICK_RATE);
  // v2.18 — SENZA SCELTE IN SOSPESO SI SCENDE DRITTI. Il riepilogo al livello 1 esisteva per una ragione
  // sola: costringere a scegliere la prima attiva prima di entrare. Adesso la firma si riceve, la coda e'
  // vuota, e fermare il giocatore davanti a una schermata che non chiede niente sarebbe un ostacolo e
  // basta. Il MAGO, che la scuola la sceglie ancora, passa invece dal riepilogo — ed e' provato sopra.
  assert(!!p.abil[0], 'la firma di classe e gia in mano, senza averla scelta (' + p.abil[0] + ')');
  assert((p.abilDovute || []).length === 0, 'quindi non c e nessuna scelta in sospeso');
  assert(r.phase === C.PHASE_COMBAT || r.phase === C.PHASE_BOSS || r.phase === C.PHASE_SHOP,
    'e la faglia del villaggio porta in campo senza fermarsi (' + r.phase + ')');
  r.shopReady('a');
  for (let i = 0; i < 6 && r.phase === C.PHASE_SHOP; i++) r.update(1 / C.TICK_RATE);
  assert(r.phase === C.PHASE_COMBAT || r.phase === C.PHASE_BOSS, 'e adesso si va in campo (' + r.phase + ')');
  assert(r.wave === 1, 'all ondata 1 (' + r.wave + ')');
  assert(r.pending > 0, 'e i nemici stanno arrivando (' + r.pending + ')');

  // --- 4b) v2.8 — E SI SCENDE IN UNA GROTTA, NON NEL VILLAGGIO ---
  // IL BUG. Dal villaggio d'apertura si finiva all'ondata 1 *sulla mappa del villaggio*: `nextWave()`
  // rigenerava solo `if (this.wave > 1 && (... || this._forceNewMap))`, quindi la bandiera "rigenera"
  // era chiusa dentro un controllo che all'ondata 1 e' falso. Finche' all'ondata 1 ci si arrivava solo
  // da startGame (che la mappa se l'era gia' fatta) non si vedeva. Risultato: dodici mostri piantati
  // addosso al giocatore in mezzo alle botteghe, su una mappa con ZERO posti dove farli comparire.
  assert(!r.map.market, 'e si combatte in una grotta, non nel villaggio');
  assert(r.map.w !== 60 || r.map.h !== 46, 'la mappa e stata rigenerata (' + r.map.w + 'x' + r.map.h + ')');
  assert((r.map.enemySpawns || []).length > 50, 'e ha i suoi posti dove far comparire i nemici (' + (r.map.enemySpawns || []).length + ')');

  // --- 4c) v2.8 — MENTRE PARLA QUALCUNO NON CI SI MUOVE ---
  // Il blocco sta sul SERVER: il client puo' anche smettere di mandare i comandi, ma chi decide dove sta
  // un giocatore e' il server, e un blocco che vale solo di la' non e' un blocco.
  {
    const rb = new Room('sto1b'); const pb = rb.addPlayer('a', conn, 'A', 'arciere');
    avviaConStoria(rb);
    const x0 = pb.x, y0 = pb.y;
    rb.setInput('a', { mx: 1, my: 1, shoot: true, dash: true });
    for (let i = 0; i < C.TICK_RATE; i++) rb.update(1 / C.TICK_RATE);
    assert(Math.hypot(pb.x - x0, pb.y - y0) < 1, 'mentre parla non ci si sposta di un pixel');
    const n2 = rb.storia.n; for (let i = 0; i < n2; i++) rb.avanzaStoria('a', false);
    const x1 = pb.x;
    rb.setInput('a', { mx: 1, my: 0 });
    for (let i = 0; i < C.TICK_RATE; i++) rb.update(1 / C.TICK_RATE);
    assert(Math.abs(pb.x - x1) > 100, 'e finito il dialogo si torna a camminare (' + Math.round(Math.abs(pb.x - x1)) + ' px)');
  }

  // --- 5) SALTARE SALTA LA SCENA, NON LA PARTITA ---
  // E' l'errore facile: "salta" che salta anche quello che doveva succedere dopo, e ci si ritrova
  // senza missione o senza villaggio. Qui si rifa' il giro premendo sempre Esc.
  const r2 = new Room('sto2'); const p2 = r2.addPlayer('a', conn, 'A', 'arciere');
  avviaConStoria(r2);
  r2.avanzaStoria('a', true);
  assert(r2.storia === null && r2.phase === C.PHASE_PROLOGO, 'saltando, la voce tace ma si resta nella cella');
  assert(r2.missione === 'faglia', 'e la missione resta');
  p2.x = r2.faglia.x; p2.y = r2.faglia.y; r2.update(1 / C.TICK_RATE);
  assert(r2.phase === C.PHASE_MARKET && r2.missione === 'oracolo', 'si arriva al villaggio lo stesso');
  r2.avanzaStoria('a', true);
  const sh2 = r2.map.village.npcs.find(n => n.kind === 'oracolo');
  p2.x = sh2.x + 40; p2.y = sh2.y; r2.update(1 / C.TICK_RATE);
  r2.avanzaStoria('a', true);
  assert(r2.missione === 'discesa', 'e saltando il discorso la missione cambia lo stesso');
  p2.x = r2.faglia.x; p2.y = r2.faglia.y; r2.update(1 / C.TICK_RATE);
  scendi(r2, 'a', p2);
  assert(r2.wave === 1, 'e si scende lo stesso all ondata 1');
  // v2.8 — e chi esce SENZA nemmeno parlargli non resta con "trova l’oracolo" appeso per venti ondate
  {
    const r6 = new Room('sto6'); const p6 = r6.addPlayer('a', conn, 'A', 'mago');
    avviaConStoria(r6); r6.avanzaStoria('a', true);
    p6.x = r6.faglia.x; p6.y = r6.faglia.y; r6.update(1 / C.TICK_RATE);
    r6.avanzaStoria('a', true);
    assert(r6.missione === 'oracolo', 'appena arrivato la missione e trovare l’oracolo');
    p6.x = r6.faglia.x; p6.y = r6.faglia.y; r6.update(1 / C.TICK_RATE);
    scendi(r6, 'a', p6);
    assert(r6.wave === 1 && r6.missione === 'discesa', 'ma uscendo senza parlargli diventa comunque la discesa');
  }

  // --- 6) IN DUE: il dialogo lo fa scorrere CHI COMANDA ---
  const r3 = new Room('sto3'); r3.addPlayer('a', conn, 'A', 'paladino'); r3.addPlayer('b', conn, 'B', 'mago');
  avviaConStoria(r3);
  assert(r3.capo && r3.capo.id === 'a', 'comanda chi e arrivato per primo');
  const riga0 = r3.storia.riga;
  r3.avanzaStoria('b', false);
  assert(r3.storia.riga === riga0, 'il secondo preme e non succede niente: sta leggendo');
  r3.avanzaStoria('a', false);
  assert(r3.storia.riga === riga0 + 1, 'il capo preme e la riga scorre');
  // e se il capo se ne va, comanda il successivo
  r3.players.get('a').connected = false;
  assert(r3.capo && r3.capo.id === 'b', 'se il capo si disconnette comanda il successivo');

  // --- 7) LA RIGA INVECCHIA DA SOLA: chi non preme niente non resta bloccato ---
  const r4 = new Room('sto4'); r4.addPlayer('a', conn, 'A', 'arciere');
  avviaConStoria(r4);
  const r0 = r4.storia.riga;
  for (let i = 0; i < Math.ceil((C.STORIA_RIGA + 0.5) * C.TICK_RATE); i++) r4.update(1 / C.TICK_RATE);
  assert(!r4.storia || r4.storia.riga > r0, 'senza premere niente la riga passa da sola');

  // --- 8) LE PROVE non passano dal prologo: chi sceglie un ondata dal pannello vuole quell ondata ---
  const r5 = new Room('sto5'); r5.addPlayer('a', conn, 'A', 'mago');
  avviaConStoria(r5, 7);
  assert(r5.phase !== C.PHASE_PROLOGO && r5.wave === 7, 'la prova parte dall ondata scelta (' + r5.wave + ')');

  // --- 9) IL TESTO: non e' codice, ma ha comunque delle regole ---
  // v2.8 — ogni riga dice CHI parla. La voce del risveglio ha `chi: ''` e non e' una dimenticanza: e'
  // l’oracolo, e il giocatore lo scopre solo quando gli parla — per questo non ha nome ne ritratto.
  for (const sc of ['prologo', 'arrivo', 'oracolo', 'oracoloAncora', 'guardia1', 'guardia2', 'guardia3', 'finale']) {
    assert(Array.isArray(Storia[sc].righe) && Storia[sc].righe.length > 0, 'la scena ' + sc + ' ha delle righe');
    for (const q of Storia[sc].righe) {
      assert(typeof q.t === 'string' && q.t.length > 0, 'ogni riga di ' + sc + ' ha un testo');
      assert(['tu', 'oracolo', 'guardia', 'nota', ''].indexOf(q.chi) >= 0, 'e dice chi parla (' + sc + ': "' + q.chi + '")');
    }
  }
  assert(Storia.prologo.righe.some(q => q.chi === ''), 'nel risveglio parla una voce senza volto');
  assert(!Storia.prologo.righe.some(q => q.chi === 'oracolo'), 'e non si presenta: e lui, ma non si sa ancora');
  assert(Storia.arrivo.righe.every(q => q.chi === ''), 'e al villaggio e ancora una voce');
  const lunghe = [].concat(Storia.prologo.righe, Storia.arrivo.righe, Storia.oracolo.righe).map(q => q.t).filter(t => t.length > 130);
  assert(lunghe.length === 0, 'e nessuna riga e un paragrafo: si leggono a schermo, non su carta (' + lunghe.length + ' troppo lunghe)');
  for (const k in Storia.missioni) { const m = Storia.missioni[k];
    assert(m.t && m.t.length <= 34, 'la missione ' + k + ' sta nel riquadro (' + m.t.length + ' caratteri)'); }
  // v2.9 — LE PAUSE. Sono le didascalie del copione diventate silenzio. Se sparissero il discorso
  // continuerebbe a funzionare ma le tre rivelazioni arriverebbero tutte con lo stesso passo.
  const pause = Storia.oracolo.righe.filter(q => q.p).length;
  assert(pause >= 5, 'il discorso respira: ' + pause + ' righe aspettano prima di scriversi');
  // v2.20.2 — LE DIDASCALIE ADESSO SI VEDONO, per scelta di Paolo: *«aggiungi anche le scritte tra
  // parentesi, aiutano a dare profondita' al dialogo»*. Quindi il controllo si gira: una riga fra
  // parentesi e' ammessa, ma DEVE essere marcata `chi: 'nota'` — se arriva come battuta di qualcuno, il
  // client le mette il ritratto e il nome accanto, e una didascalia con la faccia dell'oracolo che dice
  // «(L'Oracolo guarda verso lo schermo)» e' esattamente il pasticcio che questo test esiste per evitare.
  for (const sc of ['prologo', 'arrivo', 'oracolo', 'oracoloAncora'])
    for (const q of Storia[sc].righe)
      assert(!/^\(/.test(q.t) || q.chi === 'nota', sc + ': la riga fra parentesi e una didascalia, non una battuta (' + q.t + ')');
  assert(Storia.oracolo.righe.some(q => q.chi === 'nota'), 'e il discorso dell oracolo ne ha almeno una');
  ok('la storia v2.9 verificata');
}


// ============================================================================================
// TEST 71 — v2.13: LA SCHERMATA UNICA. Il baule, le derivate, e l'equipaggiare senza fabbro.
// ============================================================================================
// Cosa difende: che il pannello di fine ondata porti al client TUTTO cio' che la schermata nuova
// disegna, e che la porta per equipaggiare dal baule non diventi per sbaglio un negozio aperto ovunque.
function testSchermataUnica() {
  console.log('\n[TEST 71] v2.13 — la schermata di fine ondata: baule, derivate, equipaggiare senza fabbro');
  const Gear = require('../shared/gear.js');
  const conn = { send() {} };
  const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } };
  const room = new Room('v213'); const p = room.addPlayer('a', cap, 'A', 'paladino'); room.startGame();

  // --- 1) il pannello porta heroId, derivate e baule ---
  room.wave = 3; room.phase = C.PHASE_SHOP;
  sent.length = 0; room.offerShop(p);
  const m = sent.find(x => x.t === C.MSG.OFFER_SHOP);
  assert(!!m, 'il pannello arriva al client');
  assert(m.heroId === 'paladino', 'e porta la classe (serve al ritratto per sapere chi disegnare)');
  const d = m.inv && m.inv.derivate;
  assert(!!d && typeof d.danno === 'number' && typeof d.armatura === 'number' && typeof d.cadenza === 'number' && typeof d.passo === 'number',
    'porta le quattro derivate: ' + JSON.stringify(d));
  // le derivate devono essere quelle VERE, non una ricostruzione: si confrontano col motore
  assert(d.danno === Math.round(room.effDamage(p)), 'il danno e quello che usa il motore');
  assert(Math.abs(d.cadenza - 1 / room.effFireDelay(p)) < 0.02, 'e la cadenza pure');
  // v2.18.1 — le caselle sono QUATTRO e si chiamano come stanno attorno al personaggio: due mani,
  // armatura, calzature. Non tutte sono piene (il guerriero non ha calzature), quindi si controlla che
  // quelle piene portino l'ID — che e' cio' che serve al ritratto per non disegnare un nudo.
  assert(m.inv.gear.length === 4 && m.inv.gear.map(g => g.slot).join(',') === 'manoDx,manoSx,armor,boots',
    'le caselle sono le quattro attorno al personaggio');
  assert(m.inv.gear.filter(g => g.nome !== '—').every(g => g.id), 'ogni casella piena porta l ID del pezzo');
  assert(Array.isArray(m.inv.inventario) && m.inv.inventario.length === 3, 'l inventario arriva diviso per slot');
  const tuttiAddosso = m.inv.inventario.every(sl => sl.pezzi.every(x => x.addosso));
  assert(tuttiAddosso, 'appena nati nell inventario c e solo cio che si ha addosso');

  // --- 2) si equipaggia dal baule, e non costa niente ---
  const spadone = Gear.itemsOfRank('paladino', 'weapon', 2).find(i => i.carattere === 'pesante');
  p.coins = 500; room.enterMarket(); p.x = room.gearMerchant.x; p.y = room.gearMerchant.y;
  room.buyGear('a', spadone.id);
  assert(!!p.owned[spadone.id] && p.coins === 500 - spadone.cost, 'si compra dal fabbro, come sempre');
  assert(p.gear.manoDx !== spadone.id, 'ma non va in mano da solo: comprare non e impugnare');
  const partenza = Gear.startingGear('paladino');
  room.phase = C.PHASE_SHOP;
  room.equipaggia('a', spadone.id, 'manoDx');
  assert(p.gear.manoDx === spadone.id, 'e lo si impugna dall inventario, scegliendo la mano');
  const soldi = p.coins;
  room.equipaggia('a', partenza.manoDx, 'manoDx');
  assert(p.gear.manoDx === partenza.manoDx, 'e dall inventario ci si rimette in mano il vecchio');
  assert(p.coins === soldi, 'senza spendere niente: e gia tuo');
  // e il pannello si rimanda, se no la schermata resterebbe a mostrare il pezzo di prima
  sent.length = 0; room.equipaggia('a', spadone.id, 'manoDx');
  assert(sent.some(x => x.t === C.MSG.OFFER_SHOP), 'e il pannello si rimanda, con l inventario aggiornato');

  // --- 3) LE TRE COSE CHE QUESTA PORTA NON DEVE FARE ---
  // (a) non compra: se comprasse, sarebbe un negozio aperto ovunque e il fabbro non servirebbe piu'
  const mai = Gear.itemsOfRank('paladino', 'armor', 5).find(i => i.carattere === 'pesante');
  const c0 = p.coins, g0 = p.gear.armor;
  room.equipaggia('a', mai.id);
  assert(p.gear.armor === g0 && p.coins === c0, 'dall inventario NON si prende cio che non e tuo');
  // (b) non in combattimento: cambiarsi l'armatura mentre arrivano addosso non e un gesto
  room.phase = C.PHASE_COMBAT;
  room.equipaggia('a', partenza.manoDx, 'manoDx');
  assert(p.gear.manoDx === spadone.id, 'in combattimento non ci si cambia');
  room.phase = C.PHASE_SHOP;
  // (c) niente roba di un'altra classe, nemmeno se te la scrivi in owned a mano
  const armaMago = Gear.itemsFor('mago', 'weapon')[0];
  p.owned[armaMago.id] = 1;
  room.equipaggia('a', armaMago.id, 'manoDx');
  assert(p.gear.manoDx === spadone.id, 'ne roba di un altra impalcatura');
  delete p.owned[armaMago.id];

  // --- 3bis) v2.13.1 — IL PROFILO DELLA CLASSE, e la promessa che NON conta ---
  // Le quattro statistiche partivano da zero per tutti: un guerriero e un mago appena nati mostravano
  // gli stessi quattro zeri. Adesso portano il profilo della classe. Ma il profilo e' SOLO da leggere, e
  // questo blocco esiste per tenerlo tale: il giorno che qualcuno lo fa entrare in un calcolo senza
  // dirlo, qui si rompe qualcosa.
  const Her = require('../shared/heroes.js');
  sent.length = 0; room.offerShop(p);
  const pan = sent.find(x => x.t === C.MSG.OFFER_SHOP);
  assert(pan.stats.every(st => typeof st.base === 'number' && st.tetto === Her.STAT_MAX), 'ogni statistica porta il suo valore di base e il tetto');
  // v2.18 — LA MATRICE E' 7 x 5. Il paladino e' una classe a DUE statistiche (Forza per le armi,
  // Carisma per le magie) e per questo non ha nessun picco: e' la difficolta' voluta.
  assert(pan.stats.length === 5, 'il pannello mostra cinque statistiche (' + pan.stats.length + ')');
  assert(pan.stats.find(st => st.id === 'st_for').base === 6, 'il paladino parte con Forza 6');
  assert(pan.stats.find(st => st.id === 'st_car').base === 6, 'e Carisma 6: divide i punti su due fronti');
  assert(Her.STAT_BASE.mago.st_int === 10 && Her.STAT_BASE.mago.st_for === 1, 'il mago e tutto Intelligenza e niente Forza');
  assert(Her.STAT_BASE.arciere.st_des === 10, 'e l arciere ha la Destrezza al picco');
  for (const h of Heroes.ORDER) {
    const b = Her.STAT_BASE[h];
    const tot = Object.values(b).reduce((a, x) => a + x, 0);
    // il warlock somma 23 invece di 22: segnalato a Paolo, che lo lascia cosi'. Non e' un baco.
    assert(tot === 22 || (h === 'warlock' && tot === 23), h + ': i punti di partenza sono 22 (' + tot + ')');
    assert(Math.max(...Object.values(b)) <= 10, h + ': nessun picco sopra 10');
  }
  // IL TETTO NON SI TOCCA. Con i picchi a 10 il conto di prima (8 + 12 = 20) non torna piu': chi parte
  // da 10 e spende tutti i 12 punti arriverebbe a 22 e viene tagliato a 20. Parole di Paolo: *«lascia
  // cosi' anche il tetto, so cosa faccio»*. Questo test afferma la decisione, non l'aritmetica.
  assert(Her.STAT_MAX === 20, 'il tetto resta 20 anche con i picchi a 10: e una decisione, non un conto');
  // --- v2.15 — IL PROFILO MORDE, E SI FERMA DOVE DEVE ---
  // Fino alla v2.14 qui si controllava il contrario: che il profilo non entrasse in nessun calcolo. Ora
  // conta, ma dentro un perimetro stretto, e il perimetro e' la cosa che va difesa: PV, riduzione, passo
  // e rinculo SI', danno e cadenza NO. Il motivo e' misurato e sta scritto in shared/heroes.js — ogni
  // classe ha il valore piu' alto proprio nella statistica della sua scuola di danno, quindi lasciarlo
  // contare sul danno rovescerebbe la parita' fra le tre (79/78/78 -> 93/105/102, col mago in testa).
  {
    const salvato = JSON.stringify(Her.STAT_BASE);
    // v2.18 — il centro e' 4,4 (22 punti su CINQUE statistiche) e non piu' 5,5. Col centro vecchio ogni
    // classe sarebbe risultata sotto la media e il profilo avrebbe tolto PV a chiunque — l'esatto
    // contrario del suo mestiere. Il confronto qui e' fra chi sta sopra (paladino, COS 7) e chi sta
    // sotto (assassino, COS 4): il mago adesso ha COS 5 ed e' appena sopra il centro.
    assert(Math.abs(Her.STAT_CENTRO - 4.4) < 1e-9, 'il centro del profilo e 4,4: la media di 22 su cinque caselle');
    // v2.19.8 — l'assassino ha COS 6 (Paolo: *«subisce troppi danni»*): nessuna delle sette sta piu' sotto
    // il centro in Costituzione. Il «sotto» si prova con un profilo messo a mano e poi rimesso a posto.
    const cosAss = Her.STAT_BASE.assassino.st_cos;
    Her.STAT_BASE.assassino.st_cos = 3;
    assert(Her.profiloPunti('paladino', 'st_cos') > 0 && Her.profiloPunti('assassino', 'st_cos') < 0,
      'il profilo conta lo SCARTO dal centro: sopra si guadagna, sotto si perde');
    const r1 = new Room('v215a'); const g = r1.addPlayer('g', conn, 'G', 'paladino'); r1.startGame();
    const d0 = r1.effDamage(g), cad0 = r1.effFireDelay(g), hp0 = r1.effMaxHp(g), vel0 = r1.effSpeed(g);
    // (a) chi sta sopra il centro in Costituzione nasce piu' duro dei suoi PV nudi, chi sta sotto piu'
    // fragile. Il confronto e' col nudo PIU' l'equipaggiamento di partenza, se no passerebbe da solo.
    assert(hp0 > g.maxHp + g.gearBonus.maxHpFlat, 'il guerriero (COS 8) nasce piu duro: ' + hp0 + ' PV');
    const r2 = new Room('v215b'); const m = r2.addPlayer('m', conn, 'M', 'assassino'); r2.startGame();
    assert(r2.effMaxHp(m) < m.maxHp + m.gearBonus.maxHpFlat, 'e chi sta sotto il centro (COS 3, messo a mano) e piu fragile: ' + r2.effMaxHp(m) + ' PV');
    Her.STAT_BASE.assassino.st_cos = cosAss;
    assert(Her.STAT_BASE.assassino.st_for === 4 && Her.STAT_BASE.assassino.st_cos === 6, 'l assassino ha Forza 4 e Costituzione 6');
    // (b) ma la riduzione non va mai sotto zero: il motore la ignorerebbe (`if (dr > 0)`) e il pannello
    // mostrerebbe un'armatura negativa che non esiste. Chi sta sotto il centro paga in PV, non in bugie.
    for (const h of Heroes.ORDER) {
      const rr = new Room('v215' + h); const q = rr.addPlayer('q', conn, 'Q', h); rr.startGame();
      assert((q.stats.dmgReduce || 0) >= 0, h + ': la riduzione del profilo non e mai negativa');
      assert(rr.effMaxHp(q) > 0 && rr.effSpeed(q) > 0, h + ': PV e passo restano numeri sensati');
    }
    // (c) LA PROMESSA CHE RESTA. Si sposta il profilo a un valore assurdo e si ricalcola: PV e passo
    // devono muoversi (se no il profilo non morde piu' e la v2.15 e' tornata indietro senza dirlo),
    // danno e cadenza NO (se no qualcuno ha rimesso schoolDmg/schoolRate dentro `applicaProfilo`).
    Her.STAT_BASE.paladino = { st_for: 99, st_cos: 99, st_des: 99, st_int: 99, st_car: 99 };
    r1._recomputeBoons(g);
    assert(r1.effMaxHp(g) > hp0 && r1.effSpeed(g) > vel0, 'spostare il profilo muove PV e passo');
    assert(r1.effDamage(g) === d0 && r1.effFireDelay(g) === cad0,
      'ma NON danno ne cadenza: la parita fra le tre classi non la tocca il profilo');
    Object.assign(Her.STAT_BASE, JSON.parse(salvato));
    r1._recomputeBoons(g);
    assert(r1.effMaxHp(g) === hp0, 'e rimettendo il profilo a posto si torna esattamente dov era');
  }

  // --- 4) il riepilogo dell'ondata porta danni e combo ---
  p.damageDealt = 1234; p.comboBest = 9;
  sent.length = 0; room.inviaRiepilogo(p);
  const r = sent.find(x => x.t === C.MSG.WAVE_STATS);
  assert(r && r.danni === 1234 && r.combo === 9, 'il riepilogo porta danni e combo migliore');
  ok('la schermata unica verificata');
}

// ============================================================================================
// v2.19 — LE TRE BOTTEGHE E L'EQUIPAGGIAMENTO MISTO
// ============================================================================================
// Quello che questo test difende non e' «ci sono due negozi nuovi» (lo dice gia' il TEST 28): e' la
// REGOLA. Con un fabbro solo la domanda «posso comprare questo?» aveva una risposta sola — «e' del
// tuo corpo?» — e per tre classi su sette era la risposta sbagliata. Adesso la risposta e' la tabella
// del documento, e qui si controlla riga per riga che sia quella.
function testV219() {
  console.log('\n[TEST 72] v2.19 — tre botteghe, e chi puo comprare cosa (equipaggiamento misto)');
  const Gear = require('../shared/gear.js');
  const Heroes = require('../shared/heroes.js');
  const CLASSI = ['barbaro', 'paladino', 'maestro', 'assassino', 'arciere', 'mago', 'warlock'];

  // --- 1) LE TRE BOTTEGHE ESISTONO, e il server le aggancia tutte ---
  const room = new Room('v219'); const p = room.addPlayer('b', { send() {} }, 'B', 'warlock'); room.startGame();
  room.wave = 3; room.phase = C.PHASE_SHOP; room.vaiAlVillaggio('b');
  assert((room.gearMerchants || []).length === 3, 'il server aggancia tre banchi (' + (room.gearMerchants || []).length + ')');
  assert(new Set(room.gearMerchants.map(b => b.cat)).size === 3, 'e i tre cataloghi sono distinti');
  assert(MU.dist(room.gearMerchant.x, room.gearMerchant.y, room.gearMerchants[0].x, room.gearMerchants[0].y) < 1,
    'il vecchio `gearMerchant` resta il fabbro: chi lo legge non si accorge di niente');
  // due banchi non si sovrappongono mai: «quello piu' vicino» non e' mai una scelta ambigua
  for (let i = 0; i < 3; i++) for (let j = i + 1; j < 3; j++) {
    const a = room.gearMerchants[i], b = room.gearMerchants[j];
    assert(MU.dist(a.x, a.y, b.x, b.y) > (C.MARKET_MERCH_RANGE + 12) * 2, 'i banchi ' + a.cat + ' e ' + b.cat + ' non si sovrappongono');
  }

  // --- 2) LA TABELLA, riga per riga come sta nel documento ---
  // Ogni voce: [classe, slot, catalogo, si puo'?]. Le righe «no» valgono quanto le «si»: una regola
  // che apre e non chiude non e' una regola.
  const T2 = (h, slot, cat) => Gear.itemsBottega(h, cat, slot).length;
  // il barbaro: armi da mischia tutte, armature SOLO leggere (mischia o arco), niente magia
  assert(T2('barbaro', 'weapon', 'guerriero') > 0 && T2('barbaro', 'weapon', 'ladro') === 0 && T2('barbaro', 'weapon', 'mago') === 0,
    'barbaro: armi solo da mischia');
  assert(Gear.itemsBottega('barbaro', 'guerriero', 'armor').every(i => i.rank <= 1 || i.carattere === 'leggera'),
    'barbaro: armature leggere, come dice la sua tabella');
  assert(T2('barbaro', 'armor', 'ladro') > 0, 'e anche quelle di cuoio leggero dell arciera: e il suo equipaggiamento misto');
  // il paladino e il maestro: tutto da mischia e basta
  for (const h of ['paladino', 'maestro']) {
    assert(T2(h, 'weapon', 'guerriero') === 13 && T2(h, 'armor', 'guerriero') === 13 && T2(h, 'shield', 'guerriero') === 13,
      h + ': il catalogo da mischia per intero');
    assert(T2(h, 'weapon', 'ladro') + T2(h, 'weapon', 'mago') + T2(h, 'armor', 'ladro') + T2(h, 'armor', 'mago') === 0,
      h + ': e nient altro, da nessun altro banco');
  }
  // l'assassino: due botteghe, ma niente pesante e niente scudo
  assert(T2('assassino', 'weapon', 'guerriero') > 0 && T2('assassino', 'weapon', 'ladro') > 0,
    'assassino: compra armi dal fabbro E dall arciera');
  for (const sl of ['weapon', 'armor']) for (const cat of ['guerriero', 'ladro'])
    assert(Gear.itemsBottega('assassino', cat, sl).every(i => i.rank <= 1 || i.carattere !== 'pesante'),
      'assassino: niente pesante (' + cat + '/' + sl + ')');
  assert(T2('assassino', 'shield', 'guerriero') === 0, 'assassino: niente scudo');
  // l'arciere: solo l'arciera
  assert(T2('arciere', 'weapon', 'ladro') === 13 && T2('arciere', 'weapon', 'guerriero') === 0 && T2('arciere', 'weapon', 'mago') === 0,
    'arciere: solo archi');
  assert(Gear.slotsBottega('arciere', 'guerriero').length === 0, 'e dal fabbro non ha niente da comprare');
  // il mago: solo l'arcanista
  assert(T2('mago', 'weapon', 'mago') === 13 && T2('mago', 'weapon', 'guerriero') === 0, 'mago: solo bastoni');
  assert(T2('mago', 'shield', 'guerriero') === 0, 'mago: niente scudo');
  // il warlock: tutta la magia piu' le armi LEGGERE da mischia
  assert(T2('warlock', 'weapon', 'mago') === 13, 'warlock: tutto il catalogo arcano');
  assert(T2('warlock', 'weapon', 'guerriero') > 0 &&
    Gear.itemsBottega('warlock', 'guerriero', 'weapon').every(i => i.rank <= 1 || i.carattere === 'leggera'),
    'warlock: e dal fabbro le sole armi leggere');
  assert(T2('warlock', 'weapon', 'ladro') === 0, 'warlock: ma nessun arco');

  // --- 3) NESSUNA CLASSE PARTE CON ADDOSSO QUALCOSA CHE NON POTREBBE PORTARE ---
  // E' il controllo che vale piu' di tutti: una tabella che vieta l'equipaggiamento di partenza
  // lascerebbe il personaggio in uno stato che il resto del gioco non sa ne' disegnare ne' calcolare.
  for (const h of CLASSI) {
    const sg = Gear.startingGear(h);
    for (const k in sg) if (sg[k]) assert(Gear.puoAvere(h, Gear.BY_ID[sg[k]]), h + ': il pezzo di partenza ' + k + ' e ammesso dalla sua tabella');
    // e ogni classe ha almeno una bottega dove comprare: una vetrina vuota per tutti non e' una bottega
    assert(Gear.BOTTEGHE.some(b => Gear.slotsBottega(h, b).length > 0), h + ': ha almeno una bottega sua');
  }

  // --- 3bis) v2.19.1 — L'ARMA DI PARTENZA NON PUO' CONTRADDIRE LA CLASSE ---
  // Il difetto trovato da Paolo: *«l'assassino parte con 2 spade ma lo sparo e' la freccia»*. Causa:
  // la sua famiglia d'arma e' la mischia leggera ma il suo CORPO e' `ladro`, e `startingGear` pescava
  // il grado minimo del corpo — un arco. E' l'unica delle sette in cui i due non coincidono, ed e'
  // per questo che era l'unica a sbagliare. Questo controllo vale per tutte e sette, cosi' il giorno
  // che nasce l'ottava classe il difetto non torna in silenzio.
  for (const h of CLASSI) {
    const classe = (Heroes.HEROES[h] || {}).weapon || {};
    const inMano = Gear.BY_ID[Gear.startingGear(h).manoDx];
    assert(!!inMano, h + ': parte con qualcosa in mano');
    assert(!!inMano.weapon.melee === !!classe.melee,
      h + ': cio con cui parte colpisce come la sua arma di classe (' + classe.name + ' -> ' + inMano.name + ')');
  }
  // e l'assassino in particolare: pugnali veri, scuola `agile`, e NON un arco
  {
    const ra = new Room('v2191'); const pa = ra.addPlayer('x', { send() {} }, 'X', 'assassino'); ra.startGame();
    const w = ra.effWeapon(pa);
    assert(w.melee === true, 'l assassino mena di pugnale, non tira frecce');
    assert(w.school === 'agile', 'e il suo colpo sta nella scuola agile');
    assert(Gear.BY_ID[pa.gear.manoDx].carattere === 'leggera', 'e cio che impugna e leggero, come dice la sua tabella');
    // v2.19.6 — L'ASSASSINO PARTE CON DUE PUGNALI. Nella v2.19.1 la doppia era «da guadagnare»
    // comprando la seconda lama; Paolo ha deciso il contrario: *«l'assassino con 2 pugnali, altrimenti e'
    // troppo svantaggiato»*. E il bonus di classe della doppia leggera deve esserci DAL PRIMO COLPO:
    // questo controllo, scritto al rovescio, passava solo perche' alla partenza i bonus non si
    // calcolavano affatto (vedi il blocco sulla partenza, piu' sotto).
    assert(!!pa.gear.manoSx && pa.gear.manoSx !== pa.gear.manoDx, 'parte con DUE pugnali, due oggetti diversi');
    assert(pa._doppiaLeggera === true, 'e il bonus della doppia leggera c e dal primo colpo');
    assert(Gear.BY_ID[pa.gear.armor].carattere === 'leggera' && Gear.BY_ID[pa.gear.armor].hero === 'guerriero',
      'e addosso ha una corazza leggera da mischia');
    assert((Gear.BY_ID[pa.gear.armor].bonus.dmgReduce || 0) > 0, 'che protegge davvero (gli stracci non riducevano niente)');
    // la coppia si migliora un pugnale alla volta, dal fabbro
    const lama = Gear.itemsBottega('assassino', 'guerriero', 'weapon').find(i => i.rank === 2);
    pa.coins = 100000; ra.wave = 3; ra.phase = C.PHASE_SHOP; ra.vaiAlVillaggio('x');
    alBanco(ra, pa, 'guerriero'); ra.buyGear('x', lama.id); ra.equipaggia('x', lama.id, 'manoSx');
    assert(pa.gear.manoSx === lama.id, 'un pugnale nuovo dal fabbro, impugnato a sinistra');
    assert(pa._doppiaLeggera === true, 'e la doppia leggera resta accesa');
  }

  // --- 3ter) v2.19.6 — LA SECONDA ARMA DA' DANNO, e non dipende dall'ordine delle mani ---
  // Paolo: *«impugnare 2 armi non porta bonus al danno: se uso 2 pugnali non posso fare lo stesso danno,
  // o addirittura meno, di uno solo»*. Tre cose da non perdere piu':
  {
    const armaDps = (room, pl) => room.effDamage(pl) / room.effFireDelay(pl);
    const conArmi = (h, dx, sx) => {
      const rr = new Room('d' + h + dx + sx); const pl = rr.addPlayer('x', { send() {} }, 'X', h); rr.startGame();
      for (const id of [dx, sx]) if (id) pl.owned[id] = 1;
      pl.gear.manoDx = dx || null; pl.gear.manoSx = sx || null; rr._recomputeBoons(pl); rr._recomputeGear(pl);
      return { d: rr.effDamage(pl), dps: armaDps(rr, pl) };
    };
    const P = Gear.ITEMS.filter(i => i.famiglia === 'pugnale' && i.rank === 3);
    const uno = conArmi('assassino', P[0].id, null), due = conArmi('assassino', P[0].id, P[1].id);
    // 1. due armi fanno PIU' di una, e si vede nel numero «danno» del pannello (non solo in cadenza)
    assert(due.d > uno.d * 1.3, 'due pugnali: il DANNO sale davvero (' + Math.round(uno.d) + ' -> ' + Math.round(due.d) + ')');
    assert(due.dps > uno.dps * 1.4, 'e il danno al secondo pure (' + Math.round(uno.dps) + ' -> ' + Math.round(due.dps) + ')');
    // 2. l'ordine delle mani non conta: l'arma principale e' la piu' forte, dovunque sia
    const W = (car, rk) => Gear.itemsOfRank('maestro', 'weapon', rk).find(i => i.carattere === car).id;
    const ab = conArmi('maestro', W('leggera', 3), W('equilibrata', 2)), ba = conArmi('maestro', W('equilibrata', 2), W('leggera', 3));
    assert(Math.abs(ab.dps - ba.dps) < 0.01, 'le stesse due armi fanno lo stesso danno in qualunque mano (' + Math.round(ab.dps) + ' e ' + Math.round(ba.dps) + ')');
    // 3. con due armi non si fa MAI meno che con la migliore delle due da sola
    for (const [h, a, b] of [['maestro', W('leggera', 3), W('pesante', 2)], ['barbaro', W('pesante', 3), W('leggera', 2)], ['assassino', P[0].id, Gear.ITEMS.find(i => i.famiglia === 'pugnale' && i.rank === 2).id]]) {
      const sa = conArmi(h, a, null).dps, sb = conArmi(h, b, null).dps, dd = conArmi(h, a, b).dps;
      assert(dd >= Math.max(sa, sb) - 0.01, h + ': due armi non fanno mai meno della migliore da sola');
    }
    // e l'arma a DUE MANI non riceve la quota della seconda mano: e' un'arma sola
    const pes = conArmi('paladino', W('pesante', 3), null);
    const rq = new Room('dq'); const pq = rq.addPlayer('x', { send() {} }, 'X', 'paladino'); rq.startGame();
    pq.owned[W('pesante', 3)] = 1; pq.gear.manoDx = W('pesante', 3); pq.gear.manoSx = null; rq._recomputeBoons(pq);
    assert(!pq._bonusSeconda, 'l arma a due mani non prende il bonus della seconda mano');
  }

  // --- 3quater) v2.19.6 — I BONUS CI SONO DAL PRIMO COLPO, per tutte e sette le classi ---
  // Alla partenza si ricalcolava l'equipaggiamento ma non i bonus: arciere e mago partivano senza il loro
  // +8% di classe (dalla v2.18), l'assassino senza il 69% del suo danno. Il controllo: il danno alla
  // partenza e' identico a quello dopo un ricalcolo completo.
  for (const h of CLASSI) {
    const rr = new Room('p' + h); const pl = rr.addPlayer('x', { send() {} }, 'X', h); rr.startGame();
    const a = rr.effDamage(pl) / rr.effFireDelay(pl);
    rr._recomputeBoons(pl); rr._recomputeGear(pl);
    const b = rr.effDamage(pl) / rr.effFireDelay(pl);
    assert(Math.abs(a - b) < 0.01, h + ': alla partenza il danno ha gia tutti i suoi bonus (' + Math.round(a) + ' contro ' + Math.round(b) + ')');
  }

  // --- 4) A RUNTIME: si compra dove si deve, e non altrove ---
  p.coins = 100000;
  const bastone = Gear.itemsBottega('warlock', 'mago', 'weapon').find(i => i.rank === 2);
  const sciabola = Gear.itemsBottega('warlock', 'guerriero', 'weapon').find(i => i.rank === 2);
  const spadone = Gear.ITEMS.find(i => i.hero === 'guerriero' && i.slot === 'weapon' && i.rank === 2 && i.carattere === 'pesante');
  alBanco(room, p, 'guerriero');
  room.buyGear('b', bastone.id); assert(!p.owned[bastone.id], 'dal fabbro non si comprano bastoni');
  room.buyGear('b', spadone.id); assert(!p.owned[spadone.id], 'e nemmeno uno spadone: al warlock la tabella concede solo le leggere');
  room.buyGear('b', sciabola.id); assert(!!p.owned[sciabola.id], 'ma la sciabola leggera si: e l equipaggiamento misto che funziona');
  alBanco(room, p, 'mago');
  room.buyGear('b', bastone.id); assert(!!p.owned[bastone.id], 'e il bastone si compra dall arcanista');
  // si rivende SOLO al banco che vende quella roba
  alBanco(room, p, 'mago'); room.phase = C.PHASE_MARKET;
  const soldi0 = p.coins; room.vendiGear('b', sciabola.id);
  assert(p.coins === soldi0 && !!p.owned[sciabola.id], 'l arcanista non ricompra una sciabola');
  alBanco(room, p, 'guerriero'); room.vendiGear('b', sciabola.id);
  assert(p.coins > soldi0 && !p.owned[sciabola.id], 'il fabbro si');

  // --- 4bis) v2.19.1 — IL GRADO SCARSO NON E' MERCE (era una zecca) ---
  // Il buco l'ha aperto l'equipaggiamento misto: una classe vede anche i pezzi scarsi di un catalogo
  // che non e' il suo, quelli costano ZERO e la rivendita ne vale 8. Comprare e rivendere in circolo
  // faceva monete dal nulla. Il controllo resta anche se domani i prezzi cambiano: la regola e'
  // «costo zero = non in vendita», non «questo id».
  {
    const rz = new Room('v2191z'); const pz = rz.addPlayer('z', { send() {} }, 'Z', 'warlock'); rz.startGame();
    rz.wave = 3; rz.phase = C.PHASE_SHOP; rz.vaiAlVillaggio('z');
    alBanco(rz, pz, 'guerriero'); pz.coins = 0; rz.phase = C.PHASE_MARKET;
    const scarso = Gear.itemsFor('paladino', 'weapon').find(i => i.rank === 1);
    assert(scarso.cost === 0, 'il pezzo di grado 1 costa zero');
    for (let g = 0; g < 5; g++) { rz.buyGear('z', scarso.id); rz.vendiGear('z', scarso.id); }
    assert(pz.coins === 0 && !pz.owned[scarso.id], 'comprare e rivendere il grado scarso non fa monete dal nulla');
    // e non si vede nemmeno sul banco, se non e' gia' tuo
    const sz = []; pz.conn = { send(x) { try { sz.push(JSON.parse(x)); } catch (_) {} } };
    rz.offerGear(pz, 1, 'guerriero');
    const ofz = sz.find(m => m.t === C.MSG.OFFER_GEAR);
    const armi = (ofz.slots.find(x => x.slot === 'weapon') || {}).items || [];
    assert(!armi.some(i => i.id === scarso.id), 'e il banco non lo mette nemmeno in vetrina');
    assert(armi.length > 0 && armi.every(i => i.cost > 0), 'in vetrina ci sta solo roba che si compra davvero');
  }

  // --- 5) IL PANNELLO dice DOVE sei, e quando e' vuoto lo dichiara ---
  const sent = []; const cap = { send(x) { try { sent.push(JSON.parse(x)); } catch (_) {} } };
  const arc = room.addPlayer('a', cap, 'A', 'arciere');
  sent.length = 0; room.offerGear(arc, 1, 'ladro');
  const off1 = sent.find(m => m.t === C.MSG.OFFER_GEAR);
  assert(off1 && off1.cat === 'ladro' && off1.kind === 'fletcher' && !off1.vuoto, 'il banco dell arciera si presenta, e ha roba');
  sent.length = 0; room.offerGear(arc, 1, 'mago');
  const off2 = sent.find(m => m.t === C.MSG.OFFER_GEAR);
  assert(off2 && off2.cat === 'mago' && off2.vuoto === 1 && off2.slots.length === 0,
    'e quello dell arcanista si dichiara vuoto invece di aprirsi muto');

  // --- 6) LE MANI, con la tipologia: e' la regola che senza le tre botteghe non poteva sbagliarsi ---
  const M = Heroes.MANI;
  assert(M.assassino.doppiaTipo.join() === 'mischia' && M.mago.doppiaTipo.join() === 'magia',
    'la doppia arma ha una tipologia: mischia per l assassino, magia per il mago');
  for (const h of ['barbaro', 'paladino', 'maestro'])
    assert(M[h].scudoTipo.join() === 'mischia', h + ': lo scudo sta accanto a un arma da mischia');
  // il barbaro resta l'unico con pesante + scudo, e adesso anche con la tipologia di mezzo
  const bg = Gear.startingGear('barbaro');
  const asciaP = Gear.itemsBottega('barbaro', 'guerriero', 'weapon').find(i => i.carattere === 'pesante');
  const scudo = Gear.itemsBottega('barbaro', 'guerriero', 'shield')[0];
  const conAscia = Gear.impugna('barbaro', bg, asciaP.id, 'manoDx').gear;
  assert(!!conAscia && !!Gear.impugna('barbaro', conAscia, scudo.id, 'manoSx').gear,
    'il barbaro tiene ancora arma pesante e scudo insieme');

  // --- 7) E CIO CHE NON E STATO TOCCATO: l inventario resta coerente con la tabella ---
  // la sciabola l'abbiamo rivenduta al punto 5: si ricompra, se no l'inventario e' di una bottega sola
  // e questo controllo non proverebbe niente.
  alBanco(room, p, 'guerriero'); room.buyGear('b', sciabola.id);
  p.conn = cap;            // il warlock era muto: gli si attacca la presa per leggere il suo pannello
  sent.length = 0; room.offerShop(p);
  const pan = sent.find(m => m.t === C.MSG.OFFER_SHOP);
  assert(!!pan && !!pan.inv, 'il pannello del personaggio arriva');
  const tuttiPezzi = [].concat.apply([], (pan.inv.inventario || []).map(sl => sl.pezzi || []));
  assert(tuttiPezzi.every(it => Gear.puoAvere('warlock', Gear.BY_ID[it.id])),
    'e nell inventario non compare niente che la tabella vieti');
  assert(tuttiPezzi.some(it => it.tipo === 'magia') && tuttiPezzi.some(it => it.tipo === 'mischia'),
    'ma ci stanno insieme i pezzi delle due botteghe: e il punto di tutto il lavoro');
  ok('le tre botteghe e l equipaggiamento misto verificati');
}

// ============================================================================================
// v2.19.2 — LE SOGLIE: davanti a una porta non ci sta niente
// ============================================================================================
// Paolo: *«perche' metti oggetti all'ingresso delle case e/o negozi? toglili, rendono ingombrante
// l'entrata, specie da arciere e mago»*. Aveva ragione su cinque stanze su tredici — le due botteghe
// nuove erano le peggiori, con tre mobili ciascuna e uno proprio in mezzo alla soglia.
//
// Il difetto era STRUTTURALE, non di posizionamento: la regola della soglia esisteva solo dentro
// `arredaCasa`, e le botteghe erano arredate a mano una per una senza che nessuno controllasse.
// Questo test misura in DUE modi diversi, e i due servono a cose diverse:
//   1. LA REGOLA — la fascia 1,5 x 2,6 delle case, applicata a tutte le stanze. E' una regola di
//      forma: dice «qui non si mette niente», ed e' quella che il generatore fa rispettare.
//   2. IL FATTO — un flood fill a passo fine, col corpo del giocatore vero contro gli ingombri veri,
//      dalla strada fino al banco. Perche' una regola rispettata non dimostra ancora che si passi:
//      misurando a occhio con i centri delle tessere avevo creduto bloccata l'erboristeria, che
//      invece era solo stretta. Il fatto si misura, non si deduce.
function testSoglie() {
  console.log('\n[TEST 73] v2.19.2 — davanti a ogni porta non ci sta niente, e si entra davvero');
  const T = C.TILE, V = MapGen.VILLAGE, m = MapGen.generateMarket(7), RG = C.PLAYER_RADIUS;
  const solidi = m.solids.filter(s => !s.chi);

  // --- 1) LA REGOLA: nessun mobile solido nella fascia della porta ---
  // (il generatore spacca da solo se qualcuno ne rimette uno: qui si controlla che spacchi davvero,
  //  se no sarebbe una rete senza buchi e senza filo)
  for (const r of V.rooms) {
    const [px, py, lato] = r.porta, oriz = lato === 'e' || lato === 'o';
    for (const pr of m.props) {
      if (!MapGen.INGOMBRI[pr.type]) continue;
      const x = pr.x / T - 0.5, y = pr.y / T - 0.5;
      if (x < r.x0 - 1 || x > r.x1 + 1 || y < r.y0 - 1 || y > r.y1 + 1) continue;
      const dentro = oriz ? (Math.abs(y - py) <= 1.5 && Math.abs(x - px) <= 2.6)
                          : (Math.abs(x - px) <= 1.5 && Math.abs(y - py) <= 2.6);
      assert(!dentro, r.id + ': niente davanti alla porta (c e un ' + pr.type + ' a ' + x.toFixed(1) + ',' + y.toFixed(1) + ')');
    }
  }

  // --- 2) IL FATTO: dalla strada si entra, e si arriva al banco ---
  const muro = (tx, ty) => tx < 0 || ty < 0 || tx >= m.w || ty >= m.h || m.grid[ty * m.w + tx] === C.T_WALL;
  const libero = (x, y) => {
    if (muro(Math.floor(x / T), Math.floor(y / T))) return false;
    for (const s of solidi) {
      if (s.t === 'c') { if (Math.hypot(s.x - x, s.y - y) < s.r + RG) return false; }
      else if (Math.abs(s.x - x) < s.hw + RG && Math.abs(s.y - y) < s.hh + RG) return false;
    }
    return true;
  };
  const PASSO = 8;
  const arriva = (da, ax, ay) => {
    const visti = new Set([da[0] + ',' + da[1]]), coda = [da];
    while (coda.length) {
      const [x, y] = coda.shift();
      if (Math.hypot(x - ax, y - ay) < T * 0.9) return true;
      for (const d of [[PASSO, 0], [-PASSO, 0], [0, PASSO], [0, -PASSO]]) {
        const nx = x + d[0], ny = y + d[1], k = nx + ',' + ny;
        if (visti.has(k)) continue; visti.add(k);
        if (nx < 0 || ny < 0 || nx > m.w * T || ny > m.h * T) continue;
        if (!libero(nx, ny)) continue;
        coda.push([nx, ny]);
      }
      if (visti.size > 90000) break;
    }
    return false;
  };
  for (const r of V.rooms) {
    const [px, py, lato] = r.porta;
    const dx = lato === 'e' ? 1 : lato === 'o' ? -1 : 0, dy = lato === 'n' ? -1 : lato === 's' ? 1 : 0;
    const fuori = [(px + dx) * T + T / 2, (py + dy) * T + T / 2];
    const centro = [((r.x0 + r.x1) / 2) * T + T / 2, ((r.y0 + r.y1) / 2) * T + T / 2];
    assert(arriva(fuori, centro[0], centro[1]), r.id + ': dalla strada si entra fino in mezzo alla stanza');
    const st = (m.village.npcs || []).find(n => {
      const tx = n.x / T - 0.5, ty = n.y / T - 0.5;
      return tx >= r.x0 - 1 && tx <= r.x1 + 1 && ty >= r.y0 - 1 && ty <= r.y1 + 1;
    });
    if (st) assert(arriva(fuori, st.x, st.y), r.id + ': e si arriva fino al banco del mercante');
  }

  // --- 3) E IL PASSAGGIO E' LARGO, non solo esistente ---
  // Una soglia che c'e' ma da cui ci si infila di sbieco e' esattamente cio' che Paolo ha segnalato.
  // Il minimo e' UNA TESSERA libera nelle prime tre: sotto, e' una strettoia.
  for (const r of V.rooms) {
    const [px, py, lato] = r.porta;
    const dx = lato === 'e' ? -1 : lato === 'o' ? 1 : 0, dy = lato === 'n' ? 1 : lato === 's' ? -1 : 0;
    let minW = Infinity;
    for (let d = 1; d <= 3; d++) {
      const cx = (px + dx * d) * T + T / 2, cy = (py + dy * d) * T + T / 2;
      let best = 0, run = 0;
      for (let o = -3 * T; o <= 3 * T; o += 4) {
        const x = dx ? cx : cx + o, y = dx ? cy + o : cy;
        if (libero(x, y)) { run += 4; best = Math.max(best, run); } else run = 0;
      }
      minW = Math.min(minW, best);
    }
    assert(minW >= T, r.id + ': il passaggio e largo almeno una tessera (' + (minW / T).toFixed(2) + ')');
  }
  // --- 4) v2.19.11 — E LA CORSIA DEL BANCO E' SGOMBRA FINO AL MERCANTE ---
  // Paolo: *«nel negozio di magia hai piazzato un ostacolo proprio davanti al bancone del mago»*.
  // La soglia era libera — i tre controlli qui sopra passavano tutti — e tre passi piu' avanti c'era
  // un cristallo in mezzo alla strada. Quindi il fatto da misurare non e' «si entra», e' «si ARRIVA
  // AL BANCO camminando dritto»: la striscia che contiene la riga del mercante, da un passo dentro la
  // porta fino a un passo e mezzo dal banco, dev'essere larga almeno una tessera per tutto il tragitto.
  // Si misura la striscia CHE CONTIENE la riga del mercante, non la piu' larga della stanza: una
  // corsia larga due tessere ma rasente al muro di settentrione non e' la corsia del banco.
  for (const st of V.stalls) {
    const r = V.rooms.find(q => q.id === st.room); if (!r) continue;
    const [px, py, lato] = r.porta, oriz = lato === 'e' || lato === 'o';
    const verso = oriz ? Math.sign(st.x - px) : Math.sign(st.y - py);
    const da = (oriz ? px : py) + verso, a2 = (oriz ? st.x : st.y) - verso * 1.5;
    let minW = Infinity, dove = 0;
    for (let q = da; verso > 0 ? q <= a2 : q >= a2; q += verso * 0.5) {
      const cx = oriz ? q * T + T / 2 : st.x * T + T / 2, cy2 = oriz ? st.y * T + T / 2 : q * T + T / 2;
      if (!libero(cx, cy2)) { minW = 0; dove = q; break; }
      let w = 0;                                              // quanto e' larga la striscia QUI, attorno alla riga del banco
      for (const s2 of [1, -1]) for (let o = 4; o <= 2.5 * T; o += 4) {
        if (!libero(oriz ? cx : cx + o * s2, oriz ? cy2 + o * s2 : cy2)) break;
        w += 4;
      }
      if (w < minW) { minW = w; dove = q; }
    }
    assert(minW >= T, r.id + ': dalla porta al banco di ' + st.name + ' la corsia e larga almeno una tessera ('
      + (minW / T).toFixed(2) + ' a ' + dove.toFixed(1) + ')');
  }
  ok('le soglie sono sgombre, si entra in tutte e tredici le stanze, e ai banchi si arriva camminando dritto');
}

// ============================================================================================
// v2.19.5 — L'ARMA A DUE MANI E LO SCUDO: due bug nella stessa combinazione
// ============================================================================================
// Paolo: *«se al paladino equipaggio un'arma a due mani (e rimuove lo scudo) non carica l'ondata
// successiva, ma mostra un'immagine freezata del villaggio»*. Il blocco era nel DISEGNO (il client),
// e lo proteggono i controlli sul renderer; qui si proteggono le due cose del SERVER trovate cercandolo.
function testDueMani() {
  console.log('\n[TEST 74] v2.19.5 — arma a due mani senza scudo: si salva, si riprende, si prosegue');
  const Gear = require('../shared/gear.js'), Salva = require('../shared/salvataggio.js'), Her = require('../shared/heroes.js');

  // --- 1) LA RIPRESA NON RIDA' LO SCUDO A CHI IMPUGNA UNA DUE MANI ---
  // Il riempimento dei salvataggi vecchi riempiva OGNI casella vuota con l'equipaggiamento di partenza —
  // comprese le mani. Ma la sinistra di chi tiene lo Spadone e' vuota APPOSTA: riempirla ricreava
  // Spadone + scudo, la combinazione che `Gear.impugna` vieta.
  const r = new Room('v2195'); const p = r.addPlayer('a', { send() {} }, 'A', 'paladino'); r.startGame();
  r.wave = 3; r.phase = C.PHASE_SHOP; r.vaiAlVillaggio('a'); p.coins = 99999;
  alBanco(r, p, 'guerriero');
  const spadone = Gear.itemsBottega('paladino', 'guerriero', 'weapon').find(i => i.rank === 2 && i.carattere === 'pesante');
  r.buyGear('a', spadone.id); r.equipaggia('a', spadone.id, 'manoDx');
  assert(p.gear.manoDx === spadone.id && !p.gear.manoSx, 'lo Spadone a due mani libera la sinistra (lo scudo va via)');
  const dati = Salva.costruisci(r, p);
  const r2 = new Room('v2195b'); r2.addPlayer('a', { send() {} }, 'A', 'paladino'); r2.riprendi('a', dati);
  const q = r2.players.get('a');
  assert(q.gear.manoDx === spadone.id, 'ripresa: lo Spadone e ancora in mano');
  assert(!q.gear.manoSx, 'ripresa: e la sinistra resta LIBERA, niente scudo rimesso di nascosto');
  // e un salvataggio VECCHIO, di prima delle mani, deve ancora riceverle
  const vecchio = JSON.parse(JSON.stringify(dati)); vecchio.gear = { armor: dati.gear.armor };
  const r3 = new Room('v2195c'); r3.addPlayer('a', { send() {} }, 'A', 'paladino'); r3.riprendi('a', vecchio);
  const v = r3.players.get('a');
  assert(!!v.gear.manoDx && !!v.gear.manoSx, 'un salvataggio senza mani riceve arma e scudo di partenza');

  // --- 2) E SI PROSEGUE: la partita arriva all'ondata successiva ---
  p.x = r.map.exit.x * C.TILE + C.TILE / 2; p.y = r.map.exit.y * C.TILE + C.TILE / 2; r._checkMarketExit();
  r.shopReady('a');
  const dt = 1 / C.TICK_RATE; for (let i = 0; i < C.TICK_RATE * 4; i++) r.update(dt);
  assert(r.phase === C.PHASE_COMBAT && r.wave === 4, 'con lo Spadone in mano si arriva all ondata 4 (fase ' + r.phase + ', ondata ' + r.wave + ')');

  // --- 3) LO SNAPSHOT DICE COSA C'E' IN OGNI MANO ---
  // Il disegno del guerriero segue l'equipaggiamento: gli servono arma principale, seconda arma, scudo.
  const io = (r.snapshot().players || []).find(x => x.i === 'a');
  assert(!!io, 'lo snapshot contiene il giocatore');
  assert(io && io.wp === spadone.id && !io.sh && !io.wx, 'lo snapshot porta lo Spadone, nessuno scudo, nessuna seconda arma');
  // un barbaro con due armi manda anche la seconda
  const rb = new Room('v2195d'); const pb = rb.addPlayer('b', { send() {} }, 'B', 'barbaro'); rb.startGame();
  rb.wave = 3; rb.phase = C.PHASE_SHOP; rb.vaiAlVillaggio('b'); pb.coins = 99999; alBanco(rb, pb, 'guerriero');
  const due = Gear.itemsBottega('barbaro', 'guerriero', 'weapon').filter(i => i.carattere === 'pesante').slice(0, 2);
  for (const it of due) rb.buyGear('b', it.id);
  rb.equipaggia('b', due[0].id, 'manoDx'); rb.equipaggia('b', due[1].id, 'manoSx');
  const ib = (rb.snapshot().players || []).find(x => x.i === 'b');
  assert(!!(ib && ib.wp && ib.wx && ib.wp !== ib.wx), 'il barbaro con due pesanti manda tutte e due le armi');

  // --- 4) NESSUNA IMPOSTAZIONE DI STILE HA IL NOME DI UN COLORE ---
  // E' questa, la causa del blocco: `scudo: 1` nello stile del paladino voleva dire «si disegna con lo
  // scudo», e `scudo` e' anche il colore che la tinta dello scudo ci scrive sopra. Senza scudo in mano,
  // al posto del colore restava 1. Il controllo e' sui NOMI, cosi' vale anche per quelli che nasceranno.
  const tinte = new Set(); for (const it of Gear.ITEMS) for (const k in (it.tinta || {})) tinte.add(k);
  const src = require('fs').readFileSync(require('path').join(__dirname, '../public/js/renderer.js'), 'utf8');
  const blocco = src.slice(src.indexOf('const STILE = {'), src.indexOf('};', src.indexOf('const STILE = {')));
  for (const k of tinte) {
    const re = new RegExp('\\b' + k + ':\\s*[0-9]');
    assert(!re.test(blocco), 'nello STILE la chiave «' + k + '» non e un numero: e il nome di un colore di tinta');
  }
  ok('arma a due mani: si salva, si riprende senza scudo fantasma, e si arriva all ondata dopo');
}

// ============================================================================================
// v2.19.7 — LO ZOMBIE DEL WARLOCK, IL MAGO ELEMENTALISTA, E L'ARMA A DUE MANI
// ============================================================================================
function testZombie() {
  console.log('\n[TEST 75] v2.19.7 — lo zombie del warlock, una volta per ondata, e che si muove davvero');
  const Gear = require('../shared/gear.js');
  const dt = 1 / C.TICK_RATE;
  const nuova = (id, h) => { const r = new Room(id); const p = r.addPlayer('w', { send() {} }, 'W', h || 'warlock'); r.startGame(); return { r, p }; };
  const zombiDi = (r, p) => [...r.players.values()].filter(q => q.zombi && q.evocatoBy === p.id && !q.dead);

  // --- 1) si alza, e una volta sola per ondata ---
  const { r, p } = nuova('z1');
  assert(p.abil[0] === 'ab_zombie', 'il warlock parte con lo zombie in mano');
  r.phase = C.PHASE_COMBAT;
  assert(r._usaAbilita(p, 1) === true && zombiDi(r, p).length === 1, 'lo evoca: uno zombie in campo');
  assert(r._usaAbilita(p, 1) === false && zombiDi(r, p).length === 1, 'la seconda volta nella stessa ondata no');
  assert(p.cdAb[0] >= 9000, 'e la casella resta spenta (niente numero che scende)');

  // --- 2) SI MUOVE. Il bug di Paolo: «dopo il cooldown evocavi un altro personaggio che restava fermo
  // impalato». L'IA la riceveva solo il PRIMO alleato. Qui: zombie + mercenario insieme, e un nemico
  // lontano — tutti e due devono andarci incontro.
  const q = zombiDi(r, p)[0];
  const mc = r.addPlayer('mc', { send() {} }, 'Merc', 'barbaro'); mc.merc = true; mc.mercOwner = p.id; mc.lives = 1;
  const m = r.spawnMonster('grunt', p.x + 300, p.y, { scaling: Waves.scaling(3, 1) });
  // Si controlla CHI RICEVE L'IA, ad ogni istante: e' il difetto vero. Misurare i pixel percorsi era
  // instabile — lo zombie e' lento e a volte, giustamente, resta accanto al padrone.
  const ricevuti = { z: 0, m: 0 }, N = C.TICK_RATE * 2;
  const origSet = r.setInput.bind(r);
  r.setInput = (pid, inp) => { if (pid === q.id) ricevuti.z++; if (pid === mc.id) ricevuti.m++; return origSet(pid, inp); };
  for (let i = 0; i < N; i++) r.update(dt);
  r.setInput = origSet;
  assert(ricevuti.z >= N - 1, 'lo zombie riceve gli ordini dell IA a ogni istante (' + ricevuti.z + '/' + N + ')');
  assert(ricevuti.m >= N - 1, 'e anche il mercenario, in campo insieme a lui (' + ricevuti.m + '/' + N + ')');
  assert(r.mercenario === mc, 'il «mercenario» e il mercenario, non lo zombie');

  // --- 3) la morte dello zombie non e' la morte del mercenario ---
  r.mercData = { owner: p.id, caduto: false };
  r.downPlayer(q);
  assert(q.dead && !r.mercData.caduto, 'lo zombie che muore non segna il mercenario come caduto');

  // --- 4) si sgretola a fine ondata, e all'ondata dopo se ne alza un altro ---
  const { r: r2, p: p2 } = nuova('z2');
  r2.phase = C.PHASE_COMBAT; r2._usaAbilita(p2, 1);
  assert(zombiDi(r2, p2).length === 1, 'zombie in campo');
  r2.pending = 0; r2.waveList = []; for (const mo of r2.monsters) mo.dead = true; r2.monsters.length = 0;
  r2._checkWaveClear();
  assert(zombiDi(r2, p2).length === 0 && ![...r2.players.values()].some(x => x.zombi), 'a fine ondata lo zombie si sgretola');
  r2.nextWave();
  assert(p2.cdAb[0] === 0, 'all ondata dopo la casella si riaccende');
  r2.phase = C.PHASE_COMBAT;
  assert(r2._usaAbilita(p2, 1) === true && zombiDi(r2, p2).length === 1, 'e se ne alza uno nuovo');

  // --- 5) lo snapshot lo dichiara zombie (il client lo disegna col pupazzo degli zombie) ---
  const snap = r2.snapshot();
  const sz = (snap.players || []).find(x => x.i === zombiDi(r2, p2)[0].id);
  assert(sz && sz.zb === 1, 'lo snapshot porta il segno dello zombie');

  // --- 6) L'ARMA A DUE MANI RENDE DI PIU' (+35%) — e il barbaro, che la tiene a una mano, no ---
  const dps = (h, dx, sx) => { const rr = new Room('dm' + h + dx); const pl = rr.addPlayer('x', { send() {} }, 'X', h); rr.startGame();
    for (const id of [dx, sx]) if (id) pl.owned[id] = 1; pl.gear.manoDx = dx; pl.gear.manoSx = sx || null;
    rr._recomputeBoons(pl); rr._recomputeGear(pl); return rr.effDamage(pl) / rr.effFireDelay(pl); };
  for (let rk = 2; rk <= 5; rk++) {
    const pes = Gear.itemsOfRank('paladino', 'weapon', rk).find(i => i.carattere === 'pesante').id;
    const eq = Gear.itemsOfRank('paladino', 'weapon', rk).find(i => i.carattere === 'equilibrata').id;
    const k = dps('paladino', pes, null) / dps('paladino', eq, null);
    assert(k > 1.28 && k < 1.42, 'grado ' + rk + ': l arma a due mani rende ~1,35 volte una a una mano (' + k.toFixed(2) + ')');
  }
  const pesB = Gear.itemsOfRank('barbaro', 'weapon', 3).find(i => i.carattere === 'pesante').id;
  const rb = new Room('dmb'); const pb = rb.addPlayer('x', { send() {} }, 'X', 'barbaro'); rb.startGame();
  pb.owned[pesB] = 1; pb.gear.manoDx = pesB; rb._recomputeBoons(pb);
  assert(!pb._bonusDueMani, 'il barbaro, che tiene la pesante a una mano, non prende il bonus delle due mani');
  ok('zombie: si alza una volta per ondata, si muove insieme al mercenario, si sgretola a fine ondata');
}

// v2.19.8 — IL FENDENTE COLPISCE CIO' CHE SI VEDE, PIU' 5 PIXEL. I mostri sono disegnati 1,45 volte il
// loro raggio (1,86 gli elite) e il fendente contava sul raggio piccolo: un nemico che a schermo toccava
// il bordo bianco veniva mancato. Qui si mette il BORDO DISEGNATO del nemico a distanze note dal bordo
// bianco del fendente, davanti e ai lati.
function testFendente() {
  console.log('\n[TEST 76] v2.19.8 — il fendente colpisce il nemico che si vede dentro il bordo, fino a 5 px oltre');
  const Mon = require('../shared/monsters.js');
  const colpito = (elite, oltre, lato) => {
    const r = new Room('f' + Math.random()); const p = r.addPlayer('a', { send() {} }, 'A', 'barbaro'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    const w = r.effWeapon(p), vis = Mon.MONSTERS.skeleton.radius * C.VIS_SCALE * (elite ? 1.28 : 1);
    let d, a;
    if (!lato) { d = w.arcRadius + oltre + vis; a = p.aim; }
    else { d = w.arcRadius * 0.7; a = p.aim + w.arcHalf + Math.atan2(vis + oltre, d); }
    const m = r.spawnMonster('skeleton', p.x, p.y, {}); if (elite) m.elite = true;
    m.x = p.x + Math.cos(a) * d; m.y = p.y + Math.sin(a) * d; const h = m.hp;
    r._meleeSwing(p, w, 10, false); return m.hp < h;
  };
  for (const el of [false, true]) {
    const nome = el ? 'elite' : 'normale';
    assert(colpito(el, -6), nome + ': entra di 6 px nel bordo bianco -> colpito');
    assert(colpito(el, 0), nome + ': tocca il bordo bianco -> colpito');
    assert(colpito(el, 4), nome + ': 4 px oltre il bordo -> colpito (il margine della mischia)');
    assert(!colpito(el, 12), nome + ': 12 px oltre il bordo -> mancato (il fendente non diventa infinito)');
    assert(colpito(el, 4, true), nome + ': ai lati del settore, 4 px oltre -> colpito');
    assert(!colpito(el, 14, true), nome + ': ai lati, 14 px oltre -> mancato');
  }
  ok('il fendente colpisce quello che si vede, con 5 pixel di margine');
}


// ============================================================================================
// v2.19.11 — LA SCARICA, LE BACCHETTE E LA PALLA DI FUOCO
// ============================================================================================
// Quattro richieste di Paolo in un colpo solo, e ognuna qui ha il suo fatto misurato:
//   1. lo sparo non e' piu' una bolla ma una SCARICA, azzurra per il mago e viola per il warlock;
//   2. le bacchette non hanno piu' l'ampiezza della bolla: solo danno e frequenza (TEST 37);
//   3. la firma del mago e' una PALLA DI FUOCO che VIAGGIA e fa danno AD AREA;
//   4. davanti al bancone dell'arcanista non c'e' piu' niente (TEST 73).
function testScarica() {
  console.log('\n[TEST 77] v2.19.11 — la scarica, le bacchette appiattite e la palla di fuoco che vola');

  // --- 1) NESSUNA BOLLA E' SOPRAVVISSUTA, e la scarica e' una sola per tutti i bastoni ----------
  const bast = Gear.ITEMS.filter(i => i.hero === 'mago' && i.slot === 'weapon');
  assert(bast.length === 13, 'i bastoni del mago sono sempre tredici');
  for (const it of bast) {
    assert(!it.weapon.bubble, it.id + ': non e piu una bolla');
    assert(it.weapon.scarica, it.id + ': e una scarica');
    assert(it.weapon.r === bast[0].weapon.r, it.id + ': la scarica e larga come quella di tutti gli altri');
    assert(it.weapon.bulletSpeed === bast[0].weapon.bulletSpeed, it.id + ': viaggia come quella di tutti gli altri');
    assert(it.weapon.range === bast[0].weapon.range, it.id + ': ha la gittata di tutti gli altri');
    assert(!/[Bb]olla/.test(it.desc), it.id + ': la scheda non parla piu di bolle (' + it.desc + ')');
  }
  // e le due armi di classe sono scariche pure loro
  assert(Heroes.HEROES.mago.weapon.scarica && !Heroes.HEROES.mago.weapon.bubble, 'l arma di partenza del mago e una scarica');
  assert(Heroes.HEROES.warlock.weapon.scarica && !Heroes.HEROES.warlock.weapon.bubble, 'l arma di partenza del warlock e una scarica');

  // --- 2) IL COLORE E' DELLA CLASSE, NON DEL BASTONE --------------------------------------------
  // Lo stesso identico scettro comprato dallo stesso arcanista: azzurro in mano al mago, viola in
  // mano al warlock. E' la richiesta di Paolo, e in cooperativa e' l'unico modo di capire chi spara.
  const sceltro = 'mag_w_scettro_di_piombo';
  const colore = (heroId) => {
    const r = new Room('sc' + heroId); const p = r.addPlayer('a', { send() {} }, 'A', heroId); r.startGame();
    p.owned[sceltro] = 1; p.gear.manoDx = sceltro; p.gear.manoSx = null; r._recomputeGear(p);
    p.stats.critChance = 0;                              // il critico tinge il colpo di giallo: qui si misura il colore dell arma
    r.bullets.length = 0; p.fireCd = 0; r.firePlayerWeapon(p);
    const b = r.bullets.find(x => !x.hostile); return b && b.color;
  };
  const cM = colore('mago'), cW = colore('warlock');
  assert(cM === Heroes.HEROES.mago.weapon.projColor, 'con lo scettro in mano il mago spara AZZURRO (' + cM + ')');
  assert(cW === Heroes.HEROES.warlock.weapon.projColor, 'con lo STESSO scettro il warlock spara VIOLA (' + cW + ')');
  assert(cM !== cW, 'e i due colori sono diversi');

  // --- 3) LA PALLA DI FUOCO PARTE, VOLA E SCOPPIA AD AREA ----------------------------------------
  const pf = Ab.BY_ID.ab_palla;
  assert(Ab.firma('mago').id === 'ab_palla', 'la firma del mago e la Palla di Fuoco');
  assert(pf.proiettile && pf.velocita > 700 && pf.raggio > 100, 'la Palla di Fuoco e un proiettile veloce con un raggio d area');
  const r = new Room('pf1'); const p = r.addPlayer('a', { send() {} }, 'A', 'mago'); r.startGame();
  r.monsters.length = 0; r.pending = 0; r.waveList = []; r.bullets.length = 0;
  // una direzione LIBERA: se la sfera parte contro un muro scoppia sul posto — giusto che lo faccia,
  // ma qui si sta misurando il volo, non il muro.
  const DIST = 300; let ang = null;
  for (let k = 0; k < 32 && ang === null; k++) {
    const t = k / 32 * Math.PI * 2, tx = p.x + Math.cos(t) * DIST, ty = p.y + Math.sin(t) * DIST;
    if (!r.isWallAt(tx, ty) && r.losClear(p.x, p.y, tx, ty) && !r.isWallAt(tx, ty + pf.raggio * 0.5) && !r.isWallAt(tx, ty + pf.raggio * 3)) ang = t;
  }
  assert(ang !== null, 'c e almeno una direzione sgombra da cui tirare');
  p.aim = ang;
  const bx = p.x + Math.cos(ang) * DIST, by = p.y + Math.sin(ang) * DIST;
  // tre bersagli: due vicini al punto d'impatto, uno molto piu' in la'
  const vicino = r.spawnMonster('skeleton', bx, by, {});
  const accanto = r.spawnMonster('skeleton', bx, by + pf.raggio * 0.5, {});
  const lontano = r.spawnMonster('skeleton', bx, by + pf.raggio * 3, {});
  for (const m of [vicino, accanto, lontano]) { m.hp = 99999; m.maxHp = 99999; }
  const hp0 = [vicino.hp, accanto.hp, lontano.hp];
  p.abil[0] = 'ab_palla'; p.cdAb[0] = 0;
  assert(r.useAbil(p, 1) !== false, 'l abilita parte');
  const pal = r.bullets.find(b => b.palla);
  assert(pal, 'e mette in campo un PROIETTILE, non un colpo istantaneo');
  assert(pal.dmg === 0 && pal.boomDmg > 0, 'la sfera non morde: tutto il danno sta nell esplosione');
  assert(Math.round(Math.hypot(pal.vx, pal.vy)) === pf.velocita, 'e viaggia a ' + pf.velocita + ' px/s');
  assert(vicino.hp === hp0[0], 'nell istante in cui parte non ha ancora fatto male a nessuno');
  // la si lascia volare: deve arrivare addosso al primo nemico e scoppiare li'
  let giri = 0; while (r.bullets.some(b => b.palla) && giri < 200) { r.updateBullets(1 / 60); giri++; }
  assert(giri > 3, 'ci ha messo del tempo ad arrivare (' + giri + ' tick): si vede volare');
  assert(vicino.hp < hp0[0], 'chi era sul punto d impatto ha preso il colpo');
  assert(accanto.hp < hp0[1], 'e anche chi gli stava accanto, dentro il raggio: e danno AD AREA');
  assert(lontano.hp === hp0[2], 'chi era fuori dal raggio non ha preso niente');
  assert(hp0[0] - vicino.hp === hp0[1] - accanto.hp, 'dentro l area il danno e lo stesso per tutti');

  // e scoppia anche se non incontra nessuno: a fine gittata, non si spegne per aria
  const r2 = new Room('pf2'); const q = r2.addPlayer('a', { send() {} }, 'A', 'mago'); r2.startGame();
  r2.monsters.length = 0; r2.pending = 0; r2.waveList = []; r2.bullets.length = 0;
  q.abil[0] = 'ab_palla'; q.cdAb[0] = 0; q.aim = 0; r2.useAbil(q, 1);
  let ev = null; for (let i = 0; i < 200 && !ev; i++) { r2.events.length = 0; r2.updateBullets(1 / 60); ev = r2.events.find(e => e.t === 'palla'); }
  assert(ev, 'senza bersagli scoppia comunque, a fine gittata');

  // --- 4) COMBUSTIONE: chi muore per mano sua scoppia, e la catena ha un freno -------------------
  const r3 = new Room('cmb'); const c = r3.addPlayer('a', { send() {} }, 'A', 'mago'); r3.startGame();
  r3.monsters.length = 0; r3.pending = 0; r3.waveList = [];
  const ab = Ab.BY_ID.ab_combustione;
  const vittima = r3.spawnMonster('skeleton', 900, 900, {});
  const testimone = r3.spawnMonster('skeleton', 900 + ab.raggio * 0.5, 900, {});
  testimone.hp = 99999; testimone.maxHp = 99999;
  const t0 = testimone.hp;
  r3.damageMonster(vittima, 99999, 0, 0, 0, c);
  assert(testimone.hp === t0, 'senza Combustione, chi muore non fa male a nessuno');
  c.abil[2] = 'ab_combustione'; c.cdAb[2] = 0; r3.useAbil(c, 3);
  assert(c.buffs.combustione > 0, 'la Combustione si accende');
  const vittima2 = r3.spawnMonster('skeleton', 900, 900, {});
  r3.damageMonster(vittima2, 99999, 0, 0, 0, c);
  assert(testimone.hp < t0, 'con la Combustione addosso, il nemico che cade SCOPPIA e brucia il vicino');

  // il freno della catena: venti nemici appiccicati non devono ne bloccare ne annidarsi senza fine
  const r4 = new Room('cmb2'); const d = r4.addPlayer('a', { send() {} }, 'A', 'mago'); r4.startGame();
  r4.monsters.length = 0; r4.pending = 0; r4.waveList = [];
  d.abil[2] = 'ab_combustione'; d.cdAb[2] = 0; r4.useAbil(d, 3);
  const folla = []; for (let i = 0; i < 20; i++) folla.push(r4.spawnMonster('skeleton', 1200 + i * 6, 1200, {}));
  for (const m of folla) { m.hp = 1; m.maxHp = 1; }
  r4.damageMonster(folla[0], 99, 0, 0, 0, d);
  assert(!r4._combGen, 'la catena si e richiusa: il contatore delle generazioni e tornato a zero');
  ok('la scarica ha il colore della classe, le bacchette hanno solo danno e cadenza, la palla di fuoco vola e scoppia');
}


// ============================================================================================
// v2.20.0 — LE PASSIVE NUOVE FANNO QUELLO CHE C'E' SCRITTO SULLA CARTA
// ============================================================================================
// Il mazzo e' stato rifatto da zero: 84 carte, e una quarantina non sono un moltiplicatore ma un
// AGGANCIO nuovo dentro il motore — la parata, la schivata, il contrattacco, il danno dirottato fra
// alleati, il giudizio a percentuale di PV, lo stordimento dello scatto, il debito del warlock.
// Sono tutti sul percorso del DANNO, della MORTE e della DIFESA, cioe' le tre strade che attraversano
// tutte e sette le classi: e' il cambiamento con il rischio di regressione piu' alto da quando le
// classi sono diventate sette, e senza questo test sarebbero ottantaquattro righe di testo.
// Qui si misura il FATTO, non il campo: si spara, si incassa, si uccide, e si guarda cosa cambia.
function testPassive220() {
  console.log('\n[TEST 78] v2.20.0 — le passive nuove: si misura cosa succede, non cosa c e scritto');
  const conn = () => ({ send() {} });
  // una stanza pulita con la carta addosso: niente ondata, niente mostri di passaggio
  const con = (hero, ...ids) => {
    const r = new Room('p220_' + hero + ids.join('_') + Math.random());
    const p = r.addPlayer('a', conn(), 'A', hero); r.startGame();
    r.phase = C.PHASE_COMBAT; r.monsters.length = 0; r.pending = 0; r.waveList = []; r.bullets.length = 0;
    for (const id of ids) { p.boonsOwned[id] = 1; p.cardOn[id] = 1; }
    r._recomputeBoons(p); p.hp = r.effMaxHp(p);
    return { r, p };
  };
  const mob = (r, p, dx, dy) => { const m = r.spawnMonster('skeleton', p.x + dx, p.y + (dy || 0), { scaling: Waves.scaling(2, 1) }); m.hp = m.maxHp = 90000; return m; };

  // --- 1) ZOCCOLO DURO: i colpi piccoli rimbalzano, i grossi no ---
  { const { r, p } = con('barbaro', 'bar_zoccolo');
    const max = r.effMaxHp(p);
    // si confrontano le due QUOTE (quanto arriva su quanto e' partito), non i valori assoluti: il
    // barbaro nasce con una riduzione sua dal profilo di classe, e un numero secco misurerebbe quella.
    const inviato1 = Math.round(max * 0.05), inviato2 = Math.round(max * 0.40);
    p.hp = max; r.damagePlayer(p, inviato1, p.x + 40, p.y, 0); const piccolo = (max - p.hp) / inviato1;
    p.hp = max; p.buffs = {}; r.damagePlayer(p, inviato2, p.x + 40, p.y, 0); const grosso = (max - p.hp) / inviato2;
    assert(piccolo < grosso * 0.85, 'Zoccolo Duro: del colpo piccolo ne arriva una quota minore (' + piccolo.toFixed(2) + ' contro ' + grosso.toFixed(2) + ')'); }

  // --- 2) FEDE SALDA: vale solo nella meta' bassa della vita ---
  { const { r, p } = con('paladino', 'pal_fede');
    const max = r.effMaxHp(p);
    p.hp = max; r.damagePlayer(p, 100, p.x + 40, p.y, 0); const sano = max - p.hp;
    p.hp = Math.round(max * 0.3); p.buffs = {}; const h0 = p.hp; r.damagePlayer(p, 100, p.x + 40, p.y, 0); const ferito = h0 - p.hp;
    assert(ferito < sano, 'Fede Salda: ferito incassa meno (' + ferito + ' < ' + sano + ')'); }

  // --- 3) CUOIO E CICATRICI: piu' nemici attorno, meno danno ---
  { const { r, p } = con('barbaro', 'bar_cicatrici');
    p.hp = 9000; const h0 = p.hp; r.damagePlayer(p, 100, p.x + 300, p.y, 0); const solo = h0 - p.hp;
    for (let i = 0; i < 4; i++) mob(r, p, 40 + i * 6, 10);
    p.hp = 9000; p.buffs = {}; const h1 = p.hp; r.damagePlayer(p, 100, p.x + 300, p.y, 0); const folla = h1 - p.hp;
    assert(folla < solo, 'Cuoio e Cicatrici: in mezzo alla folla si incassa meno (' + folla + ' < ' + solo + ')'); }

  // --- 4) SCUDO CONDIVISO: il paladino incassa al posto del compagno ---
  { const r = new Room('p220_cond'); const pal = r.addPlayer('a', conn(), 'A', 'paladino');
    const amico = r.addPlayer('b', conn(), 'B', 'mago'); r.startGame(); r.phase = C.PHASE_COMBAT;
    pal.boonsOwned.pal_condiviso = 1; pal.cardOn.pal_condiviso = 1; r._recomputeBoons(pal);
    pal.x = amico.x; pal.y = amico.y; pal.hp = 500; amico.hp = 500; amico.buffs = {};
    r.damagePlayer(amico, 100, amico.x + 40, amico.y, 0);
    assert(pal.hp < 500, 'Scudo Condiviso: una quota la paga il paladino (' + (500 - pal.hp) + ')');
    assert(amico.hp > 400, 'e il compagno ne prende di meno'); }

  // --- 5) EGIDA: una volta per ondata, e il colpo che farebbe cadere non arriva ---
  { const r = new Room('p220_egida'); const pal = r.addPlayer('a', conn(), 'A', 'paladino');
    const amico = r.addPlayer('b', conn(), 'B', 'mago'); r.startGame(); r.phase = C.PHASE_COMBAT;
    pal.boonsOwned.pal_egida = 1; pal.cardOn.pal_egida = 1; r._recomputeBoons(pal);
    pal.x = amico.x; pal.y = amico.y; amico.hp = 12; amico.buffs = {};
    r.damagePlayer(amico, 500, amico.x + 40, amico.y, 0);
    assert(amico.hp === 12 && !amico.down, 'Egida: il colpo che lo avrebbe steso non arriva');
    amico.buffs = {};
    r.damagePlayer(amico, 500, amico.x + 40, amico.y, 0);
    assert(amico.down || amico.hp < 12, 'e la seconda volta nella stessa ondata no'); }

  // --- 6) LEGAME OSSEO: una quota la prende lo zombie ---
  { const { r, p } = con('warlock', 'war_legame');
    p.abil[0] = 'ab_zombie'; p.cdAb[0] = 0; r.useAbil(p, 1);
    const z = [...r.players.values()].find(q => q.zombi);
    assert(z, 'lo zombie e in campo');
    const z0 = z.hp; p.hp = 500; p.buffs = {};
    r.damagePlayer(p, 100, p.x + 40, p.y, 0);
    assert(z.hp < z0, 'Legame Osseo: lo zombie ha pagato una quota (' + (z0 - z.hp) + ')');
    assert(p.hp > 400, 'e il warlock ne ha presi di meno'); }

  // --- 7) GIUDIZIO: il sesto colpo porta via una quota dei PV MASSIMI ---
  { const { r, p } = con('paladino', 'pal_giudizio');
    const m = mob(r, p, 60);
    let visto = 0;
    for (let k = 0; k < 6; k++) { const h0 = m.hp; r.damageMonster(m, 10, p.x, p.y, 0, p, {}); if (h0 - m.hp > 1000) visto++; }
    assert(visto === 1, 'Giudizio: uno solo dei sei colpi porta via la quota (' + visto + ')'); }

  // --- 8) AGGUATO ed ESECUZIONE: due condizioni opposte, stesso bersaglio ---
  { const { r, p } = con('assassino', 'ass_agguato');
    const m = mob(r, p, 60); let h0 = m.hp; r.damageMonster(m, 1000, p.x, p.y, 0, p, {}); const intero = h0 - m.hp;
    h0 = m.hp; r.damageMonster(m, 1000, p.x, p.y, 0, p, {}); const toccato = h0 - m.hp;
    assert(intero > toccato, 'Agguato: il primo colpo su chi e a vita piena pesa di piu (' + intero + ' > ' + toccato + ')'); }
  { const { r, p } = con('assassino', 'ass_esecuzione');
    const m = mob(r, p, 60); let h0 = m.hp; r.damageMonster(m, 1000, p.x, p.y, 0, p, {}); const pieno = h0 - m.hp;
    m.hp = Math.round(m.maxHp * 0.2); h0 = m.hp; r.damageMonster(m, 1000, p.x, p.y, 0, p, {}); const morente = h0 - m.hp;
    assert(morente > pieno, 'Esecuzione: su chi sta per cadere pesa di piu (' + morente + ' > ' + pieno + ')'); }

  // --- 9) MANO FREDDA: il critico si avvicina a ogni colpo mancato e si azzera quando arriva ---
  { const { r, p } = con('assassino', 'ass_fredda');
    p.stats.critChance = 0; p.freddaAcc = 0;
    // UN COLPO SOLO, non tre. Con il conto a zero e la probabilita di critico a zero il primo colpo
    // non puo' fare critico, quindi il conto sale di sicuro. Tre colpi di fila invece alzavano il
    // conto abbastanza da far uscire un critico VERO, che azzera tutto: era proprio il meccanismo
    // sotto esame a far diventare rosso il test una volta ogni tanto.
    p.fireCd = 0; r.bullets.length = 0; r.firePlayerWeapon(p);
    assert(p.freddaAcc > 0, 'Mano Fredda: i colpi non critici caricano il conto (' + p.freddaAcc.toFixed(3) + ')');
    p.stats.critChance = 1; p.fireCd = 0; r.bullets.length = 0; r.firePlayerWeapon(p);
    assert(p.freddaAcc === 0, 'e il critico lo azzera'); }

  // --- 10) RAFFICA: ogni ottavo colpo e' un ventaglio ---
  { const { r, p } = con('arciere', 'arc_raffica');
    let ventagli = 0;
    for (let k = 0; k < 8; k++) { p.fireCd = 0; r.bullets.length = 0; r.firePlayerWeapon(p); if (r.bullets.filter(b => !b.hostile).length >= 3) ventagli++; }
    assert(ventagli === 1, 'Raffica: uno solo degli otto colpi e un ventaglio (' + ventagli + ')'); }

  // --- 11) FRECCIA INCENDIARIA: la quarta lascia la fiamma dove arriva ---
  { const { r, p } = con('arciere', 'arc_incendiaria');
    const m = mob(r, p, 120); r.nebbie.length = 0;
    for (let k = 0; k < 4; k++) { p.fireCd = 0; r.firePlayerWeapon(p); }
    for (let i = 0; i < 60 && !r.nebbie.length; i++) r.updateBullets(1 / 60);
    assert(r.nebbie.length > 0, 'Freccia Incendiaria: la fiamma resta a terra'); }

  // --- 12) TERREMOTO: lo scatto stordisce chi si trova in mezzo ---
  { const { r, p } = con('barbaro', 'bar_terremoto');
    const m = mob(r, p, 10); m.stun = 0;
    p.cdDash = 0; r.useDash(p);
    for (let i = 0; i < 6; i++) r.update(1 / 60);
    assert(m.stun > 0, 'Terremoto: il nemico attraversato resta intontito'); }

  // --- 13) SPACCA IN DUE: il colpo che uccide prosegue su chi sta dietro ---
  { const { r, p } = con('barbaro', 'bar_spacca');
    p.aim = 0;
    const primo = mob(r, p, 60); primo.hp = primo.maxHp = 10;
    const dietro = mob(r, p, 120); const h0 = dietro.hp;
    r.damageMonster(primo, 999, p.x, p.y, 0, p, {});
    assert(primo.dead && dietro.hp < h0, 'Spacca in Due: chi sta dietro al morto incassa (' + (h0 - dietro.hp) + ')'); }

  // --- 14) COLPO DOPPIO: il quarto fendente morde due volte ---
  { const { r, p } = con('maestro', 'mae_doppio');
    const m = mob(r, p, 40); p.aim = 0; m.x = p.x + 40; m.y = p.y;
    const w = r.effWeapon(p); const danni = [];
    for (let k = 0; k < 4; k++) { const h0 = m.hp; r._meleeSwing(p, w, 100, false); danni.push(h0 - m.hp); }
    assert(danni[3] > danni[0], 'Colpo Doppio: il quarto fendente fa piu male (' + danni[3] + ' > ' + danni[0] + ')'); }

  // --- 15) RITMO: i colpi a segno alzano la cadenza, il tempo la spegne ---
  { const { r, p } = con('maestro', 'mae_ritmo');
    const m = mob(r, p, 60); const t0 = r.effFireDelay(p);
    for (let k = 0; k < 5; k++) r.damageMonster(m, 10, p.x, p.y, 0, p, {});
    assert(p.ritmoStack === 5 && r.effFireDelay(p) < t0, 'Ritmo: cinque colpi a segno accorciano l attesa');
    for (let i = 0; i < 180; i++) r.update(1 / 60);
    assert(p.ritmoStack === 0, 'e due secondi senza colpire la azzerano'); }

  // --- 16) DEBITO DI SANGUE: il conto si paga alla morte del maledetto ---
  { const { r, p } = con('warlock', 'war_debito', 'war_marchio');
    const vittima = mob(r, p, 60); const testimone = mob(r, p, 60, 60);
    vittima.maled = 4; vittima.maledBy = p.id; vittima.maledMult = 1.12;
    for (let k = 0; k < 6; k++) r.damageMonster(vittima, 500, p.x, p.y, 0, p, {});
    assert(vittima.debito > 0, 'il conto si accumula sul maledetto (' + Math.round(vittima.debito) + ')');
    const t0 = testimone.hp;
    r.damageMonster(vittima, 99999, p.x, p.y, 0, p, {});
    assert(vittima.dead && testimone.hp < t0, 'Debito di Sangue: alla sua morte scoppia (' + (t0 - testimone.hp) + ')'); }

  // --- 17) MALEDIZIONE PERPETUA: non scade da sola ---
  { const { r, p } = con('warlock', 'war_marchio', 'war_perpetua');
    const m = mob(r, p, 60); p.aim = 0; m.x = p.x + 60; m.y = p.y;
    for (let k = 0; k < 6; k++) { p.fireCd = 0; r.firePlayerWeapon(p); }
    assert(m.maled > 100, 'Maledizione Perpetua: il segno non ha una scadenza vera (' + m.maled + ')'); }

  // --- 18) ZOMBIE TENACE: piu' PV, ma a fine ondata si sgretola lo stesso ---
  { const a = con('warlock'); const b = con('warlock', 'war_zombie');
    for (const { r, p } of [a, b]) { p.abil[0] = 'ab_zombie'; p.cdAb[0] = 0; r.useAbil(p, 1); }
    const z1 = [...a.r.players.values()].find(q => q.zombi), z2 = [...b.r.players.values()].find(q => q.zombi);
    assert(z2.hp > z1.hp * 1.2, 'Zombie Tenace: regge di piu (' + z1.hp + ' -> ' + z2.hp + ')');
    b.r._sgretolaZombie();
    assert(![...b.r.players.values()].some(q => q.zombi), 'e a fine ondata si sgretola come sempre'); }

  // --- 19) DOPPIA INCANTAZIONE: la prima Palla non manda in ricarica, la seconda si' ---
  { const { r, p } = con('mago', 'mag_doppia');
    p.abil[0] = 'ab_palla'; p.cdAb[0] = 0;
    r.useAbil(p, 1); assert(p.cdAb[0] === 0, 'Doppia Incantazione: la prima carica e gratis');
    r.useAbil(p, 1); assert(p.cdAb[0] > 0, 'e la seconda manda in ricarica'); }

  // --- 20) ELEMENTALISTA PURO: la palla scoppia piu' larga ---
  { const a = con('mago'); const b = con('mago', 'mag_puro');
    for (const { r, p } of [a, b]) { p.abil[0] = 'ab_palla'; p.cdAb[0] = 0; p.aim = 0; r.useAbil(p, 1); }
    const p1 = a.r.bullets.find(x => x.palla), p2 = b.r.bullets.find(x => x.palla);
    assert(p2.boomR > p1.boomR, 'Elementalista Puro: il raggio cresce (' + p1.boomR + ' -> ' + p2.boomR + ')'); }

  // --- 21) SILENZIOSO: i nemici lo notano da piu' vicino ---
  { const { p } = con('assassino', 'ass_silenzioso');
    assert(p.boon.silenzioso > 0, 'Silenzioso: il campo c e');
    const AI = require('../shared/ai.js');
    assert(typeof AI.update === 'function', 'e l IA lo legge da `p.boon.silenzioso` dentro perceive'); }

  // --- 22) FARO: i nemici vicini prendono di mira il paladino ---
  { const { r, p } = con('paladino', 'pal_faro');
    const m = mob(r, p, 80);
    for (let i = 0; i < 4; i++) r.update(1 / 60);
    assert(m.taunt > 0 && m.tauntBy === p.id, 'Faro: il nemico vicino guarda lui'); }

  // --- 23) VELENO CORROSIVO: il nemico avvelenato morde meno ---
  { const { r, p } = con('assassino', 'ass_tossina', 'ass_corrosivo');
    const m = mob(r, p, 60); const d0 = m.dmg;
    r.damageMonster(m, 100, p.x, p.y, 0, p, { poison: 10 });
    r.update(1 / 60);
    assert(m.dmg < d0, 'Veleno Corrosivo: il morso del nemico cala (' + d0 + ' -> ' + m.dmg + ')'); }

  // --- 24) MAESTRIA: la seconda arma rende quasi il doppio ---
  { const Gear2 = require('../shared/gear.js');
    const due = (extra) => {
      const { r, p } = extra ? con('maestro', 'mae_maestria') : con('maestro');
      const a1 = Gear2.itemsOfRank('maestro', 'weapon', 3).find(i => i.carattere === 'equilibrata');
      const a2 = Gear2.itemsOfRank('maestro', 'weapon', 2).find(i => i.carattere === 'equilibrata');
      p.owned[a1.id] = 1; p.owned[a2.id] = 1; p.gear.manoDx = a1.id; p.gear.manoSx = a2.id;
      r._recomputeGear(p); r._recomputeBoons(p); return p._bonusSeconda;
    };
    const senza = due(false), con2 = due(true);
    assert(con2 > senza * 1.5, 'Maestria: la quota della seconda mano quasi raddoppia (' + senza.toFixed(3) + ' -> ' + con2.toFixed(3) + ')'); }

  // --- 25) TUTTE E DODICI ADDOSSO, PER TUTTE E SETTE LE CLASSI, IN PARTITA VERA ---
  // E' il controllo di non-regressione di questa versione, e vale piu' delle ventiquattro prove qui
  // sopra messe insieme: quelle misurano una carta alla volta in una stanza ferma, questa fa GIRARE il
  // gioco con tutte le carte accese insieme — il contrattacco dentro la rappresaglia, il debito dentro
  // la combustione, il mulinello dentro il fendente doppio. Se un aggancio nuovo tira un'eccezione o
  // lascia un NaN in giro, e' qui che si vede, e si vede per tutte e sette le classi.
  {
    const dt2 = 1 / C.TICK_RATE;
    for (const h of Heroes.ORDER) {
      const r = new Room('p220_tutte_' + h);
      const p = r.addPlayer('a', conn(), 'A', h); r.startGame();
      for (const b of Loot.boonsPerClasse(h)) { p.boonsOwned[b.id] = 1; p.cardOn[b.id] = 1; }
      r._recomputeBoons(p); p.hp = r.effMaxHp(p);
      // e un'abilita' attiva in mano, perche' meta' delle carte nuove ci parlano insieme
      p.abil[0] = (Ab.firma(h) || {}).id || null; p.cdAb[0] = 0;
      let errore = null, incassati = 0, inflitti = 0;
      try {
        for (let i = 0; i < C.TICK_RATE * 20; i++) {
          // NON si lascia fare al bot: il bot scappa, e un personaggio che scappa non prova NIENTE dei
          // ganci nuovi — ne' il contrattacco, ne' la parata, ne' lo scudo condiviso. Qui il nemico glielo
          // si mette addosso, e si spara: e' l'unico modo perche' le due direzioni del danno passino
          // davvero di qui. (Verificato rompendo un gancio a mano: senza questo, il test non se ne accorge.)
          if (i % 30 === 0 && r.monsters.filter(m => !m.dead).length < 6) {
            const mm = r.spawnMonster('skeleton', p.x + MU.rand(-40, 40), p.y + MU.rand(-40, 40), { scaling: Waves.scaling(6, 1) });
            if (mm) mm.awake = true;
          }
          // «incassato» = PV o scudi: il mago ha la Barriera di Mana e lo Scudo Arcano, e con quelli
          // addosso i PV non calano mai — misurarli soli direbbe che il mago non ha mai preso un colpo.
          const tot = q => q.hp + (q.manaShield || 0) + ((q.scudoAb && q.scudoAb.hp) || 0);
          const hp0 = tot(p), vivi0 = r.monsters.filter(m => !m.dead).reduce((a2, m) => a2 + m.hp, 0);
          // e ogni mezzo secondo un colpo IN FACCIA, dalla posizione di un nemico vicino: il mago
          // ammazza tutto prima che lo tocchino, e senza questo le sue carte di tenuta non le prova
          // nessuno. Il colpo arriva da dove arriverebbe davvero, se no la mischia non si riconosce.
          if (i % 30 === 15) {
            const vicino = r.monsters.find(m => !m.dead);
            if (vicino) { p.buffs.iframe = 0; r.damagePlayer(p, 12, vicino.x, vicino.y, 0); }
          }
          const inp = bot(r, p); inp.shoot = true; inp.mx = 0; inp.my = 0;
          if (i % 90 === 0) { p.cdAb[0] = 0; inp.ab = 1; }
          if (i % 120 === 60) inp.dash = true;
          r.setInput('a', inp);
          r.update(dt2);
          if (tot(p) < hp0) incassati++;
          const vivi1 = r.monsters.filter(m => !m.dead).reduce((a2, m) => a2 + m.hp, 0);
          if (vivi1 < vivi0) inflitti++;
          if (p.down || p.dead) { p.down = false; p.dead = false; p.hp = r.effMaxHp(p); }
          if (hasNaN(r)) break;
        }
      } catch (e) { errore = e; }
      assert(incassati > 0 && inflitti > 0, h + ': il finto combattimento e' + ' davvero un combattimento (colpi presi ' + incassati + ', dati ' + inflitti + ')');
      assert(!errore, h + ': venti secondi con tutte e dodici le carte addosso, senza eccezioni' + (errore ? ' (' + errore.message + ')' : ''));
      assert(hasNaN(r) === null, h + ': e senza NaN in giro (' + hasNaN(r) + ')');
      assert(r.effMaxHp(p) > 0 && r.effDamage(p) > 0, h + ': e il personaggio regge numeri sensati');
    }
  }

  ok('le passive nuove fanno quello che c e scritto sulla carta');
}


// ============================================================================================
// v2.20.1 — IL MENU: niente richiamo, titolo piu' piccolo, meta' dell'aria sopra
// ============================================================================================
// Tre ritocchi chiesti da Paolo, e tre controlli che li tengono fermi. Stanno QUI e non in
// `test/client.js`, che sarebbe il posto naturale: quel file si ferma al primo errore e da due
// versioni non arrivava piu' in fondo (parlava ancora dei tre eroi di una volta), quindi un controllo
// messo li' non lo avrebbe eseguito nessuno. Un test che non gira non e' un test.
function testMenu2201() {
  console.log('\n[TEST 79] v2.20.1 — il menu: via il richiamo, titolo piu piccolo, meta dell aria sopra');
  const fs = require('fs'), path = require('path');
  const ROOT = path.join(__dirname, '..') + path.sep;
  const html = fs.readFileSync(ROOT + 'public/index.html', 'utf8');
  const css = fs.readFileSync(ROOT + 'public/style.css', 'utf8');
  // 1) il testo non c'e' piu' — ne' il paragrafo ne' una sua riga rimasta in giro
  assert(!/class="occhiello"/.test(html), 'il richiamo sotto il titolo e stato tolto');
  assert(!/Scendi\. Venti volte/.test(html), 'e non ne e rimasta nemmeno una riga');
  // 2) e nemmeno il suo stile: un testo tolto con lo stile rimasto e' il modo in cui, fra sei mesi,
  //    qualcuno rimette il testo senza accorgersi che il CSS lo aspettava ancora
  assert(!/#titolone \.occhiello\{/.test(css), 'e nemmeno la regola di stile che lo vestiva');
  // 3) i due numeri, letti come li legge il browser
  const t = css.match(/#titolone h1\{font-size:clamp\(([\d.]+)px,([\d.]+)vw,([\d.]+)px\)/);
  assert(t, 'il titolo ha ancora la sua misura elastica');
  assert(+t[1] < 38 && +t[3] < 72, 'ed e piu piccolo di prima (' + t[1] + '-' + t[3] + 'px, era 38-72)');
  const pad = css.match(/#menu\{justify-content:flex-start;padding:min\(([\d.]+)vh,([\d.]+)px\)/);
  assert(pad, 'il menu ha ancora il suo margine in cima');
  assert(Math.abs(+pad[1] - 2.5) < 0.01 && Math.abs(+pad[2] - 26) < 0.01,
    'e l aria sopra il titolo e la meta di prima (' + pad[1] + 'vh/' + pad[2] + 'px, era 5vh/52px)');
  ok('il menu e piu corto: niente richiamo, titolo piu piccolo, meta dell aria in cima');
}

// =================================================================================================
// v2.21 — OGGETTI CHE FANNO QUALCOSA, E OGGETTI CHE APPARTENGONO A UN TEMA SOLO
// =================================================================================================
function testV221() {
  console.log('\n[TEST 80] v2.21 — urne, barili, grate e leve; e le scene esclusive per tema');
  const fs = require('fs'), path = require('path');
  const ROOT = path.join(__dirname, '..') + path.sep;

  // --- 1) OGNI TIPO DI PROP CHE LA MAPPA PIAZZA DEVE AVERE IL SUO DISEGNO -------------------
  // IL BUG CHE HA FATTO NASCERE QUESTO CONTROLLO. `chest` veniva piazzato dalla scena `deposito`
  // dalla v1.24, ma nel renderer il caso 'chest' non c'era mai stato: il prop cadeva in fondo allo
  // switch, non trovava il suo ramo e non disegnava niente. Per decine di versioni il deposito ha
  // avuto una cassa invisibile, senza un errore da nessuna parte. Questo controllo legge dal sorgente
  // che cosa piazza mapgen e che cosa sa disegnare il renderer, e pretende che i due insiemi tornino.
  {
    const srcG = fs.readFileSync(ROOT + 'shared/mapgen.js', 'utf8');
    const srcR = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
    const piazzati = new Set(); let mm;
    const reP = /\b(?:putC|putW|metti|P)\(\s*'([a-z_A-Z]+)'/g;
    while ((mm = reP.exec(srcG))) piazzati.add(mm[1]);
    const reB = /propMix:\s*\[([^\]]*)\]/g;
    while ((mm = reB.exec(srcG))) for (const q of mm[1].match(/'([a-z_A-Z]+)'/g) || []) piazzati.add(q.slice(1, -1));
    const disegnati = new Set();
    for (const q of srcR.match(/case '([a-z_A-Z]+)':/g) || []) disegnati.add(q.slice(6, -2));
    // questi il renderer li intercetta PRIMA dello switch, con un ramo tutto loro
    for (const s of ['torch', 'camp', 'bonfire', 'stall', 'glowspot', 'urna', 'barile']) disegnati.add(s);
    const muti = [...piazzati].filter(t => !disegnati.has(t));
    assert(muti.length === 0, 'ogni prop piazzato dalla mappa ha il suo disegno nel renderer'
      + (muti.length ? ' — MUTI: ' + muti.join(', ') : ''));
    assert(/case 'chest':/.test(srcR), 'e in particolare la cassa del deposito, invisibile dalla v1.24, adesso si vede');
  }

  // --- 2) LE SCENE ESCLUSIVE SONO DAVVERO ESCLUSIVE -----------------------------------------
  // Prima della v2.21 delle 24 scene ne esisteva UNA sola che appartenesse a un tema solo. Questo
  // controllo serve a non tornarci: se qualcuno aggiunge `colata` anche al ghiaccio, qui si rompe.
  {
    const ESCL = { crypt: ['loculo', 'urna', 'catafalco'], lava: ['colata', 'sfiatatoio'],
      forest: ['tronco', 'felce', 'radice'], ice: ['congelato', 'ghiacciolo'], arcane: ['cerchio', 'leggio'] };
    const visti = {};                       // tipo -> insieme dei temi in cui e' comparso
    const perTema = {};
    for (let s = 1; s <= 220; s++) {
      const m = MapGen.generate(s, 3 + (s % 12)); const t = m.theme.id;
      perTema[t] = (perTema[t] || 0) + 1;
      for (const p of m.props) { (visti[p.type] = visti[p.type] || new Set()).add(t); }
    }
    for (const tema of Object.keys(ESCL)) for (const tipo of ESCL[tema]) {
      if (tipo === 'urna') continue;        // l'urna e' un rompibile: non passa dai props
      const dove = visti[tipo];
      assert(dove && dove.has(tema), tipo + ' compare nel tema ' + tema);
      assert(dove && dove.size === 1, tipo + ' compare SOLO nel tema ' + tema + ' (visto in: ' + [...(dove || [])].join(',') + ')');
    }
    assert(Object.keys(perTema).length === 5, 'e le 220 mappe hanno comunque pescato tutti e cinque i temi');
  }

  // --- 3) IL RIPOSTIGLIO NON PUO' TAGLIARE LA MAPPA IN DUE ----------------------------------
  // E' la proprieta' su cui regge tutta la grata. Il vano si SCAVA nella roccia piena e la sua
  // conchiglia dev'essere piena a sua volta: cosi' aprirlo o non aprirlo non tocca niente di gia'
  // esistente. Il primo tentativo controllava solo le nove tessere del vano e non la conchiglia: in
  // 195 mappe su 300 il vano toccava di fianco un corridoio, il premio si prendeva senza leva e la
  // grata non chiudeva niente.
  {
    const raggiunge = (m, aperta) => {
      const W = m.w, H = m.h, g = m.grid.slice();
      if (aperta) for (const q of m.grate) for (const t of q.tiles) g[t] = C.T_FLOOR;
      const sx = (m.spawn.x / m.tile) | 0, sy = (m.spawn.y / m.tile) | 0;
      const vis = new Uint8Array(W * H), st = [sy * W + sx]; vis[st[0]] = 1;
      while (st.length) { const i = st.pop(), x = i % W, y = (i / W) | 0;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
          const j = ny * W + nx; if (vis[j] || g[j] === C.T_WALL) continue; vis[j] = 1; st.push(j); } }
      return vis;
    };
    let senzaGrata = 0, chiusoRaggiungibile = 0, apertoIrraggiungibile = 0, oltreIlVano = 0, senzaLeva = 0;
    for (let s = 1; s <= 120; s++) {
      const m = MapGen.generate(s, 3 + (s % 12));
      if (!m.grate.length) { senzaGrata++; continue; }
      if (!m.leve.length) senzaLeva++;
      const pr = m.grate[0].premio, px = (pr.x / m.tile) | 0, py = (pr.y / m.tile) | 0;
      const vc = raggiunge(m, false), va = raggiunge(m, true);
      if (vc[py * m.w + px]) chiusoRaggiungibile++;
      if (!va[py * m.w + px]) apertoIrraggiungibile++;
      let camb = 0; for (let i = 0; i < vc.length; i++) if (vc[i] !== va[i]) camb++;
      if (camb > 10) oltreIlVano++;          // il vano e' 9 tessere piu' la porta
    }
    assert(senzaGrata === 0, 'ogni mappa ha il suo ripostiglio chiuso');
    assert(senzaLeva === 0, 'e ogni ripostiglio ha la sua leva');
    assert(chiusoRaggiungibile === 0, 'a grata chiusa il premio NON si raggiunge (' + chiusoRaggiungibile + ' mappe bucate)');
    assert(apertoIrraggiungibile === 0, 'a grata aperta si raggiunge sempre (' + apertoIrraggiungibile + ' mappe murate)');
    assert(oltreIlVano === 0, 'e aprirla non cambia NIENTE fuori dal vano (' + oltreIlVano + ' mappe stravolte)');
  }

  // --- 4) LA LEVA APRE DAVVERO, E IL MOSTRO CI PASSA ----------------------------------------
  {
    const r = new Room('v221a'); const p = r.addPlayer('a', { send() {} }, 'A', 'barbaro'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    assert(r.grate.length === 1 && r.leve.length === 1, 'la stanza ha caricato una grata e una leva');
    const gt = r.grate[0], lv = r.leve[0];
    assert(gt.tiles.every(t => r.map.grid[t] === C.T_WALL), 'a inizio partita la grata e muro');
    assert(!r.isWallAt(gt.premio.x, gt.premio.y), 'ma dentro il vano c e pavimento gia scavato');
    assert(r.crates.some(c => MU.dist(c.x, c.y, gt.premio.x, gt.premio.y) < 2), 'e dentro c e la cassa premio');
    // il giocatore lontano non la tira
    p.x = lv.x + 400; p.y = lv.y + 400; r.updateLeve();
    assert(!lv.tirata && !gt.aperta, 'da lontano la leva non si tira da sola');
    // ci cammina addosso
    p.x = lv.x; p.y = lv.y; r.updateLeve();
    assert(lv.tirata && gt.aperta, 'camminandoci addosso la leva si tira e la grata si apre');
    assert(gt.tiles.every(t => r.map.grid[t] === C.T_FLOOR), 'e la griglia diventa pavimento');
    assert(r.events.some(e => e.t === 'grata'), 'e parte l evento che lo dice al client');
    // e adesso il campo di flusso ci passa: si ricostruisce dalla griglia, non da una copia sua
    const PF2 = require('../shared/pathfinding.js');
    const gx = (gt.premio.x / C.TILE) | 0, gy = (gt.premio.y / C.TILE) | 0;
    const px2 = (p.x / C.TILE) | 0, py2 = (p.y / C.TILE) | 0;
    const campo = PF2.build(r.map.grid, r.map.w, r.map.h, [{ gx, gy }]);
    assert(campo[py2 * r.map.w + px2] >= 0,
      'e il campo di flusso, ricostruito dalla griglia, adesso attraversa la porta');
    // tirarla due volte non deve contare due volte
    const quante = r.events.filter(e => e.t === 'grata').length;
    r.updateLeve(); r.updateLeve();
    assert(r.events.filter(e => e.t === 'grata').length === quante, 'e non si puo tirare due volte');
  }

  // --- 5) L'URNA SI ROMPE E LASCIA MONETE ---------------------------------------------------
  {
    const r = new Room('v221b'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    const u = r.oggetti.find(o => o.tipo === 'urna');
    assert(u, 'sulla mappa c e almeno un urna');
    const monete0 = r.groundCoins.length;
    r.rompiOggetto(u, p);
    assert(u.dead, 'colpita, l urna si rompe');
    assert(r.groundCoins.length > monete0, 'e lascia monete a terra (' + (r.groundCoins.length - monete0) + ')');
    assert(r.events.some(e => e.t === 'urna'), 'e l evento arriva al client');
    // rotta una volta, e' rotta: non si puo mungere
    const dopo = r.groundCoins.length; r.rompiOggetto(u, p);
    assert(r.groundCoins.length === dopo, 'e non si puo rompere due volte');
    // e sparisce dallo snapshot
    const snap = r.snapshot();
    assert(!(snap.ogg || []).some(o => o.e === u.eid), 'e sparisce dallo snapshot');
  }

  // --- 6) IL BARILE FA MALE AI MOSTRI, AI GIOCATORI, E INNESCA GLI ALTRI BARILI --------------
  {
    const r = new Room('v221c'); const p = r.addPlayer('a', { send() {} }, 'A', 'barbaro'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    r.oggetti.length = 0;
    const b1 = { eid: 90001, tipo: 'barile', x: 1000, y: 1000, s: 1, r: 15, dead: false };
    const b2 = { eid: 90002, tipo: 'barile', x: 1000 + C.BARILE_RAGGIO - 20, y: 1000, s: 1, r: 15, dead: false };
    const lontano = { eid: 90003, tipo: 'barile', x: 1000 + C.BARILE_RAGGIO * 4, y: 1000, s: 1, r: 15, dead: false };
    r.oggetti.push(b1, b2, lontano);
    const m = r.spawnMonster('skeleton', 1030, 1000, {}); const hp0 = m.hp;
    const fuori = r.spawnMonster('skeleton', 1000 + C.BARILE_RAGGIO * 3, 1000, {}); const hpF = fuori.hp;
    p.x = 1040; p.y = 1000; const pv0 = p.hp;
    r.rompiOggetto(b1, p);
    assert(b1.dead, 'il barile colpito scoppia');
    assert(m.hp < hp0, 'e fa male al mostro dentro il raggio');
    assert(fuori.hp === hpF, 'e non a quello fuori');
    assert(p.hp < pv0, 'e fa male anche a chi lo ha fatto scoppiare, se ci sta dentro');
    assert(pv0 - p.hp < hp0 - m.hp, 'ma meno che ai mostri: e un avvertimento, non una condanna');
    assert(b2.dead, 'e innesca il barile vicino');
    assert(!lontano.dead, 'e non quello lontano');
    assert(r.events.filter(e => e.t === 'barile').length === 2, 'due barili, due esplosioni, e la catena si ferma li');
  }

  // --- 7) CHI PUO' ROMPERLI, E CHI NO -------------------------------------------------------
  {
    // il fendente prende quello davanti e non quello dietro le spalle
    const r = new Room('v221d'); const p = r.addPlayer('a', { send() {} }, 'A', 'barbaro'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = []; r.oggetti.length = 0;
    const w = r.effWeapon(p); p.aim = 0;
    const davanti = { eid: 91001, tipo: 'urna', x: p.x + w.arcRadius * 0.6, y: p.y, s: 1, r: 12, dead: false };
    const dietro = { eid: 91002, tipo: 'urna', x: p.x - w.arcRadius * 0.6, y: p.y, s: 1, r: 12, dead: false };
    r.oggetti.push(davanti, dietro);
    r._meleeSwing(p, w, 10, false);
    assert(davanti.dead, 'il fendente rompe l urna che ha davanti');
    assert(!dietro.dead, 'e non quella che ha dietro le spalle');

    // il proiettile del giocatore rompe; quello del mostro no
    const r2 = new Room('v221e'); const q = r2.addPlayer('b', { send() {} }, 'B', 'ranger'); r2.startGame();
    r2.monsters.length = 0; r2.pending = 0; r2.waveList = []; r2.oggetti.length = 0; r2.bullets.length = 0;
    // sul PAVIMENTO, non a coordinate a caso: dentro la roccia il proiettile muore sul muro prima di
    // arrivare all urna, e il test misurerebbe tutt altro
    const mio = { eid: 91003, tipo: 'urna', x: q.x, y: q.y, s: 1, r: 12, dead: false };
    const suo = { eid: 91004, tipo: 'urna', x: q.x, y: q.y, s: 1, r: 12, dead: false };
    r2.oggetti.push(mio, suo);
    r2.bullets.push({ eid: 91005, hostile: false, owner: q.id, x: q.x, y: q.y, vx: 1, vy: 0, r: 6, dmg: 10, color: '#fff', life: 1, pierce: 0 });
    r2.bullets.push({ eid: 91006, hostile: true, owner: 999, x: q.x, y: q.y, vx: 1, vy: 0, r: 6, dmg: 10, color: '#f00', life: 1, pierce: 0 });
    r2.updateBullets(0.016);
    assert(mio.dead, 'il colpo del giocatore rompe l urna');
    assert(!suo.dead, 'quello del mostro no: un barile innescato da un nemico sarebbe un danno imprevedibile');
    assert(r2.oggetti.filter(o => o.dead).length === 1, 'e ne rompe UNO solo: il colpo si ferma sul primo');

    // E LA RIGA INFILATA FRA L'IF E IL SUO ELSE. Il controllo sugli oggetti era finito in mezzo al
    // ramo `if (b.hostile) ... else ...` di updateBullets, e l'else si era staccato dal suo if: i
    // proiettili OSTILI finivano nel ramo dei mostri e, nascendo addosso a chi li spara, si
    // ammazzavano da soli al primo fotogramma. Lo sputo dell acido aveva smesso di uscire.
    const r3 = new Room('v221f'); r3.addPlayer('c', { send() {} }, 'C', 'mago'); r3.startGame();
    r3.monsters.length = 0; r3.pending = 0; r3.waveList = []; r3.bullets.length = 0;
    // di nuovo: su PAVIMENTO. Lo spawn del giocatore e' l unico punto che sappiamo libero per certo —
    // ma il giocatore va tolto di li', se no il proiettile ostile colpisce LUI (che e' giusto) e il
    // test misurerebbe tutt altro. Senza questa riga falliva una volta su tre, a seconda del seme.
    const g3 = r3.map.spawn;
    for (const pl of r3.players.values()) { pl.x = g3.x + 4000; pl.y = g3.y + 4000; }
    const mo = r3.spawnMonster('skeleton', g3.x, g3.y, {}); const vita = mo.hp;
    r3.bullets.push({ eid: 91007, hostile: true, owner: mo.eid, x: g3.x, y: g3.y, vx: 1, vy: 0, r: 6, dmg: 25, color: '#0f0', life: 2, pierce: 0 });
    r3.updateBullets(0.016);
    assert(mo.hp === vita, 'un proiettile OSTILE non ferisce i mostri');
    assert(r3.bullets.length === 1 && !r3.bullets[0].dead, 'e non muore addosso a chi lo ha sparato');
  }

  // --- 8) IL PONTE: cio che il server manda, il client lo guarda ----------------------------
  {
    const r = new Room('v221g'); r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    const pieno = r.snapshot();
    assert(Array.isArray(pieno.ogg), 'lo snapshot pieno porta sempre la lista dei rompibili');
    const a = r.snapshot(true), b = r.snapshot(true);
    assert(Array.isArray(a.ogg), 'il primo snapshot magro la presenta');
    assert(!b.ogg, 'nei successivi non si ripete finche non cambia');
    const u = r.oggetti.find(o => !o.dead); if (u) r.rompiOggetto(u, null);
    assert(Array.isArray(r.snapshot(true).ogg), 'ma appena uno si rompe la lista riparte');
    const srcM = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
    assert(/w\.ogg\s*=/.test(srcM), 'e main.js la copia nel mondo interpolato');
    assert(/case 'grata'/.test(srcM) && /grateAperte\.add/.test(srcM), 'e segna la grata aperta quando arriva l evento');
    const srcR2 = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
    assert(/this\.grateAperte = new Set\(\)/.test(srcR2), 'il renderer azzera le grate aperte a ogni mappa nuova');
  }
  ok('urne, barili, grate e leve fanno quello che devono, e ogni tema ha i suoi oggetti');
}

// =================================================================================================
// v2.22 — LAMA ERRANTE E CUBO GELATINOSO: due nemici senza gambe
// =================================================================================================
function testV222() {
  console.log('\n[TEST 81] v2.22 — la Lama telegrafa il colpo, il Cubo ferma i proiettili');
  const fs = require('fs'), path = require('path');
  const ROOT = path.join(__dirname, '..') + path.sep;
  const Mon = require('../shared/monsters.js');

  // --- 1) NESSUNO DEI DUE HA UN PASSO DA DISEGNARE ------------------------------------------
  // E' il vincolo da cui nascono tutti e due (Paolo: «e difficile avere nemici che camminano
  // perche' ci sono le animazioni di movimento»). Se un domani qualcuno li marca `front` o `sheet`
  // finiscono nel ramo del billboard o dello sprite animato, e il vincolo salta senza un errore.
  for (const id of ['lama', 'cubo']) {
    const d = Mon.MONSTERS[id];
    assert(d, id + ' esiste nel roster');
    assert(!d.front && !d.sheet && !d.puppet, id + ' non passa da billboard, sprite-sheet o puppet: niente camminata');
  }
  {
    const srcR = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
    assert(/_lamaF\(ctx, m, rr, def, atk\)/.test(srcR) || /_lamaF\s*\(/.test(srcR), 'la Lama ha il suo disegno');
    assert(/_cuboF\s*\(/.test(srcR), 'il Cubo ha il suo disegno');
    assert(/def\.lama\s*\)\s*\{\s*this\._lamaF/.test(srcR), 'e il disegno della Lama e raggiunto dal dispatch');
    assert(/def\.gelatina\s*\)\s*\{\s*this\._cuboF/.test(srcR), 'e quello del Cubo pure');
  }

  // --- 2) LA LAMA FA TUTTO IL GIRO: gira → punta → carica → scatto --------------------------
  {
    const r = new Room('v222a'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = []; r.bullets.length = 0;
    const sp = r.map.spawn;
    p.x = sp.x; p.y = sp.y;
    const m = r.spawnMonster('lama', sp.x + 150, sp.y, {}); m.awake = true; m.impegnato = 1;
    const viste = new Set(); let eventi = [];
    let maxPasso = 0, prima = { x: m.x, y: m.y };
    for (let i = 0; i < 300 && !m.dead; i++) {
      r.events.length = 0;
      r.update(1 / 60);
      for (const e of r.events) if (/^lama_/.test(e.t)) eventi.push(e.t);
      if (m.fase) viste.add(m.fase);
      const passo = MU.dist(prima.x, prima.y, m.x, m.y); if (passo > maxPasso) maxPasso = passo;
      prima = { x: m.x, y: m.y };
    }
    for (const f of ['gira', 'punta', 'carica', 'scatto'])
      assert(viste.has(f), 'la Lama passa per la fase ' + f);
    assert(eventi.includes('lama_wind'), 'e annuncia la carica al client (lama_wind)');
    assert(eventi.includes('lama_go'), 'e lo scatto (lama_go)');
    assert(eventi.indexOf('lama_wind') < eventi.indexOf('lama_go'), 'e la carica arriva PRIMA dello scatto');
    assert(maxPasso > 8, 'lo scatto e uno scatto vero (' + maxPasso.toFixed(1) + ' px in un fotogramma)');
  }

  // --- 3) E LA CARICA E' UN AVVERTIMENTO, NON UN COLPO --------------------------------------
  // E' tutto il senso della creatura: mezzo secondo in cui si vede cosa sta per succedere e non
  // succede ancora niente. Se facesse male gia' in carica, il preavviso non servirebbe a nulla.
  {
    const r = new Room('v222b'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    const sp = r.map.spawn; p.x = sp.x; p.y = sp.y;
    const m = r.spawnMonster('lama', sp.x + 30, sp.y, {}); m.awake = true; m.impegnato = 1;
    m.fase = 'carica'; m.faseT = 0; m.facing = Math.PI;      // gia' addosso, gia' puntata
    const pv0 = p.hp; let dur = 0;
    for (let i = 0; i < 40 && m.fase === 'carica'; i++) { r.update(1 / 60); dur += 1 / 60; }
    assert(p.hp === pv0, 'durante la carica la Lama NON fa male: e un avvertimento');
    assert(dur > 0.35 && dur < 0.75, 'e la carica dura circa mezzo secondo (' + dur.toFixed(2) + 's)');
  }

  // --- 4) UNA LAMA A META' SCATTO NON VIENE PARCHEGGIATA ------------------------------------
  // Il tetto alla folla (v1.80) ferma chi e' di troppo e lo manda ad aspettare all anello. Ma chi e'
  // in mezzo a un'azione gia' partita e' esentato — rolling, slam, balzo. La carica e lo scatto
  // della Lama vanno nella stessa lista: senza, una spada resterebbe ferma per aria a meta stoccata.
  {
    const srcA = fs.readFileSync(ROOT + 'shared/ai.js', 'utf8');
    const riga = srcA.match(/const azione = [^;]+;/);
    assert(riga, 'la lista delle azioni gia partite esiste ancora');
    assert(/carica/.test(riga[0]) && /scatto/.test(riga[0]),
      'e comprende la carica e lo scatto della Lama');
  }

  // --- 5) IL CUBO FERMA I PROIETTILI, ANCHE QUELLI PERFORANTI -------------------------------
  {
    const r = new Room('v222c'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = []; r.bullets.length = 0; r.oggetti.length = 0;
    const sp = r.map.spawn;
    const c = r.spawnMonster('cubo', sp.x, sp.y, {}); c.awake = true;
    const hp0 = c.hp;
    // un colpo PERFORANTE: e' il caso che conta. Se lo attraversasse, il Cubo sarebbe solo un
    // mostro grosso e perderebbe l unica cosa che lo distingue.
    r.bullets.push({ eid: 95001, hostile: false, owner: p.id, x: sp.x, y: sp.y, vx: 1, vy: 0,
      r: 6, dmg: 10, color: '#fff', life: 1, pierce: 3 });
    r.updateBullets(1 / 60);
    assert(c.hp < hp0, 'il colpo ferisce il Cubo');
    assert(r.bullets.length === 0, 'e si spegne dentro, anche se era perforante');
    assert(c.assorbiti === 1, 'e il Cubo si tiene il conto dei colpi che ha dentro');
    assert(r.events.some(e => e.t === 'assorbito'), 'e lo dice al client');
    // il conto arriva nello snapshot, ed e' quello che il disegno usa per i dardi conficcati
    const snap = r.snapshot();
    const so = snap.mon.find(x => x.e === c.eid);
    assert(so && so.ab === 1, 'e viaggia nello snapshot (ab)');
    // e si dissolve: i dardi non restano piantati per sempre
    for (let i = 0; i < 400; i++) r.update(1 / 60);
    assert(!c.assorbiti, 'e col tempo i dardi si dissolvono');
  }

  // --- 6) MA UN COLPO NEMICO GLI PASSA ATTRAVERSO -------------------------------------------
  {
    const r = new Room('v222d'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = []; r.bullets.length = 0;
    const sp = r.map.spawn;
    for (const pl of r.players.values()) { pl.x = sp.x + 4000; pl.y = sp.y + 4000; }
    const c = r.spawnMonster('cubo', sp.x, sp.y, {}); c.awake = true; const hp0 = c.hp;
    r.bullets.push({ eid: 95002, hostile: true, owner: 777, x: sp.x, y: sp.y, vx: 1, vy: 0,
      r: 6, dmg: 20, color: '#f00', life: 2, pierce: 0 });
    r.updateBullets(1 / 60);
    assert(c.hp === hp0, 'il Cubo non assorbe i colpi dei mostri: quelli non sono roba sua');
    assert(r.bullets.length === 1, 'e il colpo nemico prosegue');
  }

  // --- 7) E QUANDO SI SCIOGLIE RESTITUISCE QUELLO CHE AVEVA INGHIOTTITO ----------------------
  // Dentro il Cubo si vede il bottino di chi ci e' finito prima. Se morendo non lo lasciasse,
  // quel disegno sarebbe una bugia.
  {
    const r = new Room('v222e'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = []; r.groundCoins.length = 0;
    r.wave = 5;
    const sp = r.map.spawn;
    const c = r.spawnMonster('cubo', sp.x, sp.y, {}); c.awake = true;
    r.killMonster(c, p);
    assert(r.groundCoins.length > 0, 'sciogliendosi lascia monete a terra (' + r.groundCoins.length + ')');
    assert(r.events.some(e => e.t === 'cubo_sciolto'), 'e l evento arriva al client');
    // e deve pagare MOLTO piu' di un mostro qualunque: ogni mostro lascia gia' le sue monete morendo,
    // quindi "lascia monete" da solo non direbbe niente. Dieci morti per parte, perche' il singolo
    // drop ha la sua forbice casuale.
    const somma = (id) => { let tot = 0;
      for (let i = 0; i < 10; i++) {
        const rx = new Room('v222f' + i); const qx = rx.addPlayer('b', { send() {} }, 'B', 'ranger'); rx.startGame();
        rx.monsters.length = 0; rx.pending = 0; rx.waveList = []; rx.groundCoins.length = 0; rx.wave = 5;
        const mm = rx.spawnMonster(id, rx.map.spawn.x, rx.map.spawn.y, {});
        rx.killMonster(mm, qx);
        for (const c2 of rx.groundCoins) tot += c2.v;
      } return tot; };
    const oroCubo = somma('cubo'), oroZombi = somma('skeleton');
    assert(oroCubo > oroZombi * 2, 'e paga molto piu di uno Zombie Putrido (' + oroCubo + ' contro ' + oroZombi + ')');
  }

  // --- 8) IL PONTE COL CLIENT ---------------------------------------------------------------
  {
    const srcM = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
    for (const ev of ['lama_wind', 'lama_go', 'lama_muro', 'assorbito', 'cubo_sciolto'])
      assert(srcM.indexOf("case '" + ev + "'") >= 0, 'il client sa cosa fare con l evento ' + ev);
  }
  ok('la Lama telegrafa e scatta, il Cubo ferma i colpi e restituisce il bottino');
}

// =================================================================================================
// v2.23 — IL PADRONE: marionetta dal disegno di Paolo, comando ai vicini, frusta e condanna
// =================================================================================================
function testV223() {
  console.log('\n[TEST 82] v2.23 — Il Padrone: comanda, frusta da presso, condanna da lontano');
  const fs = require('fs'), path = require('path');
  const ROOT = path.join(__dirname, '..') + path.sep;
  const Mon = require('../shared/monsters.js');

  // --- 1) LA MARIONETTA E' COMPLETA E COERENTE ----------------------------------------------
  // Un pezzo dichiarato nel rig ma senza il suo PNG non da' nessun errore: il renderer fa
  // `if (!p || !img) continue` e quel pezzo semplicemente non si vede. E' lo stesso silenzio
  // della cassa invisibile della v2.21, e questo controllo serve a non ripeterlo.
  {
    const dir = ROOT + path.join('public', 'assets', 'enemies', 'padrone') + path.sep;
    assert(fs.existsSync(dir + 'padrone.json'), 'il rig del Padrone c e');
    const rig = JSON.parse(fs.readFileSync(dir + 'padrone.json', 'utf8'));
    assert(rig.parts.length === 8, 'ha i suoi otto pezzi (' + rig.parts.length + ')');
    for (const p of rig.parts) {
      assert(fs.existsSync(dir + p.name + '.png'), 'il pezzo ' + p.name + ' ha il suo PNG');
      assert(p.w > 0 && p.h > 0, p.name + ' ha misure valide');
      assert(p.ox >= 0 && p.ox <= p.w && p.oy >= 0 && p.oy <= p.h,
        'il perno di ' + p.name + ' cade dentro il pezzo (' + p.ox + ',' + p.oy + ' su ' + p.w + 'x' + p.h + ')');
    }
    assert(rig.charH > 0 && rig.feetY > rig.charH, 'altezza e riga dei piedi sono coerenti');
    // e il renderer deve conoscerli tutti: un pezzo fuori dall ordine di disegno non viene mai messo giu'
    const srcR = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
    const mo = srcR.match(/padrone: \{[\s\S]*?order: \[([^\]]*)\]/);
    assert(mo, 'il profilo di animazione del Padrone esiste');
    const ordine = mo[1].split(',').map(s => s.trim().replace(/'/g, ''));
    for (const p of rig.parts)
      assert(ordine.includes(p.name), 'il pezzo ' + p.name + ' compare nell ordine di disegno');
    assert(ordine.length === rig.parts.length, 'e l ordine non nomina pezzi che non esistono');
    assert(/padrone: makePuppet\(/.test(srcR), 'la marionetta e registrata fra i puppet');
    assert(/shape === 'padrone'\) this\._puppet\('padrone'/.test(srcR),
      'e il dispatch frontale la raggiunge: senza questa riga il disegno non parte e basta');
    assert(/ali: true/.test(srcR), 'e dichiara le ali disegnate in codice');
  }

  // --- 2) IL COMANDO: chi e dentro va piu forte, chi e fuori no ------------------------------
  {
    const r = new Room('v223a'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    const sp = r.map.spawn;
    const pad = r.spawnMonster('padrone', sp.x, sp.y, {}); pad.awake = true;
    const R = Mon.MONSTERS.padrone.comandoR;
    const dentro = r.spawnMonster('skeleton', sp.x + R * 0.5, sp.y, {});
    const fuori  = r.spawnMonster('skeleton', sp.x + R * 2.5, sp.y, {});
    const altro  = r.spawnMonster('padrone', sp.x + R * 0.4, sp.y, {});
    r.applicaComando();
    assert(dentro.cmdV > 1 && dentro.cmdD > 1, 'il mostro dentro il raggio e comandato');
    assert(fuori.cmdV === 1 && fuori.cmdD === 1, 'quello fuori no');
    assert(altro.cmdV === 1, 'e un Padrone non comanda un altro Padrone: sarebbe una moltiplicazione');
    assert(pad.cmdV === 1, 'ne se stesso');
    // e il potenziamento arriva davvero al danno, non e solo un numero appoggiato sul mostro
    const ctx = r.makeCtx();
    p.hp = p.maxHp; const pv0 = p.hp;
    ctx.melee(fuori, p, 20, 0); const normale = pv0 - p.hp;
    p.hp = p.maxHp; const pv1 = p.hp;
    ctx.melee(dentro, p, 20, 0); const comandato = pv1 - p.hp;
    assert(comandato > normale, 'e chi e comandato picchia piu forte (' + comandato + ' contro ' + normale + ')');
    // morto il Padrone, il comando si spegne
    r.killMonster(pad, p); r.killMonster(altro, p); r.applicaComando();
    assert(dentro.cmdV === 1 && dentro.cmdD === 1, 'e appena il Padrone cade il comando finisce');
  }

  // --- 3) NON E SOLO UN AURA: DA VICINO FRUSTA ----------------------------------------------
  {
    const r = new Room('v223b'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    const sp = r.map.spawn; p.x = sp.x + 80; p.y = sp.y;
    const m = r.spawnMonster('padrone', sp.x, sp.y, {}); m.awake = true; m.impegnato = 1; m.atkT = 0;
    const viste = new Set(); const ev = [];
    const pv0 = p.hp;
    for (let i = 0; i < 260 && !m.dead; i++) {
      r.events.length = 0; p.x = sp.x + 80; p.y = sp.y;      // resta addosso: deve scegliere la frusta
      r.update(1 / 60);
      for (const e of r.events) if (/^padrone_/.test(e.t)) ev.push(e.t);
      if (m.pf) viste.add(m.pf);
      if (ev.includes('padrone_frusta')) break;
    }
    assert(viste.has('carica'), 'da vicino il Padrone carica la frusta');
    assert(ev.includes('padrone_wind'), 'e annuncia la carica al client');
    assert(ev.includes('padrone_frusta'), 'e poi sferza');
    assert(ev.indexOf('padrone_wind') < ev.indexOf('padrone_frusta'), 'la carica arriva PRIMA della sferzata');
    assert(p.hp < pv0, 'e la sferzata fa male davvero (' + (pv0 - p.hp) + ' danni)');
  }

  // --- 4) E DA LONTANO CONDANNA -------------------------------------------------------------
  {
    const r = new Room('v223c'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = []; r.zones.length = 0;
    const sp = r.map.spawn;
    const m = r.spawnMonster('padrone', sp.x, sp.y, {}); m.awake = true; m.impegnato = 1; m.atkT = 0;
    m.speed = 0;                                             // fermo: qui si misura la scelta, non la corsa
    const D = Mon.MONSTERS.padrone;
    // v2.24 — IL POSTO DOVE METTERE IL GIOCATORE LO CERCO, non lo do per scontato. Prima era
    // «trecento pixel a destra», e su una mappa a caso trecento pixel a destra ogni tanto e' roccia:
    // il Padrone non vedeva nessuno, non puntava, e il test diventava rosso per colpa della mappa.
    let px = 0, py = 0, trovato = false;
    for (let k = 0; k < 96 && !trovato; k++) {
      const a = (k / 96) * Math.PI * 2, dd = D.condannaMin + 60;
      const x = sp.x + Math.cos(a) * dd, y = sp.y + Math.sin(a) * dd;
      if (!r.isWallAt(x, y) && r.losClear(sp.x, sp.y, x, y)) { px = x; py = y; trovato = true; }
    }
    assert(trovato, 'c e un punto libero a distanza di condanna da cui farsi vedere');
    const ev = [];
    for (let i = 0; i < 400 && !m.dead; i++) {
      // il giocatore resta OLTRE la distanza della condanna
      p.x = px; p.y = py;
      r.events.length = 0; r.update(1 / 60);
      for (const e of r.events) if (/^padrone_/.test(e.t)) ev.push(e.t);
      if (ev.includes('padrone_condanna')) break;
    }
    assert(ev.includes('padrone_punta'), 'da lontano il Padrone punta il bersaglio');
    assert(ev.includes('padrone_condanna'), 'e apre la condanna');
    assert(!ev.includes('padrone_frusta'), 'e da lontano NON frusta: i due attacchi si scelgono per distanza');
    assert(r.zones.length > 0, 'e la zona a terra esiste davvero');
    const z = r.zones[r.zones.length - 1];
    assert(MU.dist(z.x, z.y, p.x, p.y) < 90, 'e si apre SOTTO il bersaglio, non addosso al Padrone');
    assert(z.t > 0.5, 'e ha il suo ritardo: e un avvertimento, non un colpo istantaneo');
  }

  // --- 5) UN PADRONE A META COLPO NON VIENE PARCHEGGIATO -------------------------------------
  {
    const srcA = fs.readFileSync(ROOT + 'shared/ai.js', 'utf8');
    const riga = srcA.match(/const azione = [^;]+;/);
    assert(riga && /pf === 'carica'/.test(riga[0]) && /pf === 'sferza'/.test(riga[0]),
      'carica e sferzata stanno fra le azioni esenti dal tetto alla folla');
  }

  // --- 6) L ONDATA E IL PONTE COL CLIENT ----------------------------------------------------
  {
    const at = (w) => Waves.poolForWave(w).map(x => x.id);
    assert(!at(14).includes('padrone') && at(15).includes('padrone'), 'entra alla quindicesima');
    const d = Mon.MONSTERS.padrone;
    assert(d.maxAlive && d.maxAlive <= 2, 'e non se ne vedono piu di due per volta');
    const r = new Room('v223d'); r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.monsters.length = 0; r.pending = 0; r.waveList = [];
    const sp = r.map.spawn;
    const pad = r.spawnMonster('padrone', sp.x, sp.y, {});
    const sk = r.spawnMonster('skeleton', sp.x + 40, sp.y, {});
    r.applicaComando();
    const so = r.snapshot().mon.find(x => x.e === sk.eid);
    assert(so && so.cm === 1, 'e chi e comandato lo dice allo snapshot (cm)');
    const srcM = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
    for (const e of ['padrone_wind', 'padrone_frusta', 'padrone_punta', 'padrone_condanna'])
      assert(srcM.indexOf("case '" + e + "'") >= 0, 'il client sa cosa fare con l evento ' + e);
    const srcR = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
    assert(/def\.comandoR\)/.test(srcR), 'e il renderer disegna il raggio del comando');
    assert(/if \(m\.cm\)/.test(srcR), 'e il bordo acceso su chi e comandato');
  }
  ok('il Padrone comanda i suoi, frusta da presso e condanna da lontano');
}

// =================================================================================================
// v2.24 — IL RITMO DELLE ONDATE: tetto basso, riserve che entrano in blocco
// =================================================================================================
// L'azzardo di Paolo, parola sua: «i nemici contemporanei non possono essere piu' di 14, in totale
// nelle ondate successive alla sesta saranno 20 con 6 riserve che entreranno quando i nemici rimasti
// sono 7». In due: 16 in campo e 24 in totale. E: «nei livelli avanzati voglio varieta', quindi
// devono entrare tutti i nemici».
// Tre cose da difendere, e sono indipendenti: il TETTO, il TOTALE, la VARIETA'. La quarta e' la
// pausa in mezzo, che e' la vera novita': prima il campo restava incollato al tetto dal primo
// all'ultimo secondo, perche' a ogni morto ne rientrava subito un altro.
function testV224() {
  console.log('\n[TEST 83] v2.24 — quattordici in campo, venti in tutto, le riserve aspettano');
  const Mon = require('../shared/monsters.js');
  const dt = 1 / C.TICK_RATE;

  // --- 1) I NUMERI SONO QUELLI CHE HA DETTO PAOLO ------------------------------------------
  assert(C.MAX_ALIVE === 14, 'in campo, da soli, mai piu di 14 (' + C.MAX_ALIVE + ')');
  assert(C.MAX_ALIVE_GIOC === 2, 'e +2 per ogni giocatore in piu: 16 in due');
  assert(C.ONDATA_TOT === 20, 'il totale dell ondata e 20 (' + C.ONDATA_TOT + ')');
  assert(C.ONDATA_TOT_GIOC === 4, 'e +4 per giocatore: 24 in due');
  assert(C.ONDATA_TOT_DA === 7, 'e vale dalla settima ondata in poi');
  {
    const r1 = new Room('v224n1'); r1.addPlayer('a', { send() {} }, 'A', 'ranger'); r1.startGame();
    assert(r1.tettoVivi() === 14, 'in solitario il tetto e 14 (' + r1.tettoVivi() + ')');
    assert(r1.sogliaRiserve() === 7, 'e le riserve entrano quando ne restano 7 (' + r1.sogliaRiserve() + ')');
    const r2 = new Room('v224n2');
    r2.addPlayer('a', { send() {} }, 'A', 'ranger'); r2.addPlayer('b', { send() {} }, 'B', 'mago');
    r2.startGame();
    assert(r2.tettoVivi() === 16, 'in due il tetto e 16 (' + r2.tettoVivi() + ')');
    assert(r2.sogliaRiserve() === 8, 'e la soglia si alza con lui (' + r2.sogliaRiserve() + ')');
  }

  // --- 2) IL TOTALE E' FISSO DALLA SETTIMA IN POI ------------------------------------------
  // Prima cresceva con l'ondata: alla 18 arrivavano quaranta nemici e la partita diventava una
  // questione di resistenza. Adesso dalla settima in poi il numero e' sempre quello e a cambiare
  // e' CHI arriva, non quanti.
  for (const w of [7, 10, 13, 15, 18, 22]) {
    if (Waves.isBossWave(w)) continue;
    const tot1 = Waves.buildWave(w, 1).list.length;
    const tot2 = Waves.buildWave(w, 2).list.length;
    assert(tot1 === C.ONDATA_TOT, 'ondata ' + w + ' da solo: ' + tot1 + ' nemici in tutto');
    assert(tot2 === C.ONDATA_TOT + C.ONDATA_TOT_GIOC, 'ondata ' + w + ' in due: ' + tot2);
  }
  // e prima della settima resta la rampa: le prime ondate devono essere piccole
  assert(Waves.buildWave(1, 1).list.length < C.ONDATA_TOT, 'la prima ondata resta piccola (' + Waves.buildWave(1, 1).list.length + ')');

  // --- 3) LA VARIETA': NEI LIVELLI ALTI CI DEVE ESSERE DI TUTTO ----------------------------
  // Venti nemici presi a caso da un sacchetto pesato vuol dire, in pratica, sei Zombi e quattro
  // Pipistrelli: il tetto piu' basso RIDUCE i nemici, e se non si fa niente riduce anche i tipi.
  // Per questo l'ondata semina prima uno di ogni tipo disponibile, e solo dopo riempie a peso.
  for (const w of [15, 18]) {
    if (Waves.isBossWave(w)) continue;
    const pool = Waves.poolForWave(w).map(x => x.id);
    const tipi = new Set(Waves.buildWave(w, 1).list.map(x => x.type));
    assert(tipi.size >= Math.min(pool.length, C.ONDATA_TOT - 3),
      'ondata ' + w + ': ci sono ' + tipi.size + ' tipi diversi su ' + pool.length + ' disponibili');
  }
  // e non e' una fila ordinata: l ordine di ingresso cambia da una partita all altra
  {
    let diverse = 0;
    for (let k = 0; k < 8; k++) {
      const a = Waves.buildWave(15, 1).list.map(x => x.type).join(',');
      const b = Waves.buildWave(15, 1).list.map(x => x.type).join(',');
      if (a !== b) diverse++;
    }
    assert(diverse >= 6, 'e l ordine di ingresso e mescolato, non sempre lo stesso (' + diverse + '/8)');
  }

  // --- 4) LA PAUSA IN MEZZO: le riserve NON entrano a goccia --------------------------------
  // Stanza pulita, un tipo solo e innocuo: niente Negromanti che evocano e niente Melme che si
  // dividono, cosi' i posti in campo li libera e li occupa solo la coda, e la regola si vede nuda.
  {
    const r = new Room('v224p'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.wave = 8; r.nextWave();
    r.monsters.length = 0; r.bullets.length = 0;
    const TOT = 20;
    r.pending = TOT; r.waveList = Array.from({ length: TOT }, () => ({ type: 'skeleton' }));
    r.riserveAperte = false; r.caricoFatto = false;
    const vivi = () => r.monsters.filter(x => !x.dead).length;
    let visteRiserve = false;
    const gira = (sec) => { for (let i = 0; i < C.TICK_RATE * sec; i++) {
      p.hp = 1e9; r.setInput('a', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
      r.update(dt);
      if (r.events.some(e => e.t === 'riserve')) visteRiserve = true; } };

    // il primo carico riempie il campo fino al tetto, e li si ferma
    gira(20);
    assert(vivi() === r.tettoVivi(), 'il primo carico riempie il campo (' + vivi() + ' su ' + r.tettoVivi() + ')');
    assert(r.pending === TOT - r.tettoVivi(), 'e il resto resta in riserva (' + r.pending + ')');
    assert(r.caricoFatto, 'e il primo carico risulta chiuso');
    assert(!r.riserveAperte, 'le riserve sono ancora ferme');

    // ne muoiono alcuni ma non abbastanza: il campo ha posti liberi e la coda NON si muove.
    // E' il cuore della v2.24: prima, con un posto libero, ne entrava subito un altro.
    const codaPrima = r.pending;
    while (vivi() > r.sogliaRiserve() + 3) { const v = r.monsters.find(x => !x.dead); if (!v) break; r.killMonster(v, null); }
    gira(8);
    assert(vivi() < r.tettoVivi(), 'ci sono posti liberi in campo (' + vivi() + ' su ' + r.tettoVivi() + ')');
    assert(vivi() > r.sogliaRiserve(), 'ma siamo ancora sopra la soglia (' + vivi() + ' > ' + r.sogliaRiserve() + ')');
    assert(r.pending === codaPrima, 'e la coda NON si muove: qui si respira (' + codaPrima + ' -> ' + r.pending + ')');
    assert(!r.riserveAperte, 'e le riserve restano chiuse');

    // scesi alla soglia, si aprono — e lo dicono al client
    while (vivi() > r.sogliaRiserve()) { const v = r.monsters.find(x => !x.dead); if (!v) break; r.killMonster(v, null); }
    gira(12);
    assert(r.riserveAperte, 'arrivati a ' + r.sogliaRiserve() + ' le riserve si aprono');
    assert(visteRiserve, 'e l evento arriva al client');
    { const fs = require('fs'), path = require('path');
      const srcM = fs.readFileSync(path.join(__dirname, '..', 'public', 'js', 'main.js'), 'utf8');
      assert(srcM.indexOf("case 'riserve'") >= 0, 'e il client sa cosa farne: lo annuncia'); }
    assert(r.pending === 0, 'ed entrano tutte (' + r.pending + ' rimaste)');
    assert(vivi() <= r.tettoVivi(), 'senza mai sfondare il tetto (' + vivi() + ')');
  }

  // --- 5) E IL TETTO VALE ANCHE QUANDO LE RISERVE SONO APERTE -------------------------------
  // Una volta aperte restano aperte per tutta l'ondata: se il tetto non le fermasse piu', l'ultima
  // parte dell'ondata diventerebbe l'ammasso che questa versione doveva togliere.
  {
    const r = new Room('v224t'); const p = r.addPlayer('a', { send() {} }, 'A', 'ranger'); r.startGame();
    r.wave = 8; r.nextWave();
    r.monsters.length = 0;
    r.pending = 40; r.waveList = Array.from({ length: 40 }, () => ({ type: 'skeleton' }));
    r.riserveAperte = true; r.caricoFatto = true;          // il caso peggiore: coda spalancata
    let picco = 0;
    for (let i = 0; i < C.TICK_RATE * 40; i++) {
      p.hp = 1e9; r.setInput('a', { mx: 0, my: 0, aim: 0, shoot: false, q: false, e: false, dash: false });
      r.update(dt);
      picco = Math.max(picco, r.monsters.filter(x => !x.dead).length);
    }
    assert(picco <= r.tettoVivi(), 'col tetto a ' + r.tettoVivi() + ', anche a coda aperta il picco e ' + picco);
    assert(r.pending > 0, 'e quello che non ci sta resta in coda (' + r.pending + ')');
  }

  // --- 6) I TRE RITOCCHI AI NEMICI ----------------------------------------------------------
  // Paolo, insieme all azzardo: «sistema il diavolo, fallo fluttuare con le gambe ferme e la frusta
  // che colpisce il personaggio. La spada mi sembra troppo grossa, riducila».
  {
    const fs = require('fs'), path = require('path');
    const ROOT = path.join(__dirname, '..') + path.sep;
    assert(Mon.MONSTERS.lama.radius < 14, 'la Lama e stata rimpicciolita (raggio ' + Mon.MONSTERS.lama.radius + ', era 14)');
    assert(Mon.MONSTERS.padrone.fluttua > 0, 'il Padrone fluttua: l ombra resta a terra staccata');
    const srcR = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
    const i0 = srcR.indexOf('padrone: {');
    const prof = srcR.slice(i0, i0 + 3000);
    assert(i0 > 0 && /gait:\s*'float'/.test(prof), 'e il suo profilo dice che galleggia, non che cammina');
    // LE GAMBE FERME. Paolo: «le gambe devono restare ferme altrimenti sembra una marionetta appena».
    // Se un domani qualcuno rimette la falcata, il demone torna a sembrare di cartone.
    assert(!/P\.gambaSx\s*=\s*\[W\.leg/.test(prof) && !/P\.gambaDx\s*=\s*\[W\.leg/.test(prof),
      'e nella marcia le gambe non si muovono');
  }
  ok('quattordici in campo, venti in tutto, e in mezzo si respira');
}

testMapThemes(); testLives(); testBoons(); testWeaponEvo(); testModes(); testHitstop(); testXpItems(); testV16(); testV17(); testV18(); testV19(); testV110(); testV111(); testV112(); testV113(); testV139(); testV142(); testV143(); testV145(); testV147(); testV149(); testV150(); testV151(); testV152(); testV153(); testV157(); testV158(); testV159(); testV160(); testV161(); testV162(); testV163(); testV164(); testV166(); testV167(); testV168(); testV169(); testV170(); testV171(); testV172(); testV173(); testV174(); testV1741(); testV175(); testV1752(); testV1761(); testV177(); testV178(); testV179(); testV1791(); testV1792(); testBeholder179(); testV180(); testV181(); testV182(); testV183(); testV184(); testV185(); testV188(); testV189(); testV193(); testV197(); testV199(); testV200(); testStoria(); testSceltePannello(); testSalvataggio(); testSchermataUnica(); testV219(); testSoglie(); testDueMani(); testZombie(); testFendente(); testScarica(); testPassive220(); testMenu2201(); testV221(); testV222(); testV223(); testV224(); testPonteClient(); testSanity(); testFullRun(1, 'solo'); testFullRun(3, 'trio'); testFullRun(6, 'stress');
console.log('\n=================================================='); console.log(`  RISULTATO: ${PASS} passati, ${FAIL} falliti  (${((Date.now() - T0) / 1000).toFixed(1)}s)`); console.log('==================================================');
process.exit(FAIL > 0 ? 1 : 0);
