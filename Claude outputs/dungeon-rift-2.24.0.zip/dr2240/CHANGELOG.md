# 📜 CHANGELOG — DUNGEON RIFT

Tutte le modifiche rilevanti del progetto, versione per versione (dalla più recente).

### [2.24.0] — 2026-09-26 · "L'azzardo: quattordici in campo, e in mezzo si respira"

Paolo, dopo aver visto la tabella delle ondate: *«allora facciamo un azzardo: i nemici contemporanei
non possono essere più di 14, in totale nelle ondate successive alla sesta saranno 20 con 6 riserve
che entreranno quando i nemici rimasti sono 7. Questo in solitaria, mentre in 2 diventa 16. Non fare
calcoli per 4 giocatori, tanto per ora non arriviamo a quel numero. Ovviamente nei livelli avanzati
voglio varietà, quindi devono entrare tutti i nemici»*.

Ed è un azzardo davvero, perché tocca **tre numeri che reggevano il gioco dalla v1.0**: quanti
nemici, quando arrivano, e chi sono.

---

### 📉 Il tetto: da 40 a 14

Il tetto ai vivi in campo era **40**. Non era una scelta di gioco, era una valvola di sicurezza
messa nella v1.80 perché il motore non affogasse: tanto alto che nella pratica non si attivava quasi
mai. Il numero di nemici lo decideva la curva delle ondate, e alla ventesima erano **42**.

Adesso il tetto è **14 in solitario, +2 per ogni giocatore in più** (16 in due). E non è più una
valvola: è la regola.

| | prima | adesso |
|---|---|---|
| in campo, da solo | fino a 40 (di fatto: tutti) | **14** |
| in campo, in due | fino a 40 | **16** |
| totale ondata 18, da solo | 39 | **20** |
| totale ondata 18, in due | 47 | **24** |

---

### ⏸️ La cosa che cambia davvero: la pausa

Il tetto da solo non bastava. Fino alla v2.23 la coda funzionava **uno per uno**: appena un mostro
moriva, ne entrava subito un altro a prendere il suo posto. Il campo restava incollato al tetto dal
primo all'ultimo secondo dell'ondata, e l'unica cosa che cambiava era il numero sul contatore.

Adesso l'ondata ha **due tempi**:

1. **il carico** — entrano fino a riempire il campo (14), e lì la coda **si chiude**;
2. **l'attesa** — si combatte quello che c'è. Ne muoiono, il campo si svuota, e **non entra
   nessuno**. È il momento in cui si raccolgono le monete, si beve, si sceglie dove mettersi;
3. **le riserve** — scesi a **7** (metà tetto), la coda si riapre e rientra il resto.

Quella pausa è tutto il punto della versione. Prima non esisteva: non c'era un solo istante,
dall'inizio alla fine dell'ondata, in cui il campo non fosse pieno.

E siccome una pausa senza spiegazione sembra un'ondata finita male, quando le riserve si aprono
**arriva un avviso**: *«⚠ Riserve in arrivo — altri N»*. Senza, il giocatore vede il campo svuotarsi,
si rilassa, e viene preso alle spalle senza capire perché.

---

### 🎲 La varietà non poteva pagare il taglio

Questo è il pezzo che la richiesta di Paolo rendeva obbligatorio, ed è il meno ovvio.

Tagliare da 40 a 20 non riduce solo **quanti** nemici arrivano: riduce **quanti tipi diversi**.
L'ondata pescava da un sacchetto pesato, e con venti estrazioni su un mazzo di diciassette tipi, in
pratica uscivano sei Zombi, quattro Pipistrelli e tre o quattro dei rari. Il Padrone, il Cubo, lo
Spettrale sarebbero comparsi **una volta ogni tre ondate**. Il bestiario ci sarebbe stato, ma non si
sarebbe più visto.

Quindi l'ondata adesso **semina prima uno di ogni tipo disponibile**, e solo dopo riempie i posti
rimasti a sorte pesata. I pesi non decidono più *chi c'è*: decidono *chi si ripete*. Poi mescola,
perché senza mescolata i primi a entrare sarebbero sempre gli stessi nello stesso ordine.

Misurato: alla quindicesima ondata entrano **17 tipi diversi** su 17 disponibili. Prima della v2.24,
alla stessa ondata, erano otto.

---

### 📊 La tabella, ondata per ondata

| ondata | totale (1g / 2g) | in campo (1g / 2g) | tipi diversi |
|---|---|---|---|
| 1 | 12 / 14 | 12 / 14 | 1 |
| 2 | 13 / 16 | 13 / 16 | 3 |
| 3 | 15 / 18 | 14 / 16 | 4 |
| 4 | 16 / 20 | 14 / 16 | 5 |
| 5 | 18 / 22 | 14 / 16 | 6 |
| 6 | 20 / 24 | 14 / 16 | 8 |
| 7 | 20 / 24 | 14 / 16 | 9 |
| 8 | 20 / 24 | 14 / 16 | 11 |
| 9 | 20 / 24 | 14 / 16 | 12 |
| **10** | **BOSS** | — | — |
| 11 | 20 / 24 | 14 / 16 | 15 |
| 12 | 20 / 24 | 14 / 16 | 16 |
| 13 | 20 / 24 | 14 / 16 | 16 |
| 14 | 20 / 24 | 14 / 16 | 16 |
| 15 | 20 / 24 | 14 / 16 | **17** |
| 16–19 | 20 / 24 | 14 / 16 | 17 |
| **20** | **BOSS** | — | — |

Fino alla sesta resta la rampa di prima, solo tagliata allo stesso tetto. Dalla settima in poi il
numero è fisso: a cambiare è **chi** arriva, non quanti.

---

### 🐞 Il bug che ho scritto e poi tolto

Il primo carico lo chiudevo **contando quanti erano usciti dalla coda**: quando le uscite
raggiungevano il tetto, il carico era finito. Sbagliato. Un Negromante che evoca e una Melma che si
divide occupano un posto in campo che la **coda non ha speso**: il campo arriva a quattordici con
tredici usciti dalla coda, il contatore non raggiunge mai il suo numero, e il primo carico non si
chiude mai — la coda resta aperta per sempre e la pausa non arriva.

Adesso il carico si chiude guardando **quanti sono in campo**, non quanti sono usciti. È la stessa
lezione della v2.21: contare la cosa che ti interessa davvero, non una che di solito le somiglia.

---

### 🔧 E i tre ritocchi ai nemici

Sempre nello stesso messaggio di Paolo: *«sistema il diavolo, fallo fluttuare con le gambe ferme e
la frusta che colpisce il personaggio. La spada (intendo il nemico) mi sembra troppo grossa,
riducila»*.

**Il Padrone fluttua.** Le gambe non fanno più la falcata — Paolo: *«le gambe devono restare ferme
altrimenti sembra una marionetta appena»*, e aveva ragione: due pezzi raster tagliati da un disegno
piatto che si alternano sono esattamente la cosa che fa vedere il cartone. Il corpo si alza di un
pezzo fisso e **l'ombra resta a terra dov'era**: è quel distacco, non il dondolio, a dire che i
piedi non toccano. Il movimento adesso lo raccontano l'inclinazione in avanti e le ali, che battono
più forte quando avanza.

**La frusta arriva addosso.** Il cerchio del danno si apriva a distanza fissa dal Padrone: se il
giocatore era più vicino, l'arco gli passava *oltre* e non lo toccava. Adesso il centro del colpo va
alla distanza del bersaglio, fermata al raggio massimo della frusta.

**La Lama è più piccola**: raggio da 14 a 11, e il disegno rimpicciolito di conseguenza.

---

### 🧪 Numeri e file toccati

**Test: 5093 passati, 0 falliti.** Il solo TEST 83 ne porta **40**; il resto della differenza
sta nel TEST 35, riscritto sulla regola nuova.

Cinque sabotaggi deliberati per verificare che i controlli mordano:

| cosa ho rotto apposta | il test se n'è accorto |
|---|---|
| le riserve tornano a entrare a goccia | ✅ 6 controlli rossi |
| tetto di nuovo a 40 | ✅ 6 controlli rossi |
| tolta la semina uno-per-tipo | ✅ 4 controlli rossi (fra cui la curva dell'esperienza) |
| rimessa la falcata al Padrone | ✅ 1 controllo rosso |
| la Lama torna a raggio 14 | ✅ 1 controllo rosso |

**Due test erano rossi a intermittenza, e non per colpa del gioco.** Vale la pena dirlo perché sono
due modi diversi di scrivere un test fragile:

- la carica del **Colosso** (TEST 66) girava su un seme unico condiviso da tutto il blocco: cambiando
  la composizione delle ondate è cambiato il numero di sorteggi fatti prima, il punto di partenza si
  è spostato e la carica non partiva più. Adesso quel pezzo ha **un seme suo** e non dipende da cosa
  succede sopra;
- la **condanna del Padrone** (TEST 82) metteva il giocatore «trecento pixel a destra», e su una
  mappa generata a caso trecento pixel a destra ogni tanto è roccia: niente linea di vista, niente
  bersaglio. Adesso il punto **lo cerca** fra quelli liberi e in vista;
- **Mano Fredda** (TEST 79) sparava tre colpi per vedere il conto salire, ma tre colpi alzano il
  conto abbastanza da far uscire un critico vero, che lo azzera: il test inciampava proprio nel
  meccanismo che stava misurando. Adesso ne spara **uno**.

| file | cosa |
|---|---|
| `shared/constants.js` | `MAX_ALIVE` 40→14, `MAX_ALIVE_GIOC`, `ONDATA_TOT`, `ONDATA_TOT_GIOC`, `ONDATA_TOT_DA`, `RISERVE_SOGLIA_Q`; versione |
| `shared/waves.js` | totale fisso dalla settima, semina uno-per-tipo, mescolata finale |
| `server/Room.js` | `tettoVivi()`, `sogliaRiserve()`, `_puoSpawnare()` (i due tempi dell'ondata), l'evento `riserve`; la frusta del Padrone che arriva a distanza del bersaglio |
| `shared/monsters.js` | Lama a raggio 11; `fluttua` al Padrone |
| `public/js/renderer.js` | Padrone: `gait: 'float'`, gambe ferme, corpo alzato con l'ombra a terra; Lama rimpicciolita |
| `public/js/main.js` | l'avviso delle riserve |
| `test/simulate.js` | TEST 83; TEST 35 riscritto sulla regola nuova; tre test resi stabili |

**Ancora rosso, e non è di questa versione**: `test/client.js` è rotto dalla v2.19.9 e non parte,
quindi `npm test` resta rosso anche con `simulate.js` verde.

---

### [2.23.0] — 2026-09-26 · "Il Padrone"

Paolo, dopo aver bocciato il mio demone disegnato in codice: *«insomma il padrone così così, ti
allego un'immagine fatta da me, riesci a usarla come modello? Puoi creare una marionetta come zombie
e mago, togli le ali e aggiungile fatte da te. Aggiungi parti in movimento per renderlo credibile.
Come zombie e mago resta sempre frontale, non può girarsi»*.

**Una scoperta che ha deciso tutto: il formato combaciava già.** Le marionette del gioco lavorano su
una tela larga 1024 con `originX: 512` e i piedi verso `y≈1410`. Il disegno di Paolo è **1024×1536
con i piedi a y≈1519**. Non serviva adattare niente: entrava nella pipeline esistente così com'era.

---

### 🔪 Tagliare un disegno piatto in otto pezzi

Il ritaglio dal fondo è passato per **tre tentativi**, e i primi due vanno raccontati perché dicono
qual è il problema vero.

**Soglia sulla luminosità** — fallita. Il fondo è una sfumatura rosso cupo, ma il personaggio ha le
sue ombre e il contorno a inchiostro nello stesso identico intervallo di luminosità. La soglia si è
mangiata metà dell'armatura.

**Bacchetta magica contigua** — peggio. Entrando in un pixel solo se somiglia al precedente, la
visita scivola lungo la sfumatura… e poi passa *attraverso* la linea di contorno scura, perché anche
quella somiglia al fondo. Ha divorato le membrane delle ali e le zone in ombra.

**Un modello di matting** (`rembg`, isnet-general-use) — questo funziona, ma con una fregatura: con
l'alpha matting acceso tutto il personaggio diventava un fantasma semitrasparente. Serve la maschera
**netta**, ripulita a mano dopo.

**E anche così si era mangiato la coscia destra.** Misurato: nell'originale a `y=1000` c'è carne da
`x=588` a `x=706`; nel ritaglio, niente. La correzione non è un ritocco a mano ma una regola —
l'alpha finale è **la maschera del modello OPPURE la carne**, dove la carne è rossa satura e chiara
(`r>100 && r>g*1.8 && r>b*1.5`) e il fondo è rosso cupo e spento. Due condizioni bastano a
distinguerli.

Recuperando la carne però sono tornate anche **le membrane delle ali**, che sono rosse come il corpo:
il torso si stringe su `x 258-766` e le taglia via. Tanto le ali vanno rifatte comunque.

**Gli otto pezzi**: `testa` (con le corna), `torso` (con gli spallacci), `braccioSx`, `braccioDx`,
`cintura` (il teschio e il gonnellino), `gambaSx`, `gambaDx`, `coda`.

**I confini delle braccia sono diagonali, non rettangoli.** Il braccio scende in fuori e la coscia
sale in dentro: un rettangolo o taglia il bicipite o si porta via mezza gamba. E il gonnellino è
misurato sul disegno (`x 432-586`), non messo a occhio — la prima volta l'avevo largo `386-614` e si
prendeva la coscia destra per intero.

**Il formato del rig, per chi lo ritocca domani**: `w,h` sono i pixel del PNG, `ox,oy` il perno
*dentro* il PNG, `ax,ay` dove quel perno va sulla tela. E i PNG stanno a **metà risoluzione**: il
renderer li ridisegna a `si = 2s` perché `SC = 0.5`.

---

### 🦇 Le ali sono in codice, e non è una scorciatoia

Nel disegno c'erano, ma **ferme**. Un'ala ferma è un mantello. Tolte dal ritaglio e rifatte in
vettoriale dietro alla marionetta: battono da sole, **si spalancano sulla carica** e **si chiudono di
scatto nell'affondo**.

Il battito è una rotazione più una compressione orizzontale — da sopra non si vede lo spessore, quindi
l'unica cosa che racconta il colpo d'ala è **di quanto l'ala si accorcia**.

Anche qui due giri: al primo erano lunghe un terzo del corpo (avevo scritto `L` in pixel invece che in
unità della tela) e avevano artigli grossi come la testa; ed erano tutte a spigoli, che le faceva
sembrare aquiloni di carta piegata. Adesso sono curve, con le nervature appena accennate — marcate, la
membrana sembra un ombrello — e il bordo esterno più scuro a darle spessore.

**La coda** è un pezzo raster, ma ondeggia di suo con una fase più lenta e sfasata dal passo: a tempo
col passo si leggerebbe come un bastone attaccato al bacino.

**E il respiro c'è sempre**, fermo o in marcia. Senza, da fermo sembra in pausa.

**Va lento**: cadenza del passo `0.52` contro `1.05` dello zombi, busto che dondola la metà. Chi comanda
non corre.

---

### 👑 Cosa fa

**Comanda.** I mostri dentro 250 unità vanno **1,28× più veloci** e picchiano **1,22× più forte**.
Si vede: bordo acceso addosso a loro, e sotto di lui l'anello tratteggiato che gira — l'unico modo che
ha il giocatore di sapere dove finisce il potenziamento, e quindi dove conviene tirare i mostri.

Il comando **non vale fra Padroni**: due che si potenziassero a vicenda sarebbero una moltiplicazione.

*Nota tecnica che conterà:* il comando **non tocca `m.speed` né `m.dmg`**. Il Veleno Corrosivo della
v2.20 già salva e ripristina `m.dmg`, e due meccaniche che si passano lo stesso numero prima o poi si
pestano i piedi. Due moltiplicatori a parte (`cmdV`, `cmdD`), letti nei tre imbuti da cui passa tutto
ciò che un mostro tira addosso a un giocatore: `melee`, `shoot`, `spread`.

**Non è solo un'aura — Paolo: *«deve attaccare anche lui»*.** Due attacchi, scelti per distanza:

- **da vicino, LA FRUSTA**: 0,85 s di carica che si vede (ali aperte, braccio indietro, occhi accesi),
  poi un arco largo davanti a sé. L'area si paga con un cerchio spostato in avanti — il settore vero
  costerebbe un'altra macchina e a quelle distanze la differenza non si gioca; il disegno resta un arco.
- **da lontano, LA CONDANNA**: punta il bersaglio e gli apre **sotto i piedi** una zona che si chiude.
  Il cerchio che si stringe è il cronometro, e si legge senza numeri.

I due si alternano da soli perché dipendono dalla distanza: se stai addosso ti frusta, se scappi ti
condanna. **Non c'è un posto comodo**, ed è quello che deve insegnare.

---

### 📅 Ondata 15, e il buco che riempie

Le ondate **dalla 13 alla 19 non portavano più niente di nuovo**: sette di fila con solo numeri più
grandi. Il Padrone arriva in mezzo a quel vuoto, alla **15**, con peso 5 e tetto di **2 vivi**.

Ed è giusto che arrivi tardi: a quel punto il giocatore conosce tutto il bestiario, quindi
**accorgersi che l'ondata picchia più del solito vuol dire qualcosa**. Prima della dodicesima sarebbe
solo un altro nemico nuovo fra i tanti.

Il controllo della rampa è stato aggiornato: il bestiario adesso **chiude alla 15**, non alla 12. Il
numero cambia, la regola no.

---

### 📐 Numeri, e i sabotaggi

**Test: 5055 passati, 0 falliti.** (Erano 4986 in v2.22: +69 controlli, TEST 82.)

| cosa ho rotto apposta | il test se n'è accorto |
|---|---|
| tolto il PNG di un pezzo della marionetta | ✅ «il pezzo testa ha il suo PNG» |
| il comando potenzia anche gli altri Padroni | ✅ 2 controlli rossi |
| il comando non arriva al danno | ✅ «14 contro 14» |

Il primo è il più importante: un pezzo dichiarato nel rig ma senza PNG **non dà nessun errore** — il
renderer fa `if (!p || !img) continue` e quel pezzo semplicemente non si vede. È lo stesso silenzio
della cassa invisibile della v2.21.

| file | cosa |
|---|---|
| `public/assets/enemies/padrone/` | **nuova**: 8 PNG dei pezzi + `padrone.json` (il rig) |
| `public/js/renderer.js` | `PUPPETS.padrone`, `PROF.padrone` (andatura, pose, morte), `_aliPadrone`, il raggio del comando, il bordo su chi è comandato, e il ramo `shape === 'padrone'` nel dispatch frontale |
| `shared/monsters.js` | la definizione, coi numeri di comando, frusta e condanna |
| `shared/ai.js` | il comportamento `padrone` (avanza → carica → sferza / punta → condanna); carica, sferzata e mira aggiunte alle azioni esenti dal tetto alla folla |
| `server/Room.js` | `applicaComando()`, i moltiplicatori nei tre imbuti del danno, `cm` nello snapshot |
| `public/js/main.js` | i quattro eventi `padrone_*` |
| `shared/waves.js` | ondata 15 |
| `test/simulate.js` | TEST 82; e la chiusura del bestiario spostata da 12 a 15 |

**Ancora rosso, e non è di questa versione**: `test/client.js` è rotto dalla v2.19.9 e non parte,
quindi `npm test` resta rosso anche con `simulate.js` verde.


---

### [2.22.0] — 2026-09-26 · "Due nemici senza gambe"

Paolo, dopo aver bocciato la prima lista di nemici: *«non mi convincono. Dammi altre idee, prendi
spunto da giochi o da D&D — ricorda che è difficile avere nemici che camminano perché ci sono le
animazioni di movimento»*.

**Il vincolo era giusto e la mia prima lista lo ignorava.** Cencio e Guardiano Cieco avevano tutti e
due le gambe. E guardando il roster con quella lente si vede subito dove il gioco funziona già: wisp,
occhio, nugolo di pipistrelli, melma e sfera d'ossa reggono, mentre scheletro, zombi, negromante e
troll sono la parte che costa. Regola nuova, quindi: **niente gambe**. Cose che fluttuano, rotolano,
colano, stanno ferme o strisciano.

Di tre proposte Paolo ne ha approvate due, dopo un'anteprima animata fatta prima di scrivere una riga
di codice di gioco.

---

### 🗡️ LAMA ERRANTE — *spada volante, di scuola D&D*

Ondata 2, 42 pv, la più fragile del roster.

Quattro fasi: **gira** (galleggia ruotando su sé stessa) → **punta** (si orienta) → **carica** (mezzo
secondo di rinculo e bagliore) → **scatto** (dritta, veloce, e rimbalza sui muri come la Sfera
d'Ossa). L'animazione è una rotazione più uno scatto: **zero frame**.

**La carica non è decorazione, è il contratto con il giocatore.** Uno scatto veloce senza preavviso
sarebbe un danno arrivato dal nulla; con mezzo secondo di preavviso e una traiettoria **retta**, la
risposta esiste sempre ed è semplice — spostarsi di lato. È il primo nemico del gioco che telegrafa
il colpo, ed è il motivo per cui entra alla **seconda ondata** e non alla decima: ai livelli bassi si
impara solo a sparare, questa insegna a schivare, e deve arrivare quando c'è ancora da imparare.

Il test misura proprio quello: durante la carica **i punti vita del giocatore non si muovono**, e
l'evento del preavviso arriva prima di quello dello scatto.

**L'ombra sta staccata e più in basso**, e non segue il bob in pieno. È l'unica cosa che dice
"questa galleggia" invece di "questa striscia".

---

### 🟩 CUBO GELATINOSO — *D&D, quello classico*

Ondata 6, 260 pv, raggio 40 (il più grosso non-boss del gioco), velocità 45.

**Ferma i proiettili.** Gli si conficcano dentro e si spengono — **anche quelli perforanti**. È
questo che lo rende un muro e non solo un mostro con tanti punti vita, ed è l'unica cosa che lo
distingue: senza, sarebbe un bruto lento.

**È un muro che si muove.** Ti taglia il corridoio, ti toglie la linea di tiro, ti obbliga a girarci
intorno. È l'unica cosa del gioco che ti sposta senza minacciarti di morte — e soprattutto: **è
l'opzione A della v2.21 ottenuta senza i suoi rischi**. Paolo l'aveva scartata (*«A bello ma
"pericoloso"»*) perché un ingombro messo male chiude un corridoio e il campo di flusso ci finisce
contro. Qui l'ingombro è un **mostro**: la griglia non la tocca nessuno, il campo di flusso e le
collisioni non ne sanno niente, e se davvero si incastrasse basta ucciderlo.

**Dentro si vede la roba di chi ci è finito prima** — monete, ossa, teschi, una spada — e morendo la
lascia cadere. Paga circa una cassa e mezza. Se morendo non la lasciasse, quel disegno sarebbe una
bugia; il test confronta dieci morti di Cubo contro dieci di Zombie Putrido e pretende più del
doppio.

**Non assorbe i colpi dei mostri**, solo quelli dei giocatori. Un proiettile nemico che si spegne
dentro il Cubo non vuol dire niente per chi gioca.

Entra alla 6 perché il suo mestiere è togliere la linea di tiro: ha senso quando il giocatore ha già
imparato a tenerla.

---

### 🎨 Far leggere un cubo in una vista dall'alto

Il problema vero non era l'IA, era il disegno: da sopra, un cubo è un quadrato. Quattro cose, e la
terza è quella che fa il lavoro:

1. **due facce sfalsate in verticale** (a terra e in alto) che ondeggiano in modo **diverso** fra
   loro — se ondeggiassero uguali sembrerebbero due copie della stessa figura, non le due estremità
   di una massa sola;
2. **il fianco vicino in un pezzo solo**: al primo tentativo l'avevo disegnato a segmenti, si
   vedevano le cuciture verticali e veniva fuori una staccionata. Ed era alto il doppio, quindi
   sembrava un secchio visto di fronte invece di un cubo visto da sopra;
3. **lo spigolo di fondo visto attraverso il vetro** — il bordo lontano della faccia a terra si
   intravede *dentro* la faccia in alto, spostato in basso. È il segnale che l'occhio usa per capire
   che sta guardando dentro una scatola trasparente, e sono due righe;
4. **la parallasse della roba dentro**: chi sta in superficie è disegnato più in alto, più grande e
   più nitido; chi è affondato più piccolo e più smorto, perché sopra ha della gelatina. Due monete
   alla stessa quota sono un adesivo, due monete a quote diverse sono un volume.

Lo schiacciamento quando cambia direzione lo calcola il **client** guardando il movimento, senza un
evento dal server: è una cosa che si vede, e mandarla in rete sessanta volte al secondo sarebbe peso
inutile.

---

### 🐞 IL BUG CHE NESSUN TEST AVREBBE PRESO

Dentro il Cubo si vedeva **una spada sola**. Le posizioni degli otto oggetti venivano da
`(sem * 97 + i * 37) % 1`: i moltiplicatori erano **interi**, e la parte frazionaria di un intero è
zero — quindi `i` non cambiava niente e tutti e otto finivano esattamente nello stesso punto, uno
sopra l'altro.

Il codice funzionava. Non lanciava errori, non rallentava, disegnava solo la cosa sbagliata. **Nessun
test unitario lo avrebbe mai visto**: l'ha preso il render di prova, cioè guardare il risultato.
Stessa storia dei dardi conficcati, che erano quattro e se ne vedeva uno.

Moltiplicatori non interi, e il problema sparisce.

---

### ⚠️ E una trappola evitata in tempo

Il **tetto alla folla** (v1.80) manda ad aspettare all'anello chi è di troppo, ma esenta chi è in
mezzo a un'azione già partita — `rolling`, `winding`, `lunge`. La carica e lo scatto della Lama non
erano in quella lista: una Lama oltre il tetto sarebbe stata **parcheggiata a metà stoccata**, una
spada ferma per aria. Aggiunte alla lista, e c'è un test che legge quella riga e pretende che ci
siano.

---

### 📐 Numeri e file toccati

**Test: 4986 passati, 0 falliti.** (Erano 4947 in v2.21: +39 controlli, TEST 81.)

Tre sabotaggi deliberati per verificare che i controlli mordano:

| cosa ho rotto apposta | il test se n'è accorto |
|---|---|
| tolta la carica (la Lama scatta senza preavviso) | ✅ 3 controlli rossi |
| il Cubo lascia passare i perforanti | ✅ 3 controlli rossi |
| tolta la Lama dall'esenzione del tetto alla folla | ✅ 1 controllo rosso |

| file | cosa |
|---|---|
| `shared/monsters.js` | le due definizioni (`lama`, `cubo`) |
| `shared/ai.js` | i comportamenti `lama` (quattro fasi) e `gelatina`; carica e scatto aggiunti alle azioni esenti dal tetto alla folla |
| `server/Room.js` | l'assorbimento dei proiettili (al posto della regola del perforante), il conto dei dardi con la sua dissolvenza, il bottino alla morte, `ab` nello snapshot |
| `public/js/renderer.js` | `_lamaF` e `_cuboF` + il dispatch; lo schiacciamento calcolato dal client |
| `public/js/main.js` | gli eventi `lama_wind`, `lama_go`, `lama_muro`, `assorbito`, `cubo_sciolto` |
| `shared/waves.js` | Lama alla 2, Cubo alla 6 |
| `test/simulate.js` | TEST 81; e il controllo della rampa ora verifica **la regola** (ogni ondata porta qualcosa di nuovo) invece del **numero** di archetipi, che era scritto a mano e saltava appena si aggiungeva un nemico |

**Non fatto, per scelta di Paolo**: il **Verme delle Cave** (dodici segmenti sulla scia della testa)
era la terza proposta ed era piaciuta come disegno, ma non è stata approvata per l'implementazione.
L'anteprima resta.

**Ancora rosso, e non è di questa versione**: `test/client.js` è rotto dalla v2.19.9 e non parte,
quindi `npm test` resta rosso anche con `simulate.js` verde.


---

### [2.21.0] — 2026-09-25 · "Roba da rompere, e un posto dove ognuno è a casa sua"

Paolo: *«vorrei aggiungere oggetti alle mappe della grotta ma non saprei cosa»*.

**Prima di proporre, ho contato.** E la prima cosa da dire è che quello che avevo detto io, un'ora
prima, era sbagliato: avevo scritto che la grotta aveva **11 oggetti**. Ne ha **37**. Il mio `grep`
aveva pescato solo un pezzo dello `switch` del renderer, e metà della lista che avevo proposto a Paolo
era roba già in gioco (l'obelisco è `obelisk`, le macerie sono `rubble`, la stalattite è `stalactite`).
Corretto prima di scrivere una riga di codice: costruire su una misura sbagliata sarebbe costato molto
più della figuraccia.

Contando davvero sono usciti **tre fatti**, e sono quelli che hanno deciso la versione.

#### 1. Il vero motivo per cui i cinque temi si somigliano

Le scene tematiche sono **24** (cimitero, ossario, geode, santuario, officina…) e ogni tema ne pesca
una quindicina. Ma **solo `fungaia` apparteneva a un tema solo** (la foresta). Tutte le altre erano
condivise da due, tre o quattro temi. Detto altrimenti: **la lava non aveva una sola scena che
parlasse di lava**, il ghiaccio nessuna di ghiaccio, l'arcano nessuna sua. Il colore della roccia della
v2.20.3 aiutava, ma non poteva bastare: sotto, l'arredamento era lo stesso.

**Adesso ogni tema ha due scene che sono solo sue**, e il test pretende che restino tali:

| tema | scene esclusive | oggetti nuovi |
|---|---|---|
| Cripta Dimenticata | `sepolcreto`, `veglia` | loculo murato, urna cineraria, catafalco col sudario |
| Caverne di Lava | `colata_lavica`, `fumarole` | colata rappresa con le crepe vive, sfiatatoio |
| Rovine nella Foresta | `boschetto`, `radici` | tronco caduto muschioso, felce, radici che sfondano il pavimento |
| Cripta di Ghiaccio | `assideramento`, `gelicidio` | sagoma congelata dentro il ghiaccio, colonna di ghiaccio |
| Tempio Arcano | `rituale`, `studio` | cerchio rituale col pentacolo, leggio col libro aperto |

Anche il **pulviscolo ambientale** (`propMix`, gli oggetti piccoli sparsi lungo le pareti) adesso
cambia da tema a tema: felci nella foresta, colate sulla lava, ghiaccioli sul ghiaccio.

Misurato su 220 mappe: ogni oggetto esclusivo compare **solo** nel suo tema, e i cinque temi escono
tutti. Il test lo ricontrolla a ogni giro — se qualcuno un giorno aggiunge `colata` anche al ghiaccio
per fare in fretta, si rompe lì.

#### 2. Il bug della cassa invisibile

`chest` veniva piazzato dalla scena `deposito` **dalla v1.24**. Nel renderer il caso `'chest'` non c'è
mai stato: il prop cadeva in fondo allo `switch`, non trovava il suo ramo, e non disegnava niente.
**Per decine di versioni il deposito ha avuto una cassa che nessuno vedeva**, senza un errore da
nessuna parte.

Disegnata (cassa di legno con le bande di ferro dorato e la serratura). Ma soprattutto: adesso c'è
**il controllo che rende impossibile che ricapiti**. Legge dal sorgente quali tipi piazza `mapgen.js`
e quali sa disegnare `renderer.js`, e pretende che i due insiemi tornino. È lo stesso mestiere del
controllo del ponte client della v2.17.

*(I cinque oggetti disegnati e mai usati — `pillar`, `statue`, `demon_statue`, `puddle`, `mimic` —
restano spenti: Paolo li ha guardati e ha detto «non erano molto belli».)*

#### 3. Gli oggetti non facevano niente

Nessun oggetto della grotta era toccabile. `INGOMBRI` conteneva solo i mobili del villaggio più
`crystal_cluster`: rocce, lapidi, bare, ossa, catene, ragnatele si attraversavano tutte. Erano carta
da parati. Il villaggio "si legge" come un posto perché ci sbatti contro; la grotta era una stanza
vuota decorata.

Paolo ha scelto **B e C**, scartando A (gli oggetti che ingombrano): *«A bello ma "pericoloso"»* — e
aveva ragione, un ingombro messo male chiude un corridoio e il campo di flusso ci finisce contro.
Quindi **nessuno dei tre oggetti nuovi blocca il passaggio**. Fanno altro.

---

### 🏺 L'URNA — si rompe e lascia monete

Tre-cinque per mappa, su **tutti** i temi (nella cripta qualcuna in più, perché ce la mettono anche le
sue scene). Si rompe con un colpo qualunque e lascia **una mancia**, non un tesoro: `URNA_MONETE: 9`
più 1,5 per ondata, cioè **meno di metà cassa**. È voluto — se l'urna pagasse come una cassa, aprire
le casse smetterebbe di essere la ragione per attraversare il centro della mappa, che è tutto il
motivo per cui le casse stanno lì (v1.63).

### 🛢️ IL BARILE — esplode, e fa male anche a te

Due-tre per mappa, lontani dalla partenza. Colpito, **deflagra**: raggio 112, danno 34 + 6 per ondata
sui mostri, **metà sui giocatori che stanno dentro**.

Che facesse male anche a noi non è una svista. Un barile che ferisce solo i nemici è una bomba
gratis, e *quando* farlo scoppiare smetterebbe di essere una scelta. Metà danno è la taratura giusta:
abbastanza per insegnare a starne lontani, non abbastanza per morire per distrazione.

**Il disegno è parte della meccanica**: doghe scure, cerchi rossi, miccia accesa. Deve distinguersi a
colpo d'occhio dal `barrel` normale del deposito, se no l'esplosione sarebbe una punizione arrivata
dal nulla.

**I barili si innescano fra loro.** Lo scoppio di uno rompe tutto ciò che sta nel suo raggio, barili
compresi. La catena non può tornare indietro perché `rompiOggetto` segna `dead` **prima** di
esplodere — una riga, ed è quella che tiene.

**Chi può romperli**: i proiettili dei giocatori, i fendenti, e qualunque esplosione (granate, palla
di fuoco). **I proiettili dei mostri no**, di proposito: un barile innescato da un colpo nemico
sarebbe un danno arrivato da una catena che il giocatore non ha nessun modo di prevedere.

### ⛓️ LA GRATA E LA LEVA — un ripostiglio chiuso, e la catena che lo apre

Ogni mappa ha **un vano chiuso da una saracinesca**, e da qualche parte — fra 7 e 22 tessere di
distanza, mai addosso — la **leva** che la apre. Dentro c'è una **cassa vera**, con tutto quello che
comporta, mimic compreso: se dietro una porta chiusa ci fosse sempre e solo oro, aprirla smetterebbe
di essere una scommessa dopo la prima volta.

**La regola che rende la cosa sicura, ed è tutta la versione.** Il vano **non si ricava da spazio
esistente: si scava nella roccia piena**. Così aprirlo o non aprirlo non può in nessun caso tagliare
in due la mappa — che è il modo in cui una porta che si apre a gioco in corso rompe di solito il campo
di flusso.

Tutto il resto viene da sé, e questa è la parte bella: **il campo di flusso si ricostruisce da solo
ogni 0,12 s dalla griglia**, e collisioni e linea di vista la rileggono a ogni chiamata. Cambiata la
griglia, sono cambiate tutte e tre. Il codice che apre la grata è **una riga**.

**Il primo tentativo era bucato, e il test l'ha preso.** Controllavo che fossero roccia le nove
tessere del vano, ma non la **conchiglia** attorno: in **195 mappe su 300** il vano toccava di fianco
un corridoio già esistente, il premio si raggiungeva senza mai tirare la leva, e la grata non chiudeva
niente. Adesso si pretende piena anche la cornice 5×5. Misurato su 120 mappe: il premio è
irraggiungibile a grata chiusa **sempre**, raggiungibile ad aperta **sempre**, e aprire non cambia lo
stato di **nessuna** tessera fuori dal vano.

**Il client non ricuoce niente.** Le tessere della grata vengono cotte come **pavimento** (stesso
trucco delle lapidi del cimitero, `_leggero`), la saracinesca la disegna il render a ogni fotogramma:
quando la leva la apre, basta smettere di disegnarla — sotto il pavimento c'è già. La leva cambia posa
(braccio alzato/abbassato, pomo giallo/verde): è l'unico modo che ha il giocatore, tornando indietro,
di sapere di averla già tirata.

---

### ⚠️ L'ERRORE CHE HO RIFATTO, ED È PROPRIO QUELLO CHE MI ERA STATO DETTO DI NON RIFARE

Paolo, regola permanente: *«non ripetere errori di regressione: dopo una modifica va verificato anche
ciò che NON è stato toccato»*. Nasceva da una riga infilata fra un `if` e il suo `else` che aveva
cancellato il disegno di tutte le mappe dall'ondata 3 in poi (v1.97.1).

**L'ho rifatto, nello stesso identico modo.** Il controllo sugli oggetti l'ho messo in mezzo al ramo
`if (b.hostile) {…} else {…}` di `updateBullets`. L'`else` si è staccato dal suo `if`, e da quel
momento **i proiettili OSTILI finivano nel ramo dei mostri**: nascendo addosso al mostro che li spara,
si ammazzavano da soli al primo fotogramma. **Lo sputo dell'acido aveva smesso di uscire.**

Nessun errore da nessuna parte. L'hanno preso i test (`0 bolle d'acido`). Il controllo adesso sta
**dentro** l'`else`, con scritto sopra perché.

E per non fidarmi del fatto che i test passino, **ho rotto di proposito tre cose** per vedere se se ne
accorgono:

| cosa ho rotto apposta | il test se n'è accorto |
|---|---|
| tolto il disegno della cassa | ✅ 2 controlli rossi |
| rimesso il controllo fuori dall'`else` | ✅ lo sputo dell'acido torna a 0 bolle |
| tolto il controllo della conchiglia del vano | ✅ «79 mappe bucate» |

---

### 📐 Numeri e file toccati

**Test: 4947 passati, 0 falliti.** (Erano 4879 in v2.20.3: +68 controlli nuovi, TEST 80.)

| file | cosa |
|---|---|
| `public/js/renderer.js` | 16 disegni nuovi (13 scenici + barile, saracinesca, leva) + la cassa; grate/leve/rompibili disegnati a ogni fotogramma; `_leggero` include le tessere della grata |
| `shared/mapgen.js` | 10 scene esclusive; `propMix` per tema; urne e barili escono dai `props` e diventano entità; lo scavo del vano con la conchiglia; la leva |
| `server/Room.js` | `oggetti`/`grate`/`leve`; `colpisciOggetti`, `rompiOggetto`, `_scoppioBarile`, `updateLeve`; gli agganci in `updateBullets`, `_meleeSwing`, `_explodeAt`; `ogg` nello snapshot solo quando cambia |
| `shared/constants.js` | `URNA_MONETE`, `URNA_XP`, `BARILE_RAGGIO`, `BARILE_DANNO`, `BARILE_QUOTA_GIOCATORE`, `GRATA_RAGGIO` |
| `public/js/main.js` | gli eventi `urna`, `barile`, `grata`; `w.ogg`; lo stato delle grate aperte |
| `test/simulate.js` | TEST 80; e i due controlli di raggiungibilità ora misurano **a grate aperte** |

**Ancora rosso, e non è di questa versione**: `test/client.js` è rotto dalla v2.19.9 (identificatori di
classe vecchi, v2.18) e non parte, quindi `npm test` resta rosso anche se `simulate.js` è verde. È un
mio errore di allora, non l'ho ancora sistemato perché Paolo non me l'ha chiesto.


---

### [2.20.3] — 2026-09-25 · "Ogni posto ha la sua pietra"

Paolo, guardando le mappe: *«c'e' modo di variare in modo piu' significativo? anche solo colori delle
rocce diversi»*.

**Aveva visto giusto, ma il motivo non era quello che sembrava.** I cinque colori c'erano gia', uno per
tema. Il problema stava nella COTTURA: dentro `_bakeCaverna` il chiaro con cui si schiarisce la pietra e
lo scuro con cui la si incide erano **due costanti uguali per tutte e cinque le grotte** — un
grigio-azzurro e un nero-blu. Qualunque colore avesse il tema, la roccia veniva impastata sempre verso
lo stesso grigio freddo: il colore c'era e se lo rimangiava il disegno. Ecco perche' cripta, ghiaccio e
arcano, che pure hanno tre `wall` diversi, a schermo si somigliavano.

**Adesso il chiaro e lo scuro li porta il TEMA**, e cambiano tutti e cinque:

| | pietra | com'e' |
|---|---|---|
| Cripta Dimenticata | osso sporco `#d8cfb4` | calcare vecchio |
| Caverne di Lava | cenere rossa `#e0a271` | basalto caldo |
| Rovine nella Foresta | verde lichene `#b9cfa0` | pietra mangiata dal bosco |
| Cripta di Ghiaccio | bianco-ciano `#cfe9f5` | ghiaccio vero |
| Tempio Arcano | lilla pallido `#d3bff0` | pietra incisa |

**Il tema continua a sorteggiarsi** come sempre — *«preferisco la casualita'»* — quindi non cambia
niente su quale mappa esce quando: cambia solo come ogni mappa dipinge la sua pietra. E **il villaggio
resta identico**: non porta `chiaro`/`scuro`, quindi la cottura usa i valori di prima. Si cambia il
sottosuolo, non casa della gente.

**Il test non guarda il disegno, guarda che le cinque pietre restino DIVERSE**: ogni tema deve avere i
suoi due colori, nessun chiaro puo' essere uguale a un altro, e fra due qualunque devono esserci almeno
40 punti di distanza sui canali RGB — sotto quella soglia, a schermo, non le distingue nessuno. E' la
rete contro il giorno in cui qualcuno ricopia una riga per fare in fretta e si torna al punto di
partenza senza che se ne accorga nessuno.

**Scelte fatte prima di scrivere il codice, e le anteprime che le hanno decise.** Erano in ballo tre
strade: (1) come adesso, (2) il tema su tutta la mappa, (3) il tema solo sulla roccia col pavimento
neutro. La prima anteprima ha mostrato che la strada 2 tinge piu' il PAVIMENTO che la roccia — il
pavimento si schiarisce con una presa fra il 23% e il 45%, la roccia solo fra il 12% e il 18% — e io
avevo consigliato la 3. **Paolo ha scelto la 2**, perche' varia di piu': ed e' la 2 che e' nel gioco.

**Scartata: la foresta.** Provata con due prototipi (pianta a radure e sentieri, chiome a strati,
tronchi caduti, massi col muschio, felci, una pozza come ostacolo). Paolo: *«la differenza con la mappa
della grotta e' molto marcata»* — e ha ragione, il gioco ha UN mondo solo, scavato nella stessa roccia
dal villaggio in giu': un prato verde non e' una mappa diversa, e' un altro gioco incollato dentro.
Resta scritto qui perche' l'idea non vada ritentata per distrazione.

**Test: 4879 passati, 0 falliti.**

---

### [2.20.2] — 2026-09-24 · "Il dialogo riscritto"

**I dialoghi d'apertura sono di Paolo, parola per parola** — il risveglio nella stanza, l'arrivo al
villaggio e il discorso dell'oracolo. Cosa e' cambiato, e perche' conta:

- **La rivelazione non si spiega piu'.** Prima l'oracolo diceva «un Dio», «ti sta guardando», «ogni
  potere che otterrai sara' perche' lui lo vorra'»: tre gradini e una regola servita al giocatore.
  Adesso chiede all'avatar se ha scelto LUI di attraversare il portale — e aspetta. La risposta
  («Io… non lo so. E' come se qualcuno mi guidasse») la dice l'avatar, non il vecchio.
- **C'e' il ciclo, ed e' la cosa nuova.** *«Non sei il primo» · «Sono tornati all'inizio» · «Molte
  volte»*. Spiega la morte senza nominarla: non hai finito, hai ricominciato. E l'ultima battuta e'
  dell'avatar — *«Sempre che io mi ricordi di te»* — con l'oracolo che risponde *«Esatto»* e non lo
  consola.
- **Il boss e le venti discese non si nominano piu' nel discorso**: restano nel riquadro della
  missione, che e' il posto dove il giocatore li legge quando gli servono.

**Le frasi fra parentesi adesso si vedono.** Paolo: *«inserisci anche le frasi tra parentesi come fuori
campo, danno profondita'»*. Erano commenti nel codice — `(l'oracolo lo osserva)`, `(sorride appena)` —
e non le leggeva nessuno. Adesso sono righe con una voce loro (`chi: 'nota'`): **corsivo, piu' spente,
senza ritratto e senza nome**, cosi' in mezzo secondo si capisce che non e' qualcuno che parla ma la
regia. Sette in tutto nel discorso dell'oracolo, e ognuna porta anche la PAUSA: il «(Pausa.)» non e'
solo una parola che dice di aspettare, e' un'attesa vera prima che la riga si scriva.

**Il test si e' girato con loro.** Chiedeva al discorso di nominare il boss, di dire «venti» e di
spiegare che i poteri sono doni: tre cose che il discorso nuovo non fa piu', e non per distrazione.
Adesso chiede i due fatti che, se sparissero, lascerebbero venti ondate senza perche' — **qualcuno
osserva adesso e tu sei il suo strumento**, e **non sei il primo, tutto questo e' gia' successo** — piu'
il controllo che il boss e le venti discese siano rimasti nella missione. E una regola nuova: una riga
fra parentesi **deve** essere marcata come fuori campo, se no il client le mette accanto la faccia
dell'oracolo e si legge «(L'Oracolo guarda verso lo schermo)» detto dall'Oracolo in persona.

**Test: 4853 passati, 0 falliti.**

---

### [2.20.1] — 2026-09-23 · "Il menu si accorcia"

Tre ritocchi chiesti da Paolo sulla schermata d'avvio, e una cosa che e' saltata fuori facendoli.

- **Via il richiamo sotto il titolo** — le tre frasi («Scendi. Venti volte, e ogni volta piu' a
  fondo…»), che dalla v2.8.2 stavano fra il titolo e le due colonne. Con la scheda della classe
  cresciuta nella v2.19.9 la schermata era diventata lunga, e quello era il pezzo che si poteva togliere
  senza perdere niente di utile. Tolto anche il suo stile: un testo che sparisce e una regola CSS che
  resta e' il modo in cui, fra sei mesi, qualcuno rimette il testo senza sapere che il CSS lo aspettava.
- **Titolo un filo piu' piccolo**: da 38-72px a 34-64px, con la spaziatura fra le lettere scesa con lui
  (era tarata sulla misura vecchia).
- **Meta' dell'aria sopra il titolo**: il margine in cima al menu passa da `min(5vh,52px)` a
  `min(2.5vh,26px)`. Misurato a 1500×900: il titolo comincia a 23px invece che a 45, e le due colonne
  salgono da y=238 a y=148.

**E una cosa da dire, perche' e' un mio errore.** Facendo questi tre ritocchi ho scoperto che
**`test/client.js` era rotto da due versioni** e non se n'era accorto nessuno: si ferma al primo errore,
e il primo errore era che dalla v2.19.9 `HUD._mettiArtwork` chiede `img.getAttribute('src')` mentre lo
stub del DOM aveva solo `setAttribute` e non `getAttribute`. Subito dopo ne aveva un altro: parlava
ancora di `'guerriero'` e `'ladro'`, che dalla v2.18 non sono classi ma CORPI. La causa e' semplice e
sta in me: ho sempre lanciato `simulate.js` da solo, mai `npm test`, che li lancia tutti e due.

Ho riparato lo stub (adesso tiene una mappa di attributi, come il DOM vero) e i due punti che parlavano
delle classi vecchie, ma **il file non e' ancora sano**: piu' avanti ha altri controlli fermi al
pannello del fabbro di due versioni fa. Nel frattempo i controlli su questi tre ritocchi li ho messi in
`simulate.js` (TEST 79), che gira davvero — un test che non gira non e' un test.

**Test: 4753 passati, 0 falliti** (`simulate.js`).

---

### [2.20.0] — 2026-09-23 · "Le passive rifatte"

Il mazzo delle abilita' passive e' rifatto da zero. Paolo: *«Secondo me vanno ripensate: qualcuna puo'
anche andare bene ma la maggior parte non e' indicata per la classe. Riduci da 4 a 3 opzioni per i 4
step, ma che siano davvero indicate alle classi in gioco»* — e poi: *«togli qualsiasi abilita' che possa
curare i personaggi, di qualsiasi tipo; dimezza gli effetti di bonus a danni, punti vita o altro; togli
magie che portano in vita»*.

**Da 38 carte a 84, e nessuna condivisa.** Il mazzo vecchio era quello dei tre eroi allargato a sette:
ai livelli 3 e 5 barbaro, paladino e maestro d'armi vedevano le STESSE due carte, e mago e warlock pure;
le classi si separavano solo dal 9 in su. Adesso ogni classe ha **dodici carte sue**, e se una carta va
bene a tre classi vuol dire che non e' la carta di nessuna.

**Tre opzioni invece di quattro, e sono le stesse tre vie a ogni livello:** ⚔️ **il colpo** (potenzia il
modo in cui quella classe fa male), 🛡️ **la tenuta** (copre la sua debolezza con lo strumento che le e'
proprio), 🎭 **il mestiere** (la cosa che solo quella classe fa). Il mazzo NEUTRO e' sciolto: le carte
neutre che valevano la pena sono state date alla classe a cui appartengono davvero — il Colpo di Grazia
all'assassino, il Campo di Lentezza all'arciere e al warlock, la Tossina all'assassino, il Baluardo al
paladino — e le altre sono sparite. Sulla carta, al posto di «TUA CLASSE» (che adesso varrebbe per tutte
e tre), c'e' scritta la via.

**Niente cure e niente resurrezioni.** Ultima Occasione (risorgi a meta' vita) e' tolta; sono state
tolte in fase di progetto anche le quattro carte che curavano. Restano ammessi gli scudi e gli
assorbimenti, che non curano e non riportano in vita. Non e' una promessa: un test applica **tutte e 84
le carte** a un personaggio ferito, una per una, e controlla che i PV non salgano e che non compaia
nessuna carica di resurrezione.

**Tutto dimezzato.** Non solo i numeri sulle carte: anche le magnitudini che stavano scritte a mano
dentro il motore e che nessuna carta poteva toccare — la cadenza della Furia Crescente (+8% → +4% a
uccisione), il passo del Passo di Danza, il Tributo di Sangue, la soglia del Colpo di Grazia (14% → 10%),
il rimbalzo della Catena (25% → 12%), la Frattura (50% → 25%), il Tocco Gelido (50% → 25%) e il Campo di
Lentezza (25% → 12%). Adesso quei valori li porta la CARTA: ritoccarli e' una riga in `loot.js`, non una
caccia dentro `Room.js`.

**Le carte nuove che non sono un moltiplicatore.** Una quarantina hanno richiesto un aggancio nuovo nel
motore: la parata e la schivata (il colpo non arriva), il contrattacco (chi ti colpisce in mischia se lo
ritrova addosso), il colpo doppio del maestro, il Ritmo (i colpi a segno di fila alzano la cadenza, un
colpo a vuoto azzera), il Faro (i nemici vicini prendono di mira il paladino), lo Scudo Condiviso (una
quota dei danni dei compagni la incassa lui davvero), il Giudizio (ogni sesto colpo porta via una quota
dei PV massimi, molto meno sui boss), il Terremoto (lo scatto sbalza e stordisce), Spacca in Due (il
colpo che uccide prosegue su chi sta dietro), il Mulinello, il Silenzioso (i nemici ti notano da piu'
vicino — sta dentro `perceive`, perche' e' una proprieta' di chi viene guardato, non di chi guarda), il
Veleno Corrosivo (il nemico avvelenato morde meno), il Legame Osseo e la Carne Debitrice del warlock, e
il **Debito di Sangue**: ogni colpo su un maledetto va in conto, e il conto scoppia quando quello muore.

**Due scelte fatte in corso d'opera, e vanno sapute.**
1. **Non Cado e' stata sostituita da ZOCCOLO DURO** (i colpi che ti tolgono meno del 10% dei PV fanno il
   25% in meno). Motivo: «resti a 1 PV invece di cadere» e' gia' **Ultimo Respiro**, l'abilita' attiva
   del barbaro al livello 13. Due carte che fanno la stessa cosa non sono una scelta.
2. **Le sinergie sono state ripuntate.** Le sei di prima chiedevano coppie miste (Tossina + Colpi
   Esplosivi, Perforazione + Lama Sporca) che nel mazzo nuovo **nessuno puo' piu' mettere insieme**:
   sarebbero rimaste scritte e morte. Adesso sono sette, una per classe, con effetti volutamente piccoli
   — dopo il dimezzamento, una sinergia grossa rimetterebbe dalla finestra quello che e' uscito dalla
   porta.

**Test: 4746 passati, 0 falliti.** Il nuovo TEST 78 misura venticinque meccaniche una per una — e poi fa
girare venti secondi di combattimento vero, **per tutte e sette le classi, con tutte e dodici le carte
accese insieme**, controllando che nessun aggancio tiri un'eccezione o lasci un NaN. Quest'ultima parte
e' stata verificata rompendo di proposito tre agganci: senza di essa non se ne accorgeva nessuno.

**Resta segnalato** (e la scelta e' di Paolo): quattro carte, dopo il dimezzamento, stanno sotto la
soglia in cui un giocatore SENTE la differenza — Presenza, Pelle di Patto, Faro e Doppia Guardia, tutte
fra il 3 e il 4%. La strada indicata, se un giorno si volesse rimediare, e' **dare meno carte** (tre
livelli invece di quattro), non rialzare i numeri.

---

### [2.19.11] — 2026-09-22 · "La scarica e la palla di fuoco"

Quattro richieste di Paolo sul mago (e in parte sul warlock), fatte tutte in una versione sola.

**1. Lo sparo non è più una bolla: è una scarica.** *«L'effetto dello sparo (la bolla) non mi piace per
niente, sembra che spara bolle di sapone. Quello che vorrei è l'effetto, per il mago, di una scarica di
energia (non elettrica) azzurra, e per il warlock viola. Magari un effetto tipo un lampo.»*

Il proiettile arcano è una **saetta**: una spezzata che corre lungo la traiettoria, nucleo bianco,
alone del colore della classe, due rametti corti che la fanno leggere come un lampo. Si rimescola dodici
volte al secondo — vibra, non lampeggia — e la spezzata è **deterministica** (dipende dall'id del
proiettile e dal tempo a scatti): tutti i giocatori vedono la stessa saetta.

**Il colore è della CLASSE, non del bastone: azzurro il mago (#5aa8ff), viola il warlock (#c06bff).**
Lo stesso scettro comprato dallo stesso arcanista spara azzurro in mano al mago e viola in mano al
warlock — in cooperativa è l'unico modo di capire chi sta sparando.

**2. Il suono è nuovo.** *«Cambia anche il suono che non mi piace per niente.»* Il vecchio era una
sinusoide morbida che scendeva da 420 a 180 Hz con sotto un colpo di grancassa: suonava come una goccia,
cioè come la bolla che disegnava. Il nuovo ha tre pezzi e **nessun sub**: lo *schiocco* (rumore a banda
stretta spazzato da 5200 a 900 Hz in 70 ms — è l'aria che si apre), il *corpo* (due voci stonate di 5 Hz
che scendono in fretta: ronzano senza suonare elettriche) e la *coda* (una risonanza corta che resta
appesa). Il patto è lo stesso suono un'ottava sotto, con la dente di sega: si riconosce a orecchio chi
dei due ha sparato.

**3. Le bacchette hanno solo danno e frequenza.** *«Devi togliere dalle bacchette l'ampiezza della bolla
(lo sparo) e lasciare solo danno e frequenza.»*

Tutti e tredici i bastoni del mago hanno ora la **stessa scarica**: stessa larghezza (r 7), stessa
velocità (760 px/s), stessa gittata (640), stessa perforazione (nessuna). Del bastone restano **due
numeri soli**: quanto pesa il colpo e quanto spesso parte. Il bivio dentro il grado resta — pesante =
colpo grosso e raro, leggera = tanti colpi leggeri, equilibrata in mezzo a 1,5 colpi/s — e il vincolo
del 4% sul danno al secondo vale come per tutte le altre classi. Le schede del negozio non dicono più
«Bolla r16 · 330 px/s · gittata 520», dicono «99 a colpo · 1 colpo/s · 99 danni/s».

**4. La firma del mago è la Palla di Fuoco, e vola.** *«La scarica elementare non mi piace, ESIGO che
l'abilità del mago sia una palla di fuoco con danno ad area. Deve essere una sfera di fuoco convincente,
muoversi (tipo la bolla molto più veloce) e generare danno ad area.»*

- **Scarica Elementale: tolta.** Non esiste più, né come firma né altrove.
- **Palla di Fuoco: promossa al livello 1**, ed è diventata un **proiettile**. Prima era un colpo
  istantaneo nel punto mirato: nessuno la vedeva partire, e in effetti non si disegnava affatto —
  l'evento che il server mandava non lo raccoglieva nessuno nel client. Ora parte dalla mano, corre a
  **900 px/s** (la scarica ne fa 760) e **scoppia dove arriva**: addosso al primo nemico che tocca, su
  un muro, o a fine gittata (620). Il danno è **tutto nell'area** (raggio 150, 2,4× il colpo): la sfera
  in sé non morde, altrimenti chi la prende in faccia pagherebbe due volte.
- **La sfera si vede.** Tre strati che non hanno lo stesso centro — nucleo bianco-giallo spostato in
  avanti, palla arancione attorno, alone rosso cupo che resta indietro e si allunga in scia — più un
  bordo di sei punte che si rimescola quindici volte al secondo. È il trucco della fiamma di candela:
  il caldo davanti, il fumo dietro. Lo scoppio è due anelli, una vampata larga quanto il raggio vero e
  lo scossone.
- **Al livello 13, al posto della Palla, c'è la COMBUSTIONE** (nuova): per dieci secondi ogni nemico
  che uccidi **scoppia**, e lo scoppio può incendiare il vicino. La catena si ferma alla terza
  generazione — senza quel freno un'ondata fitta si incendierebbe tutta in un fotogramma.

**E il bancone dell'arcanista è libero.** *«Attenzione anche nel negozio di magia, hai piazzato un
ostacolo proprio davanti al bancone del mago.»* Misurato: il cristallo grande sedeva a 50,6 — sulla riga
della porta e a 2,8 tessere dal mercante — e insieme a candelabri e rastrelliere chiudeva la stanza:
alla colonna x=51 restavano **0,75 tessere** libere e al banco ci si arrivava rasente al muro. Ora il
cerchio è di quattro cristalli, due per parete, in mezzo non c'è niente, e la corsia è larga **1,8
tessere** per tutto il tragitto.

**La regola adesso è scritta e spacca da sola.** C'era già il controllo «niente davanti a una porta»
(v2.19.2), ma guardava solo la fascia dell'uscio: dentro la stanza non controllava nessuno, ed è per
questo che è successo di nuovo. Il nuovo controllo guarda il **tragitto**: dalla porta al mercante c'è
una corsia larga 1,2 tessere e dev'essere vuota, in ogni bottega. Ha trovato **altri tre casi** che
nessuno aveva segnalato: l'**incudine** in mezzo alla corsia del fabbro, due **casse** sulla riga del
banco del Capitano, e il **fuoco** dell'oracolo fra l'uscio e l'oracolo stesso. Spostati tutti.

**Test: 4513 passati, 0 falliti.** Il nuovo TEST 77 misura la scarica (colore di classe con lo stesso
scettro in mano a mago e warlock), le bacchette appiattite e la palla di fuoco che parte, vola, scoppia
ad area e non tocca chi è fuori dal raggio; il TEST 73 misura in più la corsia di ogni banco.

**Resta aperto** (come prima, e per la stessa ragione): gli **elementi delle verghe** — fuoco, gelo,
fulmine, veleno — non esistono ancora, quindi le abilità elementali si comportano tutte come fuoco.

---

### [2.19.10] — 2026-09-21 · "Un nome da eroe"

**Il nome proposto viene dalla classe.** *«Nomi casuali di eroi del fantasy, vincolati alla classe: che
so, Gandalf per il mago, o un paladino famoso. Ovviamente poi è modificabile.»* Al posto di «Eroe352»
il campo propone un nome a caso fra sette per classe:

| Classe | Nomi |
|---|---|
| Barbaro | Conan, Kull, Sonja, Fafhrd, Wulfgar, Beowulf, Grom |
| Paladino | Lancillotto, Galahad, Artù, Orlando, Uther, Sturm, Parsifal |
| Maestro d'armi | Aragorn, Boromir, Geralt, Inigo, Musashi, Brienne, Rinaldo |
| Assassino | Entreri, Ezio, Garrett, Arya, Corvo, Altaïr, Ombra |
| Arciere | Legolas, Robin, Bard, Merida, Tanis, Faramir, Guglielmo |
| Mago | Gandalf, Merlino, Raistlin, Elminster, Rincewind, Radagast, Dumbledore |
| Warlock | Morgana, Elric, Thulsa, Saruman, Malefica, Nekros, Vecna |

Cambiando classe con le frecce il nome cambia con lei — **finché il giocatore non l'ha scritto lui**:
un nome scritto a mano resta, qualunque classe si scelga dopo.

**«Da arciere», non «da arco»**, nella riga delle armature della scheda di scelta.

### [2.19.9] — 2026-09-21 · "La scheda che spiega"

Paolo, sulla schermata di scelta: *«creala più grossa, lo spazio c'è. Aumenta di 1 punto il font del
testo nel menu, è troppo piccolo. Aggiungi le competenze di classe piuttosto che la descrizione, così
uno capisce la differenza tra i vari personaggi. Indica anche con quale abilità scala.»*

**Più grande.** La colonna della scelta prende più spazio della guida dei comandi (1,45 a 1), e la
scheda non è più un quadrato: è alta almeno 520 px, con l'artwork più largo.

**Un punto in più a tutto il testo del menu**: scheda, campi, comandi, guida, titoli.

**Le competenze al posto della descrizione.** Sette righe per classe:

| Riga | Cosa dice |
|---|---|
| 📈 Scala con | la statistica del **danno** e, se ha magie, quella delle **magie** |
| ⚔️ Armi | cosa può impugnare (per tipo e peso; i pugnali dell'assassino per nome) |
| 🥼 Armature | cosa può indossare |
| 🤲 Due armi | se e con cosa combatte a due armi |
| 🛡️ Scudo | se lo porta, e con quali armi accanto |
| ✨ Abilità | l'abilità del livello 1 |
| ⭐ Passiva | il bonus di classe |

Non sono un testo scritto a parte: **si leggono dalle stesse tabelle che il gioco usa per decidere**
(`Gear.PERMESSI`, `Heroes.MANI`, la scuola dell'arma di classe, la firma). Se un giorno cambia una
regola, la scheda cambia con lei — non può dire una cosa mentre il gioco ne fa un'altra.

**Corretta per strada** la passiva del maestro d'armi: diceva *«con due armi la cadenza sale
dell'8%»*, ma dalla v2.19.6 la seconda arma dà danno, e l'8% si applica lì.

> ⚠️ **Segnalato, non cambiato:** il documento dà al maestro d'armi **Destrezza / Forza**, ma nel gioco
> il suo danno cresce solo con la **Forza** (la sua arma è della scuola «mischia»); la Destrezza gli
> dà soltanto un po' di passo. La scheda dice la verità del gioco: **danno: Forza**.

### [2.19.8] — 2026-09-21 · "Colpisci quello che vedi"

**⚔️ Il fendente colpisce quello che si vede, più 5 pixel.** *«A volte i nemici sembrano non prendere
danni.»* Misurato: il gioco **disegna i nemici 1,45 volte più grandi** (1,86 gli élite) del cerchio con
cui il server calcolava il colpo. Uno scheletro che a schermo entrava di **6 pixel** dentro il bordo bianco
del fendente veniva mancato; un élite nemmeno entrandoci di **12**. Adesso il colpo si misura sul **corpo
disegnato** del nemico — stessa formula del disegno — e, come chiesto, conta colpito anche chi sta fino a
**5 pixel oltre** il bordo bianco, in profondità e ai lati.

| bordo del nemico rispetto al bordo bianco | prima | adesso |
|---|---|---|
| dentro di 6 px (normale) | mancato | **colpito** |
| dentro di 12 px (élite) | mancato | **colpito** |
| lo tocca | mancato | **colpito** |
| 4 px fuori | mancato | **colpito** |
| 12 px fuori | mancato | mancato |

**🗡️ Assassino: Forza 4, Costituzione 6** (erano 6 e 4). Da **112 a 127 PV**, stesso danno: i pugnali
crescono con la Destrezza. La schermata di scelta legge la tabella, quindi mostra già i valori nuovi.

**🖱️ Il mirino arriva più lontano: 200 → 320 pixel.** E davanti al **mercante errante** il cursore torna
libero, come nel villaggio: lui compare in piena ondata, col cursore agganciato al mirino, quindi il suo
pannello si apriva ma non c'era un puntatore per cliccarlo.

**🧙 Il mercante errante vende un oggetto solo**, poi raccoglie le sue cose e se ne va fino alla prossima
ondata (con una nuvola dove stava e una riga che lo dice). **La vita extra costa 1000 monete** (era 180).

**Test** — 4390 passati, 0 falliti. Nuovo `[TEST 76]`: il bordo disegnato del nemico messo a distanze
note dal bordo bianco, per nemici normali ed élite, davanti e ai lati — colpito fino a 5 px oltre,
mancato più in là. Il test del mercante controlla che dopo un acquisto se ne vada e che la vita costi
1000.

### [2.19.7] — 2026-09-21 · "Lo zombie del patto"

**⚔️ L'arma a due mani rende di più: +35%.** *«Deve fare più danno, altrimenti non ha senso rinunciare
allo scudo.»* Ora rende circa **1,35 volte** un'arma a una mano dello stesso grado, quanto due armi
(1,37): le due vie che rinunciano allo scudo si equivalgono, e cambia lo stile — un colpo grosso col
rinculo, contro tanti colpi. Il barbaro, che la pesante la tiene a una mano, non lo prende.

| grado | una mano + scudo | **due mani** | due armi (maestro) |
|---|---|---|---|
| 2 | 93 | **134** | 157 |
| 3 | 108 | **156** | 160 |
| 4 | 122 | **176** | 179 |
| 5 | 148 | **212** | 219 |

**🔥 Il mago è solo Elementalista.** *«Evocatore e negromante sono troppo simili.»* Niente più scelta
della scuola al livello 1: riceve la Scarica Elementale come ogni classe riceve la sua firma. Nella
schermata di scelta è sparito il riquadro delle tre scuole e la descrizione dice cosa fa. Il suo titolo
è Elementalista. I salvataggi di un evocatore o di un negromante riprendono da elementalista: la firma
si sostituisce da sola, e le abilità del 7 e del 13 che non esistono più tornano da scegliere.

**🧟 Il warlock alza uno zombie**, al posto del Patto (che era un doppione della Maledizione
Contagiosa). **Una volta per ondata**, senza ricarica: sulla barra la casella dice «usata» fino
all'ondata dopo. Lo zombie **si sgretola a fine ondata**, e **può stare in campo insieme al mercenario**
(decisioni di Paolo). Si disegna col pupazzo degli zombie nemici, ma con **occhi, alone e cerchio
viola** del warlock: nella mischia si capisce subito che è tuo. PV e danno sono quote del warlock,
e crescono col suo Carisma.

**🐛 Perché l'evocazione restava «ferma impalata».** Il gioco dava l'intelligenza artificiale **a un
solo alleato**: il primo che trovava vivo. Dal secondo in poi gli evocati non ricevevano mai un ordine e
restavano lì. E lo stesso difetto aveva altri due effetti, trovati cercando il primo: un evocato veniva
**scambiato per il mercenario** — la sua morte segnava il mercenario vero come «caduto», e la sua
presenza impediva al mercenario di scendere in campo. Adesso ogni alleato ha la sua IA, e il
mercenario è il mercenario.

**Test** — 4373 passati, 0 falliti. Nuovo `[TEST 75]`: lo zombie si alza, **non** una seconda volta
nella stessa ondata, riceve gli ordini dell'IA **a ogni istante insieme al mercenario**, la sua morte non
tocca il mercenario, si sgretola a fine ondata e se ne alza un altro all'ondata dopo; l'arma a due mani
rende ~1,35 a ogni grado, e il barbaro non prende quel bonus. Verificato che il controllo sull'IA scatta
rimettendo apposta il vecchio difetto (il secondo alleato: 0 ordini su 60). Riscritti i controlli che
davano per giuste le tre scuole del mago.

### [2.19.6] — 2026-09-21 · "Due pugnali"

Cinque richieste di Paolo, e **due bug** trovati misurando.

**🗡️ L'assassino parte con due pugnali**, due oggetti diversi: il Pugnale Sbeccato e lo Stiletto
Sbeccato. Stesso danno al secondo per strade diverse — il primo colpisce un po' più forte, il secondo
un po' più spesso e di punta.

**🛡️ E con una corazza leggera da mischia**: il **Giaco di Cuoio Nero** (+10 PV, −4% danni subiti,
+3% passo) al posto degli Stracci, che davano +6 PV e **zero** riduzione del danno — cioè niente, su una
classe da mischia con la Costituzione a 4.

**🗡️ I pugnali, e via le sciabole.** *«Non si è mai visto un assassino con la sciabola.»* Una famiglia
d'arma sua, venduta dal fabbro ma visibile solo a lui: **due pugnali per grado** dal 2 al 5 (Pugnale e
Stiletto, Daga d'Ombra e Misericordia, Kris Serpentino e Stiletto del Vuoto, Zanna della Faglia e
Pungiglione d'Ossidiana), **a metà prezzo** — una coppia costa quanto un'arma degli altri. Due per
grado perché un oggetto non può stare in due mani: senza la coppia, al grado 5 l'altra mano resterebbe
al 4. L'assassino non vede più armi equilibrate né sciabole; dall'arciera, solo archi leggeri.

**⚔️ La seconda arma adesso dà danno.** Misurato: prima alzava solo la **cadenza**, e il numero «danno»
del pannello non si muoveva mai — un maestro faceva 36 con una sciabola e 36 con due. Adesso aggiunge
una quota del **proprio** danno al secondo, secondo quanto è maneggevole nella mano debole: **leggera
55%, equilibrata 35%, pesante 25%**. L'arma pesante **a due mani** non prende niente: è un'arma sola.

**⚔️ E l'ordine delle mani non conta più.** L'arma principale era sempre quella a destra: con le stesse
due armi si faceva 103 o 130 danni al secondo a seconda di come le avevi messe. Adesso la principale è
**la più forte**, dovunque sia — ed è anche il motivo per cui con due armi non si fa mai meno che con
la migliore da sola.

**🐛 Un oggetto sta in una mano sola.** *«Un'arma puoi metterla sia a destra che a sinistra, ma non è
possibile.»* Si poteva, e non dava niente. Adesso metterla nell'altra mano la **sposta**. (Un test di
ieri, per provare la doppia arma, metteva proprio lo stesso oggetto in due mani: considerava giusto il
bug. Riscritto con due oggetti.)

**🐛 I bonus mancavano alla partenza — per tutti, dalla v2.18.** Trovato perché un controllo che doveva
fallire passava. All'inizio della partita si ricalcolava l'equipaggiamento ma **non i bonus**: il
bonus di classe e quello della seconda arma arrivavano solo al primo cambio d'arma o alla prima carta.
Misurato: **arciere e mago partivano senza il loro +8%**, l'assassino coi due pugnali senza il 69% del
suo danno. Corretto sia all'inizio della partita sia per chi entra a partita iniziata.

**Il bilancio**, misurato, in multipli di un'arma a una mano dello stesso grado:

| | Rende |
|---|---|
| assassino, un pugnale | 0,80 |
| **assassino, due pugnali** | **1,38** — il «danno» sale da 18 a 29 |
| **maestro, due armi** | **1,37** — ma paga due armi intere |
| barbaro, due pesanti | 1,29 |
| arma pesante a due mani | 0,99 — invariata |

Il disegno segue: l'assassino mostra due lame, una, o l'arco, secondo cosa impugna.

**Test** — 4354 passati, 0 falliti. Nuovi controlli: due armi alzano il **danno** (non solo la
cadenza); le stesse due armi rendono uguale in qualunque mano; con due armi non si fa mai meno della
migliore da sola; l'arma a due mani non prende la quota della seconda mano; lo stesso oggetto si
sposta invece di duplicarsi; e **per tutte e sette le classi** il danno alla partenza è già quello
completo.

### [2.19.5] — 2026-09-21 · "Si disegna quello che impugni"

Due segnalazioni di Paolo, e la stessa radice sotto tutte e due.

**🐛 Il villaggio congelato.** *«Se al paladino equipaggio un'arma a due mani (e rimuove lo scudo)
non carica l'ondata successiva, ma mostra un'immagine freezata del villaggio.»*

Riprodotto dal vero — client vero, server vero, lo stesso gesto: impugnato lo Spadone, il disegno del
personaggio lanciava un errore **a ogni fotogramma**, il ciclo di disegno si fermava e restava l'ultima
immagine buona. Anche il movimento si bloccava. Il server invece andava avanti regolarmente.

La causa era un **nome condiviso**, ed era mio (v2.18). Nella tabella di stile del paladino c'era
`scudo: 1` — cioè «questa classe si disegna con lo scudo». Ma `scudo` è anche il nome del **colore** che
la tinta dello scudo impugnato scrive sulla tavolozza. Con lo scudo in mano il colore sovrascriveva il
numero e tutto funzionava; tolto lo scudo, al posto del colore restava `1`, e schiarire il colore `1`
è impossibile. Controllato: era l'**unica** collisione fra impostazioni di stile e colori di tinta.

**🐛 E un secondo, trovato cercando il primo.** Riprendendo una partita salvata, la mano sinistra
lasciata **vuota apposta** dall'arma a due mani veniva «riempita» con lo scudo di partenza: il paladino
tornava in gioco con **Spadone e scudo insieme**, la combinazione che le regole vietano. (Era anche il
motivo per cui il blocco non si vedeva ricaricando: lo scudo tornava da solo e ne nascondeva l'assenza.)
Ora le mani si riempiono solo se sono vuote **tutte e due** — cioè in un salvataggio di prima delle mani.

**🎨 Il barbaro con l'ascia.** *«Questo genera un'incongruenza se equipaggia una spada. Fallo più
generico.»* Stessa radice del blocco: il personaggio in gioco era disegnato secondo la **classe** — il
barbaro sempre con l'ascia, il maestro sempre con due spade, il paladino sempre con lo scudo — invece
che secondo **cosa impugna davvero**.

Adesso il corpo del guerriero (barbaro, paladino, maestro d'armi) disegna le sue **mani**:

- l'arma principale e l'eventuale seconda arma come una **lama generica** — né ascia, né spada, né
  maglio: *un'arma*, che non contraddice nessun pezzo del listino. Ciò che la lama dice è il **peso**,
  l'unica cosa che conta al colpo: la leggera è corta e sottile, l'equilibrata è la lama di mezzo, la
  pesante è lunga e larga — e se è **a due mani** la si tiene davanti al corpo, non di lato;
- lo **scudo solo se c'è**, e per chiunque lo imbracci: prima il barbaro e il maestro, a cui la
  tabella lo concede, lo portavano **invisibile**.

Per disegnare la seconda arma il server manda un campo nuovo, `wx`, solo quando c'è.

**E una rete di sicurezza.** Anche con la causa tolta, un errore di disegno non deve mai più fermare
la partita: il disegno di ogni personaggio è isolato, e se uno fallisce salta quel fotogramma mentre
tutto il resto va avanti. L'errore si scrive **una volta** in console, perché va visto e corretto, non
nascosto.

**Verificato dal vero** il percorso esatto della segnalazione: impugnato lo Spadone dal vivo →
portale → pannello → PROSSIMA MAPPA → **ondata 4**, schermo vivo, zero errori (prima: errore
all'istante). Disegnate otto combinazioni — barbaro con spada, pesante + scudo, due pesanti,
leggera; paladino con spada + scudo e con lo Spadone; maestro con due lame e con lama + scudo — tutte
senza errori, ognuna con in mano quello che ha.

**Test** — 4249 passati, 0 falliti. Nuovo `[TEST 74]`: la ripresa non ridà lo scudo a chi tiene una
due mani (e un salvataggio vecchio riceve ancora le mani), la partita arriva all'ondata successiva, lo
snapshot porta arma, seconda arma e scudo — e **nessuna impostazione dello stile può avere il nome di un
colore di tinta**. Verificato che quest'ultimo scatta davvero, rimettendo apposta `scudo: 1`.

### [2.19.4] — 2026-09-21 · "L'ascia del barbaro"

Paolo: *«l'estetica del barbaro non mi piace molto, sembra che abbia in mano una mazza da hockey»*.

**Il perché era geometrico.** Il manico era un tratto sottile, e la lama erano due «petali» piccoli e
sbilanciati attaccati **vicino** alla punta, non **in cima**; quello grosso sporgeva da una parte sola.
Stecca più paletta storta da un lato è il disegno di una mazza da hockey, da qualunque rotazione.

**Adesso è un'ascia da guerra a doppia lama**, con tre regole scritte nel codice:

1. la **testa sta in cima** al manico — il manico finisce dentro l'occhio della testa;
2. le lame sono **perpendicolari** al manico, non allungate lungo di lui;
3. sono **due e simmetriche**: una sagoma simmetrica attorno al manico non può sembrare una stecca da
   nessuna angolazione, ed è anche l'ascia dei barbari per antonomasia.

In più: manico più spesso con un filo di luce per dargli volume, **fasciatura di cuoio** dove la mano
stringe, **pomolo di ferro** in fondo, **filo chiaro** lungo il bordo delle lame (è quello che fa
leggere «lama» e non «piastra» anche a sedici pixel) e una piccola punta in cima. La mano sta a un
terzo dal pomolo, così la testa si allontana dal corpo e si legge da sola.

Controllato nelle tre pose (a riposo, a metà colpo, colpo pieno) sia ingrandito sia **alla dimensione
vera del gioco**, dove la sagoma a doppia lama si riconosce subito. Solo il disegno: nessuna regola,
nessun numero.

### [2.19.3] — 2026-09-21 · "Si vede cosa porti"

Paolo, con due screenshot: un paladino con lo **Spadone** in mano prova a imbracciare lo **scudo**. Lo
scudo giustamente non entra — lo Spadone è a due mani — *«ma è successo questo»*: al centro un
personaggio tagliato sul bordo, e nell'inventario scudo e Spadone praticamente identici.
*«Semplifichiamo: al centro metti l'artwork del personaggio. Rendi più evidente l'equipaggiamento
indossato. Nell'immagine si capisce poco che lo scudo non è equipaggiato.»*

**La regola non era rotta, il pannello sì.** Tre difetti, tutti nello stesso posto:

1. **Il ritratto era rotto.** Era il personaggio ridisegnato dal motore di gioco sessanta volte al
   secondo; dopo le sagome nuove della v2.18 usciva tagliato. **Ora c'è l'artwork della classe**, lo
   stesso della schermata di scelta — un'immagine invece di un disegno continuo.
2. **"In uso" era una stellina gialla di nove pixel.** Ora è un **bordo verde pieno** con alone, e una
   fascia **IN USO · DX / SX / 2 MANI** sopra la cella. I pulsanti della mano in cui il pezzo sta già
   sono **verdi pieni** — prima i DX/SX dello Spadone impugnato erano blu come quelli di un pezzo da
   prendere, e sembrava che fosse ancora da impugnare.
3. **Il rifiuto partiva e nessuno lo vedeva.** Il messaggio *«l'arma è troppo pesante per lo scudo»*
   andava nel riquadro dei messaggi di gioco, che col menu aperto sta **sotto** il menu. Hai cliccato e
   non è successo niente, senza un perché. Ora l'esito compare **sopra l'inventario**: rosso se
   rifiutato (col motivo), verde se fatto (con la mano). E un pulsante spento, cliccato, dice perché è
   spento invece di tacere.

**Due frasi sbagliate corrette per strada.** L'inventario diceva *«porti addosso l'unica roba che hai»*
mentre spada e scudo erano lì sotto inutilizzati: contava le **caselle** (sempre quattro) invece dei
pezzi indossati. E il rifiuto d'acquisto diceva sempre *«ce l'hai già»*, anche quando il motivo era
un altro (le ragioni nate con la v2.19 non avevano ancora una frase).

**Test** — 4230 passati, 0 falliti. Verificato nel browser con il **pannello vero del server** nello
stato esatto dello screenshot: artwork caricato, Spadone e casacca verdi, clic su SX dello scudo →
richiesta partita → rifiuto del server → riga rossa nel pannello col motivo giusto. Nessun errore in
console. I sette artwork rispondono tutti.

### [2.19.2] — 2026-09-20 · "Le soglie sgombre"

Paolo: *«perché metti oggetti all'ingresso delle case e/o negozi? toglili, rendono ingombrante
l'entrata, specie da arciere e mago»*.

**Aveva ragione, e non solo sulle due nuove.** Misurato: **cinque stanze su tredici** avevano mobili
solidi nella fascia della porta.

| Stanza | Cosa c'era sull'uscio | Dove è finito |
|---|---|---|
| **Archeria** | **tre bersagli**, uno in mezzo alla soglia | in fila contro la parete di settentrione — un tiro a segno visto di lato |
| **Bottega Arcana** | **tre cristalli**, il più grosso sulla soglia | in cerchio attorno al tappeto runico, in mezzo alla stanza |
| Casa del portale | un candelabro e la rastrelliera | candelabri stretti negli angoli, rastrelliera a ponente |
| Taverna | la colonna di tavoli di levante | arretrata di ottanta centimetri |
| Casa di settentrione | il focolare | scostato lungo la parete, dalla parte opposta alla porta |

**Il difetto era strutturale, non di posizionamento.** La regola della soglia esisteva già — è
`sgombro()` dentro `arredaCasa`, 1,5 tessere per lato e 2,6 di profondità — ma **valeva solo per le
case**. Le botteghe erano arredate a mano, una per una, e nessuno controllava. Le mie due botteghe
nuove sono nate dentro quel vuoto.

Adesso il controllo è **uno e vale per tutte le stanze**, sta nel generatore dopo che i mobili sono
stati messi, ed è l'unico punto in cui si vede il villaggio finito. **E spacca, non corregge**: un
filtro silenzioso toglierebbe un mobile senza dirlo, e chi ha arredato la stanza crederebbe di averlo
messo. Il villaggio è identico a ogni partita, quindi o l'errore c'è sempre o non c'è mai: se c'è deve
fermare tutto al primo avvio, non nascondersi in una partita su cento. *(Verificato che spacchi
davvero, rimettendoci un bancone sulla soglia apposta.)*

**Il focolare era l'unico mobile che saltava il controllo delle case**, perché veniva piazzato con `P`
invece che con `M`. Ora, se il centro non è libero, si scosta lungo la parete dalla parte opposta alla
porta — e **chi si scalda lo segue**, perché da adesso «il centro della stanza» e «il fuoco» non
coincidono più sempre.

**E una che avevo quasi sbagliato a segnalare.** Il primo metro — campionare i centri delle tessere —
diceva l'erboristeria **bloccata**. Non lo era: le tre aiuole lasciavano fra loro varchi da cui si
passa, e il campionamento grossolano semplicemente non ci cadeva dentro. Un flood fill a passo fine,
col corpo del giocatore vero contro gli ingombri veri, dice che **tutte e tredici le stanze si entrano
e tutti i banchi si raggiungono** — da sempre. L'erboristeria però era davvero **stretta** (0,75
tessere: ci si infilava di sbieco), ed era quello che si vedeva: le aiuole erano in colonna proprio sul
davanti. Il commento diceva *«le piantagioni in fila in fondo»*, ma con la porta a ponente il fondo è
l'altro lato. Ora sono una fila lungo la parete di mezzogiorno.

**Il passaggio più stretto del villaggio, prima e dopo:**

| | Prima | Dopo |
|---|---|---|
| Erboristeria | 0,75 tessere ⚠ | 2,06 |
| Archeria | *bloccata sulla linea* | **2,06** |
| Bottega Arcana | *bloccata sulla linea* | **2,06** |
| Peggiore di tutte | 0,75 | **1,17** (casa di settentrione) |

**Test** — 4230 passati, 0 falliti. Nuovo `[TEST 73]`, e misura in **due modi diversi apposta**: la
*regola* (la fascia, su tutte le stanze) e il *fatto* (flood fill a passo 8px col corpo vero, dalla
strada fino al banco di ogni mercante), più una terza prova sulla **larghezza** — almeno una tessera
libera, perché una soglia da cui ci si infila di sbieco è esattamente ciò che è stato segnalato. Una
regola rispettata non dimostra ancora che si passi: il fatto si misura, non si deduce.

### [2.19.1] — 2026-09-20 · "I pugnali dell'assassino"

Paolo: *«l'assassino parte con 2 spade ma lo sparo è la freccia»*. Un fix per volta, e questo è il primo.

**La causa, non il sintomo.** L'assassino dichiara come arma di classe i **Pugnali Gemelli** (mischia,
scuola `agile`) ma la sua **impalcatura è `ladro`**, e `startingGear` pescava il grado minimo del
catalogo dell'impalcatura — l'**Arco Sfibrato**. Il renderer nel frattempo lo disegnava con le lame
(`arma: 'pugnali'`), quindi si vedeva un uomo con due pugnali che tirava frecce. Su sette classi è
**l'unica** in cui corpo e famiglia d'arma non coincidono: ecco perché era l'unica che sbagliava.

| Classe | Arma di classe | Parte con | |
|---|---|---|---|
| Barbaro | Ascia da Guerra | Spada Scheggiata | mischia = mischia |
| Paladino | Spada Consacrata | Spada Scheggiata | mischia = mischia |
| Maestro d'Armi | Lame Gemelle | Spada Scheggiata | mischia = mischia |
| **Assassino** | **Pugnali Gemelli** | ~~Arco Sfibrato~~ → **Pugnali Sbeccati** | **era arco ≠ mischia** |
| Arciere | Arco Lungo | Arco Sfibrato | arco = arco |
| Mago | Bolla di Energia | Bastone Nodoso | magia = magia |
| Warlock | Dardo del Patto | Bastone Nodoso | magia = magia |

**I Pugnali Sbeccati**: grado 1, *leggera*, mischia — 22 danni × 3,5/s = **77 danni/s**, in linea con gli
altri tre pezzi di partenza (78-79). Stanno nel catalogo `guerriero` perché lì stanno le armi **da
mischia**, che è la loro tipologia: metterli fra gli archi per far tornare l'impalcatura sarebbe stato
rimettere a posto il sintomo lasciando la causa.

**Un tipo di pezzo nuovo: `avvio`.** Un grado 1 costa zero, e un grado 1 in più nel catalogo del fabbro
sarebbe stata un'arma leggera **gratis** per barbaro, paladino, maestro e warlock. I pezzi marcati
`avvio` non compaiono su nessun banco, non entrano nella forma del listino (che resta **117 pezzi**) e
li può avere solo la classe che ci sta scritta. Oggi ce n'è uno solo.

**La doppia arma non è regalata.** L'assassino parte con una mano sola occupata; il bonus di classe
(*«doppia arma leggera da mischia»*) si accende comprando la **seconda lama dal fabbro** — cosa che
prima non poteva fare, e che l'equipaggiamento misto della v2.19.0 ha reso possibile. La progressione
è quella, ed è coerente con la tabella.

---

**🐛 E un buco che avevo aperto io con la v2.19.0 — chiuso.** I pezzi di **grado 1 costano zero**.
Finché ogni classe vedeva un catalogo solo non si notava: il suo pezzo scarso ce l'aveva già addosso e
il controllo «è già tuo» bastava a chiudere la porta. Con l'equipaggiamento misto una classe vede anche
i pezzi scarsi di un **altro** catalogo, che non possiede — li comprava **gratis** e li rivendeva a
**8 monete** l'uno, in circolo, all'infinito. Misurato: 5 giri = 40 monete partendo da zero.

Adesso **il grado scarso non è merce**: `buyGear` rifiuta qualunque pezzo a costo zero, e il banco non
lo mette nemmeno in vetrina se non è già tuo (quello tuo resta, per rimetterlo su o rivenderlo una
volta sola). La regola è scritta come *«costo zero = non in vendita»*, non come un elenco di id, così
regge anche se domani il listino cambia.

**Test** — 4102 passati, 0 falliti. Due controlli nuovi che valgono per **tutte e sette** le classi, non
solo per chi ha sbagliato oggi: (1) ciò con cui una classe parte deve colpire come la sua arma di
classe — il giorno che nasce l'ottava, il difetto non torna in silenzio; (2) comprare e rivendere il
grado scarso non fa monete dal nulla.

### [2.19.0] — 2026-09-20 · "Le tre botteghe"

Paolo: *«togliere 2 case e metterci un venditore di magia (quindi equipaggiamento da mago) e uno da
arciere (quindi equi. da arciere). Questo perché, come ti ho scritto, ci sono classi che possono avere
equipaggiamento misto»*.

**Due case in meno, due botteghe in più.** `casa_a` (fila di ponente, sotto la fucina) è diventata
l'**ARCHERIA**; `casa_c` (fila di levante, sotto la gilda) la **BOTTEGA ARCANA**. Le case restano
cinque. Le due nuove stanze sono speculari alla fucina nell'impianto — bancone sulla porta, mercante
dietro — e diverse in tutto il resto:

| | Fucina | Archeria | Bottega Arcana |
|---|---|---|---|
| **Mercante** | Fabbro | **Arciera** | **Arcanista** |
| **Colore** | ambra `#ffb14a` | verde `#8fd96a` | viola `#a98cff` |
| **Pavimento** | lastre | terra battuta | lastre viola |
| **Arredo** | incudine, colata di lava, rastrelliere | **tre bersagli di paglia con le frecce piantate**, rastrelliere d'archi, faretre, cuoio | cristalli accesi, scaffali di volumi, tappeto runico, bastoni in rastrelliera |
| **Attrezzo in mano** | martello | **arco incordato con la freccia incoccata** | **bastone con la gemma accesa** |
| **Impalcatura** | barbaro | arciere | mago |
| **Catalogo** | `guerriero` | `ladro` | `mago` |

Il **bersaglio** è un mobile nuovo: balla di paglia su treppiede, tre anelli dipinti e tre frecce
sempre nello stesso punto — niente casualità, il villaggio dev'essere identico a ogni partita.

**L'EQUIPAGGIAMENTO MISTO, che è la parte vera.** Era una dipendenza aperta della v2.18 — i pezzi
restavano catalogati per le tre *impalcature*, e con un fabbro solo non si vedeva. Con tre botteghe si
vede subito. La regola adesso c'è, ed è la trascrizione delle sette tabelle di
`PIANO-CLASSI-SETTAGGI.md` §3, perché i **due assi** del documento sono già nel listino:

- **tipologia** (mischia / arco / magia) = il catalogo, cioè la bottega;
- **peso** (leggere / medie / pesanti) = il `carattere` del pezzo (leggera / equilibrata / pesante).

`Gear.PERMESSI` è quella tabella, riga per riga. Chi compra cosa, in breve:

| Classe | Fabbro | Arciera | Arcanista |
|---|---|---|---|
| **Barbaro** | armi tutte, **armature solo leggere**, scudi tutti | **armature e calzature leggere** | — |
| **Paladino** | tutto | — | — |
| **Maestro d'Armi** | tutto | — | — |
| **Assassino** | armi e armature **leggere/medie** | armi, armature e calzature **leggere/medie** | — |
| **Arciere** | — | tutto | — |
| **Mago** | — | — | tutto |
| **Warlock** | armi e armature **solo leggere** | — | tutto |

Tre classi su sette (**barbaro, assassino, warlock**) fanno adesso il giro di due botteghe: è quello
che «equipaggiamento misto» voleva dire.

**Il grado 1 non si filtra per peso**, ed è una scelta esplicita: i pezzi «scarsi» costano zero, non
si comprano, sono quelli con cui si parte, e nel listino di oggi esistono solo in versione
*equilibrata*. Filtrarli avrebbe fatto partire il barbaro con addosso una casacca che la sua tabella
gli vieta — uno stato che il resto del gioco non sa né disegnare né calcolare.

**Le mani hanno preso la tipologia.** Finché il negozio era uno, chiedersi «di che tipo è l'arma
nell'altra mano?» non aveva risposte diverse. Adesso sì, e le tabelle le distinguono: l'assassino fa
doppia arma *«leggere, SOLO MISCHIA»* — **non due archi**; il mago *«leggere, mago»* — non due pugnali;
lo scudo, nelle tre tabelle che lo concedono, sta sempre accanto a un'arma da mischia. `Heroes.MANI`
ha quindi due chiavi nuove, `doppiaTipo` e `scudoTipo`. Il barbaro resta l'unico con **arma pesante +
scudo**.

**Sul server** `gearMerchant` resta — e resta il fabbro, perché mezzo mondo lo legge (salvataggio,
minimappa, test) — e accanto c'è `gearMerchants`, la lista vera. `_bottegaVicina(p)` risponde *a quale*
banco sei: `_nearGear` non è più un sì/no ma il **catalogo** del banco davanti a cui stai. Comprare,
vendere ed equipaggiare passano tutti da `Gear.puoAvere`, che è una regola sola in un posto solo.

**Ogni bottega ricompra solo la sua roba.** L'arciera non ti prende indietro un bastone: è la stessa
regola del comprare letta al contrario, e tiene il pannello coerente con sé stesso.

**Un banco vuoto lo dice.** Un arciere davanti al fabbro non ha niente da comprare: il pannello scrive
*«Qui non c'è niente per te»* invece di aprirsi senza righe, che si legge come un guasto.

**Corretto per strada** — il banco non segnava mai «addosso». `offerGear` guardava
`p.gear[slot] === it.id`, ma dalla v2.18.1 le chiavi sono `manoDx`/`manoSx`: la casella `weapon` non
esiste più e il confronto era sempre falso. Adesso guarda se il pezzo è in **una qualunque** delle
caselle, come già fa l'inventario.

**Tolte 45 righe morte** dal renderer: il fabbro disegnato a mano della v1.52 (forgia, incudine,
martello che batte) era già stato sovrascritto dalla v1.57 e nessuno lo chiamava più. Adesso i
mercanti li disegna il giro degli npc, con l'**alone del colore della bottega** sotto ai piedi — e dal
minimappa i tre punti si distinguono a colpo d'occhio.

**Test** — 4054 passati, 0 falliti. Nuovo `[TEST 72]`: le tre botteghe, la tabella riga per riga
(comprese le righe «no»), nessuna classe che parte con addosso qualcosa di vietato, la compravendita
al banco giusto e a quello sbagliato, il pannello vuoto, le mani con la tipologia, e l'inventario
misto. Riscritti — non cancellati — una ventina di controlli che davano per scontato **un** negozio.

**Resta aperto** (segnalato, non fatto): l'arma sostituisce il *colpo* ma non la **scuola**, che è
ancora quella della classe. Un warlock con la sciabola mena di sciabola ma scala ancora con Carisma.
Sistemarlo vuol dire legare la scuola al pezzo — è il rifacimento per peso × tipologia. E le
**calzature** non sono in nessuna delle sette tabelle: qui seguono l'armatura (stessi cataloghi,
stessi pesi), ed è un'assunzione mia, da confermare.

### [2.18.1] — 2026-09-20 · "Le due mani"

Quattro cose segnalate da Paolo dopo la **prima partita** con le sette classi. Tutte e quattro erano
dimenticanze della v2.18, non richieste nuove.

**I ranghi non esistono più.** *«La classe di partenza rimane la stessa, invece il Barbaro è diventato
un Razziatore»*. Aveva ragione, e la v2.18 aveva sbagliato per inerzia: quando gli eroi erano tre e
senza nome proprio, i titoli di rango davano un'identità che cresceva; adesso l'identità ce l'ha dal
primo minuto — **si chiama Barbaro**, l'ha scelto lui guardando un artwork e cinque barre. Il titolo
accanto al livello è **il nome della classe**, sempre. `RANK_NAMES` resta vuoto e non cancellato, come
`CARDS` e `SPECS`; l'annuncio «sei diventato…» non parte più.

**«Baule» si chiama INVENTARIO** e mostra tutto quello che possiedi, con la **★** su ciò che stai
portando. Prima il «lo sto portando» si decideva con `p.gear[slot] === id`, cioè «è nella casella del
suo slot»: con le due mani quella domanda non ha più senso, e adesso si guarda se il pezzo è in **una
qualunque** delle caselle.

**«Addosso» si chiama EQUIPAGGIAMENTO** e le caselle stanno **attorno al personaggio**: mano destra in
alto a sinistra, mano sinistra in alto a destra (il personaggio si guarda di fronte), armatura e
calzature in basso. Era un elenco sotto il ritratto: diceva le stesse cose senza far vedere *dove*
stanno.

**Le due mani, per davvero.** L'equipaggiamento non è più `{arma, armatura, scudo}` ma
`{manoDx, manoSx, armatura, calzature}`, e le regole vengono dalle tabelle del documento:

- un'arma **pesante** è a due mani e occupa entrambe le caselle — **tranne per il barbaro**, che per
  questo può portare due asce, o un'ascia e uno scudo (*«unica classe che può portare arma pesante e
  scudo»*);
- **due armi** insieme solo per barbaro, maestro d'armi (leggere/medie), assassino e mago (leggere);
- lo **scudo** solo per barbaro, paladino e maestro d'armi, e non insieme a un'arma troppo pesante.

La regola sta in **un posto solo** (`Gear.impugna`), usata dal server per decidere e dal client per
spegnere i pulsanti **DX** / **SX** sulle caselle che quella mano non accetta. La seconda arma non
raddoppia il danno — alza la **cadenza**, che è come funziona combattere con due lame.

**Comprare non è più indossare.** Il pezzo comprato dal fabbro entra nell'**inventario**; impugnarlo è
un secondo gesto, con la mano scelta. Con due mani non era nemmeno più definito: in quale delle due
sarebbe dovuto andare?

**Corretto per strada:** la scaletta delle abilità scriveva «ricarica **undefineds**» — dalla v2.18 la
ricarica viene dallo **slot** e non sta più addosso all'abilità, e quella riga non se n'era accorta.
Ed `equipaggia` ricalcolava nell'ordine sbagliato (`gear` prima di `boons`), azzerando la perforazione
dell'arma appena impugnata.

**Test: 3979 passati, 0 falliti.** Il test dell'equipaggiamento è stato riscritto sulle due mani e
adesso prova le regole **classe per classe** — è quello che avrebbe visto subito un barbaro incapace di
tenere scudo e ascia insieme.

---

### [2.18.0] — 2026-09-20 · "Sette classi"

La versione più grossa dalla v1.66. **I tre eroi diventano sette classi**: barbaro, paladino, maestro
d'armi, assassino, arciere, mago e warlock. Tutte le decisioni, con le parole di Paolo accanto a
ciascuna, stanno in **`PIANO-CLASSI-SETTAGGI.md`** — questo file riassume cosa è stato fatto.

**La regola che ha reso fattibile il passaggio: `corpo`.** Ogni classe dichiara una delle **tre
impalcature** di prima — pesante (guerriero), agile (ladro), arcana (mago). Chi disegna o veste guarda
il corpo; chi bilancia guarda la classe. Senza questa distinzione sarebbe stata una riscrittura:
`gear.js`, il renderer e i mercenari continuano a ragionare per tre.

**Il Carisma è la quinta statistica.** Scala le magie di paladino e warlock, che non possono scalare
con l'Intelligenza senza diventare un'etichetta invece che una statistica. Il budget resta **14 punti**
su cinque righe invece di quattro: è voluto — *«la difficoltà o la scelta è proprio il saper distribuire
i punti»*. Le scuole di danno passano da tre a cinque (`melee`, `agile`, `ranged`, `magic`, `pact`):
`agile` esiste perché l'assassino vive di Destrezza ma combatte in mischia.

**La matrice di partenza è 7 × 5.** Picco 10 per le classi monostatistiche, 6-7 per quelle che ne hanno
due. Il tetto `STAT_MAX` resta **20** anche se i picchi ora sono 10 — decisione esplicita di Paolo
(*«lascia così anche il tetto, so cosa faccio»*), e il warlock somma 23 invece di 22: **segnalati
entrambi e lasciati così. Non sono bachi.** Il centro del profilo di classe scende da 5,5 a **4,4**
(la media di 22 su cinque caselle) e il peso da 0,5 a **0,38**, perché con i picchi a 10 lo scarto
massimo più che raddoppiava.

**Trenta abilità attive al posto di dodici.** Al livello 1 la **firma** non si sceglie, si riceve —
l'unica eccezione è il mago, che sceglie la **scuola** (elementare / evocazione / negromanzia) e ne
prende il titolo. Ai livelli 7 e 13 si sceglie fra una abilità **nuova e solo sua** e una del
**serbatoio**, cioè una delle dodici di prima. Le diciotto nuove e le nove firme sono tutte scritte.
Le **evocazioni** si appoggiano alla macchina del mercenario, che è già un alleato con PV, arma e IA.

**La regola dei 10 secondi.** Ogni effetto a tempo dura 10s, con tre eccezioni che *non sono* effetti a
tempo — Turbine (1,2s), Salva (2s), il blocco della Tagliola (2,5s) — e una quarta cosa che esce dalla
regola da un'altra parte: lo **Scudo di Mana non scade**, assorbe **8 danni per punto di Intelligenza**
e dura fino a fine ondata. Le ricariche restano **30 / 45 / 60**: segnalato che così un'abilità del
primo slot è attiva un terzo del tempo, e accettato con una ragione di gioco — *«spesso ci si dimentica
di usarle»*.

**Il terzo slot non è più spento.** Era vuoto dalla v2.16 in attesa di una decisione: adesso ogni
classe ha le sue due candidate anche al 13.

**Le passive: sei carte nuove, da 32 a 38.** Contate fascia per fascia sulle sette classi, quattro ne
avevano *una sola* da qualche parte; adesso ognuna vede quattro offerte a ogni fascia. Le tre scuole
del mago condividono le passive di proposito: le carte che le distinguerebbero parlerebbero tutte di
creature evocate, e **non si progetta una carta prima della meccanica che descrive**.

**Le specializzazioni del livello 15 spariscono.** Quattro dei sei rami (Paladino, Maestro d'Armi,
Assassino, Stregone) sono diventati *classi*: tenerli avrebbe voluto dire un assassino che al
quindicesimo si specializza in assassino. `SPECS` resta vuoto e non cancellato, come `CARDS` dalla
v1.70. Il 15 dà il tetto, il punto statistica e il titolo dell'ultimo rango — che adesso esiste per
tutte e sette.

**L'estetica.** La scelta dell'eroe non è più tre riquadri ma **un box quadrato**: artwork a sinistra,
a destra nome, epiteto, i cinque attributi a barre e la descrizione; frecce ai lati e tasti ← →. I
sette ritratti stanno in `public/assets/classi/`. In partita le **sagome** si distinguono per testa,
spalle, arma e tinta sulle stesse tre impalcature — nessuna struttura di disegno nuova.

**Cose sistemate per strada:**
- la **Piastra** (−12% danni subiti) passa dal guerriero al paladino, che ne è l'erede difensivo;
- la legenda dei comandi nel menu diceva ancora *«1 2 3 Pozioni · Q E Abilità, si sbloccano al livello
  8 e al 14»*: era rimasta alla versione prima della v2.16, che aveva invertito i tasti;
- `#heroBox` era usato da **due** elementi diversi (il nuovo riquadro di scelta e il ritratto in
  partita): il secondo vinceva e il primo collassava a zero. Il nuovo si chiama `#heroScelta`;
- le **nebbie** erano macchina morta dalla v2.17 (il Velo d'Ombra era stato sostituito dal Tempo
  Rubato) e tornano come **campi a terra**: Fame delle Tenebre, Nube Mortifera e le pozze
  dell'Impronta Elementale, tre abilità su una macchina sola.

**I salvataggi vecchi si rifiutano** (`FORMATO` da 3 a 4): un salvataggio con `heroId: 'guerriero'` non
è recuperabile — quella classe si è divisa in tre e nessuno può indovinare quale volesse essere.

**Test: 3949 passati, 0 falliti.** I test che affermavano il vecchio impianto sono stati **riscritti,
non tolti** — quello delle specializzazioni adesso afferma che il bivio *non* compare, quello delle
abilità cammina su tutte e trenta invece che sulle dodici di prima, e quello delle carte gira su sette
classi invece di tre (è quello che avrebbe visto subito i quattro buchi riempiti dalle carte nuove).

---

### [2.17.1] — 2026-09-19 · "La modalità di prova si vede"

Il pannello delle prove esisteva, stava nel posto giusto — sotto la scelta dell'eroe — e **aveva la
classe `hidden` addosso**. Per aprirlo bisognava sapere di `?test` nell'indirizzo o del tasto **T**
premuto nel menu: due scorciatoie che conosce solo chi ha letto il codice. Il commento lì accanto,
dalla v1.99, diceva *«la modalità di prova torna VISIBILE nel menu»* — e quella riga non era mai stata
tolta.

Adesso è una **voce di menu**: chiusa, sotto «ENTRA IN PARTITA», si apre con un clic. Dentro ci sono le
abilità attive da scegliere e i venti pulsanti delle ondate. Le due scorciatoie restano e ora si limitano
ad aprirla.

Ritoccato anche il testo, che prometteva la vecchia modalità: ora dice che si entra **con le abilità
scelte lì sotto** e che **dall'ondata 1 si parte subito**, senza prologo né villaggio.

---

### [2.17.0] — 2026-09-19 · "Il muro di fuoco esiste, il tempo si ruba"

#### 🔍 Perché il muro di fuoco «non aveva nessun effetto grafico»
Perché **non veniva disegnato affatto**, e non da ieri: da **otto versioni**.

`muri`, `trap` e `nebb` stanno nello snapshot dalla v1.85 e **non erano mai stati copiati** nel mondo
interpolato dentro `main.js`. Il server li mandava, il client li buttava, il renderer disegnava tre array
vuoti. Nessun errore, da nessuna parte. Per tutto questo tempo **il muro di fuoco, la tagliola e il velo
d'ombra sono stati invisibili** — il che spiega anche perché due di quelle tre abilità sembravano non
valere niente.

In quel punto di `main.js` c'era già scritto, in maiuscolo, *«ATTENZIONE — QUI SI PERDONO I CAMPI
NUOVI»*, e c'era già un controllo: ma copriva i campi letti dall'**HUD**, non quelli letti dal
**renderer**. Ora c'è un controllo che legge dal sorgente quali `world.<campo>` il renderer usa davvero e
pretende che `main.js` li copi tutti. Girandolo, ha trovato **un quarto campo perso**: `tick`, il tempo
della partita con cui il renderer piazza i girovaghi del villaggio — senza, ognuno in cooperativa li
vedeva altrove.

#### 🧱 E adesso il muro è un MURO
Misurato prima: 29 danni/s su uno spessore di 24px. Un mostro che lo attraversa ci resta dentro 0,2s e si
becca **6 danni su 78** — l'8%. La descrizione prometteva di «decidere da dove ti arrivano addosso»; il
codice non lo faceva.

Ora **nega il terreno**: per i mostri è muro a tutti gli effetti. L'IA lo aggira, il negromante non ci si
teletrasporta, **la Sfera d'Ossa ci rimbalza contro**. Il giocatore ci passa attraverso — la distinzione
sta in `moveCircle`, che riconosce un mostro da un giocatore senza bandiere nuove. Il danno diventa il
pedaggio di chi ci striscia contro, non il senso dell'abilità.

**La grafica**, rifatta a quattro strati: alone sul pavimento, colata arancione pulsante, cuore
bianco-giallo che si vede da lontano, fiamme fitte (una ogni 18px invece di 34) più braci che salgono.
Nell'ultimo secondo lampeggia e cala: si capisce che sta per finire. E ogni mostro che ci sbatte fa una
**vampata** nel punto di contatto.

#### ⏳ Tempo Rubato prende il posto del Velo d'Ombra
Il velo era una nube in cui nasconderti: in un gioco dove ti arrivano addosso da ogni parte non cambiava
l'ondata, la metteva in pausa. Al suo posto la vecchia **bullet time** dei tre eroi cyberpunk, tolta nella
v1.66 insieme a loro — e il motore la sapeva ancora fare: `this.bulletTime` c'è sempre stato, col suo
fattore su mostri e proiettili nemici. **Mancava solo chi lo accendesse.**

Per 4s il mondo va al **35%**, tu no. Si accende sulla stanza, non sul giocatore: rallenta per tutti, ed
è anche il motivo per cui dura poco. Il nome non è un vezzo — un ladro al tempo lo *ruba*.

**La grafica:** tinta fredda su tutto lo schermo, vignettatura blu che stringe i bordi, due anelli lenti
dal centro (l'orologio che batte piano), rampa di 0,25s in entrata e in uscita perché un taglio netto
sembrerebbe un lampo. Più anello e scossone dal personaggio e la fascia «⏳ TEMPO RUBATO».

#### 🧪 La modalità di prova sceglie le magie
Nel pannello delle prove c'è ora un selettore essenziale: una riga per tasto, le due abilità di quello
slot, si clicca e si parte. **Anche dall'ondata 1** — prima l'ondata 1 passava da prologo e villaggio e il
personaggio di prova non veniva nemmeno costruito. Gli id li valida il server contro il catalogo della
classe: uno di un'altra classe si ignora invece di finire in mano al personaggio.

Verificato dalla strada vera, non da un fixture: menu → personaggio → abilità → ondata 1 → **tasto
premuto**, e si guarda lo schermo. Il muro compare, il tempo rallenta.

**3298 test passati, 0 falliti.**

> 📌 Restano in giro `nebbie` e `veloCrit`, che erano del velo d'ombra e ora non li riempie più nessuno.
> Non li ho tolti in fretta perché `veloCrit` passa dal codice dei critici: da fare con calma.

---

### [2.16.4] — 2026-09-19 · "Il grado stampato sopra il nome"

La v2.16.3 aveva rifatto le carte della scelta in orizzontale ma erano **illeggibili**: la riga del grado
finiva stampata **sopra il nome**, e il nome restava minuscolo. Due cause, tutte e due nel foglio di
stile, e tutte e due dello stesso tipo — **regole vecchie più specifiche delle nuove**.

#### 🐛 `position:absolute` ereditato
Il modello base delle carte grandi ha `.bc .rar{position:absolute;top:8px;right:10px}`: su una carta da
150px la rarità sta nell'angolo. Le carte della banda ora sono **righe**, e in quell'angolo c'è il nome:
senza un `position:static` esplicito il grado veniva disegnato **sopra**. Non era un problema di margini,
era un elemento fuori dal flusso.

#### 🐛 Il blocco dei corpi del carattere della v2.13.6
`#upgradeScreen #sceltaBanda .bc .nm{font-size:calc(9.5px + var(--fz))}` — tarato sui quadrati da 84px,
e **più specifico** della regola nuova (due id contro uno), quindi vinceva. Ora quel blocco porta i corpi
giusti (14,5 / 10,5 / 12,5px) e ne ha anche per il grado e la descrizione, che prima non c'erano.

#### ✂️ Due etichette accorciate
«DELLA TUA CLASSE» → **«TUA CLASSE»**, e sulle attive via il «tasto 1», che è già scritto nella riga
sopra la banda: ripetuto su ogni carta mandava la riga a capo senza aggiungere niente.

#### ✅ Le passive hanno la stessa struttura, e sono quattro
Verificato con i due casi veri: **2 carte** (le attive di uno slot) e **4 carte** (le passive di uno
scaglione). Stanno su **una riga sola** — quattro carte da 250px fanno 1.051px dentro un pannello da
1.280 — e in nessuna delle sei carte nome, grado e descrizione si intersecano. La misura è sui rettangoli
veri dei tre pezzi di testo, non sull'occhio.

**3297 test passati, 0 falliti.**

---

### [2.16.3] — 2026-09-19 · "La scaletta dice la verità, e le carte della scelta si leggono"

Tre cose segnalate da Paolo con le schermate alla mano.

#### 🐛 «— saltata» su un'abilità appena scelta (per la seconda volta)
La v2.16.2 aveva fatto leggere le abilità al pannello da `inv.abil`, che il server manda dentro
`OFFER_SHOP`. Giusto, ma **mancava metà del lavoro**: dopo la scelta il server non rimandava il
pannello, quindi il client continuava a rendere la copia di **prima** della scelta. La riga diceva
ancora «saltata». Ora `_prendiAbilita` rimanda `offerShop(p)` — `offerShop` e non `_inviaPannello`, che
rifarebbe tutto il giro delle offerte e riaprirebbe una scelta già chiusa.

#### 🐛 «Da scegliere adesso» su DUE righe (liv. 1 e liv. 5)
Quando il pannello offre un'abilità attiva, il server ci mette dentro un `tier` — `rare` per il primo
slot, `divine` per gli altri — che serve **solo a colorare la banda**. La scaletta lo prendeva per buono
e accendeva anche la riga della passiva **rara del livello 5**: due righe che chiedevano una scelta
quando la scelta era una sola. Ora il `tier` si guarda solo quando l'offerta **non** è un'abilità.

Stessa bugia, stesso posto: sulla carta dell'abilità c'era scritto «Raro». Adesso c'è scritto quello che
è — **⚡ attiva · tasto 1 · ricarica 30s**.

#### 🃏 Le carte della scelta come quelle dell'armeria
Erano quadrati da 84px con la descrizione **nascosta nel tooltip**: si leggeva una carta per volta, col
mouse fermo sopra — il contrario di ciò che serve quando bisogna sceglierne una fra tre. Ora sono carte
**orizzontali da 250px**: icona a sinistra, nome nel colore del grado, sotto grado e «per tutti / della
tua classe» (o il tasto e la ricarica, se è un'attiva), e la descrizione per esteso. **`el.title`
rimosso**, come al fabbro: l'informazione o è a schermo o non c'è.

#### 🧪 Verificato dalla strada vera
Non da un fixture comodo: pannello del livello 1 con l'offerta dell'abilità aperta, esattamente come la
manda il server (`tier` compreso), poi il clic sulla carta e il pannello rimandato. Risultato: **una**
riga chiede la scelta, le carte sono 250×148 senza tooltip con la descrizione a schermo, e dopo il clic
la riga del livello 1 dice «⚡ Carica · ricarica 30s». **3297 test passati, 0 falliti**, e i controlli
nel browser della schermata aggiornati alla forma nuova.

---

### [2.16.2] — 2026-09-19 · "Due bachi della 2.16, trovati leggendo il codice"

Paolo, con due schermate: *«non hai risolto nulla, inoltre ho preso l'abilità attiva ma segna saltata»*.
Aveva ragione su entrambe, ed entrambe erano mie della v2.16.

#### 🐛 La barra: la misura c'era, ma arrivava vuota
La v2.16.1 faceva misurare alla barra la propria larghezza dentro `buildAbilityBar`, una volta sola. Ma
`buildAbilityBar` **gira alla scelta del personaggio, quando l'HUD è ancora nascosto** — e un elemento
nascosto misura **zero**. La riga «se è zero non scrivo niente» faceva il suo dovere, il CSS restava sul
valore di riserva (480px) e in partita la cintura tornava sopra la barra. Misurato: `--abw` valeva `""`.

Adesso un **ResizeObserver** guarda la barra e scrive la misura quando passa da zero a larga, e a ogni
aggiornamento dell'HUD si ricontrolla (una lettura, e copre i browser senza observer). Verificato
riproducendo la condizione vera — barra costruita a HUD nascosto, poi HUD mostrato — a **1600 e 1280px**:
`--abw` passa da `""` a `554px` e le quattro cose in fondo non si toccano.

> La prova della 2.16.1 non l'aveva visto perché misurava a HUD **già visibile**: provava che la formula
> è giusta, non che il numero ci arrivi. È lo stesso errore di sempre — provare la funzione invece della
> strada.

#### 🐛 «— saltata» su un'abilità appena presa
Due bachi in una riga sola, `const id = (this._abSlot || {})[sc.slot]`:
- `_abSlot` nella v2.16 è diventato un **array indicizzato da 0**, ma `sc.slot` vale **1, 2, 3**: lo slot
  1 pescava il secondo e lo slot 3 non pescava niente;
- e comunque `_abSlot` lo riempie lo **snapshot del gioco**: al livello 1, appena scelta l'abilità e
  prima ancora di scendere, non è ancora arrivato nessuno snapshot.

Ora il pannello legge le abilità da **`inv.abil`**, che il server gli manda insieme a tutto il resto: la
verità viene da chi la possiede, non da un residuo del gioco.

#### ✏️ E una frase rimasta indietro
Sotto la banda della scelta c'era ancora scritto «Passive ai livelli **3, 6, 9 e 12**, abilità attive
all'**8** e al **14**» — la scaletta di due versioni fa. Adesso l'elenco si costruisce da `levels.js`.

**3295 test passati, 0 falliti**, più i controlli nel browser.

---

### [2.16.1] — 2026-09-19 · "La barra in basso non si pesta più i piedi"

Segnalato da Paolo: *«la grafica dei tasti Q ed E si sovrappongono agli altri»*. Vero, e misurato.

#### 📐 Il perché
La barra delle abilità sta al centro dello schermo; **cintura**, **riquadro dell'eroe** e **vitali** si
appoggiano ai suoi fianchi. Lo facevano con scostamenti **scritti a mano** (`calc(50% + 240px)`), tarati
su una barra da **quattro** riquadri. Con la v2.16 i riquadri sono diventati **cinque** (le abilità sono
passate da due a tre): la barra si è allargata di **108px**, cioè 54 per lato, e la cintura le è finita
sopra — i tasti Q ed E addosso allo Scatto.

Misurato nel browser: barra `x523..1077`, cintura `x368..560`. **37px di sovrapposizione.**

#### ✅ La larghezza la dice la barra, non un numero
`buildAbilityBar` misura il proprio rettangolo e scrive `--abw` sul documento; i tre vicini si
posizionano da lì (`calc(50% + var(--abw)/2 + 14px)`). Il giorno che arriva un quarto slot non si rompe
niente — che è il punto: il numero scritto a mano si era rotto alla prima occasione utile.

#### 🐛 E sei pixel che c'erano da prima
Sotto i 1440px la cintura non sta di fianco alla barra ma **sopra**, a `bottom:124px`. La barra sta a
`bottom:20px` ed è alta 110, quindi arriva a 130: **la cintura la copriva di sei pixel**, e non c'entrava
niente con la v2.16 — c'era già. Ora è a 140.

#### 🧪 Il controllo che impedisce il ritorno
`prova-tasti` adesso misura i **rettangoli veri** delle quattro cose in fondo allo schermo e verifica che
non si intersechino — in **tutte e due le disposizioni**, stretta (≤1440, cintura sopra) e larga (cintura
di fianco). L'errore segnalato stava proprio in quella larga, e una prova fatta solo a 1000px non
l'avrebbe visto. **3297 test passati, 0 falliti.**

---

### [2.16.0] — 2026-09-19 · "La progressione rifatta"

Piano: `PIANO-PROGRESSIONE.md`. Nasce da un'osservazione di Paolo — *«ci sono abilità passive e solo 2
attive»* — verificata coi numeri: le attive si sbloccavano ai livelli 8 e 14, che con la curva
dell'esperienza vera arrivano all'**ondata 12 e 18 di 20**. Undici ondate su venti col solo clic sinistro.

#### 🪜 La scaletta
Attive ai livelli **1, 7, 13**; passive a **3, 5, 9, 11**; specializzazione al 15. Otto momenti
distribuiti invece di sei ammassati in fondo, e si comincia **con un'abilità in mano**.

#### ⚡ La prima attiva si sceglie prima di scendere
Si parla con l'anziano, si attraversa la faglia e ci si trova davanti la schermata di fine livello: la
scelta è necessaria per proseguire. Il blocco è su `shopReady`, cioè **sul server** — che ripropone la
scelta invece di ignorare il clic in silenzio. Un pulsante grigio si aggira; il metodo che decide se
l'ondata parte, no.

#### ⌨️ I tasti si sono scambiati il mestiere
**1 2 3** → abilità (da due slot a tre) · **Q E** → pozioni (da tre slot a due). Vanno insieme: tre
abilità non stanno su due tasti, e due pozioni non hanno bisogno di tre. Il terzo slot **non ha ancora
nessuna abilità dentro** (Paolo ci vuole riflettere): si vede tratteggiato e dice «in arrivo», e il
livello 13 per ora dà solo il punto statistica. Uno slot vuoto non entra mai nella coda delle scelte —
bloccherebbe il giocatore su una scelta senza scelte.

#### 🎖️ I ranghi diventano scenici
Davano un punto statistica ciascuno (le fasce 2-5). Ora danno il titolo e basta.

> ⚠️ **Il prezzo, in cifre.** Il budget di una partita passa da **18 punti a 14**: −22% su un sistema in
> cui i punti sono l'unica cosa che alza danno e PV. Deciso da Paolo sapendo la cifra. Se il personaggio
> risulterà troppo magro, la via che ha in mente è alzare le **statistiche di base**, non rimettere i
> punti sui ranghi.

#### 💾 `FORMATO` 2 → 3: i salvataggi di prima si rifiutano
La cintura è scritta come tre slot e `abil` come `{q, e}`. Si potrebbe convertire, ma un salvataggio
mezzo convertito è peggio di uno rifiutato. Stessa scelta della v2.12.

#### 🧹 Dentro
- `p.abil` e le ricariche erano **quattro variabili sciolte** (`cdQ`, `cdE`, `cdQMax`, `cdEMax`): col
  terzo slot sarebbero diventate sei, col quarto otto. Ora sono array, e lo snapshot porta un elenco
  (`ab`, `cab`) invece di quattro campi.
- Il **Marchio** non si cerca più «nello slot E» ma **in quale slot è**: era un accoppiamento nascosto
  che si sarebbe rotto il giorno in cui l'abilità cambia posto.
- `_slotDovuto()` decide in **un posto solo** cosa è dovuto a un livello, e serve due volte: al salire di
  livello e all'inizio partita — perché il livello 1 non si "raggiunge" mai, quindi nessun level-up lo
  avrebbe annunciato.
- Il pannello non riscrive più la scaletta a mano: la **legge da `levels.js`**. Scritta due volte, prima
  o poi le due copie si allontanano e il pannello mente.

#### 🧪 I test
**3297 passati, 0 falliti**, più tre controlli nel browser.
- **Nuovo `prova-tasti`**: preme davvero i tasti e guarda cosa esce da `Input.build`. Se il client
  mandasse ancora i vecchi campi `q`/`e`, il server leggerebbe zero e non succederebbe niente — in
  silenzio, che è il modo peggiore.
- **La prova della scaletta rifà il conto delle ondate a ogni esecuzione**: se qualcuno tocca l'XP o la
  composizione delle ondate e le scelte scivolano in fondo, si rompe lì e non in partita. È la misura da
  cui è nata questa versione, diventata il test che impedisce di ricrearla.
- Una trentina di test affermavano la vecchia scaletta: **riscritti, non tolti**.
- L'aiuto in cima a `simulate.js` sceglie la prima attiva da solo, come già salta il prologo: dichiarato,
  in un posto solo, e i test della scelta passano dalla strada vera (`avviaSenzaAbilita`).
- **TEST 38 seminato**: falliva una volta su quattro. Non era la coda — se nell'ondata sorteggiata
  capitano delle **larve**, quelle si fanno esplodere da sole, liberano posto e la coda ne versa altre.
  L'asserzione dipendeva dal sorteggio; l'invariante vera (coda e contatore coincidono) no.

---

### [2.15.3] — 2026-09-17 · "Le calzature del mago"

Il mago aveva **due** slot (arma, armatura), il guerriero e il ladro **tre**. Non è una regressione
recente: è così dalla v1.78, cioè dal giorno in cui l'equipaggiamento esiste, e nessun commento diceva
perché. Il conto del catalogo lo confermava: 104 pezzi = 8 slot × 13, non 9.

#### 👢 Tredici pezzi nuovi
`mag_b_*`, dal grado scarso al divino, tre caratteri per grado. **I numeri sono gli stessi delle
calzature del ladro, riga per riga**: lo slot è lo stesso e quella scala è già tarata, quindi copiarla è
l'unico modo di aggiungere tredici pezzi senza aprire un cantiere di bilanciamento. Cambiano i nomi —
sandali e calzari, non stivali ferrati. Il catalogo passa da **104 a 117 pezzi**, `SLOTS.mago` guadagna
`boots`, e la scala completa costa **6.120 monete** (2.560 tornano indietro rivendendo i sorpassati).

> ⚠️ **Sul mago questa roba NON SI VEDE, e va detto prima di giocarci.** `_heroMago` lo disegna come una
> veste che arriva a terra: i piedi non ci sono, e la `tinta` (`steelDk`) è la chiave che usano lo
> stivale del guerriero e quello del ladro, che il mago non legge. L'unico effetto visibile è **l'alone
> del grado divino**, che guarda anche il rango delle calzature. Per farle vedere davvero bisogna toccare
> il disegno del mago — far prendere all'**orlo** della veste il colore delle calzature — ed è un lavoro
> a parte.

#### 💾 I salvataggi fatti prima
Gli id non sono cambiati e il `FORMATO` nemmeno, quindi un vecchio pacchetto resta valido. Ma dentro non
c'è lo slot nuovo, e senza fare niente il mago si sarebbe ripreso **scalzo per sempre** — nemmeno il
pezzo di base, che a tutte le classi è regalato. `riprendi` ora riempie gli slot mancanti col pezzo di
partenza, ed è la stessa riga che salverà il prossimo slot aggiunto.

Il test che lo controlla **è stato provato al contrario**: disattivando il riempimento fallisce
(`p.gear.boots === undefined`). La prima stesura passava anche senza la correzione, perché la stanza
faceva `startGame()` e `riprendi` esce subito se non si è in lobby: una prova che non provava niente.

#### 🧪 Stato
**3277 passati, 0 falliti**; il controllo nel browser del fabbro vede 117 pezzi e **9 slot** invece di 8,
tutti senza testo tagliato né traboccato.

---

### [2.15.2] — 2026-09-17 · "Il catalogo del fabbro come quello dell'Erborista"

Parole di Paolo davanti alla 2.15.1: *«perché hai messo il testo tutto centrale? Oltretutto il font è
piccolissimo»*, e poi *«prendi esempio dall'erborista, il suo catalogo l'hai fatto bene»*. Aveva ragione
su entrambe.

#### 🃏 Carte orizzontali, tre per riga
Le celle quadrate costringevano a incolonnare cinque statistiche e a rimpicciolire tutto per farcele
stare: veniva fuori una lapide di testo **centrato da 9,5px**. Le carte dell'Erborista (`.pc`) sono
orizzontali — icona a sinistra, nome nel suo colore, descrizione sotto — e si leggono perché il testo
scorre come scorre l'occhio. Ora il fabbro è fatto così: **3 per riga**, testo **a sinistra**, nome a
**14,5px** e statistiche a **12,5px**.

#### 🔀 Due cose diverse dall'Erborista, e perché
- **Il prezzo sta sulla riga del grado, non nell'angolo in alto a destra.** All'Erborista i nomi sono
  corti («Cura», «Fretta»); qui si chiamano «Scettro delle Stelle Morte», e riservare l'angolo al prezzo
  spezzava il nome in due righe su metà delle carte. Provato e scartato.
- **L'icona è il simbolo del carattere (▰ ▱ ▫), non l'emoji dello slot.** Dentro la linguetta «Arma»
  l'emoji ⚔️ sarebbe identica su tutte e tredici le carte: occuperebbe spazio senza distinguere niente.

Tolto anche il prezzo dai pezzi **già tuoi**: rimetterli addosso non costa niente, e una cifra lì sopra
diceva il contrario.

#### 🐛 `min-width:0`, che non è un dettaglio
Una casella di griglia parte da `min-width:auto`, cioè non si stringe sotto la larghezza del suo
contenuto: il grado più lungo («LEGGENDARIO · EQUILIBRATA») allargava la colonna e **la terza carta della
riga finiva fuori dalla finestra**. Visto sull'anteprima prima di consegnare.

---

### [2.15.1] — 2026-09-17 · "Il fabbro largo come gli altri, e le statistiche scritte"

Due richieste di Paolo sulla finestra del fabbro.

#### 📏 «La finestra delle armi è più piccola delle altre»
Vero, e misurato: le tre finestre del villaggio avevano larghezze massime diverse — **Fabbro 620px,
Erborista 760, Banditore 860** — e quella del fabbro, essendo dimensionata sul contenuto, a schermo
stava sui **494px**. Ora è **760 come l'Erborista**, con `width` e non solo `max-width`: con la sola
massima si sarebbe ristretta di nuovo sul contenuto e il problema sarebbe tornato.

Restano **4 celle per riga** (la regola data da Paolo nella fase 3), quindi le celle passano da 110 a
**175px**. Scelto da lui fra tre varianti misurate.

#### 📝 Le statistiche tornano DENTRO la cella, e il tooltip sparisce
Nella 2.14 tutto ciò che non stava in 110px finiva nel `title`: statistiche, grado, carattere,
rivendita. Funzionava solo col mouse fermo sopra, **un pezzo per volta** — cioè il contrario di quello
che serve in un negozio, che è confrontarne tredici insieme. Ora la cella è una piccola scheda:

- **nome** (fino a 2 righe), **grado a parole** nel colore del grado (il bordo lo diceva già, ma solo a
  chi ha imparato i cinque colori) e il **carattere**;
- le **statistiche una per riga** — incolonnate si confrontano, di seguito si rileggono;
- in fondo lo **stato** (in uso / già tuo / prezzo / di base) e la **rivendita**, incollati al bordo
  inferiore con `margin-top:auto` così stanno alla stessa altezza lungo tutta la riga;
- il pulsante **Vendi** non è più in `absolute` sopra il testo ma è l'ultima riga della cella: sovrapposto
  com'era, con le statistiche scritte dentro, avrebbe coperto una voce e mezza.

`el.title` è stato **rimosso**: l'informazione o è a schermo o non c'è. Aggiornata di conseguenza anche
la riga di aiuto in fondo al pannello, che prometteva «le statistiche col mouse sopra».

#### 🧪 Verificato nel browser (27 controlli, tutti verdi)
Oltre ai controlli della 2.14 rimasti in piedi, tre nuovi che servivano proprio qui:
- **niente trabocca** dal quadrato, in **tutti e tre gli slot** — gli scudi hanno le descrizioni più
  lunghe del gioco (5 voci) e misurare solo le armi non avrebbe detto niente;
- **niente è tagliato dai puntini**: le voci hanno `text-overflow:ellipsis`, quindi una statistica troppo
  lunga non traboccherebbe, **sparirebbe in silenzio**. Una statistica scritta a metà è peggio di una non
  scritta, perché sembra scritta. Controllate **tutte e tre le classi, 8 slot** (il mago ne ha due, il
  ladro ha gli stivali: roba mai vista prima in questa finestra);
- lo **stato alla stessa altezza** lungo la riga, confrontando celle della stessa riga e escludendo
  quelle col pulsante Vendi, dove sta una riga più su di proposito.

Suite completa: **3155 passati, 0 falliti**; prova del menu di fine ondata: tutto OK.

---

### [2.15.0] — 2026-09-17 · "Il profilo della classe morde"

Prima delle tre decisioni rimaste in sospeso dopo la chiusura di `PIANO-EQUIPAGGIAMENTO.md`.

#### 🎭 Com'era
`Heroes.STAT_BASE` (guerriero 8/8/4/2, ladro 4/6/8/4, mago 2/4/6/8) era **solo da leggere**: quattro
numeri sulla scheda che non entravano in nessun calcolo, e un test lo teneva tale.

#### 🔢 La misura che ha cambiato la risposta
Paolo aveva scelto «un punto di base vale una frazione di un punto speso», e come verifica una tabella di
numeri invece di una partita simulata. La tabella ha detto una cosa che non era prevista: con un quarto di
punto su tutto, i danni al secondo passavano da **79/78/78** a **93/105/102** — parità rotta, e **il mago
il più forte dei tre**. Non è un numero da ritoccare: ogni classe ha il suo valore più alto proprio nella
statistica della propria scuola di danno, e INT e DES alzano danno **e** cadenza mentre FOR alza solo il
danno. Sono state misurate tre varianti e Paolo ha scelto la terza.

#### ✅ Cosa fa adesso
- **Conta lo SCARTO dal centro (5,5), non il valore assoluto.** Sopra si guadagna, sotto si perde: la
  somma per classe è quasi zero, quindi le classi si allontanano fra loro senza che la potenza media salga.
- **Non tocca né danno né cadenza.** Solo PV, riduzione, passo e rinculo — la *forma* della classe. Quanto
  picchia resta dell'arma e dei punti spesi, ed è lì che vive la parità fra le tre.
- `Heroes.profiloPunti()` = `(base - 5,5) × 0,5`; `STAT_CENTRO` e `PROFILO_PESO` sono costanti dichiarate.
- `applicaProfilo()` in `Room.js` sta **accanto** ad `applicaStat()` ed è deliberatamente separata:
  riusarla con un peso sarebbe più corto e trascinerebbe dentro `schoolDmg`/`schoolRate`.
- Applicata nei **tre** punti in cui le statistiche ripartono da zero (`addPlayer`, reset di `startGame`,
  `_recomputeBoons`): saltandone uno il profilo sparirebbe alla prima carta accesa o spenta.
- **La riduzione non va mai sotto zero**: il motore la ignorerebbe (`if (dr > 0)`) e il pannello mostrerebbe
  un'armatura negativa inesistente. Chi sta sotto il centro paga in PV, non in bugie.

#### 📊 I numeri, letti dal codice
| classe | DPS | PV | riduzione | PV efficaci | passo |
|---|---|---|---|---|---|
| Guerriero | 79,2 invariato | 206 → **231** | 0 → 1,5% | +13,8% | **-1,9%** |
| Mago | 78,0 invariato | 106 → **91** | 0 | **-14,2%** | +0,6% |
| Ladro | 78,2 invariato | 118 → **123** | 0 → 0,3% | +4,6% | **+3,1%** |

> ⚠️ **Il prezzo, detto prima di consegnare.** Il mago passa da **7 a 6 morsi di zombie** all'ondata 1. È un
> colpo di margine in meno sul personaggio già più fragile, ed è la conseguenza voluta della variante scelta.

#### 🧪 I test
- **TEST 71** diceva l'opposto ed è stato **riscritto, non tolto**: ora pretende che spostare il profilo
  muova PV e passo e **non** muova danno né cadenza — i due lati insieme, se no metà della regola non è
  sorvegliata.
- **TEST 54** misurava la riduzione delle carte in assoluto e falliva perché il ladro ora nasce con mezzo
  punto di riduzione: ora misura la **differenza** prima/dopo la carta.
- **3155 passati, 0 falliti.**

#### 🔎 Trovato strada facendo, NON toccato
Il passivo **Piastra** del guerriero — «riduce del 12% i danni subiti», scritto nella scheda che il
giocatore legge alla scelta del personaggio — **non è applicato da nessuna parte**: `plate` e `passives`
non compaiono in nessun calcolo del server. È un -12% che il giocatore crede di avere e non ha. Segnalato
a Paolo, in attesa della sua decisione.

---

### [2.14.0] — 2026-09-17 · "Il fabbro a icone quadrate" — FASE 3, e il piano è chiuso

Ultima delle tre fasi di `PIANO-EQUIPAGGIAMENTO.md`. Fase 1 → v2.12.0, fase 2 → v2.13.0, fase 3 → questa.

#### 🔨 Com'era, e perché non andava
Dalla 2.12 il fabbro mostrava **tutti** i pezzi della classe in una colonna sola: 13 per slot, 3 slot,
**39 carte alte 150px** dentro un pannello da 620. Si scorreva per due schermate, e il confronto — che è
l'unica cosa che serve in un negozio — si faceva a memoria.

#### 🗂️ Una linguetta per slot, e i pezzi come quadrati
13 per volta invece di 39, e le caselle sono **quadrati**, gli stessi del baule e della banda delle
scelte. Il menu ha un solo modo di disegnare «una cosa che si sceglie cliccandola», e adesso è lo stesso
in tutti e tre i posti.

**Quattro per riga, su tutta la larghezza.** Le celle sono `1fr`, non 84px fissi: si allargano a riempire
il pannello (110px l'una) e `aspect-ratio` le tiene quadrate a qualunque larghezza esca. Con la misura
fissa restava una striscia di vuoto a destra, cioè mezzo pannello inutilizzato.

**In ordine di prezzo.** È la domanda vera davanti a un negozio — «cosa posso permettermi» — e lasciando
il grado a fare da ordine si leggeva una classifica che non si usa. A pari prezzo resta pesante,
equilibrata, leggera: senza un secondo criterio, due partite di fila mostrerebbero ordini diversi.

#### ✂️ Cosa è sparito, su richiesta di Paolo
- I **titoli dei gradi** («COMUNE», «RARO»…): il colore della cella lo dice già. Un test controlla che i
  cinque gradi abbiano davvero **cinque colori distinti** — se li perdessimo, togliere i titoli avrebbe
  tolto l'informazione e non l'etichetta.
- La **colonna dei prezzi a destra** di ogni fascia: *«non vuol dire nulla»*, e aveva ragione — il prezzo
  è scritto sulla cella.

> ⚠️ **Cosa si è perso, e va detto.** Prima le tre colonne erano i caratteri, sempre nello stesso ordine:
> due pesanti di grado diverso stavano incolonnati e si confrontavano senza cercarli. Con quattro per riga
> in ordine di prezzo quell'incolonnamento non c'è più; il carattere si legge dal simbolo in cima alla
> cella (▰ ▱ ▫) e dal titolo. È il prezzo del layout richiesto.

#### 🟢 Tre aggiunte
- Il **pallino verde** sulla linguetta: «qui dentro c'è qualcosa che ti puoi permettere e non hai addosso».
  Senza, per sapere se vale la pena aprire una linguetta bisogna aprirla.
- Gli **stati scritti in chiaro** sulla casella — *in uso*, *già tuo*, il prezzo, o spenta se non ti
  bastano le monete. Quello che non si capisce in un negozio è «perché non posso cliccarlo».
- Le **statistiche col mouse sopra**, come chiedeva il piano: dentro 110px sarebbero scritte e non lette.
  Nel titolo ci sono anche grado, carattere e prezzo di rivendita.

La linguetta aperta si ricorda per classe, e sfogliarle non parla col server.

#### 🧪 I test
`3144 passati, 0 falliti`, più i tre controlli nel browser verdi. Quello del fabbro è a **17 voci** e
misura le cose invece di crederci: che le prime quattro celle stiano **davvero sulla stessa riga** e
coprano 462px su 462, che i titoli dei gradi siano **zero**, che i colori siano **cinque**, che l'ordine
dei prezzi sia crescente — letto dal **dato sull'elemento**, non dal testo, perché a schermo il costo non
compare su ciò che hai già (e leggendo il testo si dedurrebbe zero dove il testo non lo dice).

Provato rimettendo i due errori possibili: ordine per grado invece che per prezzo → lo prende; celle di
nuovo a 84px fissi → prende sia la larghezza sia il fatto che una cella smette di essere quadrata.

---

### [2.13.6] — 2026-09-16 · "Un punto in più sopra il full HD"

Paolo: *«quando la risoluzione è > di full HD aumenta il font di 1 punto»*, e — chiarito subito dopo —
**solo nel riepilogo di fine livello**.

#### 🔎 Cosa guarda, e perché
`screen.width`, cioè la **risoluzione del monitor**, non la larghezza della finestra. Su uno schermo 4K
con la finestra a metà il testo è fisicamente piccolo lo stesso, ed è lì che il punto in più serve.

E la legge in **pixel CSS, non fisici**, che è la cosa giusta: un portatile 4K al 200% riporta 1920 e il
suo testo *non* è piccolo, perché ci pensa già il sistema — con i pixel fisici ingrandiremmo una cosa che
è già grande. Si ricontrolla a ogni `resize`, perché spostare la finestra su un altro monitor cambia
`screen.width` senza ricaricare la pagina.

#### 🎯 Solo lì, e la variabile sta su `#upgradeScreen`
Il primo tentativo l'aveva applicato a **tutta l'interfaccia** — riscrivendo tutti e 217 i `font-size`
del foglio. Sbagliato e sproporzionato: Paolo ne voleva una schermata.

Adesso `--fz` vale 0 dappertutto e diventa 1px **su `#upgradeScreen`**, non sulla radice. La differenza
non è pignoleria: sulla radice si erediterebbe ovunque, e basterebbe che un domani una regola fuori di lì
usasse `--fz` per far crescere mezzo gioco senza che nessuno l'avesse chiesto.

#### 🤖 Le 58 regole non le ho scritte a mano
Un blocco in fondo a `style.css` ripete 58 regole del foglio aggiungendoci il punto, tutte dentro
`#upgradeScreen`. **Sono state raccolte chiedendo al browser** quali regole colpiscono davvero un elemento
di quella schermata, con la schermata aperta e popolata.

Serviva: al primo giro le avevo scelte leggendo i selettori, e ne erano entrate **104** — classi come
`.ic`, `.nm`, `.ds` sono condivise con i pannelli dell'Erborista, del Banditore e dei mercanti, e a occhio
ci si sbaglia in tutte e due le direzioni. Una cosa in più: `body` non aveva **nessun** `font-size` —
ereditava i 16px del browser — quindi tutto ciò che non ne dichiara uno proprio sarebbe rimasto fermo
mentre il resto cresceva. Ora `#upgradeScreen` ha la sua misura di base.

> ⚠️ Chi aggiunge una regola con un `font-size` nuovo in quella schermata **la aggiunga anche al blocco**.
> Il controllo se ne accorge.

#### 🧪 Il controllo
`prova-font.js`, nuovo. Apre la stessa pagina a **tre risoluzioni** (1920, 2560, 3840) dichiarando
`screen` separatamente dal viewport — che è proprio la distinzione che conta qui — e misura il font
**calcolato dal browser** su **ogni** elemento con del testo: 121 dentro la schermata, 16 nell'HUD.

- a 1920 esatti non si muove niente;
- sopra, **tutti e 121** crescono di esattamente 1px;
- e i 16 **fuori** non si muovono.

Provato rimettendo i due errori possibili — togliere una regola dal blocco (quattro testi restano fermi) e
lasciar sfuggire `--fz` sulla radice (si muovono tutti e 16 gli elementi dell'HUD) — e li prende entrambi.

`3144 passati, 0 falliti`, più i tre controlli nel browser verdi.

---

### [2.13.5] — 2026-09-16 · "Via le linguette, e le colonne si fermano dove finisce la roba"

Paolo, guardando la schermata in partita: *«l'allineamento non è ottimale. Credo che i 2 tab non servano.
Credo che i contenuti possano essere disposti meglio»*. Poi, sull'anteprima: *«togli la scritta "i poteri
che hai concesso all'avatar" e aggiungi un piccolo padding tra i box»*.

#### 🗂️ Le due linguette non ci sono più
Erano l'ultimo residuo del pannello a schede della v1.79. Con una schermata che mostra tutto insieme, una
linguetta vuol dire **«qui c'è qualcosa che non vedi»** — cioè esattamente il difetto che questa schermata
è nata per togliere.

I **poteri concessi** — che stavano dietro la seconda linguetta — sono finiti nella colonna di destra,
sotto il baule. È il loro posto: sono l'altra metà di «cosa hai». E danno alla colonna una **forma stabile
fin dalla prima ondata**, perché la scaletta dei sei scaglioni (liv. 3, 6, 8-Q, 9, 12, 14-E) c'è sempre,
piena o vuota che sia. Si collega anche alla banda in cima: lo scaglione in sospeso dice «▲ da scegliere
adesso».

#### 📐 Il vuoto nero, e da dove veniva
Nello screenshot di Paolo, a ondata 1, centro e destra erano **due riquadri alti e neri**. La causa non era
che la sinistra fosse troppo lunga: le colonne erano una griglia `align-items: stretch`, quindi si
allungavano **tutte fino alla più alta**, e dove il contenuto non c'era il vuoto si vedeva tutto.

Ora è `align-items: start`: ogni colonna si ferma dove finisce il suo contenuto. I bordi in basso non sono
più allineati fra loro — ma un riquadro vuoto si legge come un errore, uno corto no.

#### ✂️ E il resto
- Via il titolo **«I poteri che hai concesso all'avatar»**: le righe dicono già «Liv. 3 / non comune», e lo
  stacco dal baule lo fa un **filetto**, non una scritta.
- **Più aria fra i riquadri**: gap delle colonne 14 → 18px, padding interno 12/14 → 14/16, e più spazio fra
  le righe delle statistiche, le derivate, i quadretti del baule e le righe dei poteri. Erano tutti a 3-4px
  di distanza: il colpo d'occhio era una griglia unica in cui non si capiva dove finiva un gruppo.
- **Il ritratto era tagliato** dal bordo quando l'ho ingrandito: il disegno del personaggio esce fino a 1,7
  raggi per via dell'alone del divino. Rimesso a misura, e il centro sta a metà del riquadro.

#### 🧪 I test
`3144 passati, 0 falliti`. Il controllo nel browser non cerca più «quale linguetta è aperta» — controlla
che le sette cose che compongono la schermata (statistiche, derivate, riepilogo, ritratto, slot, baule,
scaletta dei poteri) siano **tutte visibili nello stesso momento**, misurandone il rettangolo. Provato
nascondendo il baule: lo prende.

---

### [2.13.4] — 2026-09-16 · "Quadrati, non rettangoli allungati"

Paolo, sulla 2.13.3: *«i box delle abilità devono essere dei quadrati, non dei rettangoli allungati»*.

#### ⬜ La storia in quattro passi
| | forma | misura |
|---|---|---|
| v2.13 | carte verticali | 150px, un terzo di schermo per tre |
| v2.13.2 | stessa forma, rimpicciolita | 84px — ancora scatole |
| v2.13.3 | girate in orizzontale | 42px di altezza, ma larghe un terzo di banda: **rettangoli lunghi** |
| **v2.13.4** | **quadrati** | **84×84**, allineati e centrati |

Ed è la forma giusta perché è quella che il menu usa già: **gli stessi quadretti del baule**, a destra.
Una schermata dovrebbe avere un solo modo di disegnare «una cosa che si sceglie cliccandola», e adesso ce
l'ha — in cima e a destra si somigliano perché sono la stessa cosa.

#### 🔑 Cosa rende possibile il quadrato
Che la **descrizione non sta più a schermo**: sta nel titolo, col resto (rarità, «per chi vale», effetto
per esteso). A schermo restano icona e nome, che è quanto serve per riconoscere una carta già vista — la
prima volta ci si passa sopra. Era l'unico modo: a 84px di lato la descrizione ci starebbe solo scritta
così piccola che nessuno la leggerebbe, e scrivere qualcosa che nessuno legge è peggio che non scriverlo.

#### 📐 Due dettagli che fanno la differenza
- La griglia è a **colonne fisse**, non `1fr`. Con `1fr` le carte si allargherebbero a riempire la banda e
  tornerebbero rettangoli — che è *esattamente* il difetto della 2.13.3, ed è così che ci era finito.
- La banda si **stringe su ciò che contiene**: tre quadrati da 84 dentro una cornice larga 1280 lasciavano
  due terzi di vuoto, e un riquadro quasi tutto vuoto sembra un errore di impaginazione.

#### 🧪 I test
`3144 passati, 0 falliti`. Il controllo nel browser misura **larghezza e altezza** di ognuna delle tre
carte e verifica che coincidano: una regola che dice `width: 84px` non garantisce niente sull'altezza, e il
difetto di prima era proprio che la larghezza se la prendeva dalla griglia. Provato rimettendo
`flex: 1 1 200px`: le misura a 241×84 e le boccia.

---

### [2.13.3] — 2026-09-16 · "Le carte girate di novanta gradi"

Paolo, sulla 2.13.2: *«meglio ma troppo grosso, deve essere grande la metà: sono ancora troppo grossi i box
delle abilità»*.

#### ↩️ Dimezzate di nuovo, girandole
A 84px erano ancora **scatole**: icona sopra, nome sotto, descrizione sotto ancora. Tre righe incolonnate
non scendono sotto una certa altezza senza diventare illeggibili — rimpicciolire i caratteri ancora avrebbe
dato una carta piccola che non si legge, che è peggio di una grande.

Quindi sono girate di novanta gradi. **In orizzontale** — icona a sinistra, nome e riga di effetto a destra
— la stessa roba sta in **42px**:

| | v2.13 | v2.13.2 | v2.13.3 |
|---|---|---|---|
| carta | 150px | 84px | **42px** |
| banda intera | 227px | 134px | **88px** |

La banda è passata da un terzo di schermo a una striscia. Sotto, la colonna di sinistra adesso mostra tutto
il suo contenuto senza scorrere anche con una scelta aperta, che prima non succedeva.

#### 🏷️ Cosa è finito nel titolo
Quello che a 42px non ci stava e che comunque si leggeva poco: l'etichetta della **rarità** (la dice già il
colore del bordo) e il **«PER TUTTI / DELLA TUA CLASSE»**, che conta una volta su dieci. Sono nel titolo al
passaggio del mouse, insieme alla descrizione per esteso. A schermo resta ciò che serve per scegliere:
icona, nome, cosa fa.

#### 🧪 I test
`3144 passati, 0 falliti`. Il controllo nel browser misura l'**altezza reale** della carta e della banda,
controlla che la carta sia davvero in orizzontale (`flex-direction: row` calcolato, non dichiarato) e legge
il titolo per verificare che ciò che è sparito da schermo sia finito lì. Provato rimettendo le carte a
84px: le prende.

---

### [2.13.2] — 2026-09-16 · "Niente titolone sopra le carte"

Correzioni chieste da Paolo: *«anche i box in "concedi un'abilità" sono troppo grandi, vanno ridotti della
metà. Togli anche la scritta "concedi.." non mi piace, lascia solo le icone tanto si capisce»*.

#### ✂️ Via il titolone
Sopra le tre carte c'erano un `<h2>` («🎴 CONCEDIGLI UN'ABILITÀ») e una riga di accompagnamento: **due
righe di testo per dire una cosa che le carte dicono da sole** — appaiono solo quando c'è da scegliere, e
si scelgono cliccandole.

Resta **una riga piccola**, e resta perché dice ciò che le carte *non* dicono: quale scaglione è (il colore
da solo non basta a ricordarlo) e, per un'abilità attiva, su quale tasto finisce. Il titolo della
**specializzazione** è entrato lì dentro invece di sparire: è l'unica scelta della partita che non si può
rifare, e senza nome sembrerebbe una carta di rango qualunque.

#### 📏 Carte dimezzate
Le `.bc` erano tarate su una schermata che non esiste più — una colonna sola, larga 960, con la scelta come
unico contenuto. Nella banda della 2.13 stanno sopra tre colonne piene, e alte 150px spingevano il resto
fuori dallo schermo.

| | prima | ora |
|---|---|---|
| carta | 150px | **84px** |
| banda intera | ~227px | **134px** |
| icona | 40px | 22px |

A rimpicciolire sono i vuoti: nome e riga di effetto sono rimasti quelli.

#### 🧪 I test
`3144 passati, 0 falliti`. Il controllo nel browser è a 31 voci: misura l'**altezza reale** della carta e
della banda, conta i `<h1>/<h2>` dentro la banda e cerca la parola «CONCEDIGLI» nel testo. Provato
rimettendo i due bug — le carte a 150px e il titolone nel markup — e li prende tutti e quattro.

---

### [2.13.1] — 2026-09-15 · "La scheda, non quattro cartelloni"

Correzioni chieste da Paolo guardando la 2.13.0: *«i 4 box di forza, intelligenza, etc sono troppo grandi.
Puoi farli molto più piccoli ovvero come nei GDR in orizzontale con a fianco il livello […] anche i
quadrati degli oggetti nell'inventario mi sembrano troppo grossi»*.

#### 📋 Le quattro statistiche sono diventate quattro righe
Erano quattro riquadri da 150px con icona, nome, descrizione e prezzo: **mezza colonna per dire quattro
numeri**. Ora sono righe alte **36px**, come su una scheda da GDR:

```
💪 Forza          12 /20  [+]
❤️ Costituzione   11 /20  [+]
```

Il **`+` sta accanto al numero** e si accende solo quando hai i punti per premerlo — spento, premerlo non
manda niente (verificato in tutti e due i casi: il caso «con i punti» da solo non prova nulla, un pulsante
sempre acceso lo passerebbe). La descrizione non è sparita: è nel titolo al passaggio del mouse, insieme a
quanto viene dal profilo e quanto dai punti spesi.

#### 🎭 Il profilo della classe
Le quattro statistiche partivano **da zero per tutti**: un guerriero e un mago appena nati mostravano gli
stessi quattro zeri, quando sono due cose opposte. Adesso ogni classe ha il suo profilo, come Paolo lo ha
scritto:

| | Forza | Costituzione | Destrezza | Intelligenza |
|---|---|---|---|---|
| **Guerriero** | 8 | 8 | 4 | 2 |
| **Ladro** | 4 | 6 | 8 | 4 |
| **Mago** | 2 | 4 | 6 | 8 |

Il tetto è **20** = 8 (la base più alta) + 12 (`Loot.STAT_MAX_LEVEL`, i punti spendibili in una statistica).
Un mago non arriverà mai a 20 di Forza, e va benissimo così.

> ⚠️ **Il profilo è da leggere, non è un bonus: non entra in nessun calcolo.** Le differenze vere fra le
> classi ci sono già e stanno altrove (arma, PV, velocità, scuola); i punti che spendi restano gli unici
> numeri che mordono. Un test lo tiene tale: mette il profilo del guerriero a 99 su tutto e controlla che
> danno, PV massimi e velocità **non si muovano**. Se un giorno si volesse che contassero davvero, il posto
> è `newStats()` in `Room.js`, non la tabella in `heroes.js`.

#### 📐 E lo spazio, in generale
- I **quadretti del baule** da 96px a **68px**: ne stanno sei per riga invece di tre, e il nome sta lo
  stesso perché va a capo su tre righe.
- Le quattro **derivate** più compatte, gli **slot addosso** pure, e i testi di contorno (note, cornice
  della storia, riepilogo dell'ondata) rimpiccioliti: erano tarati su una colonna larga 960 e dentro una
  colonna da 400 rubavano spazio a ciò che si guarda davvero.
- **Ordine nuovo nella colonna di sinistra: causa, effetto, risultato.** Statistiche (su cui agisci) →
  derivate (ciò che ne esce) → riepilogo dell'ondata (che si legge e non si tocca). Prima le statistiche
  erano in fondo, cioè **sotto la piega**: la cosa su cui devi agire era l'unica che non si vedeva.
- Una regola CSS di quando le statistiche erano cartelloni (`grid-template-columns: minmax(140px,1fr)`)
  le rimetteva **due per riga** e troncava i nomi in «Costit…», «Intellig…»: tolta.

#### 🧪 I test
`3144 passati, 0 falliti`, **otto giri di fila**. Il controllo nel browser è salito a 24 voci: misura
l'**altezza reale** di una riga e il **lato reale** di un quadretto, non si fida del CSS. Ogni controllo
nuovo provato rimettendo il bug che deve prendere — compreso il caso «senza punti in mano»: quello «con i
punti» da solo non prova nulla, un `+` sempre acceso lo passerebbe.

**Una seconda sfarfallata spenta.** Il TEST 66 (caldera) falliva circa una volta su cinque sulla riga «si
muove davvero»: la caldera è generata a caso, e in una manciata di mappe il boss partiva da un punto da cui
non si allontanava abbastanza nei secondi concessi. Non era un bug del boss: era il test che chiedeva la
stessa cosa a mappe diverse. Seminato come il 58 e il 62.

---

### [2.13.0] — 2026-09-15 · "Una schermata sola: chi sei, cosa porti, cosa hai"

**Fase 2 del piano equipaggiamento** (`PIANO-EQUIPAGGIAMENTO.md`). Resta la fase 3: il negozio del fabbro
ridisegnato con lo stesso stile a icone quadrate.

#### 🗺️ Da quattro linguette a una schermata
La v1.79 aveva diviso il pannello di fine ondata in **quattro schede** — riepilogo, personaggio, abilità,
villaggio — perché tutto in colonna non ci stava. Il prezzo era che per sapere com'eri messo dovevi girare
per tre schede, e il **baule** (la roba che possedevi e non indossavi) non si vedeva **da nessuna parte**:
esisteva solo nel pannello del fabbro, dall'altra parte del villaggio.

Adesso è una schermata sola, **larga 1280** (era `min(960px, 94vw)`), a tre colonne:

| | |
|---|---|
| **Sinistra** | chi sei: livello, le quattro derivate, il riepilogo dell'ondata, i punti da spendere. Due linguette: PERSONAGGIO e ABILITÀ |
| **Centro** | cosa porti addosso: il **ritratto** del personaggio e i suoi slot |
| **Destra** | cosa hai: il **baule**, a icone quadrate |
| **In fondo** | due soli pulsanti: vai al villaggio, prossima mappa |

Il riepilogo dell'ondata sta **sopra** i punti: la prima domanda di chi apre questa schermata è «com'è
andata», la seconda «cosa ci faccio adesso».

#### 🖼️ Il ritratto è il personaggio vero
Non è un'illustrazione: è `Renderer._hero`, **la stessa funzione che lo disegna in partita**, con addosso
gli id dell'equipaggiamento che porta. Quindi le `tinta` dei 104 pezzi della 2.12 si vedono qui esattamente
come si vedono sulla mappa, l'alone del divino pure, e il giorno che cambia il disegno del personaggio
cambia anche qui senza che nessuno debba ricordarsene.

#### 📊 Le quattro derivate
Forza, Costituzione, Intelligenza e Destrezza si spendevano **alla cieca**: il pannello diceva quanti punti
avevi messo, mai che effetto avessero. Adesso ci sono **danno per colpo, danni assorbiti, cadenza, passo**,
calcolati dal server con le sue funzioni (`effDamage`, `effFireDelay`, `effSpeed`) — non ricostruiti nel
client, che il giorno di una ritaratura direbbe una cosa e il gioco un'altra. Un test lo verifica
confrontandoli col motore.

#### 🎒 Il baule, e il clic che equipaggia
`p.owned` era già l'inventario — tutto ciò che compri resta tuo — e non lo vedevi mai. Ora è la colonna di
destra, per slot, con il pezzo indossato marcato, e **un clic te lo mette addosso**. Non costa niente: l'hai
già pagato. Chiedere di attraversare il villaggio per cambiarsi una corazza che è nel proprio baule non è
una regola, è un attrito — ed è esattamente il motivo per cui l'inventario non si guardava mai.

**È una porta nuova (`MSG.EQUIPAGGIA`), non `buyGear` con un controllo in meno**, e la differenza conta:
`buyGear` può *spendere* e per questo pretende che tu sia davanti al fabbro. Questa non spende. E non compra:
un id che non è in `p.owned` viene ignorato, perché se questa porta potesse comprare sarebbe un negozio
aperto ovunque e il fabbro non servirebbe più a niente. Non funziona nemmeno in combattimento, e non accetta
roba di un'altra classe. Tre cose che il test verifica una per una.

#### 🃏 La scelta in sospeso è una banda, non una scheda
Carte di rango e abilità non stanno più in una linguetta: quando c'è qualcosa da scegliere compare una
**banda a tutta larghezza in cima**, e sparisce quando hai scelto. Tre carte da leggere e confrontare non
stanno in una colonna laterale, e una scelta in sospeso non è una scheda fra le altre — è la cosa da fare
adesso. Il testo in fondo diceva *«nella sezione ABILITÀ»*: non era più vero, ora dice «lì in cima».

#### 🔧 E il resto
- **L'altezza è una catena**: la schermata riempie lo schermo, le tre colonne prendono ciò che avanza dopo
  la banda, e a scorrere sono **solo le colonne**. Col primo tentativo (`max-height` in vh sulle colonne) la
  banda aperta spingeva i due pulsanti **fuori dallo schermo** — cioè proprio quando servono di più.
- **Sotto i 1100px** le tre colonne diventano una, in ordine di importanza.
- Il riepilogo dell'ondata porta anche **danni inflitti e combo migliore**: due numeri che il gioco già
  teneva e faceva vedere solo nella tabella di fine partita, cioè quando non servono più a niente.
- La coda *«Puoi passare dal villaggio prima di ripartire»* è sparita: il villaggio è un pulsante a due
  centimetri da lì, e ridirlo a parole è rumore.

#### 🧪 I test
`3135 passati, 0 falliti`. Nuovo **TEST 71** (15 controlli) sul pannello e sulla porta che equipaggia,
verificato rimettendo il bug. Il controllo nel browser entra da `Net.onOfferShop` — il punto d'ingresso
vero — misura la larghezza reale, conta le colonne e **legge i pixel del canvas** per essere sicuro che il
ritratto disegni davvero; provato rompendolo, e li prende.

**E una sfarfallata pre-esistente è stata spenta.** Il TEST 58 (mercenari) falliva circa **una volta su
tre**, e non per un bug: la mappa è generata a caso e a volte il mercenario finiva dietro uno spigolo. Adesso
è seminato come il TEST 62. Un test che fallisce a caso è peggio di un test che non c'è: la volta che
segnala qualcosa di vero, nessuno gli crede.

---

### [2.12.0] — 2026-09-15 · "Centoquattro pezzi, e dentro ogni grado un bivio"

**Fase 1 del piano equipaggiamento** (`PIANO-EQUIPAGGIAMENTO.md`). Le fasi 2 e 3 — schermata di fine
livello unica con inventario, e negozio ridisegnato a icone quadrate — restano da fare.

#### 🎯 Da dove nasce
Parole di Paolo: *«la gestione dell'inventario e delle abilità non mi piace molto perché secondo me il
personaggio si sviluppa troppo poco»*. Misurato invece che creduto: in una run intera il giocatore
prendeva 4 carte passive, 2 abilità attive, 1 specializzazione, ~14 punti statistica — e **zero**
decisioni sull'equipaggiamento. L'equipaggiamento c'era ma era una **scala**: si comprava il pezzo dopo
quando si avevano le monete. Una scala non è una scelta.

#### ♻️ La regola che si ribalta
In `shared/gear.js` c'era scritto nero su bianco: *«un rango più alto costa di più e ha statistiche
migliori, SEMPRE — niente scambi alla pari, niente svantaggi nascosti»*. Era onesto ed era il problema.
Adesso le regole sono due e vanno tenute insieme:

- **Fra un grado e l'altro si sale.** Il divino batte il leggendario, sempre. Questo non è cambiato.
- **Dentro lo stesso grado non si sale: si sceglie.** I tre pezzi di uno stesso grado costano uguale e
  rendono uguale — sulle armi il danno al secondo sta dentro il **4%** — e cambiano solo in *come* si gioca.

#### 🗂️ Cinque gradi, 104 pezzi
| Grado | Quanti per slot | Si compra? |
|---|---|---|
| **Scarso** | 1 | no — è quello che hai addosso, ~20% sotto il comune |
| Comune · Raro · Leggendario · Divino | 3 ciascuno | sì |

13 pezzi per slot, **104 in tutto** (guerriero 3 slot, mago 2, ladro 3).

#### 🎭 I tre caratteri, e la regola che li tiene onesti
Ognuno è il **migliore in UNA cosa e il peggiore nelle altre due**. Senza questo vincolo il bivio
tornerebbe a essere una scala mascherata.

| | Guerriero | Mago | Ladro |
|---|---|---|---|
| ▰ **Pesante** | rinculo | bolla grande | gittata |
| ▱ **Equilibrata** | portata | gittata | perforazione |
| ▫ **Leggera** | arco largo | bolla veloce | cadenza |

Sulle difensive il carattere è **protezione contro velocità e cadenza**: il pesante rallenta e abbassa la
cadenza, il leggero fa il contrario. A grado divino, guerriero: kit pesante **1,435 s** fra un fendente e
l'altro, 435 PV, −51% danni · kit leggero **0,390 s**, 314 PV, −27%. Due modi di giocare, non due livelli.

#### 🐞 Due difetti della prima stesura, trovati rileggendo i numeri
1. **Il danno al secondo era pari, ma i numeri secondari no.** A grado leggendario l'Alabarda aveva
   portata 152 contro i 112 del Maglio *a parità di danno*: non era un bivio, era la risposta giusta e due
   sbagliate. Il divario di portata è passato dal 36% al 14%, e ora si paga con arco stretto e rinculo dimezzato.
2. **Le descrizioni del mago promettevano ciò che i numeri non facevano.** «Bolla lenta e grossa» era
   scritto, ma il campo per la grandezza (`weapon.r`) non era mai stato impostato — pur essendo letto dal
   motore. Ora la bolla va da **r6 a r24**, quattro volte, e si vede. Da qui la regola nuova: **le `desc` di
   `gear.js` nascono dai numeri, non si scrivono a mano.** Una descrizione scritta a mano può mentire.

#### 💰 La rivendita, e un commento falso corretto
- Si rivende **a metà prezzo**, e si vende **ciò che si ha nel baule**, mai ciò che si ha addosso (il
  fabbro rifiuta *dicendo perché* — un rifiuto muto si legge come un pulsante rotto). I pezzi scarsi, che
  non sono costati nulla, valgono 8 monete: buttarli non dev'essere gratis.
- In `gear.js` c'era scritto che *«il Mercato apre ogni 3 ondate»*: **falso**, il villaggio si raggiunge
  alla fine di **ogni** ondata. I vecchi prezzi erano tarati su quell'ipotesi. Commento corretto.
- **Il listino sta ora in un posto solo** (`PREZZI` in `gear.js`, una riga per slot). Prima era scritto su
  ogni pezzo: 104 occasioni perché due pezzi dello stesso grado finissero a prezzi diversi per una
  distrazione — che è proprio la cosa che un bivio non può permettersi.

#### 🔧 Le tre cose che il passaggio a 5 gradi rompeva, sistemate prima di scrivere i dati
1. **L'arco del ladro spariva al grado divino.** In `renderer.js` un array di quattro valori indicizzato
   per rango: con un'arma di grado 5 leggeva `[4]` → `undefined` → tutto il disegno in `NaN`.
2. **L'alone del pregiato** era a `>= 4`: con cinque gradi avrebbe preso anche il leggendario. Spostato a
   `>= 5` — deciso da Paolo, deve brillare **solo il divino**.
3. **La `tinta` su tutti i 65 pezzi difensivi.** Senza, niente crasha (`_palGear` controlla) ma il
   personaggio smette di cambiare aspetto comprando — cioè sparisce la soddisfazione che il catalogo esiste
   per dare. Ora un test lo verifica pezzo per pezzo.

#### ⚙️ E il resto
- **`Room.effFireDelay` legge la cadenza dall'equipaggiamento.** `bonusOf` sommava `fireRateMult` e
  **nessuno lo leggeva**: le armature pesanti promettevano di rallentare la cadenza e non la toccavano.
- **`Room.js`, il salto a un'ondata**: sceglieva il pezzo per **posizione** nella lista (`l[rango - 1]`).
  Funzionava con quattro gradi e quattro pezzi; con tredici pezzi per slot `l[3]` all'ondata 16 avrebbe
  dato un pezzo **comune**. Adesso si chiede il **grado**. Le soglie vengono dalla misura (vedi sotto).
- **`SHOP_GEAR_ENABLED` resta spento**, e il motivo è cambiato: non è più «in attesa di ridisegno», è che
  il fabbro del villaggio funziona e vende tutto. Due negozi con la stessa merce in due posti diversi
  vogliono dire che chi ne trova uno smette di cercare l'altro.
- **`shared/salvataggio.js`: formato da 1 a 2.** Non per un campo nuovo: `gear` e `owned` contengono ID di
  oggetti, e nessuno di quegli ID esiste più. Un salvataggio della 2.11 non esploderebbe — e sarebbe molto
  peggio: ripartiresti disarmato e senza bonus, senza nessun errore. Meglio un rifiuto pulito.
- **Il negozio del fabbro**: una fascia per grado, e le colonne sono i caratteri — pesante a sinistra,
  equilibrata al centro, leggera a destra, **sempre**. I pallini del grado sono passati da 3 a **5** (erano
  già sbagliati da quando i gradi erano quattro: leggendario e divino mostravano lo stesso riempimento).

#### 📏 Misurato, non creduto — `test/monete.js`
Nuovo file. Conta le monete che ogni ondata **contiene** (stessa formula di `Room._killMonster`, stessa
composizione di `Waves.buildWave`), separando drop, premio di velocità e taglia del Banditore.

> Il primo tentativo faceva giocare tre bot e contava le monete in mano. Non ha funzionato, e il motivo va
> scritto: un bot scritto per un file di misura gioca molto peggio di una persona: si impantanava
> all'ondata 4 e la misura finiva lì. La sua mortalità diceva qualcosa sul bot, niente sull'economia.

Risultato: **~14.200 monete** in una run intera di 20 ondate (~9.900 senza premi di velocità né taglie).

#### 🔬 I test
`3119 passati, 0 falliti`. Tre test che **codificavano la regola vecchia** sono stati riscritti per
difendere quella nuova (TEST 12, 37, 62): non è un aggiustamento cosmetico — un test che dice «ogni pezzo
è migliore del precedente nella lista» adesso è un test che difende il bug. E i controlli nel browser
partono dal punto d'ingresso vero (`Net.onOfferGear`), guardano cosa il client **disegna** e cosa
**manda**, e sono stati verificati rimettendo il bug per controllare che lo prendessero.

---

### [2.11.3] — 2026-09-14 · "Salvato da ladro, ripreso con la skin del guerriero"

#### 🐛 Il bug, segnalato giocando
*«Ho salvato la partita come ladro. Sono uscito e al riavvio ho trovato il pulsante RIPRENDI. Nel menu
avevo preselezionato il guerriero e quando ho cliccato ero col ladro ma con la skin del guerriero.»*

Riprodotto al primo tentativo. Ed erano **due** difetti diversi, tutti e due miei.

#### 1. La skin — lo snapshot magro
Nome ed eroe viaggiano nello snapshot **una volta sola**:

```js
const nuovo = !slim || !p._sent; if (slim) p._sent = 1;
...
if (nuovo) { o.n = p.name; o.h = p.heroId; }   // nome ed eroe: immutabili in partita
```

Il commento diceva la verita' — *in partita* non cambiano mai — ma **riprendere e' l'unico momento in cui
la classe cambia sotto i piedi del client**: entri come guerriero dal menu, e il salvataggio ti rifa'
ladro. Il client aveva gia' ricevuto `h: 'guerriero'` e messo in cache, e nessuno gliel'ha piu' detto.
Risultato: ladro nei numeri, guerriero a vedersi.

`riprendi()` adesso rimette `p._sent = 0` dopo aver applicato il salvataggio, e lo snapshot successivo
ridice nome ed eroe. Il client, ricevendo di nuovo la parte piena, **sostituisce** la voce in cache.

#### 2. La barra delle abilita' e il ritratto — il client
In `entra()`:

```js
G.meHero = HUD.selectedHero;      // <-- cancellava quello letto dal salvataggio
```

Sul pulsante RIPRENDI avevo gia' scritto `G.meHero = d.heroId`, e due righe dopo `entra()` lo sovrascriveva
con la casella rimasta selezionata nel menu. Il client restava convinto di essere un guerriero anche per la
barra dei tasti e per il ritratto nei dialoghi. Adesso, **riprendendo comanda il salvataggio**.

#### ✅ Verifiche
- **Riprodotto prima di correggere**, e riprovato **togliendo** la correzione: senza, lo snapshot
  successivo alla ripresa non contiene la classe (*«il client vede: niente, resta guerriero»*).
- `test/simulate.js` — blocco nuovo dentro il TEST 70: si salva da **ladro**, si entra da **guerriero**, si
  verifica che la cache del client contenga guerriero *prima*, e che lo snapshot dopo la ripresa **ridica**
  `h: 'ladro'` col nome. **2470 passati, 0 falliti.**
- `test/client.js` — che la classe la decida il salvataggio e non la casella del menu.
- **Nel browser, il suo scenario esatto** — salvataggio da ladro in tasca, pagina riaperta, guerriero
  selezionato nel menu, RIPRENDI: il client disegna `ladro` e la barra mostra **🏹 Arco**, non la spada.
  Zero errori in console.

---

### [2.11.2] — 2026-09-14 · "Ricontrollato il bug delle abilita', e saltato fuori un difetto vero"

#### ❓ La domanda: «sei sicuro di aver sistemato il bug delle abilita'?»
Risposta onesta: il **server** era a posto, il **client** non era mai stato provato — e l'avevo scritto
come verificato.

#### 🔍 Il controllo nel browser della v2.9.4 era un buco nel vuoto
Diceva:

```js
if (window.HUD && window.HUD.offerBoon) window.HUD.offerBoon(payload);
```

**`HUD.offerBoon` non esiste.** La funzione vera e' `setBoons(data, onPick)`. Quel mio stesso `if` —
scritto per prudenza — ha reso la chiamata un no-op, e il *«CARICA»* che avevo trovato a schermo veniva
dalla **barra delle abilita' in basso** (il personaggio in modalita' di prova ce l'aveva gia'), non dal
pannello. Il controllo passava senza toccare niente.

#### ✅ Cosa e' stato riprovato, e come
- **Server, per la strada vera**: ondata **giocata** fino in fondo — mostri uccisi con `killMonster` (la
  porta vera: quella che conta i morti, chiude l'ondata e apre la faglia), faglia attraversata, negozio
  raggiunto dal gioco da solo. Al livello 8 il client riceve `ATTIVA-q`. Al 3, la passiva.
- **Client, dal punto d'ingresso vero** (`Net.onOfferBoon`, quello che chiama `net.js`): il pannello
  disegna le due carte — *Raro ⚡ Carica* e *Raro 📣 Grido di Guerra* — e cliccando quella giusta parte
  `{"t":"pick_boon","id":"ab_carica"}`.
- **E non si puo' saltarla**: finche' la scelta e' in sospeso il pulsante PROSSIMA MAPPA e' **spento**, la
  linguetta ha il pallino, e sotto c'e' scritto *«Hai un'abilita' da scegliere nella sezione ABILITA'»*.

#### 🐛 Il difetto vero, trovato guardando
`hideShop()` azzera `_boons`. Cliccando una carta **nello stesso fotogramma** in cui il pannello si chiude
— cambia la fase: parte l'ondata, o si va al villaggio — questa riga

```js
el.onclick = () => { if (this._pick) this._pick(b.id); this._boons.picked = true; this._render(); };
```

scriveva su `null` e **sollevava**. La scelta arrivava al server, ma il pannello non si ridisegnava: a
schermo restava la carta **come se il clic non fosse mai avvenuto**. Una guardia (`if (this._boons)`), e lo
stesso per la carta di rango.

#### 🧪 Il buco che il TEST 69 aveva
Chiamava `_inviaPannello` **a mano**. Provare quella funzione dimostra che *quella funzione* e' giusta, non
che il gioco ci passi davvero — la stessa distinzione che con le guardie del villaggio era costata una
versione buttata. Adesso c'e' anche il blocco che **gioca l'ondata**.

E perche' isolasse davvero il bug, il personaggio deve aver **gia' preso** le passive dei livelli
precedenti, come chiunque giochi: se restassero in coda terrebbero acceso il vecchio controllo e il
pannello si aprirebbe lo stesso, **per il motivo sbagliato** — cioe' il test passerebbe su codice rotto.
Sistemato: col codice vecchio dice *«offre: niente»* ai livelli 8 e 14. **Verificato rimettendolo.**

#### ✅ Verifiche
- `test/simulate.js` — **2465 passati**, restano i 2 ballerini noti del mercenario.
- `test/client.js` — le due guardie, e una prova che chiude il pannello e poi **riclicca davvero** la carta
  per vedere che non sollevi. *(2 fallimenti attesi sull'audio.)*
- **Nel browser** — pannello, carte, clic e messaggio al server, tutto letto e non dedotto.

---

### [2.11.1] — 2026-09-13 · "Nel villaggio il mirino si toglie di mezzo"

#### 🐛 Col pointer lock nel villaggio non si cliccava piu'
Segnalato giocando: *«non mi permette di cliccare nei menu (armaiolo, ostessa)»*. Ed era esatto.

Il pointer lock **fa sparire il cursore** — e' il suo mestiere. In combattimento va benissimo: il puntatore
e' il mirino e non c'e' niente da cliccare. Nel villaggio no: fabbro, Ostessa, Erborista e Banditore hanno
dei **pannelli con dei pulsanti**, e senza cursore quei pulsanti non si potevano premere. Il pannello si
apriva avvicinandosi e restava li', inutilizzabile.

Adesso dentro il villaggio:

| | |
|---|---|
| pointer lock | **sganciato**, e il clic non lo riaggancia |
| guinzaglio | **spento**: il mirino segue il cursore ovunque |
| cursore del sistema | **di nuovo visibile** (`canvas#game.libero`) |
| mirino disegnato | **no** — se no ce ne sarebbero due a schermo |

Lo decide la **fase** che arriva nello snapshot (`market`), non un flag nostro: e' la stessa ragione per cui
lo sgancio dei pannelli guarda il DOM invece di ricordarsi uno stato.

E riaccendendolo — uscendo dalla faglia — il mirino **rientra subito** nei 200 px (`setGuinzaglio`): nel
villaggio puo' essere finito a seicento pixel, e senza quel riaggancio resterebbe disegnato lontanissimo
fino al primo movimento del mouse.

#### ⭕ Tolto l'anello a 200 px
Nella v2.10 compariva un cerchio mentre il mirino premeva contro il limite, per rispondere alla domanda
*«perche' non va piu' in la'?»*. Il ragionamento reggeva, il risultato no: un cerchio che si accende e si
spegne addosso al personaggio e' rumore. Tolto. Il limite si capisce lo stesso — il mirino si ferma, e
quello si vede.

#### ✅ Verifiche
- `test/client.js` — col guinzaglio spento il mirino segue il cursore **ovunque** (499 px su un canvas
  finto), `aggancia()` non chiede piu' il pointer lock, e riaccendendolo il mirino **rientra subito** a 200.
  Piu': che il renderer **non disegni piu' l'anello**, che non disegni niente a guinzaglio spento, e che
  main.js spenga il guinzaglio e riaccenda il cursore nel villaggio.
- **Nel browser** — nel villaggio: `guinzaglio:false`, `lock:false`, cursore `crosshair`, mirino libero a
  680 px, e **un clic non aggancia** il pointer lock. In combattimento: mirino fermo a 200 px, **nessun
  anello**, cursore `none`. Zero errori in console.
- `test/simulate.js` — **2463 passati, 0 falliti**.

---

### [2.11.0] — 2026-09-13 · "Si puo' salvare la partita, e si salva dall'Ostessa"

#### 💾 Come funziona
Si salva **dall'Ostessa**, per **10 monete**, **quando lo decidi tu**. Niente salvataggi automatici:
scegliere quando salvare *e'* il salvataggio, e uno automatico toglie quella scelta senza chiedere.

| | |
|---|---|
| **Dove** | pannello dell'Ostessa, nel villaggio |
| **Quanto** | 10 monete: abbastanza da essere un gesto, troppo poco da essere una scelta |
| **Quanti** | **uno solo** — salvare sovrascrive |
| **Dove vive** | nel **browser** (`localStorage`); il server non tiene niente |
| **Come si riprende** | pulsante **RIPRENDI** nella prima schermata, con ondata, classe, livello e quando |
| **Da dove** | dal **villaggio** di quell'ondata, con tutto quello che avevi |
| **Se muori** | il salvataggio **resta**: nessuno lo cancella |
| **In co-op** | per ora no, e il pulsante lo dice |

La locanda come punto di salvataggio non e' comodita': e' il posto dove si salva in ogni gioco di ruolo da
quarant'anni, quindi al giocatore non c'e' niente da spiegare.

#### 🔑 La regola: si salvano le CAUSE, non gli EFFETTI
Un personaggio all'ondata 12 ha `stats.dmgMult`, `perk.parata`, `maxHp` — numeri **calcolati** da
`_recomputeBoons` e `_recomputeGear` a partire da cose piu' semplici: i punti spesi (`buys`), le carte prese
(`boonsOwned`), l'equipaggiamento (`gear`).

Se salvassimo i numeri calcolati, il giorno che ritari il costo di una statistica **ogni partita salvata
resterebbe col bilanciamento vecchio** — e non si vedrebbe: nessun errore, nessun crash, solo un
personaggio leggermente sbagliato che nessuno sa spiegare. Salvando le cause e ricalcolando al caricamento,
un salvataggio vecchio prende automaticamente il bilanciamento nuovo. E' il motivo per cui
`shared/salvataggio.js` e' corto: le cause sono diciassette campi, gli effetti sono cento.

#### 🧩 I tre dettagli che non si vedono
1. **Il pacchetto si costruisce PRIMA di pagare**, cosi' contiene le monete di *prima* della sosta:
   ricaricando non paghi la stessa sosta due volte.
2. **Si riparte da `startGame(1)` e non da `startGame(ondata)`**: passare un'ondata alta accende la
   **modalita' di prova** (`this.prova`, e il personaggio finto di `_preparaProva`). Una partita ripresa
   non e' una prova — e' la tua, e i suoi record valgono. L'ondata gliela si dice a parte.
3. **Le scelte in sospeso tornano a galla**: chi salva con una carta ancora da scegliere se la ritrova
   appena riprende. E' lo stesso errore della v2.9.4, che qui sarebbe stato facilissimo rifare in un posto
   nuovo.

#### 🧱 Un pacchetto rotto si rifiuta intero
Formato di un'altra versione, classe inesistente, livello o ondata impossibili: si rifiuta e **la partita
non parte**. Un caricamento a meta' produce un personaggio impossibile, molto peggio di un «non si puo'». I
numeri ritoccati a mano si stringono nei loro limiti — non e' antifrode (in singolo chi vuole barare apre
la console), e' che un salvataggio corrotto non deve poter mandare per aria il server.

#### ⚠️ Il prezzo di tenerlo nel browser
Cambi browser o cancelli i dati del sito e non c'e' piu'. E' il compromesso scelto: zero infrastruttura,
nessun account, nessuna cartella da gestire. `localStorage` inoltre **solleva** — non torna `null` — in
finestra anonima, coi dati del sito bloccati e a spazio esaurito: ogni lettura e scrittura sta in
`try/catch`, e **se non si puo' scrivere si dice**. Un salvataggio che il giocatore crede di avere e non ha
e' peggio di nessun salvataggio.

#### 🐛 Preso in corsa
Il pulsante RIPRENDI era finito nella **sala d'attesa** invece che nella prima schermata: il test lo
trovava (c'era, e senza la classe `hidden`) ma il giocatore no, perche' il pannello che lo conteneva era
chiuso. Visto nella schermata catturata nel browser, spostato, e adesso c'e' un controllo che pretende che
stia dentro `<div id="menu">` e non altrove.

#### ✅ Verifiche
- **TEST 70, nuovo** — si salva all'ondata 11 con un mago cresciuto, si riapre in una stanza **nuova** con
  un giocatore che comincia guerriero (cioe' riaprire il browser domani), e si confronta **campo per
  campo**: tutte le cause tornano identiche, gli **effetti** (statistiche, massimo PV) vengono **rifatti dal
  ricalcolo** e coincidono. Piu': si riparte nel villaggio giusto e **non** in modalita' di prova; le scelte
  in sospeso entrano nel pacchetto e vengono ripresentate; non si salva in mezzo a un'ondata, ne' lontano
  dall'Ostessa, ne' senza monete (e si dice sempre **perche'**); cinque pacchetti rotti si rifiutano senza
  far partire niente; e un controllo che **sporca ogni campo dichiarato** e verifica che torni indietro —
  quello serve a chi un domani aggiungera' una causa nuova e si dimentichera' di metterla nell'elenco.
- `test/client.js` — il modulo arriva al client, l'etichetta del pulsante, **RIPRENDI dentro `#menu`** e
  nascosto di suo, le letture protette, e che **nessuno** chiami `removeItem`.
- **Nel browser** — pacchetto vero catturato da una partita in Node, iniettato: finisce in `localStorage`,
  la pagina **riaperta da zero** mostra *«RIPRENDI — ondata 11 · Ladro Lv.11 · salvata adesso»*, e
  cliccandolo la partita riparte davvero (fase `market`, ondata 11, missione «Scendi fino ad AZ'GAROTH»).
  I quattro stati del pulsante dell'Ostessa disegnati e letti uno per uno. Zero errori in console.
- `test/simulate.js` — **2461 passati**, restano i 2 ballerini noti del mercenario.

---

### [2.10.0] — 2026-09-13 · "Il mirino al guinzaglio: 200px e non uno di piu'"

#### 🎯 Cosa fa
Il mirino non si allontana piu' di **200 px** dal personaggio. Il cursore lo muovi dove vuoi: dentro il
raggio il mirino lo segue, oltre si ferma sul bordo **conservando la direzione** — accorciare un vettore
non lo ruota, e la direzione e' l'unica cosa che il server riceve.

#### 🚫 Perche' non si poteva fare "limitando il cursore"
Una pagina web **non puo' spostare il cursore del sistema**. Non esiste un'API, ed e' voluto: un sito che
ti muove il puntatore e' un sito che ti fa cliccare dove vuole lui. L'unica strada e' il **pointer lock** —
si chiede al browser di *nascondere* il cursore vero e di mandare solo gli **spostamenti**
(`movementX/Y`). Da li' in poi il mirino e' roba nostra: lo teniamo noi, lo disegniamo noi, lo fermiamo dove
vogliamo. E' come si controllano i twin-stick.

Il guinzaglio e' quindi **un vettore dal centro**: il personaggio sta sempre al centro dello schermo, si
accumulano i movimenti e si accorcia il vettore quando supera il raggio. Nessuna conversione fra mondo e
schermo — la mappa e' disegnata **1:1**.

#### 🔓 E si gioca anche senza il blocco
Il pointer lock lo concede il browser e solo dopo un **clic**; l'utente ne esce con **Esc** quando vuole, e
su un telefono non esiste. Se non c'e', il mirino segue il cursore vero **clampato allo stesso raggio**: la
regola del gioco e' identica, cambia solo se il puntatore che vedi e' il tuo o il nostro. Per questo il
guinzaglio sta in **un posto solo** (`_clamp()`) — due strade con un clamp per ciascuna sono due regole che
prima o poi divergono.

Il pointer lock si **sgancia da solo** quando si apre un pannello (fine ondata, menu, sala d'attesa): da
agganciati il cursore non esiste e i pulsanti non si potrebbero cliccare. Lo decide lo stato del DOM, non
un flag nostro: i pannelli li aprono cinque punti diversi e un flag che devono ricordarsi tutti resta
indietro.

#### 👁️ Un puntatore solo, e l'anello che si accende
Il cursore del sistema sul canvas e' **nascosto** (`cursor:none`, prima era `crosshair`): se restasse
visibile, senza pointer lock si vedrebbero **due puntatori separarsi** appena superi il raggio — quello
vero che continua e il mirino che si ferma.

L'**anello a 200 px** si accende **solo mentre il mirino preme contro il limite**. Sempre acceso sarebbe un
orpello che si impara a non vedere in due minuti; acceso in quel momento e' la risposta alla domanda che il
giocatore si sta facendo: *«perche' non va piu' in la'?»*.

#### ⚠️ Cosa NON cambia, e va detto chiaro
**Nessuna meccanica.** Il client manda al server solo `aim`, che e' un **angolo**: frecce, magie, fendente e
perfino la Meteora partono da li', con una gittata loro gia' scritta. La **distanza** del mouse non e' mai
stata mandata e non e' mai stata usata. Il guinzaglio cambia **come si sente il gioco in mano**, non dove
arrivano i colpi. Se un domani servira' una gittata vera delle armi, e' un lavoro di bilanciamento.

#### ✅ Verifiche
- `test/client.js` — **prova la regola, non il disegno**: carica `input.js` davvero, gli manda eventi di
  mouse finti e guarda dove finisce il mirino. Dentro il raggio segue (90px); fuori si ferma a **200
  esatti** e l'angolo resta quello (0°); in diagonale idem (−149°, cioe' l'angolo del cursore: clampare
  accorcia, non ruota); col cursore **esattamente sul personaggio** l'angolo non diventa `NaN`; agganciato
  accumula gli spostamenti e anche spingendo trenta volte non sfonda il guinzaglio.
- **Nel browser** — cursore a 600px dal centro → mirino a **200, angolo 0**; in alto a sinistra → 200,
  angolo conservato; a 90px → segue libero e l'anello resta spento. Zero errori in console.
- `test/simulate.js` — **2412 passati**, restano i 2 ballerini noti del mercenario.

---

### [2.9.4] — 2026-09-13 · "Le abilita' attive dei livelli 8 e 14 non venivano date"

#### 🐛 Il bug, e quanto era grosso
Segnalato giocando: *«ai livelli 8 e 14 le abilita' attive non vengono applicate, il gioco le salta»*.
Riprodotto e misurato. In una run normale, un livello per ondata, il giocatore prendeva:

| | prima | dopo |
|---|---|---|
| livello 8 | *niente* | **attiva Q** |
| livello 9 | attiva Q *(in ritardo)* + passiva epica | passiva epica |
| livello 14 | *niente* | **attiva E** |
| fine run | Q preso, **`E = null`**, coda ancora piena | Q ed E, coda vuota |

Lo slot **E era perso in ogni singola partita**: dopo il livello 12 non c'e' piu' nessuno scaglione che
possa riaprire il pannello e trascinarsi dietro l'abilita' rimasta sotto in coda.

#### 🔎 Una domanda, tre risposte diverse
Le code delle scelte sono **due**: `scaglioniDovuti` (le passive, ai livelli 3, 6, 9, 12) e `abilDovute`
(gli slot attivi, 8 e 14). In **tre punti** il codice chiedeva «c'e' qualcosa da scegliere?» guardandone
**una sola**:

1. **`_inviaPannello`** apriva la scelta solo `if ((p.scaglioniDovuti || []).length > 0)`. Un'ondata che
   portava **solo** al livello 8 o **solo** al 14 finiva nell'`else`, cioe' «niente da scegliere».
2. **Dopo aver preso una passiva** ripresentava il pannello solo se restavano *altre passive*: chi in
   un'ondata sola prendeva una passiva e uno slot attivo vedeva sparire il pannello dopo la prima delle due.
3. **Dopo aver preso rango o specializzazione** non passava la mano a nessuno. La specializzazione del 15
   ha la precedenza nel pannello — giustamente — ma una volta scelta lasciava il posto vuoto, e l'abilita'
   del 14 presa nella stessa ondata spariva.

La correzione e' una riga condivisa:

```js
_scelteInCoda(p) { return ((p.abilDovute || []).length + (p.scaglioniDovuti || []).length) > 0; }
```

usata in tutti e tre i punti. La domanda adesso ha **una risposta sola** invece di tre che possono
divergere — ed e' il motivo per cui il bug e' esistito: non una svista, tre copie della stessa condizione
scritte in momenti diversi.

#### ✅ Verifiche
- **TEST 69, nuovo — e legge i MESSAGGI, non lo stato.** E' la parte che conta: un test che avesse
  interrogato `p.abilDovute` avrebbe detto che l'abilita' c'era — e c'era davvero, in coda — senza
  accorgersi che al giocatore **non veniva mostrata mai**. Questo invece decodifica il JSON che il server
  manda al client, esattamente come farebbe il browser, e poi "clicca" su cio' che gli e' stato offerto.
  Percorre le **quattordici ondate** di una run intera per **tutte e tre le classi** e verifica *dove*
  ogni scelta compare; poi i casi di doppio livello (7→9, 13→15, 11→12, 8→10); poi che la
  specializzazione non si mangi cio' che ha sotto; poi che chi **non** sceglie si veda ripresentare la
  scelta l'ondata dopo.
- **Rimettendo il codice vecchio, TEST 69 fallisce con 14 errori** — verificato. Un test che non fallisce
  sul bug che dovrebbe prendere non e' un test.
- `test/simulate.js` — **2414 passati, 0 falliti**.
- **Nel browser** — il pannello riceve l'offerta vera catturata dal server (*Carica / Grido di Guerra*,
  slot Q, livello 8) e la disegna; in modalita' di prova il personaggio ha il tasto **Q — CARICA** acceso
  nella barra e il tasto E ancora chiuso con su scritto «LIVELLO 14», che e' giusto. Zero errori in console.

---

### [2.9.3] — 2026-09-13 · "Le guardie tolte: Spazio sparava, ed era anche il tasto per continuare"

#### ❌ La regola del villaggio e' stata rimossa
La v2.9.2 aveva introdotto le guardie: attacchi nel villaggio, il gioco si ferma, tre avvertimenti e la run
finisce. **Era ingiocabile.** Segnalato subito dall'uso vero: *«la guardia vede continuamente l'attacco»*,
*«il gioco non prosegue piu'»*. Rimossa.

Nel villaggio si attacca come prima e non succede niente. Restano nel progetto, **spenti e non collegati a
niente**: il testo delle tre scene (`guardia1/2/3` in `storia.js`), il ritratto della guardia nell'HUD, e i
due numeri in `constants.js` con sopra la spiegazione del perche' non si usano.

#### 💥 Il motivo: Spazio spara
In `public/js/input.js`:

```js
const shoot = this.mouse.down || !!this.keys['Space'];
```

**Spazio e' l'attacco.** Ed e' anche il tasto che fa scorrere i dialoghi. Quindi ogni Spazio premuto per
leggere la ramanzina della guardia diventava, nel tick dopo la chiusura del riquadro, **un attacco nuovo**:
guardia → Spazio per leggere → guardia → Spazio per leggere → all'infinito. La partita si piantava, ed e'
esattamente cio' che e' stato visto.

#### 🔍 E perche' nove controlli e una prova nel browser non l'hanno preso
E' la parte che conta piu' della modifica stessa.

- I **test sul server** chiamavano `setInput` a mano. Li' dentro «Spazio continua» e «Spazio spara» erano
  due cose scollegate: **il legame che ha rotto il gioco non esisteva nella simulazione.** Nove assert
  verdi su un meccanismo che nella realta' non poteva funzionare.
- La **prova nel browser** guidava i tre avvertimenti e controllava che comparissero nell'ordine giusto.
  Comparivano — ma non per i clic che credevo: erano gli **Spazio dello script** a far ripartire la
  guardia. Il test verificava l'*effetto* e non la *causa*, quindi il bug ci e' passato attraverso senza
  toccarlo. Un test che guarda solo se la cosa giusta e' comparsa non sa dire se e' comparsa per il motivo
  giusto.

#### 🔧 Cosa servirebbe per rifarla
Separare le due cose, e le strade sono due: o l'attacco non sta piu' su Spazio (ma ci sta dalla prima
versione, e cambiarlo tocca tutti), oppure **il colpo che chiude un dialogo non conta come colpo** — dopo
`storia_fine` l'attacco resta disarmato finche' il giocatore non rilascia *e ripreme*. La seconda e' quella
giusta ed e' piccola, ma va provata con una prova che **parta dai tasti veri**, non da `setInput`.

#### ✅ Verifiche
- `test/simulate.js` — TEST 69 rimosso col resto. **2374 passati**, restano i 2 ballerini noti del
  mercenario.
- `test/client.js` — i controlli sul testo delle tre scene e sul ritratto restano (cosi' il materiale
  spento non marcisce), riformulati per dire che sono spenti. *(2 fallimenti attesi sull'audio.)*
- **Nel browser** — nel villaggio: **dieci colpi di mouse e dieci Spazio, nessun riquadro, nessuna guardia,
  il gioco prosegue.** Zero errori in console.

---

### [2.9.2] — 2026-09-13 · "Nel villaggio non si sguaina"

#### 🛡️ Il villaggio adesso ha una regola
Era l'unico posto del gioco che non ne aveva: potevi tirare frecciate ai paesani per venti minuti e non
succedeva niente. Un posto senza regole non e' un paese, e' un negozio con le case attorno.

Adesso, se attacchi li' dentro — **freccia, spada o magia, anche a vuoto** — il gioco **si ferma** e una
guardia ti parla.

| | Cosa succede |
|---|---|
| **1° colpo** | *«Ferma quella mano.»* · *«Qui dentro non si sguaina. Vale per te come per chiunque altro.»* |
| **2° colpo** | *«Due.»* · *«Non ci sarà un terzo avvertimento.»* |
| **3° colpo** | *«Ti avevo avvisato.»* — e dopo **2,6 secondi di silenzio**, fine partita |

**Perche' si ferma il gioco.** Un messaggio in un angolo non lo legge nessuno, e al terzo colpo il giocatore
direbbe *«e chi lo sapeva»*. Fermarlo e' l'unico modo di essere sicuri che l'abbia letto — ed e' anche il
motivo per cui il primo avvertimento non punisce niente: copre il clic per sbaglio. Il secondo avviso e'
**piu' corto** del primo, apposta: chi ripete non merita altre parole. Il terzo e' **una riga sola**.

**Il conto e' del singolo, la condanna e' di tutti.** Ognuno ha i suoi tre, ma al terzo la run finisce per la
squadra: si scende in gruppo e si viene cacciati in gruppo. **Il conto riparte a ogni villaggio** — in una
run ce ne sono una decina, e un contatore che non si azzera mai vorrebbe dire portarsi un clic distratto del
primo villaggio fino all'ondata venti. I due numeri stanno in `constants.js`: `VILL_AVVISI: 3`,
`VILL_CONDANNA: 2.6`.

#### 🔩 Le tre scelte che lo tengono in piedi
1. **Il controllo sta in UN punto solo** — la riga da cui passano tutte e tre le vie d'attacco
   (`firePlayerWeapon`, `useQ`, `useE` sono attaccate), non dentro le tre funzioni. Tre controlli in tre
   posti sono tre posti in cui un domani ci si dimentica di uno. Lo **scatto** non conta: non fa male a
   nessuno.
2. **Il colpo si conta sul FRONTE di salita, e il fronte si riarma solo quando molli davvero.** Senza, chi
   tiene premuto il tasto si becca il secondo avvertimento nel tick esatto in cui finisce di leggere il
   primo, e il terzo subito dopo — fuori dal villaggio senza aver capito perche'.
3. **Il rilascio si legge da `_rawAtk`, non da `p.input`.** Durante una ramanzina l'input arriva azzerato
   d'ufficio (e' lo stesso blocco che ferma i piedi durante i dialoghi): leggerlo li' vorrebbe dire credere
   a un rilascio che non c'e' stato, e ingoiare senza un perche' il colpo successivo di chi aveva mollato.

**Il conto alla rovescia parte a riga FINITA**, non quando la guardia comincia a parlare: se partisse prima,
chi legge piano vedrebbe il game over a meta' frase e chi preme in fretta avrebbe due secondi di vantaggio.
Il silenzio dopo la riga e' il punto. E scorre in **ogni fase**: chi tira il terzo colpo e poi corre dentro
la faglia non se la cava — il game over lo raggiunge di sotto.

#### 😠 La guardia ha una faccia sua
Elmo **aperto** col nasale e la borchia d'ottone, bocca dritta, acciaio e ottone. L'elmo del guerriero e'
chiuso e ha la feritoia: li' dentro non c'e' nessuno da guardare negli occhi, e per un eroe va benissimo.
Una guardia invece deve poterti guardare **male**. E i colori stanno volutamente lontani dal verderame
dell'oracolo: quando compare quel riquadro devi capire in mezzo secondo che non e' il vecchio.

#### 🎲 Un test ballerino in meno
*«e per la maggior parte del tempo non ti ha visto affatto»* (TEST 62, il vagabondaggio) falliva circa **una
volta su quattro** — misurato, e falliva uguale anche prima della v2.9.1, quindi non era una regressione. La
mappa era gia' seminata, ma il vagabondaggio pesca da `Math.random`, che non lo e': lo scheletro girava a
caso e ogni tanto capitava in linea di vista e ci restava.

**La strada sbagliata sarebbe stata alzare la soglia**: nasconde il rumore *e* il segnale, e il giorno che
l'IA peggiora davvero non se ne accorge nessuno. Invece il test adesso semina `Math.random` per la propria
durata e lo rimette a posto alla fine. Misura esattamente quello che misurava, ma da' sempre la stessa
risposta — e chi cambia l'IA vede cambiare il numero, che e' l'unico allarme utile.

#### ✅ Verifiche
- `test/simulate.js` — **TEST 69 nuovo**: il primo colpo ferma il gioco e *il proiettile non esiste
  proprio*; il secondo e il terzo; il conto alla rovescia che parte a riga finita e non un attimo prima;
  le tre vie d'attacco che contano uguale; **tenere premuto due secondi vale UN avvertimento**; il conto che
  riparte a ogni villaggio; e — la verifica di cio' che **non** e' stato toccato — che **in campo si spari
  come sempre**, visto che il controllo sta nel punto da cui passa ogni colpo della partita.
  **2405 passati, 0 falliti, su sette esecuzioni di fila.**
- `test/client.js` — la tavolozza e la sagoma della guardia, le tre scene e il nome sopra la battuta
  *(restano i 2 fallimenti attesi sull'audio: `assets/` non c'e' in container)*.
- **Nel browser** — i tre avvertimenti in sequenza col ritratto giusto e il nome «GUARDIA», e la schermata
  di fine partita che arriva dopo il silenzio. **Zero errori in console.**

---

### [2.9.1] — 2026-09-13 · "Il cimitero in stand-by: si apre in grotta"

#### ⏸️ Spento, non cancellato
`CIMITERO_FINO_A` passa da **1** a **0**. Adesso **tutte** le ondate di combattimento — la prima compresa —
si giocano nelle **grotte**.

Il cimitero **resta nel progetto, intero**: `piantaCimitero()` con i suoi settori, i vialetti e le file di
lapidi; i tipi di tessera (1 lapide, 2 pietra squadrata, 3 cinta, 4 albero secco); il `_dipingiCimitero()`
del renderer che ci dipinge sopra; i quattro nomi di zona (*Il Vecchio Camposanto*, *Il Cimitero Sommerso*,
*Il Campo di Gelo*, *Il Sepolcreto Arcano*); e la regola che non lo mette mai dentro un vulcano.

**Si riaccende rimettendo `1`.** Era il senso di averlo fatto un numero solo in v1.97, ed e' la prima volta
che serve davvero.

#### 🧪 E resta provato, altrimenti marcisce
Il rischio di uno stand-by fatto male e' che il codice spento smetta di essere verificato, si rompa per
qualche modifica di passaggio, e il giorno che lo riaccendi non funzioni piu' — e nessuno sappia da quando.

Quindi `generate(seed, level, forzaCim)` ha un **terzo argomento** che accende la pianta comunque, e serve
**ai soli test**. TEST 65 e' stato riscritto e adesso verifica due cose invece di una:

1. **che il cimitero sia spento** — `CIMITERO_FINO_A === 0`, e le ondate 1, 2, 3, 7 e 20 sono tutte grotte;
2. **che la sua pianta sia ancora sana** — forzata su cinque semi: tutto il pavimento raggiungibile dallo
   spawn, almeno 55 lapidi, il muro di cinta che gira tutto attorno, i mausolei, mai il tema lava, e lo
   spazio calpestabile nella stessa fascia di una caverna.

Il blocco che fa girare **30 secondi di ondata vera** (i nemici camminano invece di impiantarsi) resta, e
adesso gira in **grotta**: e' il posto dove quell'ondata si gioca davvero.

#### ✅ Verifiche
- `test/simulate.js` — **2363 passati, 0 falliti**.
- `test/client.js` — invariato *(restano i 2 fallimenti attesi sull'audio: `assets/` non c'e' in container)*.
- **Misurato** — ondata 1 → `stella`/`quadrifoglio` (piante di caverna), ondata 3 → caverna, ondate 10 e 20
  → **caldera, intatte**; cimitero forzato → 118 lapidi, pianta sana.
- **Nel browser** — ondata 3 *(Caverne di Lava)* disegnata correttamente, **zero errori in console**.

> ⚠️ **Un test ballerino, e non e' colpa di questa modifica.** *«e per la maggior parte del tempo non ti ha
> visto affatto»* (TEST 62, il vagabondaggio) fallisce circa **1 volta su 4**: lo scheletro vaga a caso e
> ogni tanto capita in linea di vista e ci resta. Misurato: fallisce con la stessa frequenza anche con il
> cimitero **riacceso**, quindi era gia' cosi'. Si sistemerebbe alzando la soglia o dando un seme fisso a
> quel test — da decidere.

---

### [2.9.0] — 2026-09-13 · "I dialoghi riscritti, e lo sciamano diventa l'oracolo"

#### 🧿 Un nome solo, in tutto il progetto
Lo **sciamano** e' diventato l'**ORACOLO**. Non cambia niente di quello che fa — stesso antro nella fila di
levante, stessa casa con le ossa appese alla porta, stesso ritratto (corna, cappuccio, barba bianca) —
cambia come si chiama.

E si chiama cosi' **dappertutto**: `shared/mapgen.js` (`kind: 'oracolo'`, che e' la fonte da cui leggono
tutti gli altri), `server/Room.js` (`_oracolo`, `_oracoloDetto`, `updateOracolo`, `_nearOra`),
`public/js/renderer.js` (la tavolozza, il bastone con le ossa, il banco), `public/js/hud.js` (il ritratto),
`public/js/main.js` (il nome sopra la battuta), la missione in evidenza, i due file di test e i documenti.
**79 occorrenze in 9 file.** Un nome che sopravvive in meta' progetto e' un nome che un domani torna fuori
nel posto sbagliato.

#### ✍️ Tutti i dialoghi riscritti
Risveglio, arrivo al villaggio e discorso dell'oracolo: testo nuovo da capo, piu' secco e con molto piu'
botta-e-risposta.

Il risveglio adesso comincia dal personaggio che **non capisce cosa sta guardando**, non da una voce che
spiega:

> **TU** — *«Cos'e' quella luce?»* · *«No…»* · *«C'e' un portale. Nella mia stanza.»*
> **VOCE** — *«Non temere.»*
> **TU** — *«E perche' dovrei attraversarlo?»*
> **VOCE** — *«Perche' e' gia' troppo tardi per tornare indietro.»*

La voce continua a non presentarsi (`chi: ''`), e al villaggio e' ancora lei: *«Eccoti. Ora vieni da me.
Cerca la casa con le ossa appese alla porta.»*

#### ⏸️ Le pause: le didascalie diventano silenzio
Il copione aveva delle **didascalie** — *«Pausa.»*, *«l'oracolo osserva il giocatore per qualche istante»*,
*«sorride appena»*. Stamparle a schermo sarebbe stato l'errore facile: una didascalia **dice** al giocatore
cosa dovrebbe provare, ed e' il modo piu' sicuro perche' non lo provi.

Quindi non si scrivono: si **sentono**. Una riga marcata `p: 1` in `storia.js` resta **900 ms in silenzio**
col volto gia' a schermo e il cursore che lampeggia, poi comincia a scriversi. Otto righe del discorso sono
marcate cosi', e sono esattamente le tre rivelazioni e i loro appoggi:

> *«Da qualcuno che non vive in questo mondo.»* · *«Un Dio.»* · *«E ti sta guidando.»* · *«Non lo hai
> ancora capito?»* · *«E' quello che tiene gli occhi su di te in questo momento.»*

Tecnicamente la pausa e' un **`t0` spostato in avanti**, non un `setTimeout`: cosi' e' lo stesso orologio
che governa le lettere, e lo Spazio che ha fretta la salta senza dover anche spegnere un timer. La trappola
da evitare e' che durante la pausa il contatore delle lettere e' **negativo**, e `slice(0, -3)` taglia dalla
*fine*: si tiene a zero, se no la riga comparirebbe a pezzi al contrario.

#### 🎭 Il colpo di scena non dice piu' "schermo"
Prima: *«Al di la' del nostro mondo, seduto davanti a uno schermo, c'e' qualcuno che ti muove.»*
Adesso: *«Non lo hai ancora capito?»* … *«E' quello che tiene gli occhi su di te in questo momento.»*

Indicare lo schermo era spiegare la battuta. Cosi' l'ultimo passo lo fa il giocatore, che e' l'unico modo
perche' quel passo valga qualcosa. La regola che la rivelazione **spiega** resta intatta: *«Avrai bisogno
dei suoi poteri per arrivare in fondo»* — cioe' le carte che arrivano a fine ondata sono i suoi doni. Il
test, di conseguenza, non pretende piu' la parola *schermo* ma il *«ti sta guardando»*.

#### 🗣️ Tornando dall'oracolo: un congedo, non una riga
Fino alla v2.8, tornandogli davanti, partiva **una riga sola** mandata al singolo giocatore
(`storia_riga_sola`): non si vedeva in due, non si saltava con Esc, non bloccava i piedi. Adesso e' una
**scena vera** (`oracoloAncora`), cinque righe, che si chiude con l'unico dubbio di tutto il racconto:

> *«Il resto… lo decide lui.»* · *«O forse lo decidi tu.»*

#### ✅ Verifiche
- `test/simulate.js` — TEST 68 aggiornato: il giro intero (risveglio → villaggio → oracolo → ondata 1), il
  congedo che parte al ritorno ed e' **piu' corto** del discorso, le pause presenti nel copione, e nessuna
  didascalia stampata a schermo. **2362 passati, 0 falliti.**
- `test/client.js` — il `PAUSA` dell'HUD, la pausa che arriva **dal copione** e non dal codice, e la
  tavolozza del ritratto dell'oracolo. *(restano i 2 fallimenti attesi sull'audio: `assets/` non c'e' in
  container)*
- **Nel browser** — il prologo parte col testo nuovo e la missione giusta; la pausa misurata: a 250 ms il
  riquadro e' **muto col solo cursore**, a 1650 ms la riga c'e' tutta. Attraversata la faglia si arriva al
  villaggio con *«Trova l'oracolo · Villaggio, la casa con le ossa appese»*, e la grotta dell'ondata 1
  resta una grotta. **Zero errori in console.**

---

### [2.8.2] — 2026-09-13 · "La schermata d'avvio invoglia invece di spiegare"

#### ✨ Un richiamo, al posto di un manuale
La colonna di destra della schermata d'avvio conteneva *«🎯 Come funziona una run»*: cinque punti fitti con
dentro i due boss e le loro ondate, il tempo obiettivo, le due vite, le **quattro** vie di crescita coi
livelli 3·6·9·12 e 8·14, l'evoluzione delle armi e il villaggio. Tutto vero, tutto utile — e tutto da
leggere **prima ancora di aver premuto un tasto**.

Chi arriva la prima volta non vuole un manuale: vuole sapere se il gioco gli interessa. Quindi quel blocco
e' diventato un **richiamo sotto il titolo**, vago di proposito, senza un numero che sia uno:

> *Scendi. Venti volte, e ogni volta piu' a fondo. Le armi che impugni cambiano forma, i nemici imparano in
> fretta, e laggiu' qualcosa si e' appena svegliato. Fra una discesa e l'altra c'e' un villaggio dove
> tirare il fiato — poi si torna giu'.*

La larghezza e' bloccata a 620 px e non e' un vezzo: una riga lunga tutto lo schermo non si legge, perche'
l'occhio non ritrova l'inizio della riga dopo.

Nella colonna di destra restano i **comandi**, che servono davvero — e si leggono mentre si gioca, non
prima.

#### 🧪 La modalita' di prova torna nascosta
Nascosta, **non tolta**. E' uno strumento di sviluppo — "parti dall'ondata 14 col personaggio che avresti a
quel punto" — e in una schermata che deve invogliare a cominciare una partita e' rumore. Era stata nascosta
in v1.96.1 e rimessa in vista in v1.99; adesso torna dietro le due scorciatoie di allora:

- **`?test`** (o `#test`) nell'indirizzo;
- il **tasto T** stando nel menu.

La T resta scritta fra i comandi: e' l'unico modo per sapere che quella scorciatoia esiste, e un'uscita di
sicurezza che nessuno sa dov'e' non e' un'uscita di sicurezza.

#### ✅ Verifiche
- `test/client.js` — il pannello nasce nascosto, la griglia c'e' ancora, le due scorciatoie gli tolgono il
  `hidden`, e la T resta documentata. Piu': sotto il titolo c'e' il richiamo, l'elenco delle regole non c'e'
  piu' nella colonna di destra, e il richiamo **non fa numeri**.
- Guardata a schermo a 1600 e a 1100 px, e provate tutte e due le scorciatoie.

---

### [2.8.1] — 2026-09-13 · "La schermata di fine ondata parla la lingua del patto"

Una rivelazione che spiega una regola vale solo se **poi la regola la dice anche l'interfaccia**. Dopo il
colpo di scena della v2.8 la schermata fra un'ondata e l'altra affermava il contrario: *«PUNTI — dove metti
quello che hai imparato»*. Lui non impara niente: **riceve**.

| Dove | Prima | Adesso |
|---|---|---|
| Cornice del riepilogo | — | *Statistiche della partita* |
| Titolo dei punti | dove metti quello che hai imparato | **cosa gli concedi** |
| Sotto | — | *Non impara: riceve. Ogni punto che spendi qui e' una cosa che tu gli dai.* |
| Carta a fine ondata | 🎴 SCEGLI UN'ABILITA' | **🎴 CONCEDIGLI UN'ABILITA'** · *Dona al tuo avatar una nuova abilita'* |
| Elenco delle carte | LE TUE ABILITA' | **I poteri che hai concesso all'avatar** |
| Rango | — | *Le tue azioni hanno permesso al tuo avatar di salire di livello* |
| Emporio | — | *Le monete sono sue: questo se lo compra da solo.* |
| Sotto il pulsante | — | *Prosegui* |

**Il patto per esteso si legge una volta sola**, a fine ondata 1. Queste righe si rileggono venti volte, e
la letteratura letta venti volte stanca: dalla seconda in poi restano solo quelle corte.

**E l'invito a donare compare solo se c'e' davvero qualcosa da dare.** Con la scelta chiusa il titolo
diventa "nessuna scelta questa volta", e sotto restava *«Dona al tuo avatar una nuova abilita'»*: un invito
a fare una cosa impossibile e' peggio di nessun testo.

Il testo sta in `shared/storia.js` come tutto il resto del parlato — `menu:` — quindi si riscrive senza
aprire ne' l'HTML ne' l'HUD. L'unica cosa in tutta la schermata che **non** passa dalla divinita' sono le
**monete**: quelle se le guadagna lui.

#### ✅ Verifiche
- `test/simulate.js` — **2279 passati, 0 falliti**.
- `test/client.js` — le otto righe esistono, la schermata nomina l'**avatar**, le frasi vecchie
  ("quello che hai imparato", "LE TUE ABILITA'") non ci sono piu', e il patto compare solo all'ondata 1.
- Guardate a schermo tutte e tre le sezioni, con la scelta aperta e chiusa.

---

### [2.8.0] — 2026-09-13 · "La stanza, il riquadro coi ritratti, e il colpo di scena"

#### 🐛 Dal villaggio non si scendeva — ed e' istruttivo
Uscendo dal villaggio d'apertura si finiva all'ondata 1 **sulla mappa del villaggio**: dodici mostri
piantati addosso al giocatore in mezzo alle botteghe.

```js
// prima
if (this.wave > 1 && (this.wave % 2 === 1 || this._forceNewMap)) { … }
// adesso
if (this._forceNewMap || (this.wave > 1 && this.wave % 2 === 1)) { … }
```

La bandiera **"rigenera la mappa" era chiusa dentro un controllo che all'ondata 1 e' falso**. Una riga
scritta quando all'ondata 1 ci si arrivava in un modo solo — da `startGame`, che la mappa se l'era gia'
fatta — e rimasta li' per venti versioni senza dare fastidio. Poi la v2.7 ha aperto una seconda strada
verso l'ondata 1, e il difetto e' uscito subito.

**Una bandiera che vuol dire "fai X" non va messa in AND con una condizione che non c'entra.** Se e'
alzata si fa X, a qualunque ondata. Il test ora pretende che dopo il villaggio la mappa sia una grotta,
che sia stata rigenerata, e che abbia dei posti dove far comparire i nemici — le tre cose che mancavano.

#### 🛏️ Non e' piu' una cella: e' la tua stanza
La v2.7 apriva in una cella di roccia, e non reggeva quello che dice il testo: il personaggio si sveglia
e chiede *«perche' si e' aperto un portale nella mia stanza»*. Con la roccia viva attorno quella frase
non sta in piedi.

Adesso e' **20x14**, assi per terra, muri di **conci**, un letto, una cassapanca, un tavolo, una
lanterna accesa sul comodino. E in mezzo, dove ieri c'era il pavimento, un portale.

Non ha uscite, ed e' voluto: e' una camera da letto, non un livello. Se ci fosse una porta uno proverebbe
ad aprirla, e il primo minuto di gioco diventerebbe una caccia alla maniglia.

#### 🖼️ Il dialogo e' un riquadro al centro, col ritratto di chi parla
Nella v2.7 era una striscia in basso col testo sopra uno sfondo sfumato: **elegante e illeggibile**. Su
un pavimento chiaro le lettere sparivano, e comunque durante il gioco l'occhio sta al centro dello
schermo, non ai piedi.

Adesso e' un riquadro vero — opaco, bordato d'oro — con dentro il **ritratto** di chi parla. Disegnati a
codice come tutto il resto: **guerriero** (elmo con la feritoia e gli occhi che brillano dentro),
**mago** (cappello a punta con la stella, barba), **ladro** (cappuccio calato e fazzoletto sul viso),
**oracolo** (corna, cappuccio, barba bianca).

Sono di **fronte**, non dall'alto: una testa vista dall'alto dentro un riquadro di dialogo non si legge
come una faccia. E sono semplici apposta — ottanta pixel non reggono i dettagli, quello che li fa
riconoscere e' la **silhouette**.

La voce senza volto del risveglio **non ha ritratto e non ha nome**, e non e' una mancanza: e' lo
oracolo, e il giocatore lo scopre solo quando gli parla.

#### 🔒 Mentre parla qualcuno non ci si muove
Il blocco sta sul **server**, in `setInput`. Il client puo' anche smettere di mandare i comandi, ma
quello che decide dove sta un giocatore e' il server, e un blocco che vale solo di la' non e' un blocco.
Si ferma il movimento e tutto quello che si fa con le mani; la mira no, quella non sposta niente. Non
c'e' rischio di restare incastrati: la riga scade da sola dopo `STORIA_RIGA` secondi.

#### 🎭 Il colpo di scena: una divinita' davanti a uno schermo
Il discorso dell’oracolo e' stato riscritto da capo, ed e' un **dialogo** — l'avatar non capisce e
continua a chiedere, che e' giusto: e' lui il posseduto, non l'informato.

> **ORACOLO** — Sotto questo villaggio dorme una cosa vecchia di mille anni. Si chiama AZ'GAROTH, e si
> sta svegliando.
> **TU** — Cosa volete da me?
> **ORACOLO** — Tu sei stato scelto. Da una divinita'.
> **TU** — Non capisco.
> **ORACOLO** — Sei lo strumento di un Dio.
> **TU** — …
> **ORACOLO** — Al di la' del nostro mondo, seduto davanti a uno schermo, c'e' qualcuno che ti muove.
> **ORACOLO** — Si'. Dico a te che ci stai guardando.

**Non e' «l'eroe sei tu»: e' «sei lo strumento di un Dio, e il Dio e' chi tiene il mouse».** La
differenza non e' di gusto — la seconda versione **spiega una regola**: le carte potere che arrivano a
fine ondata sono i doni della divinita'. *«Lasciati guidare. Ti donera' i poteri che ti servono.»* Una
rivelazione che spiega una regola vale dieci rivelazioni che strizzano l'occhio, e il test pretende che
quelle tre cose (divinita', schermo, poteri) restino nel testo anche se un domani lo si riscrive.

#### 📋 "Missione principale", non "missione"
Il filo della storia resta acceso per tutta la partita, ma taglie, prigionieri e tutto il resto
continuano a funzionare come sempre: la parola nel riquadro lo dice senza spiegarlo. E chi esce dal
villaggio **senza** parlare con l’oracolo non si ritrova "trova l’oracolo" appeso per venti ondate:
la missione diventa comunque la discesa, perche' e' quello che sta facendo.

#### 🐛 Corretti per strada
- Nel prologo la fiala della vita restava vuota con scritto "—/—": nascondendo la barra delle ondate
  avevo messo un `return`, e si portava via tutto quello che veniva dopo nella stessa funzione.
  **Nascondere un pezzo non vuol dire saltare il resto.**

#### ✅ Verifiche
- `test/simulate.js` — **2279 passati, 0 falliti**, con la non-regressione del bug (dopo il villaggio:
  grotta, mappa rigenerata, posti di spawn) e la prova del blocco movimenti.
- `test/client.js` — i ritratti per ognuno dei quattro, il riquadro al centro, la voce senza volto.
- Provato in browser il giro intero coi tre eroi: stanza → portale → villaggio → oracolo → **ondata 1
  in una grotta 64x46 con dodici nemici**.

---

### [2.7.0] — 2026-09-13 · "La storia: ci si sveglia, si attraversa, si parla, si scende"

#### 🕯️ La partita comincia con uno che si sveglia
Non con un'ondata. **Fase nuova** (`PHASE_PROLOGO`) e **mappa nuova** (`generatePrologo`): una cella di
22x16, quasi nera, con una faglia viola in mezzo e un braciere mezzo spento accanto al giaciglio da cui ti
sei svegliato.

La cella e' **piccola e senza svolte** apposta: se ci fosse un corridoio uno lo esplorerebbe, e il primo
minuto di gioco diventerebbe una caccia al tesoro al buio. Non ci sono nemici, non ci sono casse, non c'e'
un mercante. C'e' una faglia.

Dichiara `lit` come il villaggio — che non vuol dire "illuminata" ma "il buio lo fanno le **sorgenti**
invece del campo visivo". Di sorgenti ce ne sono due: il braciere e la faglia. Tutto il resto e' nero.

E la barra in cima **sparisce**: "ONDATA 0/20 · NEMICI 0" sopra il risveglio era la cosa piu' stonata della
scena — dice al giocatore che sta giocando a un gioco a ondate prima ancora che il gioco gli abbia detto
dov'e'.

#### 🗣️ Il registro: secco
Frasi corte, nessuna spiegazione, chi parla sa piu' di quello che dice e non ha nessuna intenzione di dirlo
tutto:

> *«Sei sveglio.»*
> *«Non chiedere dove. Non te lo direi.»*
> *«Sei sceso da solo. Nessuno scende da solo.»*
> *«In mezzo alla sala c'e' una faglia. La vedi.»*
> *«Attraversala.»*
> *«Quelli prima di te sono rimasti a guardarla.»*

**La voce non si presenta mai, e `chi: ''` non e' una dimenticanza: e' il punto.** E' l’oracolo, e il
giocatore lo scopre solo quando gli parla — *«Ti ho parlato mentre dormivi. Non lo ricordi: e' normale.»*

Se uno gira invece di entrare, la voce insiste **una volta sola** (*«La faglia. Non il muro.»*) e poi tace:
insistere la trasformerebbe in un tutorial, e questa non e' una voce che spiega le cose.

#### 🧿 L’oracolo dice di cosa parla il gioco
Si arriva al villaggio all'**ondata 0** con la missione in evidenza (*«Cerca l’oracolo. Sa cosa sei.»*).
Avvicinandosi parte il discorso: sotto c'e' una cosa che non dorme, si chiama **AZ'GAROTH**, venti volte la
roccia si aprira' e ogni volta si scende piu' in fondo. E la riga che dice tutto senza spiegare niente:
*«Noi ci abbiamo provato. Siamo ancora qui, quindi hai capito com'e' andata.»*

Il boss dell'ondata 20 esisteva da sempre e **non lo nominava nessuno**: era il buco che una storia riempie.

Dopo il discorso la missione diventa **"Scendi fino ad AZ'GAROTH"**, e dal villaggio d'apertura la faglia
porta **all'ondata 1** invece che al menu di fine ondata — perche' all'ondata 0 non c'e' nessun menu a cui
tornare: si e' arrivati dalla cella, e di qui si scende.

All'inizio dell'ondata 20 una riga sola chiude il cerchio: *«E' sotto di te. Non ti sta aspettando: non sa
che esisti.»*

#### 💬 I sottotitoli si scrivono
Una striscia in basso, le lettere **una alla volta** (34 ms l'una). Non e' un vezzo: una riga che appare
tutta insieme si legge in un colpo d'occhio e si preme subito, e la voce non ha il tempo di essere una
voce. Le lettere che arrivano danno il ritmo del parlato.

Il gioco **non si ferma mai**: si continua a vedere il personaggio e la mappa. E' una voce fuori campo, non
un filmato, e la differenza sta tutta qui.

- **Spazio** continua — ma il primo Spazio **finisce la riga** invece di passarla: chi ha gia' letto non
  aspetta, ed e' la convenzione di tutti i giochi che hanno dialoghi.
- **Esc** salta. E saltare salta la **scena**, non la partita: si arriva al villaggio lo stesso, la
  missione cambia lo stesso, si scende lo stesso. E' l'errore facile, ed e' coperto da un test suo.
- La riga **invecchia da sola** dopo 5,5 s: chi legge piano non deve premere niente.

**In due o piu' il dialogo lo fa scorrere chi ha aperto la stanza**, gli altri leggono. Se dovessero
premere tutti, ogni riga diventerebbe l'attesa dell'ultimo distratto — e una storia che si aspetta smette
di essere una storia. A chi non comanda il suggerimento dei tasti non si mostra nemmeno: dirgli "premi
Spazio" sarebbe una bugia, e le bugie dell'interfaccia si pagano in fiducia.

#### 📜 Il testo sta in un file solo
`shared/storia.js`, UMD come tutto il resto. Il testo si riscrive dieci volte prima di suonare giusto, e
riscriverlo dentro il codice del server vuol dire rileggere la logica ogni volta per trovare la riga.

#### 🔌 Dettagli tecnici che valgono una riga
- **La riga corrente sta sul SERVER**, non sul client, e viaggia nello **snapshot** (due campi). Poteva
  stare sul client e costare zero banda: ma in due schermi diversi le due voci andrebbero per conto loro,
  e chi entra a meta' scena non vedrebbe niente. Cosi' invece si risincronizza da sola.
- Il client **rincorre** la riga dello snapshot invece di reagire a un evento: un evento si perde (scheda
  in secondo piano, ingresso a meta'), lo snapshot no. E se la riga e' gia' quella giusta non fa niente —
  se no la riscriverebbe venti volte al secondo.
- **`startGame(da, senzaStoria)`**: la suite fa partire una cinquantina di partite per misurare ondate,
  bilanciamento e collisioni, e farle passare tutte dal risveglio vorrebbe dire provare cinquanta volte il
  prologo e zero volte quello che si voleva provare. L'uscita e' dichiarata **in un posto solo** in cima a
  `test/simulate.js`; il gioco chiama `startGame()` e il prologo c'e'.

#### ✅ Verifiche
- `test/simulate.js` — **2205 passati, 0 falliti**. Il TEST 68 e' l'unico che fa partire una partita vera,
  col prologo, e prova la **catena intera**: risveglio → faglia → villaggio → oracolo → ondata 1. Piu' il
  giro premendo sempre Esc, il capo che comanda in due, la riga che invecchia da sola, e le regole del
  testo (nessuna riga piu' lunga di un paragrafo, i titoli delle missioni che stanno nel riquadro).
- `test/client.js` — i pezzi dell'interfaccia, la riga che arriva dallo snapshot, Spazio ed Esc.
- Controllato anche **quello che non si e' toccato**: ondata 5 in grotta, campo visivo, villaggio dal menu.

---

### [2.6.0] — 2026-09-13 · "Il villaggio rifatto: due file di case, la piazza di terra, il portale nella casa delle guardie"

#### 🏘️ La pianta: due file che si guardano
La pianta della v2.0 era una sala con delle stanze appese dove capitava: si leggeva come un livello, non
come un paese. Questa e' costruita sull'unica cosa che rende un villaggio riconoscibile dall'alto: **due
file di case** e in mezzo lo spazio comune.

```
 x:  0..2   rocce          3..16  fila di PONENTE      17..19  via di ponente
    20..39  lo spiazzo (e dentro, la PIAZZA di terra)  40..42  via di levante
    43..56  fila di LEVANTE                            57..59  rocce
```

**60x46** (era 56x40). Cinque edifici per fila, tre case nello spiazzo, tredici in tutto: la casa del
portale, cinque botteghe, sette case. Le due vie lunghe corrono davanti alle porte, la via alta e la via
bassa le chiudono, lo spiazzo in mezzo e' tutt'uno con loro.

**Ogni stanza dichiara la sua PORTA** (tessera + lato). Prima la porta si indovinava dalla lista dei varchi
con un confronto di coordinate, e bastava spostare una stanza per far arredare una casa **col letto sulla
soglia**. Adesso la porta e' un dato della stanza: i varchi si generano da li' e l'arredamento sa da che
parte si entra senza doverlo dedurre.

#### 🪨 Fuori e' la roccia delle grotte, dentro no
Il villaggio aveva una tavolozza sua — pietra calda — e si vedeva: una sala beige con dentro delle case,
mentre tutto il resto del gioco e' roccia fredda. Adesso il tema e' quello della cripta e la cottura e' la
**stessa delle ondate** (`_bakeCaverna`): massi tondi, ombre proiettate, contrasto vero.

Il `muri` del villaggio dice di che cosa e' fatto ogni muro: **2 = concio** per le pareti delle case,
**0 = roccia di grotta** per il perimetro e per la massa in cui il paese e' scavato. Il giro esterno non ha
un solo concio — fuori dal paese c'e' la montagna.

**Dentro le case il pavimento resta quello di prima**: assi, lastre, terra. E' li' che si sta al caldo.

#### 🟫 La piazza e' terra battuta, e ha il bordo sfrangiato
Il primo battuto era una tinta al 58% con dieci trattini scuri sopra: sotto la luce diventava una lastra di
grigio uniforme — la stessa cosa che chiamavamo patina, perche' **mancava il nero**. Adesso ha chiazze piu'
scure, **ghiaia chiara E scura** (solo scura e' fuliggine) e ogni tanto un solco.

E il bordo non e' dritto: era un rettangolo pieno e da lassu' si leggeva come un **tappeto srotolato sulla
roccia**. Una piazza si consuma dove ci si cammina, quindi il giro si allarga di una tessera e si copre a
chiazze — piena dentro, sfrangiata sull'orlo, qualche macchia fuori.

Attorno: **dodici torce** (agli angoli e a meta' di ogni lato) e **dodici bancarelle** (pane, carne, pesce,
frutta, vasi, tessuti, candele, formaggi, spezie, pellami, ferro, vino), ognuna col suo disegno e il tendone
tinto del colore della merce — con dodici banchi in giro alla piazza un tendone rosso uguale per tutti li
faceva leggere come dodici copie.

#### 🌀 Il portale nella casa delle guardie
Stava in mezzo alla piazza, e uno spiazzo con un buco viola al centro non e' una piazza: e' una sala del
portale con delle case attorno. Adesso e' nella **casa del portale**, la prima della fila di ponente, con
**due guardie sulla soglia** — un ottavo tipo di paesano, elmo con la cresta, fessura per gli occhi, lancia
piantata a terra. Dallo spawn sono una quindicina di tessere: tre secondi e mezzo, non un bottone sotto i
piedi.

#### 💡 Piazza chiara, resto buio
`VILL_PIAZZA: 0.60` e `VILL_PZ_ORLO: 1.4`. Dentro il rettangolo della piazza il buio di base vale meno, e
fra i due si passa sfumando per qualche tessera. **Non e' una luce appoggiata sopra** — quella sarebbe di
nuovo una patina — e' buio che si toglie. Ed e' un ovale, non un rettangolo: un alone quadrato con gli
spigoli si legge come una finestra.

Il falo' e' sceso da **430 a 340** di raggio (x1,45 = 624 → 493 px). Con la vecchia sala calda era la luce
della stanza; sul pavimento freddo della grotta era diventato un alone bianco largo mezzo schermo.

#### 🧿 La Cartomante e' diventata lo Oracolo
Per ora non fa nulla: niente `crd`, quindi il server non gli attacca nemmeno il richiamo di prossimita'. Le
sue carte erano spente da tempo (`CARTOMANTE_ATTIVA`), quindi non si perde niente — cambia chi abita
l'antro. Verderame invece di viola, bastone con le ossa invece del ventaglio di carte, ciotola dei fumi sul
banco invece della sfera.

#### 🩶 E la patina, stavolta davvero
Non era uno strato di troppo: era uno **SFASAMENTO**. Il buio si bucava con un raggio e il bagliore caldo si
disegnava con un ALTRO — l'alone dell'eroe usciva a 190x1,45 = **275 px** dentro un buco di **130**. Quei
145 px di differenza sono luce appoggiata sul buio, cioe' esattamente una patina, e ti seguiva perche'
l'eroe sei tu.

**Il rimedio non e' limare un numero: e' che i due passaggi leggano LA STESSA LISTA.** Le sorgenti del
villaggio si dichiarano una volta sola — `[x, y, raggio, colore, alfa, forza]` — si bucano con quel raggio e
si accendono con lo stesso. Nessun bagliore senza il suo buco, nessun buco piu' piccolo del suo bagliore.

Piu' due colpevoli minori, trovati guardando **quello che non avevo toccato**: la **cottura piatta** del
villaggio (un motivo ripetuto sotto tutto, senza nero e senza contrasto) e la **fascia viola della faglia**,
spenta a schermo dalla v2.1 ma ancora **cotta** sui bordi della mappa.

#### 🐛 Corretti per strada
- Nelle case basse quattro tessere il conto "centro meno 1,8" finiva nella riga di muro: il mobile spuntava
  dentro la stanza dal lato sbagliato e **tappava il passaggio** — una casa intera irraggiungibile. Adesso
  chi non ci sta, non ci va, e le case piccole si arredano con meno roba.
- Fra il braciere e il tavolo della taverna restava una **tasca larga otto pixel**: irraggiungibile,
  invisibile, e il flood fill la trovava ogni volta. Due candelabri fanno la stessa luce e ingombrano un
  terzo.
- Le porte a settentrione e mezzogiorno erano larghe **una tessera sola**: 48 px contro un personaggio largo
  35 lasciavano sei pixel per parte. Adesso sono due come tutte le altre.

#### ✅ Verifiche
- `test/simulate.js` — **2155 passati, 0 falliti**. Flood fill a mezza tessera coi corpi solidi: **nessuna
  zona isolata**, tutte e tredici le stanze raggiungibili, ogni mercante avvicinabile.
- `test/client.js` — nuovi blocchi per la lista unica delle sorgenti, la cottura del villaggio, i tipi di
  muro (conci per le case, roccia sul perimetro), il pavimento (terra in piazza, assi nelle case, grotta
  nello spiazzo), la piazza chiara, la guardia, l’oracolo e i dodici banchi.
- Controllato anche **quello che non si e' toccato**: mappa di combattimento all'ondata 5, campo visivo a
  torcia, ombre dei muri e nebbia delle grotte invariati.

---

### [2.5.0] — 2026-09-13 · "La patina vera era la nebbia · bancarelle · sette paesani · mimic raro"

#### 🩶 La patina non era la velatura: era la nebbia
In v2.4 avevo tolto il velo e dichiarato chiuso il problema. Il villaggio restava **appannato lo stesso**, e
il motivo stava altrove: `_drawFog` stende **quattordici macchie grigio-azzurre** (`rgba(150,160,185)`) su
tutta l'inquadratura a **ogni fotogramma**. Nelle grotte ci vogliono, sopra un paese illuminato a fuoco sono
esattamente la pellicola che si vedeva.

```js
if (!this.map.lit) this._drawFog(ctx, camX, camY, dt);
```

**La lezione vale piu' della riga: quando si toglie una cosa, si controlla anche quello che NON si e'
toccato.** Avevo guardato solo il pezzo che stavo cambiando e consegnato meta' del difetto. Il test pretende
la guardia **e** che `_drawFog` si chiami da un posto solo — con due chiamate la guardia servirebbe a poco.

#### 🧰 Sei bancarelle di contorno
Cinque negozi usabili e sette case non fanno un villaggio: fanno un menu. Sulle vie ci sono ora **PANE,
CARNE, PESCE, VASI, TESSUTI, CANDELE** — tendone a righe, banco, la merce del mestiere, due casse ai piedi e
l'insegna. **Non sono negozi**: non compaiono fra gli `npcs`, non hanno dialogo, non si aprono. Ma
**ingombrano** (`INGOMBRI.bancarella` 35×15, ruota col verso del banco): ci si gira attorno. Raggiungibilita'
del villaggio verificata col flood fill a mezza tessera — **99,9%**, invariata.

#### 🧍 Sette tipi di paesano, disegnati da zero
Prima erano tutti **la sagoma del ladro ricolorata**: una fila di gemelli in tinte diverse. Adesso:
**paesano** (cintura e sacco), **paesana** (fazzoletto e cesto), **vecchio** (barba e bastone, statura 0,90),
**bimbo** (palla, statura 0,66), **bottegaio** (grembiule), **monaco** (cappuccio), **minatore** (elmetto con
lampada e piccone). **Un segno solo per tipo**: a quella dimensione due si sovrappongono e non se ne legge
piu' nessuno.

**Due tentativi buttati prima di arrivarci.** Un ovale con un pallino di fianco leggeva *sassi con la
faccia*; un cerchio con due moncherini dietro leggeva *Topolino*. Dall'alto una persona la fa la
**proporzione**: corpo schiacciato davanti-dietro e largo di traverso (`rx 0.46`, `ry 0.84` — le spalle),
testa che **sporge** (`hx 0.50` > `rx 0.46`), braccia **ai lati e sopra** il corpo (dietro tornano orecchie)
e piu' chiare della veste, con la **mano** in punta: due macchie di pelle, e sono loro a far leggere le
braccia. Passo `sin(t*3.1)` in controtempo, respiro `sin(t*1.6)` al 2%.

**I quattro eroi non sono stati toccati.** Il test verifica che `_ePaesano` dica di no a guerriero, ladro,
mago e arciere, e che le sette vesti abbiano sette colori distinti.

#### 🪤 Il mimic torna a essere una sorpresa
`MIMIC_PROB` **0,30 → 0,06**. Il numero che conta e' quello **per ondata**, non per cassa: con quattro casse
si passa da **76% a 22%** di trovarne almeno uno — da tre a ondata a circa **uno ogni cinque ondate**. Al 76%
non era una rarita', era una **tassa** sull'aprire le casse, e si smetteva di aprirle.

#### ✅ Verifiche
- `test/simulate.js` — **2108 passati, 0 falliti**.
- `test/client.js` — nuovi blocchi per la nebbia guardata, i sette paesani (tavolozze distinte, proporzione
  delle spalle, testa sporgente, mani, eroi non toccati), le bancarelle (sei banchi, sei mestieri, un corpo
  solido ciascuno, nessuna fra i mercanti) e il mimic (quota per cassa **e** conto per ondata).
- Controllato anche **quello che non si e' toccato**: mappa di combattimento all'ondata 5, campo visivo a
  torcia e nebbia delle grotte invariati.

---

### [2.4.0] — 2026-09-13 · "Via la patina: il villaggio è buio, e la luce la fanno le sorgenti"

#### 🩶 Cos'era la patina
Dalla v2.2 il villaggio aveva sopra una **velatura**: un rettangolo semitrasparente steso su tutto. Piu' la
si caricava (0,18 → 0,26 → 0,55) e piu' si vedeva per quello che era.

**Un velo uniforme non scurisce: SBIANCA.** Schiarisce i neri esattamente quanto spegne i chiari, quindi
comprime tutto verso il grigio — ed e' per questo che sembrava una pellicola appoggiata sul disegno invece
di un posto buio. Il difetto non era il valore: era il metodo.

#### 🕯️ Adesso: buio vero, bucato dalle sorgenti
Il villaggio e' **quasi nero** (`VILL_BUIO: 0.90`) e la luce la fanno **solo le sorgenti**, che ci scavano
dentro i loro buchi: i sette focolari delle case, il falo' della piazza, bracieri e candelabri, gli aloni
dei mercanti, il portale e le lanterne dei girovaghi. Piu' un cerchietto che ci si porta dietro
(`VILL_EROE: 130`), per non essere ciechi fra una luce e l'altra.

E' **lo stesso meccanismo del campo visivo delle grotte** — una tela a parte, si cancella col
`destination-out`, si sfoca, si appoggia — applicato alle sorgenti invece che alla vista. La differenza con
la velatura e' tutta qui: **la' si aggiungeva grigio, qui si toglie buio**. Il nero resta nero e i colori
restano colori.

#### 💡 E ogni sorgente illumina il doppio
`VILL_LUCE: 1.45` moltiplica il raggio di **ogni** luce del villaggio: focolare 200 → 290, torcia 120 →
174, falo' 430 → 624, alone del mercante 100 → 145.

**Attenzione al numero, perche' l'ho sbagliato al primo colpo.** "Area doppia" e' **radice di due** sul
raggio (1,41), non due: col raggio raddoppiato l'area e' QUADRUPLA, e il villaggio si e' acceso tutto —
le pozze di luce si sovrapponevano e del buio non restava niente. Adesso il conto e' raggio ×1,45 = area
×2,1, e il test lo pretende: `K*K` dev'essere vicino a 2, non a 4.

Il moltiplicatore vale **anche per il colore caldo**, non solo per il buco nel buio: se crescesse solo il
buco resterebbe un alone grigio con un puntino caldo in mezzo. Sta scritto in un posto solo (`KL`), e fuori
dal villaggio vale 1 — le grotte non cambiano di una virgola.

#### 🧪 Test
Il client verifica che la velatura sia sparita dal renderer, che il villaggio sia buio dove non arriva
luce, che le sorgenti scavino invece di aggiungere grigio, che il moltiplicatore valga anche per il colore,
e — quello che conta di piu' — che **il conto dell'area torni a 2 e non a 4**. **2108 test, 0 falliti.**

**Verificato anche cio' che non ho toccato**: l'ondata 7 in partita vera ha la sua torcia e le sue ombre,
identiche.

### [2.3.0] — 2026-09-12 · "Il villaggio di notte, e la gente che ci cammina"

#### 🌑 Parecchio piu' scuro
`VILL_OMBRA` da **0,26 a 0,55**: il centro dello schermo e' velato al 55%, i bordi all'85%. E la scala e'
cambiata con lui — col vecchio rapporto (2,15x ai bordi) a questi valori gli angoli andavano a **nero
pieno** e il villaggio si chiudeva; adesso il centro vale `V` e i bordi si fermano a 0,96: buio, ma mai
cieco.

Il risultato non e' "meno visibile": e' **un altro posto**. Il villaggio non e' piu' una sala illuminata,
e' un paese sottoterra di notte, e a farlo vedere sono i fuochi — i sette focolari delle case, il falo'
della piazza, gli aloni dei mercanti. Le botteghe si trovano seguendo la luce, che e' come si trovano le
botteghe di notte.

#### 🚶 E adesso ci cammina della gente
Gli abitanti della v2.0 stavano **fermi**, ognuno al suo posto con un mestiere in corso: davano vita alle
stanze ma non alle strade, e un paese in cui nessuno cammina non e' un paese. Adesso ci sono **dieci
girovaghi** che percorrono le vie: due corsie in versi opposti sulla via alta, due sulla via bassa, una
sulla via maestra, due che **girano in tondo attorno al portale**, e un paio che vanno e vengono dai vicoli
delle botteghe.

**Non si muovono: sono una funzione del tempo.** Ognuno ha una rotta — una polilinea che segue le strade —
e la sua posizione si calcola dal `tick` della partita. Tre conseguenze, tutte volute:

- il **server non manda niente**: zero banda, zero codice di movimento;
- **tutti i giocatori li vedono nello stesso punto**, perche' il tempo della partita e' lo stesso per tutti;
- chi entra a meta' sosta li trova dove devono essere, **senza nessuna sincronizzazione**.

Camminano, si fermano al capolinea, si guardano attorno e tornano indietro. Quelli dell'anello girano e
basta.

**Non hanno un corpo solido, e non e' una dimenticanza**: il corpo lo calcola il server dalle posizioni, e
qui le posizioni non esistono — esiste una formula. Un corpo fermo sotto una persona che cammina sarebbe
peggio di nessun corpo: ci sbatteresti contro il vuoto. Sono scenografia, e ci si passa attraverso; i
mercanti e la gente ferma il corpo ce l'hanno come prima.

#### 🏮 La lanterna
Col villaggio a 0,55 chi camminava diventava una **sagoma nera**: la vita c'era e non si vedeva. Ognuno
adesso si porta dietro una lanterna, ed e' anche il motivo per cui le strade si leggono — le percorre della
gente con la luce in mano. Guardare il paese dall'alto e vedere le lucine muoversi per le vie e' meta' del
perche' questa versione esiste.

#### 🐞 E un difetto introdotto e chiuso subito
Le posizioni delle lanterne si azzeravano **quando si disegnavano i girovaghi**, cioe' solo nel villaggio:
uscendo, l'elenco restava pieno e in mezzo alla grotta si accendevano **lanterne senza nessuno che le
porta**. Adesso si azzerano a ogni fotogramma, prima di ridisegnarle — e il test del client pretende
proprio quest'ordine, non solo che la riga esista.

#### 🧪 Test
Le rotte dei girovaghi sono verificate: **nessuna attraversa un muro** (si campiona ogni 12 px lungo ogni
tratto), nessuna e' degenere, nessuno passa **dentro il portale** (uno che entra nella faglia e ne esce come
se niente fosse rovina il posto), e i girovaghi **non compaiono fra i corpi solidi**. **2107 test, 0
falliti.**

**Verificato anche cio' che non ho toccato**: l'ondata 7 in partita vera ha la sua torcia, le sue ombre e
nessuna lanterna fantasma.

### [2.2.0] — 2026-09-12 · "La schermata principale, e il villaggio un po' piu' sottoterra"

#### 🏠 Il titolo esce dal pannello, e la guida si apre
Prima la schermata di avvio era un pannello solo, alto e stretto: dentro ci stavano il titolo, il nome, gli
eroi, il pulsante e — **chiusa in un accordion che nessuno apre mai** — tutta la guida del gioco. Chi
arrivava nuovo non sapeva niente, e chi ci tornava dopo un mese doveva ricordarsi da solo cosa fa il tasto E.

Adesso:

- **Il titolo sta fuori**, sullo sfondo, grande. E' l'insegna del gioco, non una riga di un modulo.
- **Sotto, due colonne**: a sinistra si entra in partita (nome, stanza, eroe, prova), a destra c'e' la
  guida — **aperta, senza niente da cliccare**. In una schermata di avvio un accordion e' un modo elegante
  di non far leggere niente a nessuno.
- Ogni colonna **scorre per conto suo**: il titolo resta sempre in cima, e su uno schermo basso non si
  perde ne' il pulsante di sinistra ne' la guida di destra. Sotto i **1080 px** si impilano invece di
  schiacciarsi.

Vale **solo per la schermata principale**: la sala d'attesa e il menu di fine ondata restano com'erano.

#### ⌨️ E finalmente c'e' scritto cosa fanno i tasti
Tutti, compreso il **tasto L**, che dalla v2.1.4 e' acceso all'avvio e che nessuno sapeva esistesse:
movimento, mira, sparo, **scatto**, le tre **pozioni** (1 2 3), le due **abilita' attive** (Q ed E, coi
livelli a cui si sbloccano), **L** (luce), **M** (musica), **Invio** (chat) e **T** (modalita' di prova).
Il test li pretende uno per uno: se un domani se ne aggiunge uno e ci si dimentica di scriverlo, e' li' che
ce lo si ricorda.

Sotto, **le cinque cose che contano davvero** in una run: venti ondate e due boss col tempo obiettivo; le
due vite; i **quattro modi separati di crescere** (XP → statistiche, livelli 3·6·9·12 → carte, 8·14 →
abilita' attive, monete → equipaggiamento) e la specializzazione al 15; l'evoluzione delle armi; e il
villaggio fra un'ondata e l'altra. Piu' una nota su come funziona la torcia nelle grotte.

Niente immagini: testo e icone. Una guida fatta di schermate invecchia alla prima modifica alla grafica,
questa no.

#### 🕯️ Il villaggio e' un po' piu' sottoterra
Dalla v2.0.2 la sosta e' illuminata piena — nessun velo — e **senza niente sopra sembrava una stanza a
giorno**. Adesso c'e' una velatura leggera, uguale dappertutto e un po' piu' carica ai bordi
(`VILL_OMBRA: 0.26` → 16% al centro, 56% agli angoli).

Resta **tutto leggibile**, che e' il motivo per cui questa mappa e' illuminata e non va perso: si vede
ancora dove sono le botteghe senza doverle cercare. Con `VILL_OMBRA: 0` si torna alla luce piena della
v2.0.2, alzandolo si scende verso il buio.

**2102 test, 0 falliti.**

### [2.1.4] — 2026-09-10 · "La torcia parte accesa"

Lo strato del **tasto L** c'e' dalla v1.16: una seconda mano di buio bucata da aloni tondi — uno grande
attorno all'eroe, e uno piccolo per ogni torcia, braciere e pozza. Da solo era una modalita' alternativa;
insieme al campo visivo della v2.1 e' **l'illuminazione giusta**: il campo visivo da' la forma e le ombre
dei muri, questo strato scava i tondi di luce attorno alle sorgenti e ammorbidisce il resto.

Il suo valore predefinito era **gia' "acceso"**. Il problema era un altro: chi l'aveva spento anche una
volta sola si ritrovava uno `0` salvato nel browser, e da li' in poi il gioco partiva sempre senza — con
l'illuminazione a meta'.

Il vecchio `0` non deve piu' comandare, ma la scelta di chi lo spegne d'ora in poi si', quindi la chiave ha
**cambiato nome**: `dr_torch` → `dr_torcia`. Chi aveva spento riparte acceso, **una volta sola**; il tasto L
continua a spegnere e accendere, e continua a ricordarselo. Cambiare nome alla chiave e' il modo pulito di
dare un valore predefinito nuovo senza buttare via la memoria della scelta.

Il test lo pretende su tutti e quattro i pezzi: nasce accesa, legge la chiave nuova, **non legge piu' la
vecchia**, e continua a salvare. E nel villaggio lo strato non si applica comunque (`lit`, v2.0.2): la L
non puo' rimettere al buio la sosta.

### [2.1.3] — 2026-09-10 · "La penombra"

Il bordo dell'ombra proiettata da un muro era un **taglio netto**. Geometricamente e' giusto — un raggio o
passa o non passa — ma all'occhio e' sbagliato: nessuna luce vera fa un bordo cosi'.

Adesso il velo si **sfoca** quando lo si appoggia sopra la scena: `FOV_SFUMA: 6` pixel. E' una sola
operazione per fotogramma — si sfoca il velo **intero, una volta**, invece di ammorbidire ogni contorno uno
per uno — e ammorbidisce insieme due cose: i bordi delle ombre e la coda delle due luci.

**E ha portato con se' un dettaglio che non e' un dettaglio.** Sfocando un rettangolo il suo bordo diventa
semitrasparente: se quel bordo coincidesse col bordo dello schermo si vedrebbe una **cornice chiara**
tutt'attorno al gioco. Per questo la tela del velo e' piu' grande dello schermo di **26 px** per lato e la
si appoggia partendo da `-M`: il bordo sfumato cade fuori. I due numeri vanno insieme, e il test lo
pretende — il margine dev'essere piu' largo del doppio della sfocatura.

`FOV_SFUMA: 0` riporta il taglio netto di prima.

Il villaggio resta fuori: la sfocatura sta dentro il ramo che si esegue solo quando la mappa non e'
illuminata (`lit`, v2.0.2).

**2102 test, 0 falliti**, client verde.

### [2.1.2] — 2026-09-10 · "Due luci: l'alone e il fascio"

Una torcia vera fa **due cose insieme**: un **alone** largo che ti illumina attorno, e un **fascio** stretto
che va lontano dove la punti. Fino alla 2.1.1 c'era una goccia sola e doveva fare entrambe — o era corta e
non illuminava lontano, o era lunga e si allargava troppo. Adesso sono due.

#### 🔗 Perche' si integrano invece di stare appiccicate
Il cono **non e' una forma nuova**: e' *la stessa formula* dell'alone con numeri diversi.

```
R(a) = DIETRO + (AVANTI - DIETRO) * ((1 + cos a) / 2) ^ FORMA
```

| Angolo | Alone | Fascio |
|---|---|---|
| davanti | 470 | **1150** |
| 20 gradi | 455 | 1049 |
| 40 gradi | 414 | 792 |
| 60 gradi | 353 | 485 |
| 90 gradi | 251 | 144 |
| alle spalle | 118 | **0** |

Due curve continue, e il fascio si spegne da solo girandosi: **non c'e' nessun bordo da cucire**. Verso i 60
gradi il comando passa dall'uno all'altra senza che si veda dove. Il test lo pretende come numero: **il
salto massimo di portata da un grado al successivo e' il 3,8%** — sotto la soglia del 6% oltre la quale
l'occhio vedrebbe uno spigolo.

E si sommano invece di sovrapporsi: cancellare il velo e' **moltiplicativo**, quindi dove l'alone ha gia'
tolto meta' velo il fascio toglie meta' di quel che resta. Nel cuore le due luci si sommano senza gradino.

#### 🌗 Le sfumature, che sono il punto
Ogni luce ha la sua **curva**, e la curva ha un numero che decide tutto: `piena`, cioe' **fino a che
frazione della portata la luce resta piena** prima di cominciare a calare.

- l'**alone** e' pieno per il 22% e poi sfuma tutto: e' luce diffusa, non deve avere un bordo.
- il **fascio** e' pieno per il **34%** e poi cala piano: 100% fino a 400 px, 82% a 600, 64% a 750, 51% a 900.

Al primo tentativo il fascio calava da subito e **sembrava corto per quanto lontano arrivasse la sua
portata**: su un pavimento di grotta, gia' scuro di suo, sotto il 60% di luce non si distingue piu' niente.
Il fascio era li', semplicemente non si vedeva.

#### 🔥 E la luce calda del fascio
Togliere il velo non basta: senza velo il pavimento di una grotta e' comunque scuro, e il fascio si leggeva
come *meno buio* invece che come **luce**. Tre lampade calde in fila lungo la direzione in cui guardi (a
14%, 36% e 60% della portata) sono cio' che lo rende una torcia. Sono dentro il ritaglio del campo visivo
come tutte le altre luci: **un muro le ferma**.

#### 🧪 Test
Il blocco del campo visivo prova ora anche le due luci separatamente e la loro fusione: il fascio va oltre
il doppio dell'alone, si stringe girandosi, di fianco ha perso l'87% della portata, alle spalle non esiste,
e le due curve si fondono senza gradini. **2102 test, 0 falliti**, client verde.

Il villaggio resta fuori da tutto questo (`lit`, v2.0.2).

### [2.1.1] — 2026-09-10 · "Il fascio piu' lungo, e l'ombra solo dai muri"

#### 🔦 Il fascio arriva piu' lontano
`FOV_AVANTI` da **690 a 1060 px**: davanti si vede oltre il bordo dello schermo, come una torcia vera.
Alzando la portata frontale cresce anche quella laterale, quindi `FOV_FORMA` e' salita con lei (1,7 → 2,1):
il fascio si **allunga senza allargarsi**.

| Dove guardi | Prima | Adesso |
|---|---|---|
| davanti | 690 | **1060** |
| 45 gradi | 555 | 794 |
| di fianco | 294 | 338 |
| alle spalle | 118 | 118 |

Il rapporto davanti/dietro passa da 5,8x a **9,0x**. E la curva della sfumatura e' piu' dolce (esponente
1,5 → 1,25): con la vecchia, la punta del fascio si spegneva prima di arrivarci e la portata in piu' non si
sarebbe vista.

#### 🪦 L'ombra la fanno solo i muri
La griglia del gioco e' **binaria**: per lei una lapide del cimitero e un masso sono la stessa tessera. Il
campo visivo se ne accorgeva, e ogni lapide proiettava il suo cono d'ombra — un campo di lapidi diventava
una **grattugia di ombre**.

Il tipo vero della tessera c'e' gia': e' `m.muri`, l'array che dalla v1.97 dice al renderer *cosa*
disegnare. Adesso lo legge anche la luce:

| Tessera | Ombra |
|---|---|
| **lapide** (1) | **no** — e' alta un ginocchio, ci si vede sopra |
| roccia (0) · pietra squadrata delle cappelle (2) · cinta (3) | si |
| **albero secco** (4) | si — e' alto, e per giunta fa da bordo alla mappa: se lasciasse passare la luce si vedrebbe fuori dal cimitero |

Se un giorno servisse far passare anche i muretti bassi, si aggiunge un numero in `_fovBlocca` e basta:
e' l'unico punto del gioco in cui questa distinzione esiste.

**Vale solo per la LUCE.** Per le collisioni e per l'IA una lapide resta un muro, e deve restarlo — se no i
mostri ci passerebbero attraverso.

#### 🧪 Test
Il blocco del campo visivo ora prova anche questo, su una mappa finta con una fila di lapidi e una di
cinta: la lapide non ferma la luce, la cinta si, l'albero secco si, la pietra squadrata si, e i raggi
passano **sopra** le lapidi ma si fermano alla cinta. **2102 test, 0 falliti** e client tutto verde.

### [2.1.0] — 2026-09-10 · "La torcia: si vede quello che si puo' vedere"

Fino alla v2.0 il buio delle mappe di combattimento era un velo **tondo** attorno al giocatore: vedevi un
cerchio: davanti, di fianco, dietro, uguale. E una stanza dietro una roccia si vedeva come una stanza
aperta, perche' il velo non sapeva niente dei muri. Adesso si vede **quello che si puo' vedere**, e si vede
come lo vedrebbe uno con una **torcia in mano**.

#### 🔦 Come funziona
Si tirano dei **raggi** dal giocatore su tutto il giro. Ognuno cammina a passetti di un terzo di tessera
finche' non sbatte in un muro o finisce la portata; le punte dei raggi disegnano una **macchia**, e quella
macchia e' il buco che si ritaglia nel buio. **Dietro un muro il raggio non arriva, quindi la luce non
arriva, quindi resta buio**: l'occlusione non e' un calcolo a parte, e' la stessa cosa.

A cambiare non e' *quali* raggi esistono ma **quanto lontano arrivano**:

```
R(a) = DIETRO + (AVANTI - DIETRO) * ((1 + cos a) / 2) ^ FORMA
```

| Dove guardi | Portata |
|---|---|
| davanti | **690 px** |
| 45 gradi | 555 px |
| di fianco | 294 px |
| 135 gradi | 140 px |
| alle spalle | **118 px** — poco, ma non zero: nessuno e' cieco dietro la nuca |

**5,8 volte piu' lontano davanti che dietro**, e tutto e' in `constants.js`: tre numeri, `FOV_AVANTI`,
`FOV_DIETRO`, `FOV_FORMA`.

#### ❌ Due tentativi buttati, e perche'
**Il primo**: ritagliavo la macchia direttamente sulla tela del gioco con `destination-out`. Quello non
cancella il velo, cancella i **pixel** — mondo compreso — e la zona illuminata diventava un buco
trasparente sul nero della pagina. Il velo si costruisce ora su una **tela sua** (a meta' risoluzione: il
bordo sfumato non chiede di piu' e costa un quarto), ci si ritaglia dentro la macchia, e poi la si appoggia
sopra.

**Il secondo**, e questo l'ha visto Paolo: avevo fatto un **cono** davanti piu' un **cerchietto** attorno ai
piedi. Due forme diverse cucite insieme, e la cucitura si vedeva — un cerchio netto con un triangolo
attaccato. Adesso e' **una forma sola**: il cerchietto non esiste piu', e' la stessa macchia che dietro si
accorcia.

E la sfumatura non e' un gradiente radiale — **un gradiente e' un cerchio, e questa forma non lo e'**. Sono
**quattordici contorni annidati**, dal piu' largo al piu' stretto, ognuno cancella un altro po' di velo: la
luce cala seguendo la goccia invece che un cerchio, e accanto ai muri si ferma dove si ferma la vista
(scalare tutti gli strati avrebbe aperto un anello scuro contro ogni parete).

#### 💡 E le luci seguono la stessa regola
Torce, bracieri, casse, nemici in fiamme: gli aloni di luce sono **ritagliati sulla macchia**. Una torcia
dietro una roccia non illumina piu' la roccia.

#### 👥 In cooperativa la visuale e' condivisa
Quello che vede un compagno lo vedi anche tu. Se no in due si giocherebbe peggio che da soli.

#### 🏘️ Il villaggio no
La sosta dichiara `lit` dalla v2.0.2 e resta illuminata: niente torcia, niente ombre. Il renderer decide da
quella bandiera, non dal tipo di mappa, e il test lo pretende ondata per ondata.

#### 🧪 Test
Nuovo blocco nei test del client, che prova la **funzione vera** estratta dal file (se qualcuno la riscrive
male, casca li'): la portata cala girandosi ed e' almeno 4x davanti; dietro un pilastro di roccia **zero**
tessere illuminate; davanti al pilastro venti; **nessuno dei 512 raggi attraversa la roccia**; e il campo
visivo si calcola solo dove la mappa non e' illuminata. Suite: **2102 test, 0 falliti.**

**Una conseguenza da sapere, ed e' voluta**: i nemici alle spalle non si vedono piu'. Restano sulla
minimappa, che e' l'altro modo di sapere dove sono.

### [2.0.2] — 2026-09-10 · "Nel villaggio si vede"

#### 💡 Via il buio, e via le torce della 2.0.1
La v2.0.1 aveva risolto il problema al contrario. Il villaggio non era buio perche' mancavano le torce: era
buio perche' su **ogni** mappa il gioco stende un velo scuro attorno al giocatore, e quel velo, su 56x40,
lasciava le strade nere. Cinquantasette torce a muro erano una tappezzeria di fiammelle messa li' a
combattere un velo che bastava togliere.

Quindi: **le 57 torce, i bracieri e le lanterne della 2.0.1 sono state rimosse** — il villaggio torna alle
sue luci di sempre (il falo', i sette focolari, gli aloni dei mercanti) — e al loro posto **il velo scuro,
nel villaggio, non si stende piu'**.

**Vale per UNA mappa sola.** La pianta della sosta dichiara `lit: 1`; nessun'altra mappa lo fa, e il
renderer legge quella bandiera, non il tipo di mappa. Le ondate restano buie esattamente come prima — il
velo che si stringe attorno a te e' meta' della loro tensione — e la riga che lo toglie porta scritto sopra
di non allargarla ad altre mappe senza rendersene conto. Il test lo pretende: `lit` acceso nel villaggio,
spento alle ondate 1, 5, 10 e 20.

Tolto il velo, sono servite altre due cose:
- **La tavolozza del villaggio era tarata per essere guardata ATTRAVERSO il velo**: pavimento `#1c1813`,
  roccia `#050607`. Senza, era una macchia marrone quasi nera. Adesso sono i colori veri di una sala
  scavata e illuminata a fuoco — pietra calda, non fuliggine — e la roccia resta comunque molto piu' scura
  del pavimento, se no il muro non si legge piu' come muro.
- **Fuori dai bordi della mappa** si vedeva il fondo viola della pagina, che prima il buio copriva. Adesso,
  sulla mappa illuminata, si riempie di roccia: fuori dal paese c'e' la montagna, non il vuoto.

Il tasto **L** (cono torcia) non rimette al buio il villaggio.

#### ⚡ Resta il ritaglio delle fiamme
L'unica cosa della v2.0.1 che rimane, perche' e' un guadagno a prescindere: **le fiamme si disegnano solo se
inquadrate**. Prima ogni torcia della mappa veniva disegnata a ogni fotogramma, fuori schermo compresa, e
ognuna semina scintille. Vale per tutte le mappe.

#### 🧪 Test
**2102 test, 0 falliti.** **Verificato anche cio' che non ho toccato**: l'ondata 7 in partita vera e' buia
come sempre, col cono di luce attorno al giocatore e le torce che accendono le nicchie.

### [2.0.1] — 2026-09-10 · "Il villaggio si accende"

#### 🔦 Molte piu' torce
Il villaggio nasceva con **tre** sorgenti di luce: il falo' della piazza, i sette focolari delle case e gli
aloni dei mercanti. Bastavano quando la sosta era 34x26; su **56x40** le strade restavano al buio e il paese
sembrava disabitato appena uscivi da una porta.

Adesso ci sono **57 torce, 6 bracieri e 14 lanterne** — da 3 sorgenti a 84.

| Dove | Come |
|---|---|
| **Ogni parete rivolta a sud** | una torcia ogni quattro tessere. E' la parete che si vede dall'alto, quindi e' li' che la fiamma si legge |
| **Le altre tre pareti** | una ogni otto: danno un contorno alle stanze grandi, dove la parete sud da sola lascia il fondo nero |
| **Gli angoli della piazza** | quattro bracieri. La piazza e' 13x11 e le torce a muro non ci arrivano in mezzo — e il centro e' del portale |
| **Sopra ogni porta** | una lanterna appesa: da fuori dice dov'e' l'ingresso, da dentro illumina la soglia. Sta sul soffitto, non ingombra il passaggio |
| **Dentro le case** | nessuna. Hanno gia' il focolare acceso in mezzo e la lanterna sulla porta |

Le torce si mettono **in modo regolare**, non a caso come nelle caverne: li' il 6% per tessera fa il
pulviscolo di un posto abbandonato, qui e' un paese che qualcuno illumina apposta.

**Al primo tentativo erano il doppio** — una ogni tre sulle pareti sud, una ogni cinque sulle altre, e anche
dentro le case: 115 torce. Facevano **sciame**. Cento fiammelle sparse non sono illuminazione, sono
confusione: la luce deve dire dove sono i muri, non coprirli. Dimezzate, e tolte da dentro le case.

#### ⚡ E le fiamme adesso si ritagliano sul riquadro
Un difetto che c'era da sempre e che solo il villaggio illuminato ha reso visibile: **ogni torcia della
mappa veniva disegnata a ogni fotogramma**, anche quelle fuori dallo schermo — e ogni fiamma semina
scintille. Con le 11 torce di una caverna non si notava; con 57 sarebbero state 57 fiamme e ~14 particelle
nuove per fotogramma buttate via. Adesso si disegnano solo quelle inquadrate, falo' e focolari compresi.
La *luce* (`_drawLighting`) si ritagliava gia' cosi': era il disegno a non farlo.

Vale per tutte le mappe, non solo per il villaggio.

### [2.0.0] — 2026-09-08 · "Il villaggio sotterraneo"

La sosta fra un'ondata e l'altra non e' piu' una **Sala dei Mercanti** — cinque stanze attorno a una piazza,
34x26 tessere — ma un **VILLAGGIO DI NANI scavato nella roccia**: 56x40, il doppio abbondante. La differenza
non e' la dimensione: e' che qui **ci vive qualcuno**.

#### 🏘️ La pianta
Al centro **la piazza**, e nel suo centro esatto **il portale**. Attorno, cinque **botteghe in edifici
separati** — osteria, fucina ed erboristeria grandi (12x9), l'antro della cartomante e la gilda del capitano
piu' piccole — e **sette case abitate**, con la porta aperta.

Le strade non sono corridoi da una porta all'altra: sono **vie che attraversano il paese da parte a parte** —
la via alta sotto le botteghe del nord, la via bassa davanti alle case, e la **via maestra** che taglia tutto
da nord a sud passando per la piazza. Le botteghe e le case si aprono su quelle. E' la differenza fra un
paese e un corridoio con delle stanze.

Tre regole tengono in piedi la pianta: **il portale sta al centro** (e' la prima cosa che vedi arrivando),
**ogni porta e' larga due tessere** (il personaggio e' largo 35 px su tessere da 48 — lezione della v1.75.1),
e **fuori dal villaggio c'e' roccia, e poi il nero**: non c'e' un bordo mappa, c'e' la montagna.

Misurato: **1213 tessere calpestabili**, connesse al 100%, e — la misura che conta davvero, perche' i mobili
hanno un corpo dalla v1.75.2 — **il 99,9% raggiungibile coi mobili al loro posto**. Ogni bottega, ogni casa,
ogni mercante e il portale si raggiungono a piedi.

#### 🔥 Le case
Sette, e tutte arredate dalla **stessa funzione**. Non e' pigrizia: una casa di nani ha sempre le stesse
quattro cose — il **focolare in mezzo** (e' la ragione per cui la stanza esiste), il **letto** contro la
parete lontana dalla porta, il **tavolo** dall'altra parte, la **madia** contro un muro — e a cambiare e'
solo il verso. Piazzarle a mano sette volte avrebbe prodotto sette errori diversi; cosi' l'errore, se c'e',
e' uno solo.

Ma sette case uguali sarebbero sette volte la stessa casa, quindi **a decidere e' l'indice della casa**: il
verso si specchia, una su tre ha **due letti** (e' una famiglia), una su quattro ha la rastrelliera degli
attrezzi, un'altra lo scaffale, una su cinque un tappeto davanti al fuoco. Sono venuti fuori **cinque
arredamenti diversi su sette**, e la pianta resta identica a ogni partita.

Il **focolare e' una sorgente di luce viva** come il falo': la pietra e le braci si cuociono nella mappa, la
fiamma no. E' quella luce che esce dalla porta aperta a dire, da fuori, che la casa e' abitata.

**Tre mobili nuovi** disegnati nello stile di tutti gli altri — ombra a terra, base scura, sfumatura,
contorno nero sottile: il **pozzo** della piazza (anello di conci, il buco nero, la trave e il secchio), il
**focolare** e il **letto**.

#### 🧍 Gli abitanti
Ventidue, e **fanno qualcosa**: chi si scalda al fuoco e dondola, chi **martella**, chi **rimesta** la
pentola, chi si guarda attorno, chi va e viene per la strada. Il movimento e' **piccolo apposta** — deve
leggersi con la coda dell'occhio mentre compri, non rubare la scena — e il loro **corpo resta fermo** dove
sta, se no ci si passerebbe attraverso mentre ondeggiano. Restano tutti **in piedi**: dall'alto una figura
seduta non si legge (regola della v1.75).

#### 🌀 Il portale al centro, e via il timer
L'uscita non e' piu' un quadrato verde in fondo alla piazza: e' **LA FAGLIA**, la stessa che si apre quando
hai ripulito un'ondata, piantata nel mezzo. Stesso disegno, stesso gesto, stesso raggio — e la si vede da
qualunque strada. Attraversarla riporta al **menu di fine ondata**, come faceva l'EXIT.

Nella griglia **non c'e' piu' nessuna tessera EXIT**: la pianta dichiara solo il posto, il portale lo apre il
server entrando in sosta e lo chiude uscendo.

E **il timer non c'e' piu'**. Fino alla v1.99 in multiplayer la sosta si chiudeva da sola dopo 120 secondi.
Adesso il villaggio e' un posto in cui si sta, non una schermata da sbrigare: si riparte **solo quando
qualcuno entra nel portale**. In cambio, se uno resta fermo la partita aspetta — e' il prezzo, ed e' voluto.

#### 🧪 Test
Nuovo **test 67**, che pretende: la pianta 56x40 con cinque botteghe e sette case che non si sovrappongono;
il portale nel centro esatto della piazza, su pavimento, senza tessere EXIT, e una partenza abbastanza
lontana da non uscire appena arrivati ma abbastanza vicina da vederlo; in **ogni casa** un focolare (uno
solo, in mezzo), un letto, un tavolo e almeno un abitante; almeno quattro arredamenti diversi; nessuno e
niente dentro la roccia; e — la prova vera — che **ogni mercante, ogni stanza e il portale si raggiungano a
piedi coi corpi solidi al loro posto**, camminando su una griglia da mezza tessera. Poi la partita vera:
si entra in sosta, dopo **due minuti e mezzo si e' ancora li'** (nessun timer), e attraversando la faglia si
torna al menu. Suite: **2098 test, 0 falliti**.

**Verificato anche cio' che non ho toccato**: l'ondata 7 in partita vera e' la caverna di sempre, con le sue
pozze, le sue torce e il mercante.

### [1.99.2] — 2026-09-07 · "Il centro della caldera si arreda"

#### 🔥 Via le pozze, dentro sassi, bracieri e ossa
In mezzo alla conca c'erano le **crepe della faglia**: pozze di pericolo a raggiera dal centro. Tecnicamente
funzionavano, ma **l'effetto era brutto** — una macchia arancione larga mezza arena. Tolte, e con loro anche
le pozze normali: nella caldera adesso ce ne sono **zero** (`pools = _cal ? 0 : ...`). Le altre ondate non
cambiano di una virgola — misurato: ondata 5 → 11 pozze, 7 → 11, 15 → 18; ondate 10 e 20 → **0**.

Al loro posto uno **strato di ornamenti**, sparso in campo aperto:

| Ornamento | Cosa ci fa |
|---|---|
| **Sassi** (`rock`, `rockSmall`, `stalagmite`) | il pulviscolo della conca. Scala 0,5-0,85: devono leggersi come terreno, non come coperture — se sembrano ripari, il giocatore ci si nasconde dietro e scopre che non riparano |
| **Bracieri** (3-4, oltre a quelli soliti) | una luce in mezzo al niente, con due sassi ai piedi: un fuoco a cui girare intorno mentre il boss carica |
| **Ossa** (`corpse`, `skullpile`, `bones`, `skull`) | chi e' venuto qui prima di te |
| **Macerie** (`rubble`) | il resto del crollo |

**Non costano una tessera di spazio.** Sono `props`: li disegna il renderer, la griglia binaria non li
conosce e collisioni, linea di vista e campo di flusso nemmeno. L'arena resta **sgombra** come l'ha voluta
la v1.99.1 — 1398-1419 tessere calpestabili, zero ostacoli isolati — e il boss continua a girarci senza
incastrarsi. Sgombra non vuol dire vuota.

Sono anche cercati **al contrario di tutte le altre decorazioni**: quelle stanno in nicchia, contro un muro,
perche' li' arredano; questi devono stare **lontani dai muri**, perche' il vuoto da riempire e' il centro.
E restano fuori dalle 7 tessere attorno alla partenza, come ogni altra cosa che nasce sulla mappa.

#### 🧪 Test
Il test 66 adesso pretende **zero pozze** nella caldera (prima ne pretendeva almeno 12) e, su cinque semi,
che il centro sia arredato davvero: almeno 10 sassi, 4 bracieri, 8 pezzi di ossa, e **almeno 25 ornamenti
lontani da ogni muro**. Suite: **oltre 1930 test, 0 falliti**.

**Verificato anche cio' che non ho toccato**: le pozze delle ondate normali sono al loro posto (contate
sopra), e la partita vera dell'ondata 10 parte nella caldera senza errori.

### [1.99.1] — 2026-09-07 · "L'arena sgombra e il Colosso che ti viene addosso"

#### 🌋 La caldera si apre
Nella v1.99 la conca aveva una **cresta** di roccia a meta' pendio e **dieci-quattordici speroni** sparsi
in mezzo. Erano pensati come coperture per il giocatore, ma per un boss di raggio 38-52 erano trappole: nei
varchi fra uno sperone e l'altro ci si **incastra**. Tolti tutti e due. Restano **6-10 massi appoggiati al
bordo** (`d = raggio * 0.92 - 0.02..0.07`): danno profondita' alla parete, non stanno mai sulla strada.

Misurato su cinque semi, prima e dopo:

| | v1.99.0 | v1.99.1 |
|---|---|---|
| Tessere calpestabili | 1208-1254 | **1404-1427** |
| Rocce isolate dentro l'arena | 10-14 | **0** |
| Caselle larghe 3x3 | ~730 | **1202-1224** |
| Loro connettivita' | 98,5-100% | **100,0%** |

Le crepe della faglia restano: sono `T_HAZARD`, non muri — si attraversano, fanno male, non incastrano
niente.

#### 🧍 Il Colosso non e' piu' un bersaglio fermo
Era lento e la sua unica botta si schivava **stando indietro e girandogli attorno**: bastava non entrare
mai nei 104 px. Tre modifiche, tutte sul *come ti raggiunge*, nessuna sui PV:

- **Cammina piu' svelto**: `speed 74 → 92`. Non ti prende comunque di corsa, ma non lo semini piu' a passo.
- **Il pugno anticipa il tuo movimento** (`slamPredizione: 0.55`): il punto d'impatto non e' piu' dove sei
  quando parte il colpo, ma dove *starai andando* nei 0,72 s di caricamento. Strafare in linea retta adesso
  ti porta **dentro** il colpo; per schivarlo devi cambiare direzione dopo il telegrafo, che e' la
  decisione che il boss non chiedeva mai.
- **Da lontano ti CARICA addosso** (nuovo attacco): oltre i 200 px, in vista libera, ogni ~6 s si pianta
  0,45 s (telegrafo `colosso_wind`) e poi parte a **3x la sua velocita'** per 0,9 s, con una botta al 120%.
  Se sbatte contro un muro si ferma e resta scoperto 0,7 s. In fase 2 e 3 il tempo di ricarica scende a
  0,82x e 0,65x.
- Le onde d'urto arrivano piu' spesso: `ondaCd 7,0 → 5,6 s`.

Misurato con una simulazione che gira attorno al boss sparando (il modo in cui lo si giocava davvero):

| Distanza tenuta | v1.99.0 | v1.99.1 |
|---|---|---|
| 300 px | cade in 43 s, incassi **175 PV** | cade in 31 s, incassi **255 PV** |
| 450 px | — | incassi **253 PV** (erano 197) |

Su ~325 PV di un Campione: **+46% di danno subito** a parita' di gioco, e lo scontro dura *meno* perche'
stare lontani non e' piu' gratis.

#### 🧪 Test
Il test 66 (la caldera) ora verifica anche che **dentro l'arena non ci sia nessuna roccia isolata** su
cinque semi, e che la carica del Colosso **esista e parta davvero** a piu' del doppio della sua velocita' a
piedi. Suite: **1920 test, 0 falliti**.

**Verificato anche cio' che non ho toccato** (la regola nata con la v1.97.1): ondata 7 in partita vera, la
caverna e' quella di sempre, nessun errore in console.

### [1.99.0] — 2026-09-07 · "La caldera dei boss, il menu torna nero, la prova torna nel menu"

#### 🌋 La caldera — ondate 10 e 20
Le due ondate dei boss non si giocano piu' in una caverna come tutte le altre. La **caldera** non e'
costruita da nessuno: e' successa. Una conca larga col bordo irregolare, una **cresta** di roccia spezzata
a meta' pendio che taglia la vista, **speroni** sparsi come coperture, e in mezzo la **faglia aperta**.

Non e' costata **una riga di renderer**: gli speroni e la cresta sono roccia come quella della caverna (la
cottura li disegna gia'), e le crepe sono `T_HAZARD` — le pozze di pericolo che il motore ha dalla v1.62,
col loro danno, il loro disegno e la loro luce. Il pavimento fa male a chi ci cammina: al giocatore **e ai
mostri, boss compreso**.

Le ondate sono un **elenco** (`CALDERA_ONDATE: [10, 20]`), non un confronto: aggiungerne una costa una
virgola, svuotarlo spegne la caldera. La zona si chiama *La Caldera* alla 10 e *La Faglia Aperta* alla 20.

Misurato su cinque semi: **1208-1254 tessere calpestabili**, connettivita' **100%**, e — la cosa che conta
per un'ondata di boss — **oltre 730 caselle larghe 3x3**, connesse al 98,5-100%: e' su quelle che si muove
un boss di raggio 52. In partita vera il Colosso si e' spostato di 1328 px in 40 s, AZ'GAROTH di 577: si
gira, non ci si incastra.

**Le crepe rispettano le due regole delle pozze** (v1.62), e non e' stato gratis: al primo tentativo le
scavavo dentro il generatore della pianta, e due test storici sono saltati subito — *nessuna pozza tocca un
muro* (184 violazioni) e *nessuna pozza entro 7 tessere dalla partenza*. Sono regole giuste: una pozza
attaccata a un muro chiude un passaggio invece di farti scegliere, e una che ti nasce sotto i piedi e' una
beffa. Le crepe si aprono adesso dove quelle regole valgono — dopo che la partenza e' stata scelta.

#### 🐞 E un ciclo infinito vecchio di settanta versioni
La caldera ha fatto emergere un difetto che era li' dalla **v1.22**: in `_drawCritters` (gli animaletti che
corrono per la mappa) c'era un `while (cr.length < 5)` che cercava a caso un punto non-muro **dentro
l'inquadratura**, e riprovava all'infinito. Se la telecamera guarda un'area tutta roccia quel punto non
esiste, e il gioco non rallenta: **si pianta**, dentro il primo fotogramma. Con la caverna non capitava
quasi mai — riempie il rettangolo della mappa; con la caldera, che e' un ovale con gli angoli pieni,
bastava guardare un angolo. Adesso i tentativi sono contati: niente posto, niente animaletti.

#### 🖤 Il menu torna nero
Via l'illustrazione di sfondo dal menu principale e dalla sala d'attesa (c'era dalla v1.86): restano il
gradiente scuro di sempre e il pannello. I file rimangono in `assets/art/`, rimetterla e' questione di tre righe.

#### 🧪 La modalita' di prova torna visibile
Il pannello con le venti ondate e' di nuovo nel menu (era stato nascosto in v1.96.1). Le due scorciatoie
di allora — `?test` nell'indirizzo e il tasto **T** — restano, e servirebbero se un giorno la si richiudesse.

**File toccati**: `shared/mapgen.js` (`piantaCaldera` + le crepe), `shared/constants.js` (`CALDERA_ONDATE`),
`public/js/renderer.js` (il ciclo di `_drawCritters`), `public/style.css`, `public/index.html`,
`public/js/main.js`, `test/simulate.js` (test 66 nuovo), `test/client.js`, `package.json`.

---

### [1.98.0] — 2026-09-07 · "Cimitero piu' stretto, piu' fitto, e solo alla prima ondata"

Paolo: *"il cimitero mi sembra un filo troppo grande e spoglio, l'ideale sarebbe quello nell'immagine.
Inoltre lo implementerei solo nella prima ondata: dalla seconda fino alla 20 terrei le grotte."*

#### Solo la prima ondata
`CIMITERO_FINO_A` da **2** a **1**. Dalla seconda in poi si gioca nella caverna, e il test lo verifica
ondata per ondata (1 cimitero; 2, 3, 7 e 20 no).

#### Piu' stretto
La v1.97 usava tutta la mappa: **2350 tessere calpestabili**, quasi il doppio di una caverna, ed e' da li'
che veniva l'aria di piazza d'armi. Adesso una **fascia di bosco fitta e irregolare** stringe il cimitero
da tutti i lati e lo spazio scende a **~1620 tessere**, cioe' la stessa misura della caverna. Il muro di
cinta corre dentro al bosco, con tre o quattro brecce.

#### Piu' fitto — quello che dice l'immagine di riferimento
| Prima (v1.97) | Adesso (v1.98) |
|---|---|
| lapidi in file sparse su tutta la mappa | **campi fitti**: blocchi con passo 2 in tutte e due le direzioni, e terra battuta fra un campo e l'altro |
| tanti mausolei uguali, piccoli | **tre o quattro cappelle GROSSE** (8-12 x 6-9), con camera, porta e a volte un tramezzo dentro |
| muri crollati a pezzetti | **muretti bassi lunghi** (6-14 tessere) e un **recinto chiuso** con tre aperture e le sue tombe dentro |
| alberi sparsi a uno a uno | alberi a **gruppetti** |

Densita' delle lapidi: da 6,6% dell'area a **6,2% su un'area piu' piccola** — cioe' ~101 lapidi in 1620
tessere invece di 155 in 2350, ma concentrate in blocchi invece che spalmate. E' la differenza fra un prato
con dei sassi e un camposanto.

Misurato su cinque semi: **1522-1692 tessere libere, connettivita' 100%** da ogni spawn, 81-113 lapidi.

**Verificato anche cio' che non ho toccato**: la caverna della seconda ondata e' stata guardata in gioco,
non solo generata.

**File toccati**: `shared/mapgen.js` (`piantaCimitero` rifatta), `shared/constants.js`, `test/simulate.js`
(test 65 aggiornato), `package.json`, e i .md.

---

### [1.97.1] — 2026-09-06 · "La caverna cancellata: un else attaccato alla riga sbagliata"

Paolo: *"nella prima mappa c'e' il cimitero, ma la grotta, con le varianti, dall'ondata 3 sono
completamente sballate."*

Aveva ragione, ed era **colpa mia**. La riga che dipinge il cimitero era stata infilata **fra un `if` e il
suo `else`**:

```
if (_nuova) this._bakeCaverna(g, m, T, th);
if (_nuova && m.muri) this._dipingiCimitero(g, m, T, th);   <-- inserita qui
else { g.fillStyle = floorPat; g.fillRect(0, 0, cv.width, cv.height); }
```

Quell'`else` apparteneva al **primo** `if` ed esisteva per il villaggio. Attaccato alla riga nuova, si e'
messo a scattare su **ogni mappa senza cimitero** — cioe' dalla terza ondata in poi: riempiva l'intera tela
col pavimento piatto e **cancellava la caverna appena cotta**. Niente rocce, niente pareti, niente massi:
solo una distesa uniforme con le decorazioni sopra.

La correzione e' spostare la riga **dopo** l'else. Tre righe, ma il difetto era grosso.

#### Perche' non se n'era accorto nessuno
Nel cimitero `m.muri` esiste, quindi l'else non scattava e le ondate 1-2 erano giuste: **ho verificato solo
la cosa nuova**. E nessun test poteva vederlo, perche' tutti guardano la LOGICA (la griglia, la
connettivita', gli spawn) e quella era rimasta perfetta: mappe generate **identiche bit per bit** a prima
della 1.97. Il difetto stava solo nei pixel.

#### Come e' stato accertato
Confronto a parita' di mappa fra il renderer nuovo e quello di prima, cuocendo lo **stesso oggetto mappa**
nei due e misurando quante celle-muro risultano dipinte:

| | prima del fix | dopo |
|---|---|---|
| Ondata 5, seme 777777 | **1** cella muro dipinta su 1609 | **351** su 1609 (come la 1.96) |

E su quattordici mappe (ondate 1, 2, 3, 5, 8, 12, 19 per due semi): **le dieci dalla terza in poi tornano
identiche** alla versione precedente, impronta dei pixel compresa; diverse solo le quattro delle ondate 1-2,
che sono il cimitero.

#### Il controllo che impedisce il ritorno
Nel test del client: la riga **subito dopo** `if (_nuova) this._bakeCaverna(...)` deve essere il suo `else`.
Provato rompendolo apposta — il test fallisce, come deve.

**File toccati**: `public/js/renderer.js` (tre righe), `test/client.js` (il controllo), `shared/constants.js`, `package.json`.

---

### [1.97.0] — 2026-09-06 · "Il cimitero: la prima pianta che non e' una grotta"

Paolo: *"prova a creare il cimitero, che verra' usato solo per le prime 2 ondate; poi dalla terza fino
alla 20 usiamo la grotta."*

Fino a ieri **ogni** mappa di combattimento veniva dalla stessa funzione: una caverna scavata con dentro
masse di roccia. Cambiavano palette e decorazioni, ma lo spazio era sempre quello. Adesso le piante sono
**due**, e la prima cosa che il giocatore vede non e' piu' una grotta.

#### Come e' fatto
Un cimitero non e' roba sparsa: e' **settori** separati da **vialetti**, e dentro ogni settore **file
regolari**. E' l'ordine — linee rette, ripetizioni — a dire "questo non e' una caverna", perche' la
caverna e' tutta disordine organico.

| Pezzo | Cosa fa |
|---|---|
| **Muro di cinta** | c'e' un dentro e un fuori. Tre-cinque brecce lo rompono: e' un recinto, non una scatola |
| **Settori** (un BSP) | fra un blocco e l'altro resta un vialetto di 3-4 tessere. I vialetti non si disegnano: sono lo spazio che i settori non occupano |
| **File di lapidi** | una lapide, uno spazio, una lapide. **Bloccano il tiro ma non il passo** — ci giri intorno in un passo, l'opposto della roccia |
| **Mausolei** | stanze vere, con una porta: ci entri |
| **Rovine** | muri crollati e spezzati: copertura da cui ripararsi |
| **Fosse** | una o due chiazze tonde che cancellano le file, se no ha l'aria di un foglio a quadretti |

Un settore su tre e' "vecchio": le file sbandano e hanno dei buchi.

#### La griglia resta binaria, ed e' il punto
Le lapidi sono **tessere-muro normali**. Il tipo di ciascuna (lapide, pietra squadrata, cinta, albero
secco) viaggia in un array parallelo `m.muri` che legge **solo il renderer**. Percio' collisioni, linea di
vista e campo di flusso non sanno niente del cimitero, e **non e' stata toccata una riga di IA**.

#### Due funzioni della caverna qui fanno danno
`widenForBoss()` allarga ogni corridoio stretto e `togliStrozzature()` toglie gli imbuti. Una lapide
isolata in mezzo a un vialetto **e'** un imbuto: la prima passata se ne mangiava l'85% — misurato, da 155
lapidi a 19. Nel cimitero il passaggio e' garantito per costruzione (vialetti da 3-4 tessere, nessun
settore attaccato alla cinta), quindi li' non servono. Resta `allargaPerBoss()`, che non demolisce niente
a caso — scava solo se il grafo delle celle larghe e' spezzato — ed e' la rete di sicurezza.

#### Il disegno
Lapidi (stele, croci, lastre spezzate, un po' storte, con l'ombra sempre dallo stesso lato), alberi secchi
e **conci squadrati** per mausolei e cinta: e' quello a distinguere un muro costruito da una parete di
grotta. Si dipinge **dopo la cottura della caverna, sulla stessa tela fuori schermo**: costa una volta per
mappa, **zero a fotogramma**. E i temi scendono da cinque a quattro — un cimitero dentro un vulcano no —
con un nome di zona suo: *Il Vecchio Camposanto*, *Il Cimitero Sommerso*, *Il Campo di Gelo*, *Il Sepolcreto Arcano*.

#### Una conseguenza che non avevo previsto
Il cimitero e' molto piu' **aperto** della caverna: **2350 tessere libere contro 1370**. Con meno pareti la
linea di vista e' lunga, quindi i nemici ti **vedono** da molto piu' lontano — e chi ti vede viene addosso
comunque, per la regola della v1.92. Alle ondate 1-2, con pochi nemici, e' un buon inizio di partita; ma e'
il motivo per cui il **test 56** (il vagabondaggio) adesso si genera la caverna a mano: li' si misura l'IA,
e su una mappa aperta si misurerebbe la mappa.

#### Il test 65
Verifica che le ondate 1-2 siano cimitero e la 3, la 7 e la 20 no; che da ogni seme **tutto il pavimento
sia raggiungibile dallo spawn**; che le lapidi ci siano davvero (>= 40 per mappa), la cinta giri tutta
attorno e il tema non sia mai la lava. Poi **gioca**: trenta secondi di ondata vera, e nessun nemico deve
restare incastrato fra le lapidi (non piu' di un terzo fermo) ne' finire dentro una tessera piena.

**File toccati**: `shared/mapgen.js` (`piantaCimitero`, l'aggancio, i temi), `shared/constants.js`
(`CIMITERO_FINO_A`), `public/js/renderer.js` (`_dipingiCimitero` e la cottura), `test/simulate.js`
(test 65 nuovo, test 56 adattato), `package.json`.

---

### [1.96.1] — 2026-09-06 · "La modalita' di prova si nasconde, non si toglie"

Paolo: *"nascondi il link all'ambiente di test. Non rimuoverlo, potrebbe servirmi."*

Il pannello **"Modalita' di prova"** non compare piu' nel menu: chi apre il gioco vede *Entra in partita*
e le due voci di sempre. Il codice pero' e' tutto al suo posto — pulsanti, `_preparaProva()`, il messaggio
`start` con l'ondata — e per farlo ricomparire non serve toccare niente:

| Come | Dove |
|---|---|
| **`?test` nell'indirizzo** | `http://localhost:8080/?test` (vale anche `#test`) |
| **il tasto `T`** | stando fermi nel menu |

La T non scatta mentre si scrive nel campo del nome o della stanza, e in partita non fa niente: il
controllo guarda che il menu sia ancora aperto e che il fuoco non sia su un campo di testo.

**Cinque controlli nuovi nel test del client**: che il pannello nasca `hidden`, che ci sia ancora tutto
(`#provaGrid`), e che restino tutte e due le vie per aprirlo piu' la salvaguardia sul campo di testo.
Nascosto non vuol dire tolto, e il test e' li' per dirlo.

**File toccati**: `public/index.html`, `public/js/main.js`, `test/client.js`, `shared/constants.js`, `package.json`.

---

### [1.96.0] — 2026-09-06 · "Dall'ondata 9 se ne vedono 22 alla volta"

Paolo: *"dall'ondata 9 fino alla 20 i nemici contemporaneamente visibili in pista scendono a 22, altrimenti
si riempie troppo. I restanti stanno in coda e subentrano in base al totale definito per le varie ondate."*

Il tetto dei vivi era **uno solo e alto** dalla v1.79.2: quaranta, uguale a ogni ondata. Era la risposta
giusta a un problema di allora (una curva teneva nascosta meta' dell'ondata proprio dove serviva vedere che
i nemici erano aumentati), ma con le ondate di adesso alla 19 sono **quaranta mostri in campo insieme**: non
e' un combattimento, e' una calca, e la mappa sotto non si vede piu'.

Adesso il tetto e' **due numeri**: `MAX_ALIVE` = 40 fino all'ottava, `MAX_ALIVE_TARDI` = **22 dalla nona**
(`MAX_ALIVE_TARDI_DA`). Il meccanismo della coda non e' nuovo — e' lo stesso rifornimento di sempre.

#### Quanti se ne vedono, prima e dopo (giocatore fermo, in singolo)
| Ondata | prima | **dopo** | in coda a 90 s |
|---|---|---|---|
| 9 | 28 | **22** | 4 |
| 12 | 35 | **22** | 7 |
| 15 | 38 | **22** | 12 |
| 18 | 39 | **22** | 19 |
| 19 | 40 | **22** | 18 |

#### Il totale non cambia di un nemico
E' la parte che conta: cambia **quanti ne hai addosso**, non quanti ne devi uccidere. Chi non ci sta
aspetta in coda ed entra quando ne muore uno — e la coda si svuota alla stessa velocita' di prima.
Misurato con un giocatore che uccide a ritmo costante (uno ogni 0,7 s):

| Ondata | prima | dopo |
|---|---|---|
| 12 | 22 s | 23 s |
| 15 | 21 s | 23 s |
| 18 | 24 s | 22 s |
| 19 | 24 s | 23 s |

**Il test 40, riscritto**: chiedeva *"ondata 19: il tetto e 40"*, adesso verifica i due scaglioni (40 fino
all'8, 22 dalla 9 alla 30), che fino all'ottava in singolo ci stiano ancora tutti in campo, e che dalla nona
il **totale resti sopra il tetto** — altrimenti la coda non servirebbe a niente. Il test 30 (rifornimento e
coda) ora legge `room.tettoVivi()` invece della costante, perche' gira sull'ondata 17.

**In gruppo** il tetto e' lo stesso: a sei giocatori le ondate sono molto piu' grosse e la coda lavora di
piu'. Se in cooperativa 22 dovessero risultare pochi, il numero e' una riga in `constants.js`.

**File toccati**: `shared/constants.js`, `server/Room.js` (`tettoVivi`), `test/simulate.js`, `package.json`.

---

### [1.93.5] — 2026-09-06 · "Lo slot della E c'era, ma stava sotto"

Paolo: *"nella barra di menu vedi il tasto Q ma non quello della E, va aggiunto."*

Da aggiungere non c'era niente: **lo slot della E era gia' li'**, con l'icona e il nome giusti — solo che
il riquadro dell'eroe ci stava sopra. E lo stesso valeva a sinistra per il **DX (Scatto)**, coperto dalla
cintura delle pozioni. Due slot su quattro invisibili, per un problema di posizioni.

I margini erano tarati su quando la barra aveva **due** slot. Con quattro e' larga 446 px, cioe' **223 px
per lato dal centro**, mentre gli altri due pannelli stavano molto piu' dentro:

| | prima | dopo |
|---|---|---|
| 🧪 cintura delle pozioni (`#beltBar`) | fino a **120 px** dal centro | **240 px** |
| 🧍 riquadro dell'eroe (`#heroBox`) | da **116 px** dal centro | **240 px** |
| ❤️ ampolla dei PV (`#vitals`) | da 258 px | **390 px** (dopo il riquadro) |

**Sotto i 1440 px** quella fila non ci sta piu' — cintura, quattro abilita', riquadro ed ampolla fanno
circa 1200 px — e la cintura finiva sopra la minimappa: li' sale di una riga, centrata sopra le abilita'.
Verificato a 1600x900 e a 1366x768.

**Tre controlli nuovi nel test del client** perche' non si ripeta: i margini della cintura e del riquadro
devono essere **>= 223 px**, e l'ampolla deve stare dopo il riquadro. Chi li stringe se ne accorge subito.

**File toccati**: `public/style.css`, `test/client.js`, `shared/constants.js`, `package.json`.

---

### [1.93.4] — 2026-09-06 · "L'immagine intera su qualsiasi schermo"

Paolo: *"l'immagine viene ritagliata, non si riesce a farla entrare esattamente intera a prescindere dalla
risoluzione dello schermo?"* Si': `contain` invece di `cover`.

`cover` riempie sempre la finestra ma **taglia** cio' che non ci sta: su un 16:9 esatto non si vede niente,
su un 16:10 o un ultrawide sparisce una fascia dell'illustrazione. `contain` fa il contrario — l'immagine
entra **sempre intera**, qualunque sia il rapporto dello schermo — al prezzo di lasciare scoperto lo spazio
che avanza.

Quello spazio non e' una barra nera: e' **la stessa immagine**, in `cover`, sfocata di 26 px e scurita al
42%, su uno strato sotto. Due strati, un file solo, nessun asset in piu'.

| Schermo | Cosa si vede |
|---|---|
| 1920x1080 (16:9) | l'illustrazione riempie tutto, niente cornice |
| 1680x1050 (16:10) | intera, due fasce sottili sfocate sopra e sotto |
| 1366x768 | intera, cornice minima |
| 2560x1080 (21:9) | intera al centro, cornice sfocata ai due lati |

Verificato su tutti e quattro. Il velo che stacca il pannello dall'illustrazione e' diventato l'ombra
interna dello strato dell'immagine (`box-shadow:inset 0 0 0 100vmax`), cosi' vale su tutta la finestra.

**File toccati**: `public/style.css`, `shared/constants.js`, `package.json`.

---

### [1.93.3] — 2026-09-06 · "Il menu torna al centro"

Il pannello del menu stava in alto dalla v1.86.2 (`justify-content:flex-start` piu' 4vh di margine):
serviva quando la velatura spegneva la fascia bassa dell'illustrazione e il pannello centrato lasciava un
vuoto sotto. Con l'immagine intera della 1.93.2 quel motivo non esiste piu', e centrato ci sta meglio —
il titolo dipinto resta sopra, gli eroi a destra, il portale a sinistra.

**File toccati**: `public/style.css`, `shared/constants.js`, `package.json`.

---

### [1.93.2] — 2026-09-06 · "L'immagine e basta"

Paolo, sulla 1.93.1: *"l'effetto fa cagare... bastava prendere l'immagine in fullHD e metterla come sfondo
senza zoomare o tagliare."*

Aveva ragione, e il difetto era tutto mio. L'illustrazione era gia' fatta su misura, **1920x1080**, e lo
strato che la mostrava faceva tre cose che nessuno aveva chiesto — tre modi diversi di zoomarla e tagliarla:

| Cosa faceva | Ora |
|---|---|
| `inset:-2.5%` — partiva fuori dai bordi | `inset:0` |
| `center 44%` — ancorata sopra il centro | `center center` |
| `artDrift` — deriva di 48 s con scala fino a **1,055** | tolta |
| velatura a **tre** sfumature (fascia centrale scura, cielo spento, vignettatura) | **un velo uniforme al 22%** |

La velatura in particolare risolveva un problema che il pannello risolve gia' da solo: ha il fondo
semitrasparente e la sfocatura, non gli serve che si spenga meta' illustrazione dietro.

Il titolo dipinto in alto e il nastro in basso adesso si vedono — e va bene cosi': e' l'immagine, intera,
alla sua risoluzione, senza una riga di CSS che le giri intorno.

**File toccati**: `public/style.css`, `shared/constants.js`, `package.json`.

---

### [1.93.1] — 2026-09-06 · "La key art nuova sul menu e sulla sala d'attesa"

L'illustrazione di Paolo portata a **1920x1080** (`public/assets/art/menu_key_art_1080.jpg`) e messa come
sfondo del **menu principale** e della **sala d'attesa**. L'originale arrivava a 1376x768: tolti 11 px di
larghezza per farla 16:9 esatti (6 a sinistra, 5 a destra, niente tocca titolo o personaggi), ingrandimento
Lanczos 1,4x e una passata leggera di nitidezza. Un fattore cosi' basso non sgrana. Il file precedente
(`menu_key_art.jpg`) resta nella cartella.

#### Il problema che ha creato, e come e' stato risolto
La nuova key art ha un **titolo dipinto** in alto (fino al 24% dell'altezza) e il nastro *Tales of Valor &
Magic* in basso (dal 90%): con l'inquadratura di prima spuntavano tutti e due da dietro il pannello, e
"DUNGEON RIFT" si leggeva **due volte**, una dipinta e una scritta.

Il primo tentativo — stringere l'inquadratura (`auto 160%`, ancoraggio al 70%) — li toglieva ma tagliava
via meta' scena: restava il guerriero gigante e basta. Visto in uno screenshot, non calcolato.

La strada giusta era la **velatura**, che il menu ha gia' dalla v1.86: l'immagine resta intera e a
risoluzione piena, e la sfumatura verticale sale a **0,99 di opacita' sopra il 19%** e sotto l'87%. Titolo
dipinto e nastro spariscono nel buio, la scena — portale, drago verde, i tre eroi, le rovine — si vede
tutta. Nessuno zoom, nessuna perdita di nitidezza.

**File toccati**: `public/style.css` (inquadratura e velatura), il nuovo asset, `shared/constants.js`, `package.json`.

---

### [1.93.0] — 2026-09-06 · "Nessuna abilita', arma o armatura cura piu'"

Paolo: *"Ci sono ancora abilita' e/o armi o armature che curano il personaggio: il guerriero divino si
cura moltissimo per ogni colpo inflitto ai nemici. NON devono esistere abilita' e/o armi o armature che
curano il personaggio!"*

Il colpevole era il **Vampirismo** (carta rara del guerriero, +9% del danno inflitto), moltiplicato dalla
sinergia **Sete di Sangue** (+6%) e dal **Patto Sanguinario** del Mercante Nero (+10%): con tutti e tre,
il 25% di ogni colpo tornava in vita — e con l'equipaggiamento divino i colpi sono grossi.

#### Cosa e' sparito

| | Cosa faceva |
|---|---|
| 🩸 **Vampirismo** (carta rara, guerriero) | +9% del danno inflitto ti curava |
| 🩸 **Sete di Sangue** (sinergia Vampirismo + Adrenalina) | +6% di cura, sopra al Vampirismo |
| 🩸 **Patto Sanguinario** (Mercante Nero, 70 monete) | +10% di vampirismo |
| ✨ **Aura del Paladino** (rango V del guerriero) | curava i compagni nel cerchio, 2% dei PV al secondo |
| ➕ **Vigore** (buff, 8 PV/s) | non lo assegnava piu' nessuno, ma era li' pronto |
| `stats.lifesteal` e `stats.regen` | **i due campi del motore** |

I due campi sono la parte che conta. Non li ho azzerati: li ho **tolti**. Finche' `lifesteal` esiste fra
le statistiche di un giocatore, prima o poi qualcosa lo riempie — ed e' esattamente cosi' che la cura era
sopravvissuta a tutte le pulizie precedenti (l'ultima in v1.79.2, che aveva gia' tolto la rigenerazione a
Scudo Vitale). Adesso non c'e' proprio il posto dove rimetterla.

#### Cosa e' arrivato al suo posto, e perche'
Il catalogo delle carte e' una griglia rigida: **2 carte per classe e per rarita'**. Togliere Vampirismo
lasciava il guerriero con una sola rara, quindi il posto andava riempito:

- 🛡 **Presa Salda** (rara, guerriero) — *+60% rinculo dei tuoi colpi e -6% ai danni subiti*
- 🛡 **Muro d'Acciaio** (sinergia Presa Salda + Adrenalina Pura) — *-6% in piu' ai danni subiti*

Premiano lo stesso mestiere del Vampirismo — stare in mezzo alla mischia — senza restituire un PV. Se non
convincono, si cambiano: sono due righe.

#### Il test 64, che impedisce il ritorno
La regola non va ricordata, va **imposta**. Il test non guarda i nomi: prende **tutte** le carte, tutti i
ranghi, tutti i patti e tutti i pezzi di equipaggiamento — **51 casi** — e li prova uno per uno
*giocando*: personaggio a meta' vita, cinque secondi con il colpo premuto su un bersaglio eterno. Se i PV
salgono di uno, il test fallisce e **dice quale**. Vale anche per la carta che verra' aggiunta domani.
Piu' due controlli di struttura (`stats.lifesteal` e `stats.regen` non devono esistere) e uno di verso
opposto: la **pozione di Cura deve continuare a curare**.

#### Chi cura ancora
Ostessa (monete), pozioni di Cura e Rigenerazione (cariche comprate), Bende del Viandante (45 monete),
Pozione di Salute a terra (va raccolta), ricompensa della **combo di 40** (+25% PV, dopo quaranta
uccisioni di fila) e **Ultima Occasione**, che non cura ma ti rimette in piedi a meta' vita invece di
farti cadere. **Nessuna** di queste e' un'abilita', un'arma o un'armatura.

**File toccati**: `shared/loot.js`, `shared/levels.js`, `server/Room.js`, `test/simulate.js` (test 64 nuovo,
tre vecchie asserzioni riscritte), `shared/constants.js`, `package.json`, e i .md.

---

### [1.92.0] — 2026-09-06 · "I nemici tornano a cercarti con gli occhi"

Paolo: *"i nemici devono tornare al comportamento precedente, quello in cui girano per la mappa
casualmente fino a quando non entri nel campo visivo. Ai livelli piu' alti avere tutti i nemici che
conoscono la tua posizione e vengono ad attaccarti in massa e' troppo difficile."*

Aveva ragione, e il difetto non era solo di difficolta': era di **idea**. Dalla v1.80 chi non ti vedeva
ti **cercava** lo stesso, seguendo il campo di flusso verso tutti i giocatori vivi. Funzionava fin troppo
bene — l'ondata intera sapeva sempre dove sei — e toglieva al gioco la cosa che rende viva una mappa:
un nemico deve **accorgersi** di te.

#### Che cosa cambia, in una riga
`AI.caccia()` non segue piu' il flusso: **vaga**. Chi non ti vede sceglie un punto raggiungibile a caso e
ci cammina, finche' non entri nel suo campo visivo (`sightRange` + linea di vista libera) — com'era fino
alla v1.79. Il nome della funzione resta, perche' e' il punto in cui passano tutti i comportamenti:
cambia cosa fa, non chi la chiama.

#### Che cosa NON cambia
Il **tetto alla folla** della v1.80 resta intero: solo i `FOLLA_MAX` = 6 piu' vicini hanno il permesso di
farsi sotto, e chi e' oltre l'`ANELLO_ATTESA` = 900 px rientra (adesso con un `seek` diretto, non piu'
passando dalla caccia). Serve a una cosa sola: che l'ondata resti **a portata di esplorazione** invece di
dissolversi in un angolo della mappa. Restano anche la memoria dell'ultima posizione vista (`def.memory`,
~3,5 s), l'investigazione, il Fungo Sporifero immobile e la regola "non compaiono, arrivano" della v1.76.1.

#### La misura — giocatore FERMO, in singolo, nemici entro 620 px
| | v1.91 (ti cercano) | **v1.92 (vagano)** |
|---|---|---|
| Ondata 1, dopo 45 s | 12 su 12 | **0 su 12** |
| Ondata 6, dopo 60 s | 6 su 20 | **7 su 20** |
| Ondata 12, dopo 60 s | 18 su 33 | **14 su 33** |

E con un giocatore che **esplora** (tre semi, media), l'ondata si incontra lo stesso — cambia il momento:

| | v1.91 | **v1.92** |
|---|---|---|
| Ondata 12, addosso a 15 s | 11,0 | **5,7** |
| Ondata 12, incontrati a 90 s | 24 su 29 | **22,7 su 32** |
| Ondata 16, addosso a 15 s | 8,3 | **6,7** |

La differenza vera e' **all'inizio dell'ondata**: alla 12 il branco che ti trova nei primi quindici
secondi si dimezza. Su tutta la durata i nemici li incontri comunque — ma perche' sei andato a cercarli.

#### Il test 56, riscritto
Chiedeva l'opposto: *"in 40 s ti raggiunge partendo da 976 px al buio"*. Adesso verifica che chi non ti ha
mai visto **non arrivi**, e lo fa senza misurare la distanza minima — vagando a caso, una volta ogni tanto
ti capita addosso davvero, ed e' giusto cosi'. Misura il **modo**: o ti vede, o vaga; il terzo stato della
v1.80 non esiste piu'. Piu' due controlli che restano: non si accalcano (mai piu' di 6) e non si
dissolvono (media entro 1,6 anelli).

**File toccati**: `shared/ai.js` (caccia, attesa, commento della Sfera d'Ossa), `test/simulate.js` (test 56),
`shared/constants.js`, `package.json`, e i .md.

---

### [1.91.0] — 2026-09-06 · "Modalita' di prova: si parte dall'ondata che vuoi"

Paolo: *"ho bisogno di una modalita' di test per testare tutte le ondate... devo provare prestazioni e
giocabilita' ma senza rifare i livelli decine di volte."*

Nel menu principale, sotto **ENTRA IN PARTITA**, c'e' un pannello a scomparsa **"Modalita' di prova"** con
**venti pulsanti**, uno per ondata (la 10 e la 20 marcate ☠ perche' sono i boss). Si clicca e si gioca:
stanza tutta propria, niente sala d'attesa, la run parte dall'ondata scelta.

#### Il personaggio non parte nudo
Sarebbe stato inutile: alla 16 con l'equipaggiamento della 1 non si prova niente. `_preparaProva()`
ricostruisce il personaggio che a quel punto **avresti**:

| | come si ricava |
|---|---|
| **Livello** | `1 + (onda - 1) x 0,95`, arrotondato e limitato al massimo |
| **Punti statistica** | spesi tutti, a rotazione sulle statistiche del livello |
| **Passive e abilita'** | tutte quelle dovute fino a quel livello, prese dalla prima offerta |
| **Equipaggiamento** | rango 1/2/3/4 secondo l'ondata (1-5, 6-10, 11-15, 16+) |
| **Monete** | 68 per ondata saltata |

Verificato in un browser vero (server reale + client headless): cliccando la **12** si arriva a
*Ondata 12/20, Lv.11 Campione, 375 PV, 748 monete, Q sbloccata, E chiusa fino al 14*, senza errori.

**File toccati**: `shared/constants.js` (`PROVA_MAX_ONDATA`), `server/Room.js` (`startGame(da)`,
`_preparaProva`), `server/index.js`, `public/js/net.js`, `public/js/main.js`, `public/js/hud.js`
(`buildProva`), `public/index.html`, `public/style.css`.

---

### [1.90.2] — 2026-09-05 · "Dove finiva il frame rate"

Paolo ha visto cali di fluidita' **dall'ondata 11 in poi**, quando entrano i ragni. Misurato invece che
indovinato: una scena d'ondata vera (mappa, mostri, tele, luci) renderizzata in un browser headless 300
volte, col profilo della CPU acceso.

#### La misura
| | prima | dopo |
|---|---|---|
| Ondata 8 | 4,8 ms | **2,2 ms** |
| Ondata 12 | 6,4 ms | **1,8 ms** |
| Ondata 16 | 5,3 ms | **2,0 ms** |

E il colpevole si e' visto subito: **togliendo i 7 ragni da una scena di 38 mostri il frame scendeva del
57%**. Il profilo diceva che il **23% del frame intero** se ne andava in `ctx.save()`.

Contando le chiamate al contesto 2D, un frame d'ondata 16 ne faceva **11.266**, e **7.897 erano di un
ragno solo** (gli altri erano fuori inquadratura): 1315 `save`, 1313 `fill`, 1313 `ellipse`. Da dove:
`_zampaRagno` dipinge ogni zampa con **56 macchie** e le zampe si disegnano **sedici volte** (otto dietro
e otto davanti, con le luci). Il secondo era il **Beholder, 936 chiamate** ciascuno — sei peduncoli da
otto segmenti, bordo sporco, venature e denti.

#### La cura, che il progetto usava gia'
Il Troll dal v1.47 non si disegna: si **incolla**. Stessa cosa qui.

- **Ragni**: la posa dipende dal tempo (il ciclo di camminata), dall'attacco e dal fatto che si muova o no.
  Il ciclo si quantizza in **12 fasi**, l'attacco in **3**: ogni combinazione si disegna **una volta** in un
  riquadro fuori schermo e da li' in poi e' **un `drawImage`**. Da 1313 `fill` a 1.
- **Beholder**: l'occhio segue il bersaglio in continuazione e cuocerlo sarebbe sbagliato. Si cuoce il
  **corpo** (massa, peduncoli, bocca) e si disegnano **vivi** occhio, iride e alone: una quindicina di
  chiamate. Da 936 a 195.
- **Una cottura per frame.** Cuocere una posa costa ~3,6 ms: tre di fila facevano un frame da 11 ms e si
  vedeva. Quando la posa esatta non c'e' ancora si usa **la piu' vicina gia' pronta** — a dodici fasi lo
  scarto e' mezzo passo, invisibile — e quella giusta arriva al frame dopo.

Il disegno e' **identico**: verificato affiancando la versione dipinta a macchie e quella incollata, per il
ragno e per il Beholder.

#### E il server?
Non c'entrava: tick mediano **0,108 ms**, massimo 7,7 ms su un budget di 33. Il problema era tutto nel
disegno del client.

---

### [1.90.1] — 2026-09-05 · "Torna la musica di prima"

Il brano registrato, provato in gioco, non reggeva il confronto con la musica procedurale: il giro e' corto
e in sottofondo si sente ripetersi. Spento. I file restano in `assets/audio/` e tutto l'impianto della
1.90.0 pure — `A.scene()`, il caricamento, le dissolvenze: per riaccenderlo basta rimettere `TRACCIA: true`
in `audio.js`. Nel frattempo `A.scene()` continua a fare il suo mestiere, cioe' decidere in un punto solo
cosa suona dove.

---

### [1.90.0] — 2026-09-05 · "Una musica vera"

Fino a qui la musica era **tutta sintetizzata** in `audio.js`: drone, pad, campane, battito. Adesso c'e' un
**brano** — quello registrato da Paolo — nel **menu**, nella **sala d'attesa** e durante le **ondate**. Nel
villaggio e nel riepilogo di fine ondata resta il sintetizzatore: e' l'unica cosa che quelle due schermate
hanno di loro, e spegnerla per mettere ovunque lo stesso brano sarebbe stato un peggioramento.

#### Cosa e' stato fatto al file, e perche'
La registrazione arrivava a **16,1 s, −30,1 LUFS, picco −17,3 dBFS**: giusta come materiale, inutilizzabile
come sottofondo — quattordici decibel sotto il livello di una musica da gioco, e con la coda in dissolvenza,
cioe' in loop avrebbe fatto un buco a ogni giro.

| | Prima | Dopo |
|---|---|---|
| Volume | −30,1 LUFS | **−18,0 LUFS** (guadagno statico di 12,8 dB) |
| Durata | 16,1 s con la coda che sfuma | **14,235 s, loop chiuso** |
| Sopra i 4 kHz | −12,6 dB relativi | −7,0 dB (campana alta +4 dB a 5,5 kHz) |
| Formato | m4a 204 kbps | **ogg Vorbis 196 KB** + m4a per Safari |

Tre cose meritano di essere scritte, perche' sono errori in cui si ricasca:

1. **Il punto di giunzione si cerca, non si sceglie.** L'autocorrelazione dell'inviluppo dice che la frase
   dura **4,35 s**; fra tutte le lunghezze fra 11,5 s e la fine si prende quella in cui il materiale che
   precede il taglio somiglia di piu' all'inizio del brano. Poi la coda si **dissolve dentro** l'inizio con
   curve di potenza costante (sin²/cos²), che non fanno il buco di volume a meta' dissolvenza.
2. **Il master va fatto PRIMA di montare il loop.** Montandolo prima e filtrando dopo, i filtri partono con
   la memoria vuota e i primi campioni escono diversi dal regime: alla giunzione si formava uno **scalino di
   0,123** (un clic udibile a ogni giro). Invertito l'ordine: **0,013**, cioe' −38 dB sotto la musica.
3. **Niente normalizzazione dinamica.** `loudnorm` cambia il guadagno nel tempo e quindi rompe il raccordo
   che si e' appena costruito. Si misura il volume, si applica un **guadagno fisso** e si mette un limiter
   a −1 dB dopo.

#### Come e' agganciato al gioco
Un punto solo decide cosa si sente — `A.scene('menu' | 'lobby' | 'wave' | 'village' | 'shop' | 'off')` — e
le schermate dicono soltanto dove sono. Il brano si carica **una volta** e resta in memoria; il tasto **M**
spegne anche lui (prima ne avrebbe spento solo meta'); i browser non fanno partire l'audio prima di un gesto
dell'utente, e siccome il menu e' la prima cosa che si vede, `A.scene()` se ne accorge e **riprova da sola al
primo click o al primo tasto**. Se il file non c'e', il gioco torna al sintetizzatore invece di restare muto.

---

### [1.89.3] — 2026-09-05 · "Anche in sala d'attesa"

Illustrazione nuova — la stessa scena, disegnata meglio: la faglia piu' alta e piu' viva, il troll e il
beholder piu' definiti, i tre eroi con piu' contrasto. Arriva gia' a **1920×1080**, quindi va nel gioco
**senza ricomprimerla**: ricomprimere un JPEG che e' gia' della misura giusta si porta via qualita' e non
restituisce niente (520 KB, uguali).

E l'artwork adesso c'e' anche nella **sala d'attesa**, quella con *AVVIA LA RUN*: `#menu` e `#lobby`
condividono le stesse tre regole (lo strato dell'immagine, la velatura, il pannello di vetro), quindi le due
schermate sono lo stesso posto invece che due fondali diversi — e non c'e' CSS duplicato da tenere allineato.

---

### [1.89.2] — 2026-09-05 · "Il menu cambia quadro"

Illustrazione nuova nel menu: i tre eroi in primo piano — guerriero e mago a sinistra, ladro a destra — con
l'orda, il troll, il beholder e la faglia alle spalle. Arrivava a **1376×768**, portata a **1920×1080**.

L'ingrandimento non e' un `resize` e basta: taglio esatto a 16:9 (la sorgente era 1,79, serve 1,78), poi
**due passaggi** — 2x Lanczos e giu' alla misura voluta, perche' un salto solo lascia i bordi molli — e una
**maschera di contrasto con soglia** (1,4 · 58% · 3), che affila senza alonare sui bordi netti, che in
un'illustrazione dipinta sono dappertutto. JPEG qualita' 92, **521 KB**.

La composizione va d'accordo con la velatura della 1.86: gli eroi stanno nelle due fasce laterali, che
restano accese, e sotto al pannello finisce la faglia — la parte che si puo' coprire. La prima illustrazione
resta nel repo come `menu_key_art_v1.png`.

---

### [1.89.1] — 2026-09-05 · "Dipingerli, non disegnarli"

La prima stesura dei due boss era fatta di **poligoni piatti col contorno nero**: esattamente il contrario di
come sono fatte le creature che in questo gioco vengono bene. Il Beholder, i ragni e gli zombi nascono da
**macchie morbide sovrapposte** (`_macchia`) — scure sotto, chiare in alto a sinistra — e solo alla fine
prendono qualche spigolo netto. Rifatti tutti e due con quella tecnica.

**Il Colosso.** La massa e' otto macchie sovrapposte, dal quasi-nero in basso a destra alla luce in alto a
sinistra; le lastre stanno SOPRA la massa, poche e irregolari, ognuna col fianco scuro e il filo di luce sullo
spigolo alto. Le **crepe** si disegnano due volte — una larga e fioca che fa il bagliore, una sottile e accesa
che fa il taglio — e hanno una diramazione corta: e' l'irregolarita' a far leggere *spaccata*. Le prime erano
tratti spessi e simmetrici, e sembravano **frecce dipinte sopra la roccia**. Aggiunto il pietrisco che cade di
continuo, che e' cio' che dice che questa cosa si sta sbriciolando.

**AZ'GAROTH.** Quattro correzioni, tutte per lo stesso motivo — a schermo si leggeva come una macchia:

- **le corna** erano archi chiari aperti di lato: sembravano baffi, e in una stesura precedente un collare
  attorno al muso. Adesso sono due punte corte e scure che vanno all'indietro, e si vedono appena;
- **il collo** era un trapezio scuro fra corpo e testa — una scatola. Adesso e' fatto di tre macchie che
  raccordano, e il cranio e' un cuneo dipinto con il dorso del muso piu' chiaro, le arcate sopraccigliari,
  le narici e la mandibola che si apre;
- **la cresta del dorso** e' una striscia stretta con quattro placche. Come cinque rombi sembrava una zip,
  come cinque macchie una fila di bottoni, come fascia larga un verme a strisce;
- **le crepe del corpo si accendono solo in furia**. A vita piena erano tre righe rosa sul dorso, ed erano
  loro a fare tutto l'effetto sbagliato: a riposo restano due solchi scuri, che danno pelle invece di luce.

---

### [1.89.0] — 2026-09-05 · "Due boss, non quattro"

#### ⛰️ Perche' i boss stonavano
Il Signore della Guerra usava la forma `brute` — gambe, ascia, fendente **di profilo** — e il Re Lich la
forma `lich`, una veste che fluttua vista di lato. Sono rimasti al linguaggio visivo di prima della v1.26,
mentre tutti i nemici d'ondata sono stati rifatti come **puppet dall'alto** dipinti a strati. In una mappa
vista dall'alto c'erano due boss visti di lato: non e' questione di gusto, e' una prospettiva sbagliata.

#### 🎯 I boss diventano due
Erano quattro, uno ogni cinque ondate. Alla quinta avevi visto **tre nemici su dieci** e ti arrivava gia' un
boss; alla quindicesima il boss era diventato un appuntamento invece di un evento. Adesso:

| | Prima | Adesso |
|---|---|---|
| Ondate col boss | 5 · 10 · 15 · 20 | **10 · 20** |
| Boss diversi | 3 | **2** |
| Prima meta' della run | interrotta due volte | una salita continua fino al 10 |

La curva dei PV e' stata ritarata perche' **AZ'GAROTH alla 20ª resti esattamente quello di prima** (×2,5,
22.500 PV): togliere due boss non doveva rendere il finale piu' facile.

#### 🗿 IL COLOSSO DELLA FAGLIA — ondata 10
Non e' carne: sono **lastre di roccia tenute insieme dalla luce della faglia**, e nelle fessure si vede il
vuoto acceso. Vista dall'alto e' tutta spalle, con la testa incassata in mezzo — nessun volto, solo una
fenditura con la luce dentro — e due braccia lunghe coi pugni squadrati. Intorno gli orbitano cinque blocchi
di pietra, tenuti su dalla stessa luce.

**Tre fasi, e sono tre modi di combattere diversi:**

| Fase | Vita | Come combatte |
|---|---|---|
| **Muro** | 100-66% | Ti cammina addosso. Pugno telegrafato (0,72s, come lo slam del Troll) su un'area di 132px, e ogni 7s **tre onde d'urto concentriche** che partono da lui: si schivano andando *fra* un anello e l'altro |
| **Sfaldato** | 66-33% | Perde il braccio sinistro — spalla compresa, e dal moncherino esce luce. Il pugno arriva meno spesso, ma comincia a lanciare **macerie** a ventaglio di tre |
| **Nucleo** | sotto il 33% | Il petto si spacca e resta scoperto il nucleo: corre una volta e mezza piu' veloce e le onde arrivano piu' spesso, ma **incassa il 50% di danni in piu'**. E' la finestra, e dura poco |

Non lo si picchia e basta: si aspetta che si apra, e nel frattempo si sopravvive. Ed e' l'unico boss la cui
**forma cambia** con la vita — non serve guardare la barra per sapere a che punto sei.

#### ☄️ E AZ'GAROTH ridipinto
La forma era giusta (dall'alto, ali aperte ai lati, testa in avanti) ma era fatta di campiture piatte:
un'ellisse bordeaux, due triangoli scuri per ali, una testa piccola. A schermo si leggeva come una macchia.
Rifatto col linguaggio dei nemici nuovi:

- **ali a ventaglio** con quattro dita e la membrana **a festoni** fra una e l'altra — e' il bordo che
  rientra a far leggere *ala di drago* invece di *pinna* — con un battito vero (giu' veloce, su lento);
- **coda a sei segmenti** che ondeggiano con ritardo, con la punta a lama;
- **corpo allungato** con le placche del dorso e il volume dato dal gradiente, non dal contorno;
- **mandibola che si apre** con le zanne, e la **gola che si accende prima del soffio**: il telegrafo e'
  anche decorazione;
- sotto il **40% di vita** le crepe del corpo si accendono come magma e il drago diventa una sorgente di luce.

---

### [1.88.0] — 2026-09-05 · "Si vede cosa hai addosso"

#### ⚔️ Quattro ranghi per ogni slot
Il catalogo aveva due o tre oggetti per slot e una scala di rarita' ereditata dai boon (comune, non comune,
raro, epico, leggendario) che non ci finiva dentro. Adesso ogni slot ha **quattro oggetti**, uno per rarita':

**comune** (quello che hai addosso alla partenza, gratis) · **raro** · **leggendario** · **divino**

Otto slot fra le tre classi, **32 oggetti**, quindici dei quali nuovi: la Falce della Faglia e l'Egida di
Ossidiana del guerriero, l'Aegis della Faglia, lo Scettro delle Stelle Morte e il Manto delle Ere del mago,
l'Arco delle Ombre e la Pelle del Vuoto del ladro, e cosi' via. Le regole di prima restano tutte: rango 1
gratis, prezzi crescenti, **nessuno scambio alla pari** (salendo non si perde mai niente) e il cambio libero
col ricalcolo da zero dei bonus.

#### 🎨 E si VEDE, che e' il punto
Comprare un pezzo e vedere cambiare solo un numero nel pannello e' un acquisto; vederlo addosso e' un
personaggio. Ogni oggetto porta una `tinta` e un rango, e il renderer li usa:

- **L'armatura ridipinge i pezzi grossi**: il metallo di elmo, piastra e spalline del guerriero, la veste
  del mago, mantellina e cappuccio del ladro. Cambiare corazza cambia il colore del personaggio.
- **Lo scudo cresce**: arco piu' ampio e lastra piu' spessa a ogni rango, con un rivetto in piu' e il bordo
  del colore dell'oggetto. E' l'unico pezzo che cambia la **sagoma** vista dall'alto — e nel gioco e' anche
  quello che para davvero, quindi la forma dice quanto copre senza scrivere un numero. L'Aegis (divino) ha
  una runa accesa lungo il bordo.
- **L'arco del ladro** si allunga di rango in rango (quattro lunghezze) e cambia legno; dal leggendario in
  su il dorso e' acceso del colore dell'arma.
- **L'orbe del mago** cambia colore e grandezza con la bacchetta.
- **Il rango divino** aggiunge un **alone che respira** del colore del pezzo. Uno solo, anche se hai tre
  pezzi divini: tre aloni sovrapposti sarebbero una lampadina.

Tecnicamente: lo snapshot porta adesso **tutti e quattro** gli slot (prima solo arma e scudo), il renderer
ha `_palGear()` e `_gearRanks()` che traducono l'equipaggiamento in colori e forme, e la chiave della cache
dei gradienti include la nuova tinta dello scudo — la stessa attenzione che era servita per il bug dei
mercenari nella 1.82.1.

#### 🏹 E un difetto vecchio di cinque versioni
L'**Arco Corto** aveva ancora `dmg 31, fireRate 3.0`: i numeri di **prima** della 1.83. Il ribilanciamento
del ladro (38 danni, 2,3 tiri al secondo) era stato scritto in `heroes.js`, ma `effWeapon()` legge **sempre**
dall'oggetto equipaggiato e ignora l'arma della classe quando c'e' un oggetto — e alla partenza c'e' sempre.
Quindi per cinque versioni il ladro ha giocato con l'arco vecchio. Allineato.

---

### [1.87.1] — 2026-09-05 · "Un portale, non una crepa"

La faglia d'uscita era uno **squarcio**: un'ellisse verticale di macchie morbide, alta e stretta, come una
crepa nell'aria. In mezzo a un pavimento scuro si leggeva come un'ombra o un effetto — non come una cosa in
cui si entra. Rifatta come **portale tondo e frontale**, quello che chiunque abbia giocato a un gioco
riconosce senza che glielo si spieghi:

- **La bocca e' scura al centro** e accesa verso il bordo. E' la regola che fa la differenza fra un portale e
  un disco luminoso: un portale e' un **buco**, e un buco al centro e' piu' scuro.
- **Vortice a quattro braccia** che girano insieme, disegnate a segmenti: quasi trasparenti al centro,
  accese verso il bordo. Un tratto di forza uniforme avrebbe riempito di luce proprio il buco.
- **Pulviscolo risucchiato** verso l'interno, quattordici granelli che rientrano e ricominciano dal bordo.
- **Anello** a tre tratti — un filo scuro fuori (senza, su un pavimento chiaro il portale non ha un bordo e
  sembra una macchia appoggiata sopra), l'energia morbida, il bordo netto acceso — con **sei rune a rombo
  incastonate** che girano lente e si accendono a turno. Le prime erano otto tacche *fuori* dall'anello:
  sembravano graffi.
- **Luce viola a terra** e nel sistema di illuminazione, come le torce e i bracieri: il portale illumina la
  stanza invece di stare appiccicato sopra.

---

### [1.87.0] — 2026-09-05 · "Due rimedi"

#### 🔒 I prigionieri erano diventati introvabili
Nella 1.84.1 avevo tolto il segnalino del recinto dalla minimappa — richiesta giusta, la deviazione si deve
trovare esplorando. Solo che quel segnalino era **l'unico modo per sapere che il recinto esisteva**: misurato
adesso, stava a **930 px di mediana** dal giocatore, con punte a **1745**. Fuori schermo, al buio, senza un
indizio. C'era nel 28% delle ondate e non lo vedeva nessuno.

Due correzioni, tutte e due nella stessa direzione — *nascosto* non vuol dire *dall'altra parte della mappa*:

- **Dove nasce**: `_postoLargo()` prende un terzo parametro, la distanza **massima**. Il recinto si piazza
  fra **420 e 950 px** — fuori vista, ma dentro la stanza in cui stai combattendo. Misurato dopo: mediana
  **738**, massimo **944**.
- **Come si vede**: due **bracieri accesi** ai lati del recinto, con la loro luce nel sistema di
  illuminazione. Un fuoco nel buio si legge da mezzo schermo. Se una cosa la si deve trovare guardandosi
  intorno, allora deve essere una cosa che **si vede** — e resta una scoperta invece di una commissione.

Sulla minimappa non torna niente, e la chiave resta invisibile fino a 118 px: quelle due regole restano.

#### 🎴 Le passive tornano al loro posto, le attive si spostano all'8 e al 14
Nella 1.85 le abilita' attive avevano preso il posto delle passive del **6** e del **12**, e le due rimaste
erano salite di scaglione per compensare. Era un baratto: **meta' della crescita del personaggio** ceduta
per aggiungere un tasto. Annullato.

| | Prima (1.85) | Adesso (1.87) |
|---|---|---|
| Passive | 2 — livelli 3 e 9 (rara, divina) | **4** — livelli **3, 6, 9, 12** (non comune, rara, epica, divina) |
| Attive | livelli 6 e 12 | livelli **8** e **14** |
| Scelte in una run | 4 | **6** |

L'8 e il 14 erano due livelli che non davano niente: adesso le attive **si sommano** alla progressione
invece di sostituirne un pezzo. Ricariche invariate (30s e 45s), abilita' invariate, specializzazione al 15
invariata. Cambiati solo i due numeri in `ABIL_SLOT` e la tabella `SCAGLIONI` tornata quella di prima —
piu' i test 39, 51, 52 e 61, la barra dell'HUD (i lucchetti dicono 8 e 14), l'elenco delle scelte nel menu
di pausa (adesso **sei righe**) e la guida.

---

### [1.86.2] — 2026-09-05 · "In alto"

Il pannello del menu e' **ancorato in alto** (4vh dal bordo) invece che centrato verticalmente. Da quando
e' corto, centrarlo lasciava una fascia vuota sotto e schiacciava l'illustrazione in due mezzelune sopra e
sotto; in alto l'artwork resta intero sotto al pannello. Tolto anche il `max-height:92vh` del menu: adesso
non serve piu' a niente, la card sta comoda.

---

### [1.86.1] — 2026-09-05 · "Meno da leggere"

Via dal menu la **scheda della classe**: il riquadro fra i tre eroi e il pulsante che elencava arma, danni,
cadenza, statistica, scatto, passiva, pregi e difetti. Erano sei righe di tabella davanti a un'illustrazione,
e chiedevano di studiare prima di poter giocare. Restano i **tre riquadri** per scegliere l'eroe e
**ENTRA IN PARTITA**; cosa sa fare una classe si scopre giocandola — e comunque e' tutto nel menu di pausa.

Il pannello si accorcia di un terzo e l'artwork si vede sopra e sotto, che era il punto della 1.86.
`showHeroDetail()` resta e non fa niente finche' il riquadro non c'e': se un giorno lo si rimette da
un'altra parte, torna a riempirlo da solo.

---

### [1.86.0] — 2026-09-05 · "La prima cosa che vedi"

#### 🖼️ Il menu ha un'illustrazione
Il menu iniziale era un gradiente scuro con una card sopra: onesto, muto. Adesso ha l'**artwork** —
i tre eroi di fronte, l'orda e la faglia alle spalle — a tutto schermo, in `assets/art/menu_key_art.jpg`.
Il brief completo e il prompt con cui e' stata generata stanno in **ARTWORK.md**, cosi' la prossima si fa
senza ripartire da zero.

Il file originale (PNG, 2,5 MB) resta nel repo; quello che il gioco carica e' la conversione **JPEG q88 da
385 KB**. E' la prima cosa che si scarica: un settimo del peso, differenza invisibile.

#### 🪟 E il pannello diventa vetro
Un'illustrazione dietro una lastra opaca e' un'illustrazione sprecata. Il pannello adesso e' **vetro
sfocato** (`backdrop-filter`, sfondo al 70-86%), con un **filo d'oro** in cima che lo stacca dallo sfondo
senza incorniciarlo, e un'entrata in dissolvenza di mezzo secondo. Campi e chip degli eroi sono diventati
semitrasparenti per la stessa ragione.

La velatura sopra l'artwork scurisce **la fascia centrale** — quella dietro al pannello — e lascia accese
**le due fasce laterali**. La prima versione faceva l'opposto, una vignettatura radiale che apriva il centro
e spegneva i bordi: solo guardando la schermata renderizzata si vede il problema — il centro e' coperto dal
pannello, e quella velatura spegneva esattamente gli unici due pezzi di illustrazione che si vedono.

Piccoli movimenti, niente di piu': l'immagine **deriva lentissima** (48s avanti e indietro, scala 1.055) e
la parola **RIFT** pulsa d'oro ogni 3,6s. Un menu fermo sembra una schermata; uno che respira sembra un
posto.

#### 🧭 E la guida del menu tornava alla 1.84
Diceva ancora *"le abilita' Q/E tornano con l'evoluzione delle classi"* e *"ai livelli 3, 6, 9 e 12 scegli
1 abilita' su 4"*. Corretta: **Q ed E sono le attive** (livelli 6 e 12), le **passive sono al 3 e al 9**.

---

### [1.85.0] — 2026-09-05 · "Q ed E"

#### ⚡ Dodici abilita' attive, quattro per classe
Gli slot **Q** ed **E** erano un contenitore vuoto dal v1.66: i tasti li leggeva `input.js`, il server
aveva `useQ`/`useE` come stub, i cooldown `cdQ`/`cdE` scendevano a vuoto e la barra dell'HUD teneva il
posto col lucchetto. Mancava cosa metterci.

| Classe | Slot **Q** — livello 6, ricarica 30s | Slot **E** — livello 12, ricarica 45s |
|---|---|---|
| 🛡️ **Guerriero** | ⚡ **Carica** — scatto corazzato di 300px che sfonda: doppio fendente, spinta e **stordimento**, e sei immune mentre corri<br>📣 **Grido di Guerra** — i nemici intorno puntano **te** per 3s, e tu e i compagni nel raggio subite **−25% danni** per 4s (**i boss non danno retta**) | 🌀 **Turbine** — tre giri a 360° in 1,2s, ognuno al 70% del fendente<br>✨ **Giuramento** — per 5s tu e i compagni entro 220px siete **immuni al primo colpo** |
| 🔮 **Mago** | 🔥 **Muro di Fuoco** — barriera di fiamme lunga 220px per 5s: brucia chi la attraversa<br>🫧 **Scudo di Mana** — assorbe danni per 6s, poi **esplode** respingendo e rallentando | ☄️ **Meteora** — tre impatti telegrafati sul punto mirato<br>⛓️ **Catena Nera** — fulmine che rimbalza fra **otto** nemici, a danno calante |
| 🏹 **Ladro** | 🌫️ **Velo d'Ombra** — nube di 150px per 5s: dentro sei **invisibile**, e il primo colpo dall'ombra e' critico<br>🪤 **Tagliola** — trappola armata 25s: il primo che entra resta **bloccato 2,5s** (fino a tre in campo) | 🎯 **Marchio** — il bersaglio prende **+50% danni da chiunque** per 8s; se muore marchiato, meta' ricarica torna<br>🏹 **Salva** — quindici frecce in due secondi, perforanti |

Si sceglie **una abilita' al livello 6** (slot Q) e **una al livello 12** (slot E), fra le due di quello
slot. La scelta e' **definitiva**, come le passive: le due che non prendi sono il motivo per rigiocare la
classe.

#### ⏱️ Ricariche lunghe, e nessuna risorsa nuova
**30 secondi** lo slot Q, **45** lo slot E. Una ricarica corta le trasformerebbe in una seconda arma, e a
quel punto il gioco lo giocherebbero loro. Niente mana e niente vigore: sarebbe stata un'altra barra da
guardare mentre schivi. Restano le due manopole che c'erano gia' e non facevano niente — `cdrMult` (la
Destrezza accorcia la ricarica) e `abilityMult` (la potenza).

Misurato coi bot, dodici run per classe a livello 12, con e senza abilita': **+14%** di danno al secondo
per il guerriero, **±2%** per mago e ladro. Il bot le usa a caso, quindi il numero vero in mano a una
persona e' piu' alto — ma dice quello che serviva sapere: **con queste ricariche non sbilanciano niente**.

#### 🎴 Le passive scendono da quattro a due (e salgono di scaglione)
I livelli 6 e 12 erano gia' occupati dalle passive. Le scelte della run restano **quattro** — 3, 6, 9, 12 —
ma adesso sono **due passive** (3 e 9) e **due attive** (6 e 12). Perche' il personaggio non ne uscisse
piu' povero, le due passive rimaste **salgono di scaglione**: **rara** al posto di non comune, **divina**
al posto di epica. Meno scelte, ognuna piu' pesante: la stessa regola che regge tutto il resto.

#### ★ E la specializzazione del 15 smette di promettere
Dal v1.69 ogni specializzazione dichiarava un'abilita' attiva — Giuramento, Turbine, Meteora, Catena Nera,
Marchio, Salva — che non e' mai stata scritta: sei promesse in un file di dati e nel documento delle
caratteristiche, sotto *manopole spente*. Adesso **quelle sei sono le attive del livello 12**, e la
specializzazione fa un'altra cosa: **+30% di potenza** a quelle che hai (`SPEC_ABIL_MULT`). Tiene il suo
passivo, e non promette piu' niente.

#### 🎨 Cosa si vede
Il muro di fuoco, le tagliole e la nube d'ombra sono **oggetti veri sul campo** — viaggiano nello snapshot
e si disegnano nel mondo, non sopra lo schermo. Tre linguaggi diversi apposta: il muro **brucia** (caldo,
mobile, illumina), la tagliola e' **metallo** (freddo, immobile, piccolo), la nube e' **assenza** (scura,
morbida, senza contorno). Il Turbine riusa l'arco del fendente a giro pieno — il campo `giro` c'era dal
v1.69 e non lo disegnava nessuno. Il **marchio** gira sopra la testa del nemico e **lo vede tutta la
squadra**: e' li' che sta il senso in cooperativa.

#### Le due regole che ha chiesto Paolo
- **Il mercenario non ha abilita'.** Come per l'XP, le monete e la chiave dei prigionieri: non e' un
  giocatore per le regole. C'e' un test anche per questo.
- **Il Grido di Guerra non attira i boss.** Un boss che si gira perche' hai urlato smetterebbe di essere
  un boss.

#### 🧪 Test
**1557 passati in 6,5s** — TEST 61 nuovo (la tabella, lo sblocco ai livelli giusti, le ricariche, il
mercenario, i boss, il Marchio, tutte e dodici che partono senza sporcare lo stato) e i test 39, 51 e 52
riallineati ai due scaglioni. Il suo peso resta quello della 1.84.1: la suite non e' tornata a crescere.

---

### [1.84.1] — 2026-09-05 · "Cercala"

#### 🗝️ La chiave si cerca
Era disegnata sempre, da qualunque distanza: bastava girare lo sguardo e la deviazione era gia' risolta.
Adesso **compare solo entro ~118 px**, sfumando negli ultimi 46. Il resto e' identico — dov'e', chi ce
l'ha, come si raccoglie: cambia solo che **la si trova esplorando** invece che leggendola sullo schermo.

#### 🗺️ Sulla minimappa resta solo la faglia
Il recinto aveva un segnalino. Con quello, i prigionieri non erano una scoperta ma una commissione: vai
li', fatto. Tolto. Sulla minimappa c'e' la **faglia d'uscita** e basta — ne' recinto ne' chiave.

#### 📦 Le casse possono contenere monete
Aprendone una, se non e' una mima: **meta' delle volte un mucchietto di monete** (`22 + 3 per ondata`,
±25%, sparso a terra da raccogliere), meta' il **potenziamento a tempo** di prima. Le casse erano l'unica
cosa in mappa che non c'entrava niente con l'equipaggiamento: adesso aprirle e' anche un modo per
arrivare al pezzo che manca.

#### 🧪 La suite di test dimezzata
**6,5 s invece di 10**, con tre controlli in piu' (1460). Nessuna garanzia rimossa: sono stati dimezzati i
**campioni** dove la misura era statistica — mappe generate (240 → 120, 120 → 60, 80 → 40, 50 → 25), tempo
simulato (partita di collaudo 240 s → 120, tetto ai vivi 90 s → 45), e le ripetizioni del TEST 60
(40 → 18 stanze, 400 → 150 estrazioni, 30 → 12 ondate del boss). I margini restano fuori di tre deviazioni
standard: meno campioni, non piu' fragile.

---

### [1.84.0] — 2026-09-05 · "Qualcuno da tirare fuori"

#### 🔒 I prigionieri
Ogni tanto — **una mappa su tre** circa — in un angolo lontano c'e' un **recinto di pali** con dentro della
gente. Sopra c'e' scritto cosa gli serve: *prigionieri · serve una chiave*.

| | |
|---|---|
| Quanti | da **1 a 5**, e il tetto cresce con le ondate: alla prima ne trovi uno o due, dalla dodicesima anche cinque |
| Quanto pagano | **100 monete a testa** — fino a 500, quanto un pezzo di equipaggiamento di rango 2 |
| La chiave | **addosso a un elite** se in quell'ondata ne e' previsto uno (cade quando cade lui), altrimenti **a terra accanto alle casse** |
| Obbligatorio? | **No.** L'ondata si chiude lo stesso: e' una deviazione che si sceglie, e il prezzo e' il tempo che passi a cercare invece che a uccidere |
| Nelle ondate del boss | non compare: quella mappa non divide l'attenzione |

Sono disegnati con la stessa figura dei mercanti del villaggio (`_hero` in versione civile), uno per
palette, cosi' non sono cinque copie dello stesso tizio. Il recinto e' basso e **non blocca il passaggio**:
i pali servono a farsi capire, non a fare da muro — e un muro invisibile al pathfinding avrebbe incastrato
i mostri. Quando li liberi i pali cadono e la scritta diventa *liberi*.

L'alone attorno al recinto e' **giallo se hai la chiave** e spento se non ce l'hai: la regola si legge da
lontano senza dover leggere niente. *(Il segnalino del recinto sulla minimappa e la chiave sempre visibile
sono stati tolti in **1.84.1**: vedi sopra.)*

Il **mercenario** non raccoglie la chiave e non libera nessuno: come per l'XP e le monete, non e' un
giocatore per le regole. C'e' un test anche per questo.

#### 🌀 La faglia, al posto del pulsante EXIT
Il pulsante verde in mezzo allo schermo non c'e' piu'. Quando la mappa e' ripulita si apre uno **squarcio**
a un passo da te — non addosso, se no ci finivi dentro mentre raccogli, e non fuori vista — e ci si passa
dentro per proseguire. Il gesto e' lo stesso, ma succede **nel gioco** invece che nell'interfaccia; e in
una mappa che si chiama Dungeon Rift lo squarcio e' di casa.

Il conto alla rovescia anti-AFK resta, la scritta in alto dice cosa fare, e in cooperativa dice quanti sono
gia' passati. In pratica sparisce un pezzo di UI e ne guadagna il mondo di gioco.

#### 🧱 Un difetto trovato per caso
Aggiungendo i prigionieri sono cambiate le estrazioni casuali a valle, e due test hanno iniziato a
lampeggiare. Uno dei due indicava una cosa vera: il **recupero anti-stallo** dei mostri cercava un punto
libero fra 950 e 1500 px dal giocatore e fuori dalla sua vista, e su certe mappe un punto cosi' **non
esiste** — il mostro bloccato non si spostava mai e l'ondata poteva restare aperta per sempre, che e'
esattamente cio' che quella regola doveva impedire. Adesso, se la prima passata non trova niente, ne fa una
seconda piu' larga (700-1100 px) **senza allentare la condizione che conta**: fuori dallo sguardo. Meglio
riportarlo un po' piu' vicino che lasciarlo dov'e'; comparire davanti agli occhi resta vietato.

**1457 test passati, 0 falliti.** Le prove: il recinto compare ogni tanto e mai oltre il tetto; alla prima
ondata sono uno o due; senza chiave non si apre e non arriva una moneta; con la chiave si apre e paga cento
a testa, **una volta sola**; la chiave sull'elite cade dove cade lui; il mercenario non la raccoglie; la
faglia si apre a un passo dal giocatore, non nella roccia, e attraversarla chiude l'ondata mentre restarne
fuori no; nelle ondate del boss non c'e' nessun recinto.

### [1.83.0] — 2026-09-05 · "Lo scudo sta davanti"

Ribilanciamento delle tre classi giocabili, partendo da una misura invece che da una sensazione: dodici
partite simulate per classe, coi bot, contando i danni **subiti** al secondo.

#### 📉 Il problema, in numeri
| | ondata raggiunta | vissuto | danni subiti | uccisi/s |
|---|---:|---:|---:|---:|
| 🛡️ Guerriero | **2,1** | **80 s** | **4,3/s** | 0,31 |
| 🔮 Mago | 3,0 | 163 s | 1,0/s | 0,35 |
| 🏹 Ladro | 3,2 | 172 s | 1,1/s | 0,31 |

Il guerriero incassava **quattro volte** gli altri due e moriva a meta' strada. Non per mancanza di danno
(uccide come gli altri): per il tempo che passa a contatto. E' l'unico che non puo' tenere le distanze,
quindi era l'unico **senza una risposta**.

#### 🛡️ Lo scudo para davanti, e adesso conta
Il guerriero uno scudo ce l'ha, ed e' disegnato **davanti a lui** — ma faceva solo uno sconto piatto del
5%, uguale da ogni lato. Adesso para il cono frontale:

| | sconto piatto | colpi frontali |
|---|---:|---:|
| Scudo | −5% | **−45%** |
| Scudo a Torre | −13% | **−60%** |

Il cono e' di **70° per lato** (`C.SCUDO_CONO`): largo abbastanza da poterci contare girandosi, stretto
abbastanza che essere circondati continui a far male. Alle spalle e di fianco lo scudo non c'e', e si
sente. I colpi **senza sorgente** (le esplosioni ad area) non si parano: non c'e' una direzione da cui
pararli. Quando scatta, a schermo si accende un **arco** dalla parte in cui guardi — non un anello, che
direbbe "da ogni parte": la regola si vede mentre succede.

E' una risposta che si **gioca**: girarsi verso chi colpisce. Il guerriero non diventa piu' duro, diventa
piu' bravo se lo giochi bene.

#### 🏹 L'arco: meno frecce, piu' peso
Tre frecce al secondo di partenza — che con la Destrezza al massimo diventavano **cinque** — non erano un
arco, erano un rubinetto: il gesto spariva. Cadenza **3,0 → 2,3**, danno per freccia **31 → 38**. Il danno
al secondo scende del 6% (93 → 87), il **ritmo** cambia molto: ed era il ritmo il problema.

Il mago non e' stato toccato: era gia' quello in equilibrio, e i numeri lo confermavano.

#### 📈 Il risultato, stesse dodici partite per classe
| | ondata | vissuto | danni subiti | uccisi/s |
|---|---:|---:|---:|---:|
| 🛡️ Guerriero | 2,1 → **2,7** | 80 → **119 s** | 4,3 → **2,9/s** | 0,31 |
| 🔮 Mago | 3,0 → 2,7 | 163 → 135 s | 1,0 → 1,2/s | 0,33 |
| 🏹 Ladro | 3,2 → 3,1 | 172 → 154 s | 1,1 → 1,2/s | 0,32 |

Il guerriero incassa **un terzo in meno** e vive **la meta' in piu'**; le altre due classi si muovono
dentro il rumore. Resta quello che prende piu' colpi — e' un corpo a corpo, deve essere cosi' — ma con il
doppio dei PV adesso la resistenza effettiva e' allineata.

**1428 test passati, 0 falliti** su cinque esecuzioni. Le prove: un colpo in faccia fa meno male di uno
alle spalle, e la differenza e' **esattamente** lo sconto dello scudo; di fianco (oltre i 70°) non c'e'
sconto; il cono ha un bordo netto; i colpi senza sorgente non si parano; **togliendo lo scudo** la parata
sparisce (e' l'oggetto a parare, non la classe); la Torre para piu' del piccolo; e le tre classi restano
entro il 15% di danno al secondo l'una dall'altra.

### [1.82.4] — 2026-09-05 · "Quando c'e' da menare, si mena"

Rifinitura della 1.82.3. Le distanze erano giuste ma avevano la precedenza sbagliata: *"se ci sono nemici
la priorita' non puo' essere seguirmi ma attaccare; la distanza minima vale se non ci sono nemici nel
raggio di attacco"*.

#### ⚔️ La precedenza, adesso
- **La fascia di scorta** (120 px ideali, 190 per rifarsi sotto) vale **solo quando non c'e' niente da
  fare**. Con un bersaglio comanda il combattimento e basta: prima la fascia lo faceva arretrare a meta'
  scontro per tenere le distanze da te, che e' peggio del difetto che risolveva.
- **Lo spazio personale** (70 px) resta, ma si **sospende quando ha un nemico nel raggio della sua arma**.
  Sotto l'arma non si arretra per far spazio a nessuno: si colpisce. Appena il nemico esce dal raggio — o
  muore — torna a prendersi il suo spazio.

Il minimo resta un divieto, non una preferenza: e' li' perche' due sagome sovrapposte non fanno piu' capire
chi sei. Ma un divieto che vale *anche* mentre meni non e' una regola di leggibilita', e' una regola che ti
toglie il compagno proprio quando serve.

#### 📏 Misurato (un minuto per prova, ondata vera)
| | mediana | max | sotto 70 px | in mischia | uccisi |
|---|---:|---:|---:|---:|---:|
| capo fermo | 135 px | 210 | 11% | 11% del tempo | 23 |
| capo in movimento | 223 px | 325 | 1% | 41% del tempo | 6 |
| capo in movimento | 221 px | 359 | 1% | 49% del tempo | 10 |

L'11% sotto i 70 px del primo caso e' esattamente il caso nuovo: sta addosso **mentre combatte**, che e'
cio' che deve fare. Fuori dal combattimento la fascia regge.

**1414 test passati, 0 falliti** su otto esecuzioni di fila (una prova della v1.80 misurava la
distanza MEDIA del branco, che col tetto della folla dipende da dove aspettano quelli in eccesso: adesso
misura cio' che il tetto promette davvero, cioe' che i sei piu' vicini siano arrivati). Le prove nuove sono
la coppia che descrive la regola: appiccicato al capo
**senza** nemici si scosta; nello stesso identico caso ma **col nemico a tiro** non arretra, sta li' e
colpisce; e col nemico fuori portata gli va incontro invece di stare appresso al capo.

### [1.82.3] — 2026-09-05 · "Il mercenario impara le distanze"

Due difetti segnalati sul campo: *"sta troppo vicino al personaggio principale quasi si sovrappone"* ed
*"e' troppo aggressivo"*. Sono la stessa cosa vista da due lati — il mercenario non aveva **nessuna idea
di distanza**, ne' da te ne' dai nemici.

#### 📏 Lo spazio personale
Adesso ha tre soglie invece di nessuna:

| | |
|---:|---|
| **70 px** | il minimo assoluto: sotto, si scosta e basta — vale **sopra ogni altra cosa**, anche col nemico addosso, perche' due sagome sovrapposte non fanno piu' capire chi sei |
| **120 px** | la distanza in cui si tiene quando non c'e' niente da fare |
| **190 px** | oltre, da fermo, si rifa' sotto |

La distinzione fra il **minimo** e l'**ideale** e' tutta la differenza, e me l'ha detta la misura: con il
solo minimo il mercenario si fermava esattamente sulla soglia — appiccicato — e ci restava. Stava sotto i
70 px per **meta' del tempo**. Con la distanza ideale sta a **123-186 px di mediana** e sotto i 70 px
finisce nel 2-9% dei tick, quasi sempre perche' sei tu che gli cammini addosso.

#### 🛡️ Una scorta, non un cacciatore
Prima ingaggiava qualunque cosa entro 620 px **da se'**, e partiva per conto suo dall'altra parte della
stanza. Adesso un nemico e' affar suo se sta entro **360 px dal CAPO**: si occupa di cio' che minaccia te.
Misurato con il giocatore fermo per un minuto: uccide 21-23 nemici (fa il suo mestiere) e **non si allontana
mai oltre 157-215 px**.

E siccome a parita' di velocita' un compagno che si ferma a combattere non ti riprenderebbe **mai piu'**,
mentre rientra ha un piccolo bonus di velocita' (+28%) e puo' usare lo scatto oltre i 480 px: due cose che
esistono solo quando ti sta dietro, cioe' quando non si vedono.

Verificato nel browser: dopo lo schieramento si assesta su **122-131 px** e resta li'.

**1410 test passati, 0 falliti.** Le prove nuove: incollato al capo si scosta ma continua a guardare il
nemico; un nemico lontano dal capo non lo ingaggia e non gli parte incontro; troppo addosso si stacca fino
alla distanza di scorta; a distanza giusta e senza nemici sta fermo.

### [1.82.2] — 2026-09-05 · "Colori veri, e non ci si incastra piu'"

#### 🎨 Il mercenario adesso e' di un altro COLORE
La prima passata spostava il tono di poco, e in gioco — con la luce della caverna addosso — due ladri
restavano due macchie verdi uguali. Adesso ogni variante e' un **colore suo**: ruggine, ferro, viola,
ottone per il guerriero; cremisi e oro, verde e lime, cenere e brace, porpora per il mago; bordeaux, blu
notte, viola, cuoio per il ladro. Restano scuri e sporchi, perche' la caverna e' scura e un colore acceso
pieno sembrerebbe incollato sopra, ma la tinta si legge a colpo d'occhio.

Il problema pero' non era solo la scelta dei colori: era **dove finivano**. Dall'alto di un ladro si vedono
soprattutto la **mantellina** e il **cappuccio**, e di un guerriero **elmo, piastra e spalline** — e tutte
queste superfici avevano colori scritti a mano nel renderer, fuori dalla palette. Si tingeva il torso, cioe'
la parte che si vede meno. Adesso:

- il **ladro** ha `mant` e `capp` nella palette;
- il **guerriero** ha `metallo`, un colore solo da cui nascono elmo, piastra e spalline con le sue
  schiariture: cambiarlo cambia l'armatura intera;
- il **mago** era gia' a posto (la sua veste e' il gradiente del corpo).

Le chiavi nuove entrano tutte nella firma della palette, quindi la cache dei gradienti resta separata per
variante — la correzione della 1.82.1 vale anche per queste.

#### 🧱 Il mercenario non si incastra piu'
Segnalato: *"quando un nemico entra nel campo visivo ma tra di loro c'e' un ostacolo o un cunicolo stretto
tende a bloccarsi"*. Vero, e la causa e' meccanica: il motore fa **scivolare** lungo i muri (`moveCircle`
muove un asse per volta), ma se spingi **perpendicolare** alla roccia non c'e' niente su cui scivolare — e
chi punta dritto a un nemico che sta dall'altra parte di un masso spinge esattamente cosi'.

Due rimedi, uno per causa:

1. **Il bersaglio deve essere raggiungibile.** Prima prendeva il piu' vicino e basta; adesso serve la
   **linea di vista**, e senza linea di vista vale solo chi gli e' praticamente addosso (140 px: dietro
   l'angolo si mena lo stesso). Un nemico dietro al masso non e' piu' un bersaglio, quindi non ci si punta
   contro. Di conseguenza il mago non spreca piu' colpi contro la roccia.
2. **L'anti-incastro.** Si misura l'**intento** contro lo **spostamento vero**: se per un quarto di secondo
   il primo c'e' e il secondo no, per otto decimi si cammina **di traverso** (75°, un lato per volta,
   alternandolo) invece che dritto. E' l'equivalente di dare una spallata e girare attorno. Vale per tutto:
   inseguimento, ritirata e ritorno dal capo lungo i cunicoli.

#### 🧪 Tre test che erano un lancio di dadi
Non c'entrano coi mercenari, ma sono saltati fuori girando la suite otto volte di fila e andavano chiusi:
la prova del teletrasporto (v1.76.1) non teneva conto delle spintarelle dell'**anti-incastro** dei mostri
(`_recoverStuck` sposta di una decina di px chi si e' wedgiato in un angolo) e contava un "scatto" da 23 px
come se fosse un teletrasporto — la soglia adesso e' larga rispetto a quelle, e resta venti volte piu'
stretta del difetto che deve prendere (619 px in un tick); la prova della caccia partiva anche da 1.500 px,
che su una mappa a corridoi in 30 s non sono percorribili a piedi (adesso 700-1.050 px in 40 s); e il Fungo
Sporifero poteva essere **spinto** di una ventina di px dai corpi che gli passavano addosso pur non
camminando mai.

**1401 test passati, 0 falliti** su otto esecuzioni di fila. Client verde.

### [1.82.1] — 2026-09-05 · "Il giocatore si e' ritrovato addosso i colori del mercenario"

#### 🐛 Il difetto
Con un mercenario **della stessa classe** in campo, il personaggio del giocatore cambiava colore: si
ritrovava addosso la tinta del compagno (abilita' e classe restavano quelle giuste — cambiava solo cio'
che si vedeva). Segnalato subito dopo la 1.82.0: *"avevo l'estetica di un ladro, ho assoldato un altro
ladro e sono diventato un guerriero con le abilita' di un ladro"*.

#### 🔍 La causa
Non era il mercenario: era la **cache dei gradienti**, ferma dal 2024 e cieca alla palette. La chiave era

```
'h_torso|lad|' + raggio        →  due ladri dello stesso raggio = STESSO gradiente
```

cioe' i colori di chi veniva disegnato per primo. Il torso e' la superficie piu' grande del personaggio
visto dall'alto, quindi il travaso si vedeva tutto. Finche' esisteva un solo personaggio per classe il
difetto non poteva manifestarsi — **le tinte dei mercenari sono la prima cosa che ha messo due esemplari
della stessa classe sullo schermo insieme**, e il bug e' saltato fuori al primo tentativo.

Il mago era gia' mezzo salvo per caso (la sua chiave conteneva `body`); guerriero e ladro no.

#### 🔧 La correzione
La **firma della palette** entra nella chiave (`_palKey`, una funzione pura): tinte diverse, gradienti
diversi. Chi non ha tinta produce firma vuota e continua a condividere il gradiente di sempre, quindi non
si paga niente per una funzione che non si usa. Verificato nel browser: con giocatore e mercenario
entrambi ladri, in cache ci sono adesso **due** voci `h_torso|lad|…` invece di una.

Il test lo blinda dove costa meno — su `_palKey`, che e' pura e non ha bisogno di un canvas: le quattro
tinte di ogni classe devono dare quattro firme diverse, nessuna delle quali uguale alla firma di "nessuna
tinta", e la chiave completa di giocatore e mercenario della stessa classe non deve mai coincidere.

### [1.82.0] — 2026-09-05 · "La compagnia di ventura"

#### 🗡️ I mercenari
Al **Banditore**, fra un'ondata e l'altra, c'e' un candidato al banco: nome, classe e **il tuo stesso
livello**. Lo assoldi, e dalla mappa dopo combatte con te. Serve a una cosa sola — **aiutare chi non e'
bravissimo** — e tutto il resto della funzione discende da li'.

| | |
|---|---|
| Quanti | **uno solo per volta**, e solo in **partita singola** |
| Quanto costa | **50 monete** a livello 1, **+40 per livello**: 610 al quindicesimo |
| Che classe | a caso fra guerriero, mago e ladro |
| Quanto e' forte | la **classe base al tuo livello**, coi punti statistica spesi come li spenderebbe uno che fa quel mestiere (al 15: uno cappato a 12 e sei sull'altro — la stessa forma della tua run). **Nessuna abilita', ne' passiva ne' attiva** |
| Se muore | muore e basta: niente "a terra", niente rianimazione. Al banco se ne assolda un altro |
| Fra un'ondata e l'altra | **sparisce**: non ti segue al villaggio. Lo ritrovi sulla mappa dopo, **curato del tutto** |
| XP e monete | **restano tue**: non ne prende, e non ne raccoglie da terra |

**Come pensa.** Segue il capo, ingaggia il nemico piu' vicino entro 620 px, tiene la distanza della **sua**
arma (chi mena a 100 px non puo' tenersi a 160), si sgancia quando e' ridotto sotto il 40% e in mischia
molla il contatto mentre l'arma ricarica invece di restare appoggiato al nemico. Non e' codice nuovo: e'
la testa dei **bot che guidano le partite simulate dei test**, rifinita dalla v1.52 alla v1.66 e spostata
in `shared/mercenari.js`. In piu' ha il **guinzaglio**: oltre 380 px dal capo molla tutto e torna, e non
riprende finche' non e' rientrato a 150 — senza quell'isteresi oscillava sul bordo e sembrava rotto.

**Come si vede.** Stessa sagoma, stesso vestito, **tono diverso**: quattro tinte per classe. Il renderer
aveva gia' il gancio (`eq.pal` nei tre eroi) e non lo usava nessuno — adesso lo usa lui. Sopra la testa
compaiono nome, livello e rango, come per i compagni in co-op. Quindici nomi per classe, corti.

#### ⚖️ Le cinque cose che NON deve cambiare
Il mercenario e' un **giocatore** per il motore — corpo, collisioni, bersaglio dei mostri, morte — e questo
regala gratis tutto cio' che serve a esistere in campo. Ma non deve essere un giocatore per le **regole**,
e sbagliare una di queste esclusioni non da' errore: cambia il bilanciamento in silenzio, com'e' successo
con la curva dell'XP nella 1.79. Ognuna ha il suo controllo nei test:

1. **L'ondata resta identica** — `buildWave` conta i giocatori veri: stessi nemici, stessa durezza.
2. **L'XP resta tutto tuo** — niente divisione di gruppo, e lui non ne prende un punto.
3. **La folla non raddoppia** — la quota della v1.80 (6 nemici addosso) si conta sui giocatori veri, se no
   se ne facevano sotto dodici: un aiuto che raddoppia la pressione non e' un aiuto. I mostri che lo
   **vedono** gli vanno addosso lo stesso, quindi fa comunque il suo mestiere di corpo che prende colpi.
4. **Il gioco non lo aspetta** a fine ondata: l'uscita conta un solo giocatore.
5. **La sua morte non chiude la run, la tua si'** — un mercenario vivo non tiene aperta la partita.

E una sesta, trovata provando: **una run nuova parte senza compagnia**. `startGame()` rimette a uno il
livello di tutti i giocatori in camera, e un mercenario sopravvissuto si sarebbe ritrovato di livello 1 col
nome di un veterano.

#### 🪧 Il Banditore cambia mestiere a meta' banco
La **rivendita delle armi e' stata tolta** (`sellGear` e il magazzino non ci sono piu'): quello spazio
adesso e' il reclutamento. Un banco che fa due mestieri diversi non e' un banco, e' un menu. Cio' che
possiedi resta tuo e lo **rimetti addosso gratis dal Fabbro**, esattamente come prima — che e' il
comportamento che conta, ed e' quello verificato dai test.

**1395 test passati, 0 falliti** (server) + client verde.

### [1.81.1] — 2026-09-04 · "La rampa non si ferma piu' alla settima"

#### 📉 Il problema, misurato
Il gioco smetteva di presentare cose all'**ondata 7**. Dopo arrivavano solo i tre Beholder (9, 12, 15): le
ondate **8, 10, 11, 13, 14 e tutte dalla 16 alla 19 non portavano niente di nuovo**, e all'ondata 19 la
composizione del pool era **identica** a quella della 15 — stesso 32% di Zombi, stesse percentuali per tutti.
L'ultimo terzo della partita era la stessa ondata con piu' numeri, proprio dove il personaggio finisce di
crescere (il livello 15 arriva verso la sedicesima). L'Occhio Spettrale, il nemico piu' lavorato del
bestiario, compariva alla 15 e aveva **quattro ondate di vita** prima del drago.

#### 🪜 La rampa, anticipata
**Alla dodicesima ondata il bestiario e' tutto in campo** — prima ci arrivava alla quindicesima, e da li'
in poi non succedeva piu' niente. Ogni ondata dalla 1 alla 12 aggiunge almeno un archetipo che prima non
c'era; dall'ottava in poi qualcuna ne aggiunge due, perche' i tre Ragni si intrecciano ai tre Beholder.

| Ondata | Entra | | Ondata | Entra |
|---:|---|---|---:|---|
| 1 | Zombie Putrido | | 7 | Fuoco Fatuo |
| 2 | Melma Corrosiva | | **8** | **🆕 Vedova delle Volte** + **Occhio Viola** *(era la 9)* |
| 3 | Negromante | | **9** | **🆕 Larva Fetida** |
| 4 | Fungo Sporifero | | **10** | **🆕 Ragno della Cripta** + **Occhio di Carne** *(era la 12)* |
| 5 | Nugolo di Pipistrelli | | **11** | **🆕 Tessitrice Verde** |
| 6 | Sfera d'Ossa | | **12** | **Occhio Spettrale** *(era la 15)* |

Il bestiario passa da 10 archetipi a **14**.

#### 🐛 Larva Fetida *(ondata 9)*
Ti corre addosso come uno zombi e da sola fa poco male. Il punto e' la sua morte: quando cade **si gonfia e
scoppia**. Non subito — lascia a terra il cerchio telegrafato che usano gia' il Negromante e il Fungo, e
detona **dopo 3 s** su un raggio di **104 px** per **2,4 volte il suo danno**. Insegna una cosa sola e la
insegna bene: *non stare incollato al nemico che stai finendo.* Chi arretra di un passo non prende niente, e
le zone fanno male ai giocatori e non ai mostri, quindi niente reazioni a catena.

Disegnata a codice come i Beholder e la caverna: sei segmenti di macchie morbide dal buio al chiaro, solchi
fra un segmento e l'altro, sei uncini che spingono quando striscia, mandibole, e il **nucleo che pulsa sotto
la pelle tesa** — l'unico avviso che quando cade lascera' un buco nel pavimento. Nessun asset nuovo.

#### 🕷️ I tre Ragni delle Volte *(ondate 8, 10, 11)*
Non ti vengono addosso: tengono la media distanza orbitando, e ogni pochi secondi **tessono una ragnatela
sul punto dove sei**. La tela **non fa un solo punto di danno**: ti **rallenta del 42%** finche' ci stai
sopra. E' l'unico nemico del bestiario che ti toglie la **mobilita'** invece di aggiungere danno — se lo
ignori ti chiude lo spazio, e poi ti raggiunge tutto il resto dell'ondata. Da vicino **mordono**, se no
sarebbe bastato stargli addosso per annullarli.

| | Ondata | PV | Tela | Durata | Ogni |
|---|---:|---:|---:|---:|---:|
| 🕷️ **Vedova delle Volte** | 8 | 88 | 92 px | 5,0 s | 5,5 s |
| 🕷️ **Ragno della Cripta** | 10 | 148 | 104 px | 6,0 s | 5,0 s |
| 🕷️ **Tessitrice Verde** | 11 | 196 | 112 px | 6,5 s | 4,4 s |

Stessa famiglia, stesso comportamento (`weaver`), **un disegno solo e tre palette** — la struttura che ha
funzionato coi Beholder. Dipinti a codice come la caverna: otto zampe che si piegano sopra il corpo e
ricadono a terra (disegnate in due passate, quelle di la' dietro il corpo e quelle di qua davanti, se no
diventa una macchia con dei bastoncini incollati sopra), addome ovale con la peluria sul bordo, e il
grappolo di **otto occhi** sul cefalotorace.

Tre dettagli che contano: lo **scatto strappa la tela** (chi scatta non e' rallentato: e' l'uscita), il
rallentamento **si spegne da solo poco dopo che ne sei uscito** — la tela e' un posto, non una maledizione
che ti porti dietro — e c'e' un **tetto di 14 tele in campo**, perche' tre ragni per due minuti d'ondata
coprirebbero mezza stanza, e allora non sarebbe piu' una scelta ma una tassa. Le tele spariscono anche col
cambio mappa: erano un posto sulla mappa vecchia.

#### 👻 Lo Spettro non torna
Era rientrato in lavorazione (c'era dalla v1.32, uscito nella v1.37) riusando il disegno vettoriale di
allora. Bocciato: accanto ai Beholder e alla caverna dipinti non stava in piedi, e rifarlo da zero non
valeva il prezzo di un archetipo che ne duplicava un altro. Restano nel file la sua IA `wraith` e lo
sfasamento reso leggibile (annuncio, sparizione, rientro: tre momenti distinti invece di un teletrasporto
muto), se un domani servisse.

#### 🧪 Test
**1327 passati, 0 falliti.** La rampa e' verificata ondata per ondata: dalla 1 alla 7 il pool deve avere
esattamente tanti archetipi quante sono le ondate, dalla 8 alla 12 deve **crescere sempre**, e alla
dodicesima deve essere completo (14). Se un domani se ne aggiunge uno lasciando un buco, o se ne arriva
uno tardi, il test lo dice. Verificati anche la tela (rallenta, non fa danno, si spegne quando esci, ha un
tetto, sparisce col cambio mappa) e i tre secondi della Larva.

### [1.80.1] — 2026-09-04 · "I nemici ti cercano"

#### 🐾 Chi non ti vede adesso ti CERCA
Il difetto stava in una riga scritta nella v1.43: il nemico che non ti vedeva sceglieva **un punto a caso
entro 350 px** e ci camminava. Su una mappa da 64x46 tile questo vuol dire che meta' dell'ondata gira in un
angolo dove non passerai mai — l'ondata si trascina e tu la vai a raccogliere pezzo per pezzo.

Adesso chi non ti vede segue **lo stesso campo di flusso** dell'inseguimento (ricostruito verso tutti i
giocatori vivi ogni 0,12 s: e' pathfinding vero, non una linea retta) ma **piu' piano**. Vederti continua a
contare, perche' chi ti vede corre e chi ti fiuta cammina:

| | velocita' |
|---|---|
| ti vede | 1,00 |
| ha la tua ultima posizione in memoria (*investiga*) | 0,95 |
| **ti cerca e basta** (nuovo) | **0,68 – 0,90** secondo l'archetipo |

Il vagabondaggio non e' stato cancellato: resta come **ripiego** per i due casi in cui la caccia non porta
da nessuna parte — nessun giocatore vivo, oppure il mostro e' incastrato e il flusso continua a spingerlo
contro lo stesso muro (dopo 0,8 s di spinta a vuoto vaga per 1,6 s e riprova).

Cambia anche la **Sfera d'Ossa**: prima, finche' non ti vedeva, restava piantata dov'era ad aspettare per
sempre. Adesso rotola piano verso di te finche' non ti trova, e allora si carica e parte. Il **Fungo
Sporifero** resta immobile: e' il suo mestiere, ed e' l'unico.

#### 👥 Ti cercano, ma non ti seppelliscono
Alla prima prova cercavano **tutti insieme**: con un giocatore fermo l'intera ondata gli era addosso in
venti secondi. Non e' difficolta', e' una valanga. Adesso c'e' un tetto: solo i **`FOLLA_MAX` = 6 piu'
vicini** a ciascun giocatore hanno il permesso di farsi sotto. Gli altri risalgono fino all'**anello
d'attesa** (900 px, appena fuori dallo sguardo) e li' girano finche' non si libera un posto — e un posto
si libera **quando ne uccidi uno**: l'ordine e' la distanza, quindi il piu' vicino fra quelli in attesa si
avvia da solo.

Due eccezioni, e sono la regola non un buco: chi ti **vede** viene addosso comunque (un nemico che ti ha
davanti agli occhi e si gira a passeggiare sarebbe un gioco rotto, non un gioco piu' facile), e chi e' in
mezzo a un'azione gia' partita (rotolata, slam, balzo) la finisce.

Quando ne restano pochi sono tutti dentro il tetto: **la coda di fine ondata non esiste piu'**.

#### 🐌 Spento il recupero di distanza
Chi stava oltre 340 px correva fino a **2,1x** per rientrare. Serviva quando i lontani vagavano a caso;
adesso che ti cercano tutti faceva arrivare l'ondata in blocco. Spento: chi e' lontano cammina come
chiunque altro, e l'ondata arriva a scaglioni. Un test verifica che non torni.

#### 📏 Misurato
Giocatore fermo e invulnerabile, in singolo, **nemici entro 620 px** sul totale vivo:

| | 5 s | 10 s | 15 s | 20 s | 45 s |
|---|---|---|---|---|---|
| ondata 1 | 0/12 | 2/12 | 5/12 | **6**/12 | 6/12 |
| ondata 3 | 1/15 | 3/15 | 3/15 | 5/15 | **6**/15 |
| ondata 6 | 1/14 | 4/20 | 6/20 | 6/20 | **9**/20 |

Il numero si assesta sul tetto; l'eccedenza dell'ondata 6 sono quelli che ti vedono (Beholder e maghi
oscuri tengono la distanza e restano in vista). Verificato anche nel browser: prima erano **12 addosso a
0:22**, adesso sono **6 a 0:40** e gli altri cinque sono ancora in giro per la mappa.

Prima della modifica i bot dei test restavano **fermi all'ondata 2 dopo 240 s** di partita simulata: non
perche' fossero forti, ma perche' non trovavano piu' nessuno da uccidere. Adesso le partite finiscono, e
col tetto alla folla il bot in singolo sopravvive **93 s invece di 43**.

#### 🚫 E non compaiono: arrivano
La regola della v1.76.1 vale ancora e il suo test e' verde: in 25 secondi di fuga **nessun nemico in vista
si avvicina di scatto**. Il recupero anti-stallo (mostro davvero bloccato, oltre 640 px, fermo da 5 s) resta
dov'era e sposta solo fuori dallo sguardo, oltre i 950 px. Test aggiunto ([TEST 56]): uno scheletro messo a
oltre 700 px **dietro la roccia**, senza linea di vista, arriva addosso al giocatore entro 30 s e ci arriva
**camminando**, tick per tick; dieci nemici sparsi si avvicinano ma **non superano mai il tetto** addosso
al giocatore; uccidendone tre, tre di quelli in attesa si avviano.

#### 🧪 Un test che era un lancio di dadi
Il **Campo di Lentezza** si verificava confrontando un nemico dentro al campo con uno a 900 px: reggeva
solo perche' quello lontano correva di piu' per il recupero di distanza. Spento quello, il test passava a
seconda del caso. Adesso misura **lo stesso nemico, dallo stesso punto, col campo acceso e col campo
spento** — e la differenza e' quella dichiarata.

**1286 test passati, 0 falliti.**

### [1.79.2] — 2026-09-03 · "I nemici si vedono tutti, le passive smettono di essere regali"

#### 👁 I nemici di un'ondata si vedono TUTTI
C'era una curva che teneva in campo 8 mostri alla prima ondata, 10 alla seconda, fino a 30 dalla decima:
gli altri restavano in coda. Cosi' alzare il numero dei nemici non cambiava niente a schermo — dodici in
lista, otto davanti. Adesso il tetto e' **uno solo e alto: 40**. In singolo nessuna ondata lo supera (la
diciannovesima ne ha quaranta tondi), quindi si vedono tutti; in gruppo, dove le ondate scalano, l'eccesso
continua a entrare in coda man mano che si fa posto. Misurato: 0,10 ms medi e 3,5 ms di picco per tick
contro i 33 disponibili, con 24 mostri in campo.

#### 🗡 Il Troll delle Caverne esce dal gioco
Non compare piu' in nessuna ondata e non e' piu' nel bestiario. La definizione resta nel file — sprite
sheet, slam ad area, la sua IA — ma non e' raggiungibile: buttare quel lavoro non serviva a niente. Gli
archetipi che venivano dopo di lui si fanno avanti di un'ondata ciascuno (Fungo alla 4, Pipistrelli alla
5, Sfera d'Ossa alla 6, Fuoco Fatuo alla 7), se no la rampa restava con un buco.

#### 🩸 L'Offerta di Sangue esce dal Mercante Errante
Dava **+2 vite in cambio di meta' delle monete**. Non era un prezzo: chi ne aveva quaranta ne pagava
venti e si portava a casa due vite — cioe' proprio chi non se le sarebbe dovute permettere. Tolta, con un
test che verifica che non si possano comprare vite cosi' nemmeno costruendo il messaggio a mano.

#### 🎴 Le passive: ritarate, e cinque rifatte da zero
Erano troppo forti, e il difetto era sistematico: quasi ognuna faceva **due cose** ("+15% critico **e**
+0,5× danno critico"), cioe' erano due carte in una.

| Abilita' | Prima | Adesso |
|---|---|---|
| 🎯 Occhio di Falco | +15% critico **e** +0,5× critico | **+10% critico** |
| 🏃 Passo Rapido | +15% vel., −12% scatto | **+10%, −8%** |
| ☠️ Tossina | "forza 2" astratta | **5% del danno del colpo al secondo per 3s** |
| 💠 Scudo Vitale | +25% PV **e 3 PV/s** | **−5% danni subiti, nessuna cura** |
| 🪓 Giustiziere | +70% critico **e** +10% | **+5% critico e +30% danno critico** |
| 🧱 Baluardo | −22% | **−10%** |
| 🗡 Arma Pesante | +25% arco **e** +18% danno | **+8% danno** |
| 🔭 Tiro Lungo | +44% a piena gittata | **+10%** |
| 🏹 Perforazione | +2 nemici | **+1** |

**La rigenerazione di Scudo Vitale era il caso peggiore**: 3 PV al secondo sono una cura continua e
gratis, e toglievano il mestiere all'Ostessa esattamente come facevano gli oggetti che cadevano dai nemici
prima della v1.77.

**Il veleno adesso e' una quota del colpo**, non un numero fisso: cosi' non diventa irrilevante
all'ondata 15 ne' sproporzionato alla prima, e vale uguale per il mago (che picchia forte e lento) e per
il ladro (che picchia piano e veloce) — prima, a colpi al secondo, il ladro ne otteneva il doppio.

#### 🆕 Cinque abilita' nuove, al posto di altrettante sbagliate
- ⚔️ **Colpo Ampio** *(guerriero, non comune)* — ogni nemico in piu' colpito dal fendente aggiunge +5% a
  quel colpo, fino a +15%. Sostituisce **Aura di Spine**, che faceva la stessa cosa di Rappresaglia
  (farsi colpire per fare danno) ed era quindi una scelta finta.
- 🧠 **Concentrazione** *(mago, epico)* — mezzo secondo fermo e il colpo dopo fa +10%. Si consuma: e' un
  colpo piazzato, non uno stato. Sostituisce **Doppia Bolla** (+1 proiettile: era solo "spara di piu'").
- 🔮 **Frattura Arcana** *(mago, divino)* — la bolla che **uccide** si spacca in due bolle al 50%. Si
  autolimita, e le figlie non si dividono a loro volta. Sostituisce **Eco Arcana** (40% dei colpi
  raddoppiati: danno gratis, senza condizioni).
- ⏳ **Campo di Lentezza** *(mago, divino)* — i nemici entro 200 px si muovono il 25% piu' lenti. Zero
  danno: controlla lo spazio, che e' quello che al mago manca. Sostituisce **Implosione**.
- Il **ladro** e' stato rifatto come classe, non come somma di percentuali: 🗡 **Colpo alle Spalle**
  (+20% su chi non ti guarda), 🩸 **Lama Sporca** (i critici aprono un'emorragia del 20% in 3s), 🌫 **Passo
  d'Ombra** (dopo lo scatto il primo colpo e' critico garantito), 🎯 **Punto Vitale** (un critico ogni
  cinque colpi), 🌑 **Uscita di Scena** (sotto il 30% dei PV sparisci dalla vista per 1,5s, ogni 20s).
  Escono **Piede di Porco**, **Sdoppiamento**, **Mira Guidata**, **Furia Cieca** ed **Egida Ostinata**.

Due sinergie hanno cambiato coppia perche' puntavano ad abilita' che non ci sono piu': **Frecce Sporche**
(Perforazione + Lama Sporca) al posto di Cercatore, **Cacciatore di Teste** ora su Colpo alle Spalle, e
**Onda d'Urto** su Colpo Ampio. Restano sei, ognuna raggiungibile da una classe sola.

#### 👁 I tre Beholder, dipinti e finalmente pericolosi
Il Beholder era **una marionetta** — un ritaglio raster con l'iride incollata sopra — e soprattutto **non
attaccava**: applicava debuff e basta, quindi gli si poteva restare davanti tutto il giorno. Adesso sono
**tre creature della stessa famiglia**, dipinte a codice come la caverna (strati di macchie dal buio al
chiaro, bordo sporco, venature, iride bagnata, peduncoli con l'occhietto acceso in punta):

| | PV | Danno | Raggio | Morso | Entra |
|---|---|---|---|---|---|
| 👁 **Occhio Viola** | 120 | 13 | 320 px, 45% | 90 px | ondata **9** |
| 👁 **Occhio di Carne** | 210 | 18 | 340 px, 50% | 105 px | ondata **12** |
| 👁 **Occhio Spettrale** | 260 | 22 | 400 px, 60%, **attraversa i muri** | 95 px | ondata **15** |

Stesso mestiere per tutti e tre: il raggio ruota i tre debuff **e consuma vita** finche' ti tiene nel
cono; sotto la distanza di morso smette di guardare e **azzanna**. Una cosa alla volta.

#### I test
**1272 controlli** (+62). Fra i nuovi: ogni passiva verificata per quello che c'e' scritto sulla carta
(il fendente largo che cresce col numero di nemici e si ferma a +15%, la concentrazione che si carica da
fermo e si consuma col colpo, l'emorragia che parte solo sui critici, la sparizione che non si ripete
finche' la ricarica non e' finita), la famiglia dei Beholder con la scala di pericolo crescente, il raggio
che fa male e il morso che scatta da vicino, e il tetto dei vivi che non nasconde piu' meta' dell'ondata.

### [1.79.1] — 2026-09-03 · "Le prime ondate erano vuote, e la curva era tarata su una misura sbagliata"

Segnalazione dal campo: *«alla quinta ondata, uccidendo solo nemici, ero ancora al secondo livello»*, e le
prime ondate erano troppo facili. Sono lo stesso problema visto da due lati.

#### L'errore di misura, detto per intero
La curva della 1.79 era stata tarata su una simulazione in cui il giocatore uccideva tutto
**istantaneamente**. Uccidendo tutto insieme la **combo** resta incollata al massimo (x2,5), e l'XP che
ne usciva era piu' che doppia di quella vera: 21.925 in una partita contro le **10.900** che i mostri
mettono davvero a terra. Su quel numero gonfiato il livello 15 costava 14.100 — cioe' **piu' di tutta
l'esperienza esistente nella partita**: irraggiungibile per costruzione.

La misura onesta e' l'XP che i mostri di un'ondata lasciano a terra, **senza combo e senza extra**. Sotto
c'e' quella, ondata per ondata, e adesso e' un test.

#### 👾 Piu' nemici, e presto
Il conteggio passa da `5 + 1,8·ondata` a **`10 + 1,6·ondata`**: base piu' alta, pendenza piu' bassa.

| ondata | 1 | 2 | 3 | 4 | 6 | 9 | 14 | 19 |
|---|---|---|---|---|---|---|---|---|
| prima | 7 | 9 | 10 | 12 | 16 | 21 | 30 | 39 |
| **adesso** | **12** | **13** | **15** | **16** | **20** | **24** | **32** | **40** |

Le prime ondate quasi raddoppiano; le ultime restano dov'erano, perche' li' il ritmo andava bene. Il
numero di nemici **vivi insieme** non cambia — quello lo decide il tetto (8 alla prima ondata, 30 dalla
decima) e i mostri in eccesso restano in coda: cambia quanto dura l'ondata, non quanti se ne vedono.

#### 📉 La curva, ritarata sul numero vero
Il livello 15 costa **9.470** invece di 14.100, e i primi scalini sono molto piu' bassi.

| livello | 2 | 3 | 6 | 9 | 12 | 15 |
|---|---|---|---|---|---|---|
| prima | 400 | 1.100 | 3.400 | 6.300 | 9.750 | 14.100 |
| **adesso** | **200** | **500** | **2.040** | **4.230** | **6.640** | **9.470** |

I due scalini d'apertura sono tarati su una condizione precisa, verificata dal test: **col solo bottino
dei nemici**, senza combo, senza casse e senza premio di velocita', il livello **2** arriva entro la
**seconda** ondata e il primo scaglione (livello **3**) entro la **quarta**. Tutto quello che si guadagna
in piu' — combo, casse, tempo obiettivo — anticipa, non serve ad arrivarci.

Cosa mette a terra ogni ondata adesso, misurato (solo nemici, niente combo):

| ondata | 1 | 2 | 3 | 4 | 6 | 9 | 12 | 16 | 19 |
|---|---|---|---|---|---|---|---|---|---|
| XP | 103 | 119 | 158 | 213 | 293 | 383 | 535 | 659 | 745 |
| cumulata | 103 | 222 | 380 | 593 | 1.406 | 2.467 | 3.960 | 6.377 | 8.500 |

#### Il test che impedisce che ricapiti
Nuovo controllo che confronta **le due cose fra loro** invece di fidarsi di una simulazione: quanto
un'ondata mette a terra contro quanto costa il livello. Verifica che le prime quattro ondate bastino per
il primo scaglione, che le prime due bastino per il livello 2, e che il costo del livello 15 stia fra il
60% e il 100% di tutta l'esperienza della partita — sopra e' irraggiungibile, sotto si arriva al tetto a
meta' gioco. **1179 controlli**, tutti verdi.

### [1.79.0] — 2026-08-31 · "Quindici livelli, quattro scelte"

La versione piu' grossa dalla 1.69: cambia come cresce il personaggio, come si spende quello che
guadagna e come si legge il menu fra un'ondata e l'altra. Il progetto completo, con le misure da cui
escono tutti i numeri, sta in **PROGRESSIONE-2.md**.

#### 🎚️ Tetto ai livelli: 15
Dalla 1.70 non c'era: si saliva finche' c'era esperienza, e dall'ondata 12 in poi si saliva **a vuoto**.
Adesso la crescita finisce al 15, dove si sceglie la specializzazione. L'esperienza raccolta dopo non
serve piu' a niente — come in un gioco di ruolo — e non si accumula nemmeno nel serbatoio, cosi' la barra
resta piena e onesta.

#### 🎴 Le carte diventano ABILITA' PASSIVE, a scaglioni
Prima ne arrivava una a ogni livello e se ne accumulavano una decina a run. Adesso sono **quattro in
tutta la partita**, una per **scaglione**, ai livelli **3, 6, 9 e 12**:

| Scaglione | Livello | Cosa fa |
|---|---|---|
| Non comune | 3 | da' forma al colpo base |
| Raro | 6 | aggiunge una regola a come combatti |
| Epico | 9 | definisce la build, e puo' avere un prezzo |
| Divino | 12 | riscrive una regola, e punta alla specializzazione |

Ogni scaglione mostra **quattro abilita': due della tua classe e due neutre**, e se ne sceglie **una**.
Le abilita' di classe le vede **solo** quella classe: un mago non sa nemmeno che esistono quelle del
guerriero, ed e' voluto — e' la rigiocabilita' a cambiare personaggio.

- **32 abilita'** in tutto: 8 neutre e 8 per classe. Le 33 carte di prima ci sono entrate tutte tranne
  tre, e una e' nuova (🌌 **Implosione**, divino del mago: una bolla ogni cinque risucchia i nemici in un
  punto e li blocca).
- **Niente impilamento**: ogni abilita' si prende una volta sola. Con quattro scelte in tutto, spendere
  uno scaglione per raddoppiare la stessa abilita' sarebbe sempre la mossa sbagliata. Per questo i valori
  sono **circa il doppio** della singola copia di prima.
- **Ritirate**: 🪙 Avidita', 🍀 Fortuna Sfacciata e 🧲 Fame Vorace. Sono bonus all'XP raccolta, e col tetto
  ai livelli sono spazzatura per costruzione — allo scaglione divino varrebbero esattamente zero.
- **Due correzioni di equita' fra classi**, non di grandezza: i bonus ai PV neutri diventano
  **percentuali** (il guerriero ha 200 PV e il mago 100: "+30 PV" valeva il triplo per il mago), e il
  veleno si misura **per bersaglio** e non per colpo (a 3 colpi al secondo il ladro ne otteneva il doppio
  del mago: non era una scelta di build, era la cadenza dell'arma).

#### 🔗 Le sinergie diventano scelte di build
Verificato dal test: tutte e sei restano raggiungibili, ognuna da **una sola classe** e a cavallo di
**due scaglioni diversi**. Prenderne una costa meta' delle scelte della run: e' il prezzo giusto, e si
pianifica dal livello 3 invece di capitare per fortuna.

#### 📈 La curva dell'esperienza, rifatta sulle misure
Circa il **doppio** di prima (cumulata al 15: **14.100** contro 6.810), con gli **ultimi due scalini** i
piu' cari della curva. Misurato sul gioco, con un giocatore che uccide tutto e raccoglie tutto:

| arriva il livello | 3 | 6 | 9 | 12 | **15** |
|---|---|---|---|---|---|
| ondata (gioco perfetto) | 4 | 8 | 11 | 13-14 | **16-17** |

Il livello 15 non arriva prima dell'ondata 16 **nemmeno** giocando alla perfezione, in nessuna taglia di
gruppo (misurato da 1 a 6 giocatori: 16,0 - 17,5).

#### 👥 L'esperienza e' CONDIVISA
Ogni uccisione vale per tutti i giocatori vivi: la crescita e' del gruppo, la corsa alla sfera non e' un
gioco. Con una correzione che nasce da una misura: le ondate crescono col gruppo **meno che
proporzionalmente** (un trio genera solo il **+27%** di XP totale rispetto a un solista), quindi ognuno
riceve il valore pieno moltiplicato per un **fattore di gruppo** — 1 · 0,80 · 0,69 · 0,58 · 0,52 · 0,50 —
tarato perche' la curva valga identica da 1 a 6 giocatori. Le monete no: restano di chi le raccoglie.

#### ◆ I punti statistica: costo fisso, conto esatto
**18 punti** in tutta la run (14 dai livelli, 4 dai ranghi) e **1 punto per livello** di statistica, a
qualunque altezza: spariscono gli scaglioni 1/2/3. Il conto e' esatto: cappare una statistica costa 12,
portarne una seconda a 6 ne costa altri 6, totale 18. Cappare **due** statistiche resta impossibile.

#### 🏅 I ranghi seguono gli scaglioni
Non piu' 1/5/10/15/20 ma **3/6/9/12/15**: il rango cade insieme alla scelta. Sei fasce, e a ognuna un
titolo — ne serviva uno in piu' per classe: **Signore delle Lame**, **Magister**, **Spettro**.

#### 🔮 La Cartomante e' chiusa
Struttura, porta e insegna restano nel villaggio; la funzione no. Con quattro abilita' in tutta la run,
tutte sempre accese, non c'e' piu' niente da accendere o spegnere: il tetto delle cinque carte attive e
il concetto stesso di carta *spenta* sono spariti con lei. Verra' ridisegnata.

#### 🧭 Il menu di fine ondata, rifatto
Prima era tutto in colonna nella stessa schermata — riepilogo, carte, punti, negozio, destinazione — ed
era confuso. Adesso sono **quattro sezioni** con una barra in basso, e sotto, **da solo e centrato**, il
pulsante che fa partire la mappa successiva.

- **RIEPILOGO** — si apre da sola: e' la risposta alla domanda che il giocatore ha appena finito di farsi.
- **PERSONAGGIO** — le quattro statistiche e l'**inventario**: salute, vite, arma, equipaggiamento per
  slot, cintura delle pozioni.
- **ABILITA'** — la scelta in sospeso e l'elenco per scaglione, con scritto quando arrivano quelle che
  mancano. Solo le tue: nessuna abilita' di un'altra classe.
- **VAI AL VILLAGGIO** — ci si entra **solo da qui**, mai durante l'ondata, ed e' sempre visitabile. Resta
  una mappa condivisa: ci si entra tutti insieme. **L'uscita riporta al menu**, non fa partire l'ondata.

Due regole che il menu fa rispettare da solo: finche' hai una **scelta in sospeso** il pulsante della
mappa successiva resta **spento** (uno scaglione saltato per distrazione non si recupera piu'), e la
mappa parte **solo** da quel pulsante.

#### 🔒 Le due abilita' attive: gli slot ci sono, spenti
I livelli **6** e **12** sono gli slot destinati alle abilita' attive. Le sei gia' progettate (Turbine,
Giuramento, Catena Nera, Meteora, Marchio, Salva) restano scritte e assegnate, ma **non sono
implementate**: nella barra in basso i due slot si vedono col **lucchetto**.

#### I test
**1170 controlli** nella suite del server (+98) e la suite dell'interfaccia estesa al menu. Fra i nuovi:
la griglia per classe (nessuna classe puo' vedere le abilita' di un'altra), le sinergie ancora
raggiungibili, il tetto e la coda degli scaglioni, i 18 punti spesi fino all'ultimo, l'XP condivisa col
fattore di gruppo, il giro completo menu → villaggio → menu → mappa, e l'implosione che tira i nemici
verso il punto invece di respingerli.

### [1.78.1] — 2026-08-31 · "Il pulsante EXIT a misura"

#### ✂️ Pulsante EXIT dimezzato
Alla prova sul campo era troppo grande. Ridotto del 50% in ogni misura, non solo nel testo — se no
cambiano le proporzioni e sembra un altro pulsante: testo **30 → 15px**, spaziatura fra le lettere
**7 → 3,5px**, imbottitura **19/62 → 10/31px**, angoli **18 → 9px**, alone e ombra a meta'. Lo stato
*in attesa* del multiplayer e' sceso di conseguenza (**20 → 11px**). Resta dov'era: centrato in
orizzontale e un po' sotto in verticale, per non coprire il personaggio.

#### 🟣 La faglia e' spenta, e adesso i documenti lo dicono
Nella copia di lavoro `EDGE_MARGIN` vale **0**: il bordo della mappa non drena vita, non c'e' nessuna
fascia, nessun alone viola, niente sulla minimappa. E' una scelta, non una dimenticanza — ma README e
CARATTERISTICHE continuavano a descrivere un comportamento che nel gioco non c'e'.
- **CARATTERISTICHE.md**: avviso in cima al documento con le manopole spente (la faglia e le abilita'
  attive delle specializzazioni, dichiarate dal v1.69 e mai realizzate), piu' una sezione dedicata; le
  due sezioni storiche sono marcate *«descrizione a faglia accesa»*.
- **README.md**: la stessa nota in breve, prima delle sezioni della Faglia.
- **shared/constants.js**: un commento sopra la manopola dice che e' spenta per scelta e come si
  riaccende. I valori non sono stati toccati.

Il meccanismo non e' stato rimosso: si riaccende rimettendo `EDGE_MARGIN` sopra lo zero, e i test
seguono la manopola in tutte e due le posizioni — a 0 verificano che la faglia sia spenta *davvero*
(nessuna tessera nella fascia, venti secondi sul bordo senza perdere un punto ferita, carica a zero),
sopra lo zero che morda come descritto.

### [1.78.0] — 2026-08-31 · "L'ondata finisce quando lo decidi tu"

Cinque richieste in un colpo solo: font piu' leggibili, l'uscita dalla mappa a pulsante invece che di
scatto, le carte agganciate ai livelli, una sola modalita' di ondata e un riepilogo di fine livello.

#### ✔ La mappa ripulita non ti sbatte fuori
Prima l'ultimo nemico che cadeva ti spediva nel pannello del negozio nello stesso fotogramma: non
facevi in tempo a capire di aver vinto, e quello che era rimasto a terra lo raccoglieva il gioco al
posto tuo. Adesso c'e' una fase in mezzo — **MAPPA RIPULITA** — con la scritta in alto e il pulsante
**EXIT** al centro dello schermo. Si esce quando si vuole.
- Il **cronometro si ferma** al momento dell'ultima uccisione: aspettare non costa il premio di
  velocita' (misurato: ondata chiusa in 10 s, un minuto passato a raccogliere, premio incassato lo
  stesso).
- **Quello che e' a terra non scade** finche' la mappa e' ripulita. Le sfere vivono 30 secondi: senza
  questa regola sparirebbero sotto gli occhi di chi le sta andando a prendere. Si ferma solo la
  scadenza, non la calamita.
- In cooperativa si aspettano **tutti i vivi** (i caduti no, non potrebbero premere niente) e il
  pulsante dice a che punto e' l'attesa. Dopo `EXIT_TIMEOUT` (120 s) si esce comunque: e' l'anti-AFK.
- Il pulsante sta al centro in orizzontale ma un po' **sotto** in verticale: al centro esatto coprirebbe
  il tuo personaggio, che sta sempre li'.

#### 🎴 Le carte si scelgono salendo di livello
Prima ogni fine ondata regalava una carta: il potere arrivava col **calendario**, non col merito.
Adesso la fonte e' una sola — il **livello** — e chi ne guadagna tre ne sceglie tre, una dopo l'altra.
- Quando non sei salito di livello il mazzo non si apre, ma il pannello **dice perche'** ("i poteri
  arrivano salendo di livello: al livello 2 mancano 105 XP") invece di restare muto: un riquadro vuoto
  senza spiegazione si legge come un guasto.
- Il debito si porta dietro: se sali di livello durante un'ondata a cui e' gia' agganciata una carta di
  rango, la carta ti aspetta all'ondata dopo.
- Misura sul ritmo: la prima carta adesso arriva a fine **seconda** ondata invece che della prima, ma
  all'ottava un giocatore solo ne ha **10** invece di 8. Piu' lento all'inizio, piu' generoso dopo.

#### 📊 Il riepilogo di fine livello
Un box in cima al pannello: nemici uccisi, esperienza e monete **di quell'ondata**, quanto e' durata
contro il tempo obiettivo, i livelli guadagnati e il premio del cronometro se sei rimasto sotto. Se sei
finito fuori tempo lo dice, invece di tacere.

#### 🗑 Una sola modalita'
Via **Orda**, **Caccia**, **Sopravvivenza** e **Tesoro**: ogni ondata e' un'ondata normale, e
l'indicazione della modalita' e' sparita dalla mappa perche' non indicava piu' niente. Con loro se ne
vanno lo scrigno fuggitivo (`spawnTreasure`), i suoi tre eventi, i moltiplicatori di XP e monete che
valevano solo per lui e le ondate a tempo fisso.

#### 🔤 +1px su tutti i font del testo
Cento regole del foglio di stile e quindici scritte disegnate sul canvas. **Non** sono cresciuti i
titoli (h1 resta 44px, h2 resta 19px), le icone e le emoji (che sono disegni, non testo) e i numeroni
gia' grandi (vita, combo, contatori).

#### I test
1072 controlli nella suite del server (+46) e la suite dell'interfaccia estesa. Fra i nuovi:
- il **ponte server→HUD** adesso guarda anche i metodi **delegati** da `updateTop` — `snap.ex` viveva
  fuori da `updateTop` e sarebbe passato sotto il radar, che e' esattamente il buco da cui era nato il
  cronometro fermo. Provato contro il codice col difetto: *«persi: ex»*.
- un controllo sui **colori del CSS**: ogni esadecimale dev'essere lungo 3, 4, 6 o 8 cifre e un colore
  dev'essere **un** valore solo. Nato da due errori di battitura veri (`#ffc martedi` in v1.77.2, e un
  ideogramma finito in mezzo a un esadecimale in questa versione): a schermo non si vedono finche' non
  guardi quella riga. Provati entrambi contro il test: li prende.
- la prova che la roba a terra **non scade** sulla mappa ripulita, provata contro il codice senza la
  correzione: *«0/6 sfere, 0/6 monete»*.

### [1.77.3] — 2026-08-30 · "Il cronometro arriva fino all'HUD"

Il cronometro restava fermo su 0:00 anche dopo la 1.77.2. La correzione precedente era vera ma non
era **quella**: avevo verificato lo snapshot del server e mi ero fermato li'.

#### Il difetto vero: un ponte con la lista dei campi scritta a mano
L'HUD non riceve lo snapshot del server. Riceve `G.world`, lo stato **interpolato** del client, e in
`main.js` i campi non-giocatore vanno copiati a mano, uno per uno:

```js
w.wave = next.wave; w.phase = next.phase; w.mcount = next.mcount; ...
```

`wt` e `wp` non erano in quella riga. Il server li mandava, il client li leggeva dal filo e li
buttava un istante dopo — nessun errore, da nessuna parte. Aggiunti.

#### Verificato sul gioco vero, non sul pezzo
Questa volta la prova e' stata: far girare il server, aprire il gioco in un browser, cliccare
*ENTRA IN PARTITA* e *AVVIA LA RUN*, e leggere il cronometro sullo schermo ogni due secondi e mezzo.
Col codice corretto sale (0:04 → 0:06 → 0:09 → 0:11 → 0:14); togliendo la riga della copia torna a
mostrare **⏱ 0:00** fisso, esattamente il sintomo segnalato.

#### Il test che impedisce che ricapiti
Nuovo controllo che confronta due liste prese dal sorgente: i campi che `updateTop` **legge** dallo
snapshot, e i campi che `main.js` **copia** nel mondo del client. Se il server manda un campo che
l'HUD legge e il client non lo copia, il test fallisce dicendo quale. Provato contro il codice col
difetto: *«persi: wt, wp»*.

Provare lo snapshot del server non provava il ponte: e' per questo che due versioni di test non hanno
visto niente.

#### La faglia: i test seguono la manopola
Trovato `EDGE_MARGIN: 0` nella copia di lavoro — non e' una mia modifica, e non l'ho toccata: spegne
la faglia. I test pero' la davano per accesa e fallivano. Adesso il test **segue la manopola**: se
EDGE_MARGIN e' 0 verifica che la faglia sia spenta *davvero* — nessuna tessera nella fascia, venti
secondi sul bordo senza perdere un punto ferita, carica a zero — e se e' maggiore di zero verifica che
morda come prima. La scelta resta di chi gioca; il test garantisce che la manopola funzioni in tutte e
due le posizioni.

#### ✅ Verificato
**1023 test, 0 falliti**, sei esecuzioni di fila, piu' la prova nel browser sul gioco in esecuzione.

---

### [1.77.2] — 2026-08-30 · "Il cronometro cammina"

Segnalato da Paolo: **a inizio partita il cronometro restava fermo su 0:00**.

Un errore da manuale, e vale la pena scriverlo per esteso. Il tempo trascorso si calcolava cosi':

```js
this.time - (this.waveT0 || this.time)
```

Il `||` doveva coprire il caso "waveT0 non ancora impostato". Ma alla **prima ondata** waveT0 vale
*esattamente* 0 — la partita comincia al tempo zero — e in JavaScript lo zero e' falso: scattava il
ripiego, il calcolo diventava `this.time - this.time` e il cronometro segnava zero per tutta la
partita. Dalla seconda ondata in poi funzionava, perche' li' waveT0 e' un numero diverso da zero.

Adesso `waveT0` nasce con la stanza insieme a `parT`, `waveMostri` e `parPreso`: sono sempre numeri
validi, e il ripiego non serve piu' a niente. Il tempo si calcola e basta.

Il **font del cronometro** passa da 13 a 17 px: a 13 si leggeva male mentre si combatte.

#### ✅ Verificato
**1033 test, 0 falliti.** La prova nuova si fa sulla **prima** ondata — e' l'unica in cui waveT0 vale
zero, quindi provarlo a ondata avanzata non avrebbe visto nulla: si lascia scorrere la partita e si
controlla che a 3, 8 e 15 secondi il cronometro segni 3, 8 e 15. Provata contro il codice col bug:
**fallisce tutte e tre le letture** (segnava 0 s ogni volta).

---

### [1.77.1] — 2026-08-30 · "Le vite extra non si comprano dall'Erborista"

Correzione della 1.77, segnalata da Paolo. Il **Cuore di Fenice** era finito nel catalogo
dell'Erborista come pozione da cintura, con un tetto di una carica per slot. Il tetto non bastava:
**l'Erborista e' sempre li'**. Una vita comprabile da lui e' una vita comprabile *ogni volta* che
passi dal villaggio, e le vite si accumulano senza attrito.

Resta solo dal **Mercante Errante**, che compare a caso durante le ondate: e' quella incertezza a
dargli il prezzo vero, non le 180 monete.

- Via la pozione dal catalogo: l'Erborista torna a nove voci, tre delle quali forti.
- Via anche il meccanismo che le serviva — il ramo `kind: 'life'` in `usePotion` e il tetto di cariche
  per singola pozione. Erano stati aggiunti per lei sola e non li usava piu' nessuno: un meccanismo che
  nessuno usa e' una trappola per chi legge. Nel catalogo c'e' scritto dov'e' il posto giusto se un
  domani servisse di nuovo (erano tre righe).

#### E una prova instabile, mia, sistemata
Il test della v1.76 "dietro un masso al centro non si muore" cercava un riparo interno solo nella
finestra centrale della mappa: su qualche seme quella finestra non conteneva massi interni e il test
falliva una volta su sei. Colpa della prova, non del gioco. Adesso cerca su tutta la mappa e chiede la
cosa esatta — una tessera che tocca roccia **non esterna** — con due assunti separati: che i ripari
interni esistano, e che almeno uno sia fuori dalla fascia della faglia.

#### ✅ Verificato
**1027 test, 0 falliti**, sei esecuzioni di fila. I nuovi: nel catalogo dell'Erborista non c'e' nessuna
vita extra, ne' sotto altro nome; il Cuore di Fenice e' ancora fra le merci del Mercante Errante e li'
costa 180 monete.

---

### [1.77.0] — 2026-08-30 · "Niente cade dal cielo, e le ondate hanno un cronometro"

#### I nemici non lasciano piu' oggetti
Nessuno: ne' i comuni, ne' gli elite, ne' i boss, ne' la cassa-mima. Prima cadeva un oggetto nel 9%
delle uccisioni (35% sugli elite, sempre su boss e mime), e fra quelli c'era la **Pozione di Salute**.
Una cura che arriva gratis dal nulla mentre combatti toglie il mestiere all'**Ostessa**, che si fa
pagare per rimetterti in piedi, e all'**Erborista**, che si fa pagare per la stessa cosa in boccetta:
se la cura piove dai mostri, quei due sono decorazione.

Restano **esperienza**, **monete** e quello che c'e' dentro le **casse** — che non sono nemici.

#### Le quattro pozioni forti, dall'Erborista
Gli effetti rari che cadevano a terra non spariscono: si comprano. Riusano le stesse chiavi che il
motore leggeva gia' per gli oggetti, quindi l'effetto e' identico — cambia chi te lo da'.

| Pozione | Effetto | Prezzo |
|---|---|---|
| 🔺 **Nucleo Instabile** | +50% danno per 12 s | 110 |
| 💥 **Ira Berserk** | danno raddoppiato e +40% cadenza per 8 s | 185 |
| ✨ **Egida Divina** | invulnerabile per 5 s | 270 |
| 💗 **Cuore di Fenice** | +1 vita — **una sola carica per slot** | 240 |

Sono deliberatamente care: la piu' economica costa piu' del doppio della piu' cara fra le sei di
base, e una sola carica di Egida costa piu' di una cintura intera delle vecchie. La regola e' che una
risposta potente si **paghi**, non che **capiti**. Il Cuore di Fenice ha un tetto suo di **una**
carica: tre vite di scorta in cintura renderebbero la morte una formalita'.

#### Il cronometro dell'ondata
Sotto il nome della mappa compare **⏱ tempo trascorso / tempo obiettivo**. Il colore e' l'informazione:
**verde** sei dentro, **ambra** ti restano meno di dieci secondi, **spento** obiettivo perso. Chi non
guarda i numeri legge comunque il colore con la coda dell'occhio.

Il tempo obiettivo **non e' un numero fisso**: un'ondata da 7 mostri e una da 41 non possono avere lo
stesso limite. Si calcola dal contenuto — `25 s + 3,2 s per mostro, diviso i giocatori in piedi`:

| | ondata 1 (7 mostri) | ondata 3 (15) | ondata 11 (38) | ondata 20 (41) |
|---|---|---|---|---|
| da solo | 47 s | 73 s | 147 s | 156 s |
| in tre | 36 s | 49 s | 83 s | 88 s |

Chi chiude dentro il tempo prende **+25 XP +8 per ondata** e **+12 monete +3 per ondata** — all'ondata
10 sono 105 XP e 42 monete, quanto un pezzo di equipaggiamento leggero.

Le ondate a **sopravvivenza** sono escluse per costruzione: durano un tempo fisso, non si possono
chiudere prima, e un premio che tocca sempre non e' un premio. Li' il cronometro conta e basta.

I due numeri (`PAR_BASE` e `PAR_PER_MOSTRO`) sono la manopola, e stanno in `constants.js` con scritto
cosa fa ciascuno: il primo regala tempo a tutte le ondate, il secondo soprattutto a quelle affollate.

#### Come ho scelto i tempi
Misurando. Il **pavimento assoluto** — giocatori invincibili che uccidono all'istante — sta fra 1,4 e
7,6 secondi: i mostri entrano in campo subito, quindi il tempo lo fa il combattimento e non la coda di
generazione, e un limite basato sul numero di mostri ha senso. Il pilota automatico dei test e' troppo
scarso per fare da metro (chiude l'ondata 1 in 115 secondi mediani, con punte di 473): i numeri qui
sopra sono tarati generosi apposta, e restano da ritoccare dopo averci giocato davvero.

#### ✅ Verificato
**1029 test, 0 falliti**, tre esecuzioni di fila. I nuovi: su 362 nemici uccisi — elite, boss e
cassa-mima compresi — non cade un solo oggetto, mentre esperienza e monete continuano a cadere; le
quattro pozioni forti esistono, costano piu' del doppio delle base e coprono i tre effetti che prima
cadevano a terra; del Cuore di Fenice si compra una carica sola e bevendolo si guadagna una vita; il
tempo obiettivo scala col numero di mostri; chiudendo in tre secondi il premio scatta e porta monete,
chiudendo trenta secondi oltre no; e nelle ondate a sopravvivenza il tempo obiettivo non esiste.

---

### [1.76.1] — 2026-08-30 · "I nemici non si teletrasportano"

Segnalato provando la 1.76: **scappando, ogni tanto i nemici comparivano addosso**. Non era
un'impressione, ed erano due meccanismi diversi.

#### Il recupero anti-stallo
Esisteva per una ragione buona — che un'ondata non resti aperta per sempre perche' un mostro e'
finito dove non puo' piu' raggiungerti — ma era scritto male: **se per 6 secondi il numero di mostri
non calava, teletrasportava TUTTI i mostri a 240 px da un giocatore**. Scappare senza uccidere e'
esattamente quella condizione, e allora il branco ti compariva addosso.

Adesso la regola guarda il **singolo mostro**, e ne sposta uno solo se tutte e tre valgono:

1. non si e' avvicinato di un metro al giocatore piu' vicino **da 5 secondi**;
2. sta comunque **oltre 640 px** — se ti e' addosso non e' bloccato, sta combattendo;
3. non e' uno di quelli fermi per costruzione (il Fungo sta piantato: e' il suo mestiere).

E chi si sposta va **oltre i 950 px e in un punto da cui non lo vedi**. Se un posto cosi' non si
trova, non si sposta niente e si riprova fra cinque secondi: meglio un'ondata piu' lunga di qualche
secondo che un mostro che si materializza in mezzo allo schermo.

#### Le caselle di generazione
Le caselle da cui nascono i nemici sono scelte lontane dalla **partenza**. Ma un'ondata dura minuti e
tu nel frattempo ti sei spostato: una casella lontana dal punto di atterraggio puo' trovarsi a due
passi da dove sei adesso. Adesso se ne pescano ventiquattro e si tiene la migliore — lontana almeno
520 px **e possibilmente fuori dalla tua linea di vista**.

#### ✅ Verificato
**992 test, 0 falliti**, sei esecuzioni di fila.

Il test nuovo riproduce esattamente la segnalazione: 25 secondi di fuga senza uccidere nessuno, e
**nessun nemico in vista puo' avvicinarsi piu' di quanto le sue gambe permettano** in un tick. Piu'
la controprova, che il recupero funzioni ancora: un mostro che non fa progressi da cinque secondi
viene comunque rimesso in gioco, e lontano.

Il test e' stato provato contro il codice VECCHIO e **fallisce** (75 px guadagnati in un tick, e il
mostro rimesso a 240 px): non e' una prova che passa per costruzione.

Due errori miei lungo la strada, tenuti nei commenti:
- la prima versione del test filtrava sulla distanza **prima** del tick e scartava tutto oltre gli
  800 px — cioe' scartava esattamente il caso che conta, il mostro lontano che ti compare addosso.
  Con quel filtro passava anche col codice vecchio: non provava niente.
- il primo ricollocamento mandava il mostro a 600-900 px, e 600 px sono **dentro lo schermo**. Se
  n'e' accorto il test stesso: 619 px guadagnati in un tick sotto gli occhi del giocatore.

Prova di tenuta fuori dalla suite: **sei partite da 60 secondi di fuga continua, 10.800 tick, zero
scatti in vista**.

---

### [1.76.0] — 2026-08-30 · "La caverna dipinta"

Le mappe di combattimento erano il punto debole del gioco: pietra piatta, muri disegnati come
rettangoli neri, e quasi niente sopra. Rifatte da capo — pianta, pavimento, muri, pietrisco — con le
battlemap disegnate come bersaglio. Il villaggio non e' toccato: ha il suo aspetto e se lo tiene.

#### Prima la pianta, perche' e' quella che decide se si gioca bene
La mappa passa da **46x34 a 64x46 tessere** (3072x2208 px invece di 2208x1632). Area calpestabile da
**1041 a ~1330 tessere** (+28%), e lo spazio libero attorno — quello che conta per non farsi
incastrare — da **0,78 a 1,16** (+49%).

Il vincolo che tiene tutto in piedi e' misurato, non sperato: **zero tessere-strozzatura**. Una
tessera-strozzatura e' una tessera che, tolta, spezza la mappa in due; zero significa che da ogni
camera si esce sempre da almeno due parti. C'e' un passaggio che le cerca (visita di Tarjan, una
sola passata) e le allarga finche' non ce n'e' piu'.

Tre archetipi — **anello**, **quadrifoglio**, **stella** — piu' le **dorsali**, schiene di pietra che
attraversano e obbligano a scegliere da che parte girarle.

Come si costruisce: si scava UNA caverna grande e irregolare, poi ci si mettono dentro **masse di
roccia** a scolpire le camere. Lo spazio giocabile resta grande e continuo, la struttura la fanno gli
ostacoli. La quantita' di roccia non e' un numero scelto a mano — e' un **budget**: la roccia interna
arriva al 26% della caverna e ci si ferma li'.

#### Poi l'aspetto
- **Il pavimento e' QUIETO**: macchie morbide, crepe lunghe e sottili, giunti appena accennati,
  nessun contorno. **I muri sono RUMOROSI**: massa quasi nera, massi col contorno spesso, ombra
  proiettata dentro la stanza. E' questa scala di rumore a dire all'occhio dove si cammina.
- **Il pietrisco**: massi, grappoli di macerie, ossa sparse, chiazze di sporco — tutti col contorno a
  inchiostro, tutti piu' chiari del pavimento su cui stanno.
- **La palette esce dal tema**: cripta, lava, ghiaccio, foresta e arcano restano diversi. Cambia il
  modo di disegnare, non l'identita' della mappa.

Misurato con lo stesso metodo sulle immagini di riferimento: **luminanza mediana da 18 a 48** (le
battlemap dipinte stanno a 44 — a 18 era cosi' buio che non si vedeva niente di quello che c'era) e
**densita' di contorni dall'1,3% all'8,3%** (il riferimento sta al 6,6%).

#### Quattro bug veri, trovati portandolo nel motore
- **`floodReach` murava la mappa intera.** Partiva dal centro geometrico; con la caverna il centro
  puo' essere roccia, la visita non partiva e il blocco che mura le sacche staccate murava tutto: 4
  mappe su 400 senza portale, con 2944 tessere di muro su 2944. Corretto una prima volta partendo
  dalla prima tessera libera — e sbagliato di nuovo, perche' la prima che si incontra puo' essere una
  sacca isolata da una tessera. La regola giusta non e' "da dove parto" ma "cosa tengo": si tiene la
  **componente piu' grande**.
- **La faglia aveva smesso di mordere.** La profondita' si misurava dai bordi del rettangolo; con la
  caverna rientrata, la fascia toccava il 10% delle tessere invece del 30% e arrivava a profondita' 3
  invece di 6. Adesso si misura dalla **roccia esterna** — quella che confina col bordo della mappa,
  non i massi interni, se no stare al riparo dietro un sasso sarebbe letale. Fascia profonda due
  tessere, copertura 34%, tarata sulla misura e non a occhio.
- **La radura di partenza non era piu' garantita.** Si cercava solo entro 7 tessere dal centro; se
  quella zona era roccia si ripiegava su una tessera qualunque, magari incastrata. Mezzo gioco da'
  per scontato che attorno alla partenza ci sia spazio (i nemici nascono a 200-260 px con la linea di
  vista libera). Adesso si cerca la radura piu' ampia su tutta la mappa, e a parita' la piu' vicina
  al centro. Raggio libero minimo misurato su 80 mappe: **4 tessere**.
- **Il recupero anti-incastro non bastava piu'.** Cercava pavimento entro 3 tessere: dentro una massa
  di roccia della pianta nuova non ce n'e'. Sette mostri piantati nel muro in una partita. Portato a 8.

#### Due errori miei, scritti nel codice perche' non li rifaccia
- **Allargare "dove e' stretto"** invece che i ponti che servono: ogni scavo crea nuove tessere che
  soddisfano la condizione, l'erosione va a cascata e in otto passate si mangia tutta la roccia
  (area da 1350 a 2470 su 2944). Adesso si guarda il grafo delle celle larghe abbastanza per un boss
  e si scava **solo il cammino piu' corto** fra i pezzi scollegati.
- **Cercare le strozzature a forza bruta**, un flood fill per tessera: su 1350 tessere sono 1,8
  milioni di passi per chiamata e la suite dei test e' andata in timeout. Rifatto con la visita di
  Tarjan: 10 mappe in 154 ms.

#### ✅ Verificato
**987 test, 0 falliti**, sei esecuzioni di fila. Su 400 mappe generate: nessuna rotta, pavimento
minimo 736 tessere, zero tessere-strozzatura, e il boss arriva all'uscita in tutte. Tre prove che
fallivano a intermittenza sono state stabilizzate alla radice (la radura di partenza), non zittite.

---

### [1.75.3] — 2026-08-30 · "Soglie sgombre"

Tre correzioni trovate provando la 1.75.2. Finche' i mobili erano decorazione non davano fastidio; da quando
hanno un corpo, un mobile appoggiato accanto a una porta e' uno spigolo che prendi **ogni volta** che entri.

- **Via le due casse della piazza**: stavano davanti all'osteria e davanti alla gilda delle taglie.
- **Via la rastrelliera davanti all'ingresso della fucina** (ne restano quattro, alle spalle del fabbro e
  sulla parete est in basso).
- Adesso tutte e cinque le porte hanno lo **stesso passaggio libero: 98 px**, tre volte e mezzo la larghezza
  del personaggio. Il varco del portale ne ha 146.

#### ✅ Verificato
**989 test, 0 falliti** (erano 987).

Il primo test che avevo scritto misurava la **distanza dal mobile piu' vicino** e non funzionava: una cassa
piantata davanti alla porta e un tavolo che sta due tile *dentro* la stanza danno lo stesso numero (66, 83 e
90 px le tre cose tolte; 85 px il primo tavolo della taverna, che ci sta benissimo dov'e'). Nessuna soglia
numerica li separa.

Quello che si misura adesso e' la **luce**: quanto passaggio libero resta davvero attraversando la porta,
corpi solidi inclusi. Deve essere almeno il doppio della larghezza del personaggio — oggi e' tre volte e
mezzo. In piu' un controllo diretto: **nella piazza non ci sono casse**, che e' esattamente cio' che
stava davanti all'osteria e alle taglie.

---

### [1.75.2] — 2026-08-30 · "I mobili hanno un corpo"

Attraversare un tavolo da parte a parte faceva sembrare il villaggio un disegno invece che un posto. Adesso
**mobili e persone sono ostacoli veri**: ci sbatti contro e ci giri attorno.

- **Hanno un corpo**: tavoli, banconi, credenza, scaffali, rastrelliere, incudine, aiuole, alambicco,
  mortaio, casse, botti, sacchi, bracieri, candelabri, cristalli, il cartello e il falo'.
- **Anche le persone**: i cinque mercanti e le otto comparse. Dietro il bancone non ci si passa piu' in
  mezzo.
- **Si attraversa** cio' che e' basso, appeso o dipinto a terra: tappeti, pozze di lava, ragnatele,
  stendardi, teschi, lanterne (stanno sul soffitto), le pietre attorno al falo' e **gli sgabelli** — solidi
  darebbero solo fastidio fra il tavolo e chi ci gira attorno.
- **Se ti ritrovi incastrato, ti spinge fuori.** Un teletrasporto o uno scatto possono depositarti dentro un
  mobile: si esce dal lato piu' vicino, mai dentro la roccia. E se sei stretto *fra due* corpi — fra il
  tavolo e chi ci sta seduto attorno — le due spinte si annullerebbero a vicenda, quindi in quel caso si
  smette di negoziare e si cerca il punto libero piu' vicino girando in tondo.
- **Vale solo nel villaggio.** Fuori non ci sono mobili, e nelle ondate un secondo insieme di corpi solidi
  in mezzo a mostri e proiettili sarebbe un rischio senza guadagno. Fuori dal villaggio la collisione costa
  esattamente quanto prima: un confronto con `null`.

#### ✅ Verificato
**987 test, 0 falliti** (erano 929).
I nuovi: i corpi esistono solo nel villaggio; ha un corpo **esattamente** cio' che deve averlo (26 mobili +
13 persone = 39 corpi) e ogni oggetto del villaggio e' classificato, o solido o attraversabile; con i corpi
attivi si arriva ancora **a parlare con tutti e cinque i mercanti** e al portale; **nessuna zona libera
resta tagliata fuori** dai mobili; camminando in **sedici direzioni per 260 passi ciascuna** non si finisce
mai dentro un corpo; messi dentro un tavolo, un bancone, un mercante o una comparsa si viene spinti fuori
entro 110 px e mai nella roccia; e chi non e' incastrato non viene spostato di un pixel.

---

### [1.75.1] — 2026-08-30 · "Porte piu' larghe"

Correzione trovata provando la 1.75: **le porte fra le stanze erano larghe una sola tile** — 48 pixel
contro un personaggio largo 35. Ci si passava a pelo, sfregando lo stipite a ogni ingresso.

- **Ogni porta e' larga due tile** (96 px): il doppio dello spazio, e il passaggio si legge come una porta
  invece che come una fessura. La griglia lavora a tile intere: fra una e due non c'e' nulla in mezzo.
- **Il varco verso il portale e' largo tre tile**: e' la strada principale del villaggio, e con un numero
  dispari resta centrata sull'uscita.
- **Taverna ed erboristeria guadagnano una riga** (fino a y=11): serviva perche' la loro porta si affacci
  sul fianco della piazza e non sullo spigolo, dove qualunque corridoio resterebbe stretto una tile.

#### ✅ Verificato
**927 test, 0 falliti.** Il nuovo controlla il **confine di ogni porta**: se un corridoio tocca una stanza
o la piazza con una sola tile, il test fallisce. Tutte e 385 le tile calpestabili restano raggiungibili a
piedi dallo spawn, e nessun mobile o personaggio finisce nella roccia.

---

### [1.75.0] — 2026-08-30 · "Il villaggio a micro-stanze"

La sala unica e' finita. Cinque figure in piedi dentro un rettangolo non raccontavano niente, e le nicchie
erano una mezza misura. Adesso **ogni mestiere ha la sua stanza**, con la sua porta, il suo pavimento e i
suoi mobili: e' la **pianta** a dire chi fa cosa, prima ancora dei nomi.

#### La pianta
Una **piazza centrale** col falo' — si atterra li', e li' torna il portale. Attorno, cinque stanze
attaccate da corridoi corti: **nessuna e' a piu' di due passi dalla piazza**, e da li' si vedono tutte le
porte. Il villaggio si attraversa, non si esplora.

| Stanza | Chi ci sta | Cosa c'e' dentro |
|---|---|---|
| **Taverna** (pavimento di legno) | Ostessa | bancone, credenza con le bottiglie alle sue spalle, due file di tavoli con gli sgabelli, botti, lanterne appese |
| **Antro** (lastre viola) | Cartomante | tappeto, tavolo, candelabri, scaffale di libri e mazzi, grappoli di cristallo viola |
| **Erboristeria** (terra battuta) | Erborista | bancone, alambicco, mortaio, scaffali, **tre aiuole in fila** (niente piu' funghi a caso) |
| **Fucina** (lastre rossastre) | Fabbro | bancone, incudine, **quattro rastrelliere d'armi**, la colata di lava in fondo, bracieri |
| **Gilda dei Contratti** (lastre) | Capitano | bacheca **TAGLIE**, bancone, stendardi, scaffali dell'usato, casse in ordine |

#### Le persone
- **I mercanti non sono piu' ritratti frontali.** Erano un pugno in un occhio in una mappa vista dall'alto.
  Adesso nascono dalla **stessa silhouette dei tre eroi**, ricolorata mestiere per mestiere e **disarmata**
  (niente elmo, scudo, arco o bastone): in mano hanno solo l'attrezzo del loro lavoro.
- **Ognuno ha il suo alone di luce**, del suo colore: e' cosi' che lo riconosci da lontano, al buio.
- **Il Banditore e' diventato il Capitano** della Gilda dei Contratti: un ufficiale che appende le taglie e
  ricompra l'attrezzatura dei caduti. Era il personaggio meno riuscito — un tizio con un cartello. La chiave
  interna resta `crier`/`bnd`: cambia la persona, non l'impianto.
- **Otto comparse** in piedi attorno ai tavoli e per le strade. Non parlano e non vendono, ma senza di loro
  il posto sembrava abbandonato invece che abitato. (Sedute non funzionavano: dall'alto una figura seduta e'
  un ovale con una testa.)

#### Come si aggiunge una stanza
Una riga in `ROOMS` (rettangolo, pavimento, colore) e una in `LINKS` (il corridoio che la attacca alla
piazza). L'arredo sta in una sezione per stanza dentro `generateMarket`. La mappa passa da **26x22 a 34x26**
tile e adesso espone `floors`, un rettangolo di pavimento per stanza, che il renderer disegna prima di tutto
il resto.

#### ✅ Verificato
**927 test, 0 falliti** (erano 893) piu' i controlli del client.
I nuovi: si scava solo dove previsto e non resta roccia dentro le stanze; **dallo spawn si raggiunge ogni
singola tile calpestabile** (352 su 352), portale compreso; ogni stanza e' collegata alla piazza; ogni
mercante sta dentro la stanza del suo mestiere e ha un colore diverso dagli altri; niente mercanti, comparse
o mobili dentro la roccia; **il renderer sa disegnare tutti i 26 tipi di arredo** (un tipo scritto male
sarebbe un oggetto invisibile); l'arredo sta in una stanza, nella piazza o lungo un corridoio, mai altrove.

---

### [1.74.1] — 2026-08-30 · "Nessuna cura automatica"

Correzione trovata provando la 1.74: **a ogni fine ondata il gioco curava il 25% dei PV massimi**, in
silenzio e gratis. Era lì da molte versioni, e rendeva l'Ostessa un lusso invece che un servizio: bastava
aspettare la fine dell'ondata. Rimossa.

- **I danni si portano dietro.** Chiudere un'ondata non ridà più niente: per rimettersi in piedi si paga
  l'Ostessa, si beve una pozione o si raccoglie un potenziamento.
- **Chi è a terra viene comunque rialzato** al 60%: quello non è curare, è rimettere in gioco chi
  altrimenti resterebbe fuori per sempre.
- Allineate due porte secondarie che sfuggivano alla regola della 1.74: l'offerta **"+PV massimi" del
  Mercante Errante** e la **Benedizione "+40 PV" del Mercante Nero** ora alzano il tetto e basta.

#### Le vie che restano per curarsi
Tutte richiedono che qualcuno paghi, beva, raccolga o compia qualcosa:

| Via | Quanto | Come si ottiene |
|---|---|---|
| **Ostessa** | quanto paghi | 0,4 monete a PV |
| **Pozione di Cura** | 40% dei PV max | comprata dall'Erborista |
| **Pozione di Rigenerazione** | 10 PV/s per 8 s | comprata dall'Erborista |
| **Pozione di Salute** | 35% dei PV max | raccolta a terra |
| **Bende del Viandante** | 55% dei PV max | 45 monete al Mercante Errante |
| **buff Vigore** | 8 PV/s per 10 s | uscito da una cassa |
| carta **Vampirismo** | 4% del danno inflitto | carta scelta a fine ondata |
| carta **Scudo Vitale** | 2 PV/s | carta scelta a fine ondata |
| carta **Ultima Occasione** | risorgi al 50% | carta scelta, una carica |
| sinergia **Sete di Sangue** | +6% dal danno | Vampirismo + Adrenalina Pura |
| **aura del Paladino** | 2%/s ai compagni, 1%/s a sé | specializzazione di rango V |
| **combo di 40** | 25% dei PV max | 40 uccisioni concatenate |
| rianimazione | 50-60% | un compagno, o la fine dell'ondata se sei a terra |

#### ✅ Verificato
**893 test, 0 falliti.** I nuovi: i PV con cui finisci un'ondata sono quelli con cui inizi la successiva,
e restano tali anche dopo tre ondate; chi è a terra torna comunque in gioco; pozione, oggetto e Ostessa
curano ancora; nessuna delle quattro porte che alzano il massimo (Costituzione, Colosso, Scudo Vitale,
Mercante Errante) restituisce un PV; l'equipaggiamento non cura; e un controllo sul codice sorgente che
non ricompaia da nessuna parte un aumento diretto dei punti ferita.

---

### [1.74.0] — 2026-08-30 · "L'Ostessa, e i PV massimi non curano più"

Il villaggio è **completo**: tutte e cinque le botteghe lavorano.

#### 🍺 L'Ostessa — il riposo a pagamento
Per ora fa una cosa sola: ti rimette in piedi. Il resto verrà.

- Si paga **a punto vita**, non a forfait: **0,4 monete per ogni PV** che ti manca. Un prezzo fisso sarebbe
  un affare quando sei quasi morto e uno spreco quando ti manca poco — in entrambi i casi non una scelta.
- **Se le monete non bastano compri quello che puoi**: con 28 monete ti rende 70 PV. Da lì non si esce mai
  a mani vuote.
- Resta **più conveniente della pozione di Cura** (0,4 contro 0,54 a PV): la pozione però la bevi in mezzo
  ai nemici, e quella differenza è il prezzo della comodità.

#### ❤️ La regola nuova: alzare i PV massimi non cura
Questa tocca tutto il gioco, ed è la ragione per cui l'Ostessa ha un mestiere.

- Un punto di **Costituzione** alza il massimo di 20 e **non restituisce un solo PV**. Prima ne curava 20:
  con quella regola l'Ostessa sarebbe stata inutile dal primo giorno.
- Stessa cosa per le carte **Colosso** (+45) e **Scudo Vitale** (+30): danno massimo, non salute. Le loro
  descrizioni ora lo dicono.
- Rimettersi in piedi resta possibile in tre modi: la **pozione di Cura**, i **potenziamenti** raccolti a
  terra e l'**Ostessa**.

**Il dettaglio che poteva rompersi.** Spegnere una carta dalla Cartomante abbassa il massimo e taglia i PV
in eccesso; se riaccendendola non tornassero, ogni giro costerebbe vita e la Cartomante diventerebbe una
tassa. Quindi il taglio non si perde, si **segna**, e viene restituito solo quando il massimo risale — mai
più di quanto era stato tolto. Accendere e spegnere resta **neutro al punto**, e nessuna via cura di
striscio. Il riposo comprato all'Ostessa **cancella il segno**: quei PV li hai già pagati.

#### 🏘️ Villaggio
**Nessuna bottega chiusa.** Fabbro, Erborista, Banditore, Cartomante e Ostessa.

#### ✅ Verificato
**879 test, 0 falliti.** Fra gli altri: sei punti di Costituzione di fila non curano di un PV, né lo fanno
Colosso e Scudo Vitale; il prezzo del riposo è proporzionale e non forfettario; la cura parziale rende
esattamente i PV pagati; a PV pieni non si paga; da lontano il focolare non risponde; il riposo è più
economico a PV della pozione, come da taratura; e la sequenza completa spegni-carta → prendi-danni →
paga-l'Ostessa → riaccendi-carta non regala neanche un punto vita. Più 15 controlli sull'interfaccia nei
cinque stati del pannello.

---

### [1.73.0] — 2026-08-30 · "Cinque carte, e un posto dove guardarle"

Quarta bottega, e una riorganizzazione dell'HUD.

#### 🔮 La Cartomante — cinque carte accese
Niente previsione delle ondate e niente respec (idee scartate). Fa una cosa sola: decidere **quali carte
tieni accese**, al massimo **cinque**.

- Il limite conta **carte diverse**: Rimbalzo ×3 occupa un posto solo, così approfondire una carta resta
  una strategia e non una tassa.
- Quando ne scegli una a fine ondata e ne hai già cinque accese, **la prendi lo stesso ma arriva spenta** —
  non ti blocca mai a fine ondata, e ti dà un motivo per passare dalla Cartomante.
- Le carte spente **restano tue** per sempre. Spegnere è sempre concesso, accendere solo se c'è posto.
- Le **sinergie** seguono le carte accese: spegnerne una spegne anche la sinergia che formava.

#### ⚙️ Il pezzo rischioso: il ricalcolo da zero
Fino alla 1.72 le carte, quando le sceglievi, **si sommavano dentro il personaggio e non uscivano più**.
Per poterle spegnere, ora tutto si ricostruisce da zero a ogni cambio — statistiche base → statistiche
comprate coi punti → carte accese → sinergie — esattamente come già faceva l'equipaggiamento dalla 1.67.
Con effetti che si possono togliere, sommare i delta lascerebbe in giro il bonus della carta spenta per
sempre, e nulla se ne accorgerebbe.

Due punti delicati, entrambi coperti dai test:
- **I PV.** Alcune carte alzano il massimo *e* curano di altrettanto. Al ricalcolo la cura non va rifatta,
  ma se il massimo sale quella differenza va data, e se scende i PV vanno tagliati al nuovo tetto —
  altrimenti spegnere e riaccendere sarebbe una pompa di vita infinita.
- **Ultima Occasione.** La carica si consuma giocando: spegnere e riaccendere la carta non la resuscita.

#### 🧑 Il box del personaggio
Fra la barra delle abilità e la boccetta della vita c'era un vuoto. Ora c'è un box che raccoglie tre cose
che prima erano sparse o invisibili:
- **nome, livello e rango**, che stavano **sopra la testa** — in mezzo all'azione, proprio dove serve
  vedere. Sopra la tua testa non c'è più nulla; sopra i **compagni** restano, altrimenti in co-op tre
  sagome uguali diventano indistinguibili;
- la **barra dell'esperienza**;
- le **cinque caselle delle carte**, con quelle vuote ben visibili: il tetto di cinque è una regola, e una
  regola che non si vede non esiste.

La vecchia barra dei gettoni in basso (`#boonBar`) è stata **rimossa**: mostrava le stesse icone senza dire
a chi appartenessero né quante se ne potessero tenere accese.

#### 🏘️ Villaggio
Resta chiusa solo l'**Ostessa**.

#### ✅ Verificato
**847 test, 0 falliti.** Il grosso è sul ricalcolo: spegnere toglie davvero il bonus (non resta attaccato),
riaccendere riporta al valore **identico**, dieci giri di spegni/accendi non fanno derivare i numeri di un
millesimo, le statistiche comprate coi punti sopravvivono, il tetto non si aggira dal client, i PV si
comportano nei tre casi (sale, scende, pieni) e otto giri non regalano vita, la carica di Ultima Occasione
spesa non torna, e le sinergie si accendono e si spengono con le carte. Più 22 controlli sull'interfaccia.

---

### [1.72.0] — 2026-08-29 · "Il Banditore: niente si butta"

Terza bottega ad aprire, e fa due mestieri.

#### 📦 Il magazzino — l'equipaggiamento non sparisce più
Fino alla 1.71, comprare l'alabarda faceva **svanire nel nulla** lo spadone che avevi pagato 230 monete.
Adesso tutto quello che compri resta **tuo**:
- dal **Fabbro** lo rimetti addosso **gratis** — l'hai già pagato, e il negozio ora lo dichiara (*GIÀ TUO ·
  GRATIS*) invece di richiedere il prezzo pieno;
- dal **Banditore** lo vendi a **metà prezzo**.

Così vendere diventa una scelta e non un automatismo: incassi 235 per l'alabarda adesso, ma se poi la
rivuoi la ripaghi 470. Gli oggetti di partenza non si vendono — valgono zero e toglierli lascerebbe lo
slot senza un fondo a cui tornare. Nemmeno quello che hai addosso si vende.

#### 🪧 Le taglie
Al banco trovi **tre incarichi**, sempre di **tipo diverso**, e ne accetti **uno**. Vale finché non lo
completi: **nessuna scadenza**, il conto prosegue ondata dopo ondata. Le offerte si generano una volta e
restano quelle finché non ne prendi una — riavvicinarsi non le rimescola, altrimenti sarebbe una slot
machine da ripescare finché non esce quella comoda.

| Taglia | Cosa chiede | All'ondata 6 | Paga |
|---|---|---|---:|
| 💀 Caccia grossa | uccidi N nemici | 38 nemici | 108 |
| 🎯 Contratto mirato | uccidi N di una specie | 11 × Melma Corrosiva | 124 |
| 👑 Teste grosse | uccidi N élite | 3 élite | 156 |
| 📦 Saccheggio | apri N casse | 4 casse | 91 |
| 🔥 Catena di sangue | raggiungi una combo di N | combo 24 | 129 |
| 🛡️ Nessun caduto | supera un'ondata senza perdere una vita | — | 172 |

Bersagli e paga crescono con l'ondata. Una taglia vale circa **due o tre ondate di guadagno** e ne richiede
altrettante: paga bene senza scavalcare la progressione. Le taglie sono **personali**: in co-op ognuno ha
la sua.

La taglia accettata resta **visibile in partita**, in alto a sinistra, con la barra di avanzamento — una
taglia senza scadenza che non si vede mentre giochi è una taglia che si dimentica.

#### 🏘️ Villaggio
Restano chiusi solo **Cartomante** e **Ostessa**.

#### ✅ Verificato
**809 test, 0 falliti.** Fra gli altri: il magazzino che parte con l'equipaggiamento iniziale, il
riequipaggiamento a costo zero, la rivendita a metà esatta, il rifiuto di vendere ciò che si ha addosso o
ciò che è di partenza, il banco che non risponde da lontano, le tre offerte tutte di tipo diverso che **non
si rigenerano**, la taglia unica, **ognuno dei sei tipi portato a compimento** con la paga dichiarata, il
contratto mirato che ignora la specie sbagliata, la combo contata come **record** e non come somma, gli
agganci veri (uccidere, aprire una cassa, perdere una vita) verificati sul gioco e non sul contatore, e un
controllo che nessun tipo del catalogo resti senza qualcuno che lo incrementa in `Room.js`. Più 21
controlli sull'interfaccia con DOM finto.

---

### [1.71.0] — 2026-08-29 · "L'Erborista apre bottega"

Il villaggio aveva cinque banchetti e un solo mestiere che vendeva davvero. Apre il secondo: **l'Erborista**,
e con lui l'unica cosa del gioco che si **consuma**.

#### 🧪 La cintura: tre slot, tre tasti
Tre slot, tasti **1 2 3**, massimo **3 cariche** per slot. Si beve all'istante mentre corri e spari: nessun
menù da aprire, nessuna finestra, nessuna animazione che ti blocca. `Q` ed `E` restano liberi per le
abilità di classe che arriveranno.

Il tipo di pozione di ogni slot **lo scegli tu** all'Erborista, ed è lì la strategia: con 3 slot su 6
pozioni ti porti dietro una decisione, non un magazzino. **Un tipo per slot** — niente cintura di sole cure.

#### 🌿 Il catalogo

| | Effetto | Durata | Costo a carica |
|---|---|---|---:|
| ❤️ Cura | ripristina il 40% dei PV massimi | istantanea | 45 |
| 🪨 Pelle di Pietra | −50% danni subiti | 5 s | 40 |
| 💨 Fretta | +45% velocità | 6 s | 30 |
| ⚔️ Furia | +50% danno | 6 s | 35 |
| ⚡ Frenesia | +60% cadenza | 5 s | 35 |
| ➕ Rigenerazione | 10 PV/s | 8 s | 40 |

#### 📊 Le statistiche contano, una per aspetto
Nessuna sovrapposizione, così ogni classe usa le stesse boccette in modo diverso senza bisogno di cataloghi
separati per eroe:

| Statistica | Cosa cambia | Al livello 12 |
|---|---|---|
| **Costituzione** | quanto curano | Cura dal 40% al **64%** dei PV |
| **Intelligenza** | quanto durano | Furia da 6 a **8,9 s** |
| **Forza** | quanto picchiano Furia e Frenesia | +50% → **+68%** danno |
| **Destrezza** | quanto in fretta ribevi | cooldown da 6 a **3,84 s** |

#### 🚦 I due freni
Un **cooldown globale** di 6 s **condiviso dai tre slot** (non uno per slot, altrimenti basterebbe alternarli
per berne tre di fila), e **nessun cumulo**: la seconda Furia fa ripartire il timer, non raddoppia il danno.

#### 💰 Le regole del banco
- **Le cariche si comprano, non si ricaricano**: finite quelle, l'ondata la fai a secco.
- **Cambiare il tipo di uno slot rimborsa metà** delle cariche rimaste: cambiare idea costa, ma non azzera.
- **Le cariche sopravvivono alla morte**: quello che hai comprato è tuo finché non lo bevi.

#### 🏘️ Villaggio
- L'**Erborista** non è più una bottega chiusa. Restano chiusi Cartomante, Banditore e Ostessa.
- Il quarto banchetto si chiamava **Rigattiere** nel codice e **Banditore** nei documenti: ora è Banditore
  ovunque, che è anche il mestiere che il disegno rappresenta.

#### 🔊 e 🎨
Suono della bevuta (un tonfo sordo e due note che salgono), alone del colore della pozione attorno al
personaggio, e per la Cura il numero di PV recuperati — che dipende dalla Costituzione e quindi va visto.

#### ✅ Verificato
**755 test, 0 falliti.** Fra gli altri: il tetto di 3 cariche, il rifiuto del doppione, il rimborso a metà
esatto, il cooldown che blocca anche gli **altri** slot, la durata che riparte invece di raddoppiare, le
cariche che restano dopo aver perso una vita, i quattro moltiplicatori misurati fino al **valore effettivo**
(danno, cadenza, velocità, cura, durata, cooldown), e un controllo che nessuna chiave di buff del catalogo
resti senza qualcuno che la legge in `Room.js` — un buff che nessuno legge non farebbe nulla e nessun test
se ne accorgerebbe. Più 27 controlli sull'interfaccia con DOM finto.

---

### [1.70.0] — 2026-08-29 · "Più morbido all'inizio, senza tetto alla fine"

Quattro correzioni chieste dopo aver provato la 1.69.

#### 🔢 Il numero dei nemici ora è progressivo
Il tetto dei vivi era **fisso a 30** e, unito al rifornimento rapido della 1.68, riempiva l'arena di 30
nemici **già alla terza ondata** — misurato — anche se l'ondata ne prevedeva 10. Il tetto era diventato il
numero, invece di essere un limite. Ora è una **curva**:

| Ondata | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10+ |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Vivi al massimo | 8 | 10 | 12 | 14 | 16 | 18 | 21 | 23 | 26 | **30** |

Misurato dopo la modifica, il picco reale di nemici in campo segue la curva senza mai superarla: 7 alla
prima, **12 alla terza**, 18 alla sesta, 30 solo dall'undicesima.

Nel farlo è saltato fuori che la modalità **Sopravvivenza** rifornit fino a un **14 scritto a mano** che
scavalcava il tetto: all'ondata 2 (tetto 10) si arrivava davvero a 14 vivi. Ora passa dalla stessa porta
di tutti gli altri.

#### 🎚️ Niente più tetto ai livelli
Il cap al livello 20 coincideva con la fine della partita: gli ultimi livelli si prendevano sui titoli di
coda invece di giocarli. **Il tetto non esiste più**: si sale finché si accumula esperienza, la curva
(`107 · L^1,54`) continua all'infinito e i costi si calcolano man mano. `MAX_LEVEL` non esiste più nel
codice, e la conversione dell'XP in monete oltre il cap è sparita con lui (non c'è più un cap da superare).

#### ✦ L'esperienza arriva da più fonti
Non solo dai nemici uccisi. Ora anche:

| Fonte | XP |
|---|---|
| **Cassa aperta** | 45 + 9 per ondata |
| **Potenziamento raccolto** sulla mappa | 30 + 6 per ondata |

I valori stanno in `shared/constants.js`, in chiaro: aggiungere una fonte è una riga. Il termine per ondata
tiene il passo con l'XP dei mostri, che cresce anche lei. Ogni raccolta manda al client quanta esperienza
ha dato e da dove, e la si vede salire sopra il personaggio.

Misurato dopo il cambio: una run completa porta ora al **livello 30** invece del 20, con le tappe a
Lv.10 all'ondata 9, Lv.20 alla 15, Lv.30 alla 19.

#### 🔔 LEVEL UP sopra la testa, con jingle
Salire di livello non aspetta più il pannello di fine ondata: la scritta **LEVEL UP** compare sopra la
testa del personaggio con sotto il numero del livello, resta agganciata a lui mentre si muove e combatte,
sale piano e svanisce in 1,6 secondi. La vedono anche i compagni. A chi sale parte un **jingle** dedicato:
un arpeggio maggiore do-mi-sol-do con la fondamentale tenuta sotto — una frase, non un effetto.

#### 🃏 Via le carte di rango
Le 27 carte generiche introdotte in v1.69 sono state rimosse: al loro posto arriveranno le **abilità di
classe**, sbloccate a livelli specifici come in un gioco di ruolo. Il **rango resta** (titolo nuovo e punto
in più a ogni scatto) e il contenitore è già pronto: `cardsFor()` risponde vuoto, quindi l'offerta
semplicemente non parte — quando le abilità arriveranno basta riempire la tabella, senza toccare il resto.
Il **bivio del rango V** (Paladino / Maestro d'Armi e i suoi gemelli) resta com'era.

#### 🧪 Test
- **692 passati, 0 falliti**, più 45 controlli sull'interfaccia.
- Il test nuovo verifica la curva del tetto ondata per ondata, che alla terza non si superino i 12 vivi in
  una partita vera, che l'esperienza arrivi davvero da casse e oggetti, e che l'annuncio del livello parta
  anche in mezzo al combattimento — uno per ogni livello salito, anche saltandone più in un colpo.
- La monotonia della curva XP è ora garantita a mano e non lasciata all'arrotondamento: verificato che
  nessun livello, fino al 500°, costi quanto il precedente.

### [1.69.0] — 2026-08-29 · "Guerriero, Guerriero Esperto, Veterano…"

Fino alla 1.68 la XP era una **valuta**: la raccoglievi e la spendevi al negozio di fine ondata. Da questa
versione la XP e' una **barra**: sale, ti fa salire di livello, e a ogni livello ti da' un punto da spendere.
E' la differenza fra comprare un potenziamento e diventare qualcosa. Il progetto completo, con le misure da
cui escono tutti i numeri, sta in **`PROGRESSIONE.md`**.

#### 🎚️ Venti livelli, uno per ondata
Il cap e' **20** perche' la run finisce all'ondata 20: la crescita del personaggio e quella del dungeon sono
la stessa curva, e non ci si ferma mai a "livellare". La curva (`107 · L^1,54`) e' tarata sull'XP **misurata**:
il cap chiede **10.670 XP** contro gli ~11.000 che rende una run intera. Chi arriva in fondo arriva al cap;
chi gioca bene, con le combo, ci arriva due o tre ondate prima.

Misurato dopo il cambio, con un giocatore tenuto in vita per misurare l'ondata e non il bot:

| | livello 5 | livello 10 | livello 15 | livello 20 |
|---|---|---|---|---|
| Guerriero | ondata 5 | ondata 9 | ondata 14 | ondata 18 |
| Ladro | ondata 5 | ondata 9 | ondata 14 | ondata 15 |

**Oltre il cap** la XP si converte in monete (8 XP = 1 moneta): le uccisioni dell'ultima ondata continuano a
valere qualcosa, e finiscono nell'unica cosa che a quel punto serve ancora, l'equipaggiamento.

#### ★ Cinque ranghi, uno ogni cinque livelli
Cadono **sui boss**, cosi' il rango arriva sempre in un momento che il giocatore ricorda.

| Rango | Liv. | 🛡️ Guerriero | 🔮 Mago | 🏹 Ladro |
|---|---:|---|---|---|
| I | 1 | Guerriero | Apprendista | Ladro |
| II | 5 | Guerriero Esperto | Mago Giovane | Furfante |
| III | 10 | Veterano | Mago | Predone |
| IV | 15 | Campione | Mago Anziano | Ombra |
| V | 20 | **Paladino** / **Maestro d'Armi** | **Arcimago** / **Stregone** | **Assassino** / **Cacciatore di Teste** |

Ogni rango da' **un punto in piu'** e **una carta a scelta fra tre** — potenziamenti *di classe*, non
generici: e' la differenza con i boon, che restano quelli di sempre. Sono **27 carte** in tutto (3 classi ×
3 ranghi × 3), tutte implementate: Parata, Sfondamento, Colpo Rotante, Sprone, Esecuzione, Muro, Furia
Crescente per il guerriero; Bolla Densa, Eco Arcana, Frattura, Scudo di Mana, Runa Vagante, Detonazione,
Passo del Vuoto, Convergenza per il mago; Doppia Cocca, Passo Felpato, Punta Avvelenata, Tiro Rapido,
Frecce Pesanti, Ombra, Colpo alle Spalle, Pioggia, Elusione per il ladro.

Le combinazioni per classe sono 3 × 3 × 3 × 2 = **54**: due run non si somigliano.

#### ⚔️ Il bivio del rango V
Al livello 20 non arrivano tre carte ma **due strade**, e non sono lo stesso personaggio piu' forte. In ogni
coppia una rende **subito** e una rende **di piu' ma chiede qualcosa** — una squadra, un bersaglio grosso,
il posizionamento:

- **Paladino** (aura che cura i compagni e taglia il 18% dei danni, a te e a loro) / **Maestro d'Armi**
  (+35% cadenza del fendente, +20% apertura dell'arco, rinculo ×1,5)
- **Arcimago** (ogni bolla esplode) / **Stregone** (la bolla rimbalza su 3 nemici a danno pieno)
- **Assassino** (critico al 35%, ×3, colpi alle spalle sempre critici) / **Cacciatore di Teste** (ogni tiro
  e' un ventaglio di 3 frecce che perforano 3 nemici)

**E' l'unico rango che si vede addosso**: cerchio dell'aura del Paladino (tratteggiato, col raggio vero),
cresta rossa e lama di luce del Maestro d'Armi, rune dorate dell'Arcimago, nucleo rosso dello Stregone,
scia scura e pugnale dell'Assassino, seconda faretra del Cacciatore. I primi quattro ranghi cambiano solo il
nome sotto la barra della vita: il lavoro grafico va dove c'e' una scelta da riconoscere.

#### 💠 I punti: 23 in una run, 22 per una statistica al tetto
Un punto per livello (19) piu' uno per rango (4). Il costo di una statistica cresce a scaglioni — **1 punto**
fino al 4° livello, **2** fino al 10°, **3** per gli ultimi due — quindi portarne una al tetto costa **22
punti su 23**. E' la regola della v1.66 ("con l'XP di una run si cappa una sola statistica") tradotta da
valuta a punti, e questa volta si legge a colpo d'occhio invece di stare nascosta in una tabella di costi a
sei cifre. Le tre strade che 23 punti permettono davvero: una statistica a 12; una a 8 e una a 7; tre a 5 e
una a 4.

Il pannello di fine ondata non dice piu' "hai 4.435 XP" ma **"Livello 7 · Veterano — hai 3 punti"**.

#### 🃏 Una scelta alla volta
Se c'e' una carta di rango in attesa, il **boon salta quel giro**. Siccome i ranghi cadono sui boss, in
pratica alle ondate 5/10/15/20 si sceglie la carta di classe e nelle altre il boon generico: mai due mazzi
aperti nello stesso istante.

#### 🐛 Il tetto dei nemici era ancora un auspicio
Cercando altro e' saltata fuori una falla della v1.68: il tetto dei vivi contava `monsters.length`, che
comprende i **morti non ancora filtrati**, e soprattutto la **scissione** della Melma controllava solo che
ci fosse *un* posto libero prima di generarne *due*. Con 29 in campo si finiva a 31. Ora tutte le porte
(ondata, evocazioni, scissione, mimic delle casse) passano da `_postiLiberi()`, che conta i vivi e dice
quanti ne stanno ancora: "mai piu' di 30" e' tornata una promessa.

#### 🧪 Test
- **710 passati, 0 falliti** (+76), piu' 48 controlli sull'interfaccia.
- Il test dei livelli verifica la curva, i punti (23 in una run, 22 per il tetto), i ranghi che cadono ogni
  5 livelli, le 27 carte complete e della loro classe, e i casi cattivi: una carta di un'altra classe non si
  prende, la stessa carta non si prende due volte, saltare piu' livelli in un colpo non perde ne' punti ne'
  ranghi, al rango V arriva il bivio e non le carte.
- Bilanciamento rimisurato: ondata media 3/4/4 per guerriero/mago/ladro, **identica alla v1.68**. Il
  passaggio da negozio-a-XP a punti non ha reso il gioco ne' piu' facile ne' piu' difficile.

#### ➖ Cosa NON c'e' ancora
Le **abilita' attive** delle specializzazioni (Giuramento, Turbine, Meteora, Catena Nera, Marchio, Salva)
sono descritte nel pannello ma non ancora giocabili: arrivano con la barra delle abilita', insieme al
ritorno dei tasti Q/E. Di ogni specializzazione e' implementato il **passivo**, che e' la parte che cambia
davvero come si combatte.

### [1.68.0] — 2026-08-28 · "Trenta in campo, il resto in coda"

Prima di toccare qualsiasi cosa ho **profilato server e client separatamente**, come nella 1.64, per non
ottimizzare a sensazione.

#### 📊 Dove sta davvero il costo (misurato)
| | 30 mostri | 50 mostri | 80 mostri |
|---|---:|---:|---:|
| **Tick del server** (budget 33,3 ms) | 0,31 ms | 0,33 ms | 0,38 ms |
| **Snapshot** per giocatore | 4,5 KB | 6,5 KB | 10,1 KB |
| **Banda in uscita** (6 giocatori, 20 Hz) | 554 KB/s | 834 KB/s | 1,3 MB/s |

**La CPU del server non e' un problema e non lo e' mai stata**: usa l'1% del tempo che ha a disposizione,
anche con 80 mostri e 4 giocatori. Il costo vero e' la **banda**, e i mostri sono il **90%** dello snapshot.

#### 🔢 Tetto a 30 vivi, il resto in coda
`C.MAX_ALIVE` scende da 50 a 30. L'ondata **non perde nessuno**: i nemici in eccesso restano in coda ed
entrano man mano che si fa posto (alla 20ª ondata in sei l'ondata ne prevede 86, e tutti e 86 arrivano).

Perche' il tetto non si traducesse in ondate piu' lente, il rifornimento ha **due velocita'**:
- mentre l'arena si riempie **la prima volta**, il ritmo di sempre (0,25-0,6 s fra un ingresso e l'altro):
  e' la salita che da' il senso dell'ondata che monta;
- quando l'arena e' **gia' stata piena** e si aprono dei buchi, il rimpiazzo e' quasi immediato
  (0,10-0,22 s). Uccidi, ne entra un altro.

#### 📉 Snapshot magro: −52% di traffico a parita' di nemici
Ogni mostro pesava **120 byte, 20 volte al secondo**, ma due terzi di quei byte **non cambiavano mai** dopo
la comparsa: il tipo, i PV massimi, i flag elite/boss/mega/tesoro. Ora la parte immutabile viaggia **una
volta sola**, nel primo snapshot in cui il mostro compare, e il client se la tiene. Stessa cosa per nome ed
eroe dei giocatori. In piu', **i flag che valgono 0 non si mandano affatto**: "assente" e "0" sono la stessa
cosa, e il client li rimette a 0. Un record di mostro passa da **120 a 46 byte** in regime.

| a parita' di nemici in campo | prima | ora |
|---|---:|---:|
| 30 mostri, 1 giocatore | 80 KB/s | **37 KB/s** |
| 30 mostri, 6 giocatori | 554 KB/s | **295 KB/s** |
| 50 mostri, 6 giocatori | 834 KB/s | **402 KB/s** |

Sommando le due cose — tetto a 30 **e** snapshot magro — una partita in sei passa da **834 KB/s a 295 KB/s
in uscita: −65%**.

Chi **entra adesso** non ha ancora nessuna cache, quindi riceve uno snapshot **pieno**: una serializzazione
in piu', e solo nel tick in cui qualcuno si collega. `snapshot()` senza argomenti resta completo di
proposito — un chiamante distratto (o un test) deve ottenere un oggetto autosufficiente, non record monchi.

#### 🧪 Test
- **634 passati, 0 falliti** (+24).
- Il controllo che conta su una modifica del genere e' **il giro completo**: `test/client.js` prende una
  stanza vera, le chiede la sequenza di snapshot magri che manderebbe in rete, la passa alla ricostruzione
  di `net.js` e confronta **campo per campo** con lo snapshot pieno dello stesso istante. Verifica anche che
  un mostro comparso dopo venga presentato, che la cache lasci andare i morti, e che un flag acceso in un
  frame **torni a 0** nel successivo invece di restare acceso.
- Lato server: il tetto regge (picco mai oltre 30), coda e contatore restano allineati (nessuno perso),
  e dopo le uccisioni la coda ricomincia davvero a versare.

#### 📝 Nota su cio' che NON e' stato fatto
Restano sul tavolo due interventi piu' invasivi, misurati ma non applicati: **non mandare a ogni giocatore
i mostri lontani da lui** (−50-70% con sei giocatori, ma la minimappa smetterebbe di vedere i nemici
lontani) e **abbassare la frequenza degli snapshot da 20 a 15 Hz** (−25% gratis, il client gia' interpola).
Vanno decisi quando la banda tornera' a essere un problema, non prima.

### [1.67.0] — 2026-08-28 · "Il fabbro vende oggetti, non livelli"

L'Emporio erano **tre barre da riempire** — Armatura, Stivali, Arma, cinque livelli l'una, uguali per tutti e
tre gli eroi. Una barra da riempire e' una decisione sola: *ho abbastanza monete?* Da questa versione il
fabbro vende **oggetti con un nome**, e la decisione diventa un'altra: *mi serve la portata dell'alabarda o
la cadenza dello spadone?*

#### 🔨 Un catalogo per classe
Ogni classe vede **solo la propria roba**, e ha **i suoi slot**: il guerriero lo scudo, il ladro le calzature,
il mago nessuno dei due. Il filtro sta sul server — cio' che non e' della tua classe non attraversa la rete.

| | 🛡️ Guerriero | 🔮 Mago | 🏹 Ladro |
|---|---|---|---|
| **Arma** | Spada · Spadone 🪙230 · Alabarda 🪙470 | Bacchetta di Frassino · Scettro Runico 🪙240 · Bastone del Vuoto 🪙500 | Arco Corto · Arco Lungo 🪙300 |
| **Armatura** | Maglia di Ferro · Armatura a Piastre 🪙250 | Veste da Apprendista · Manto dell'Arcanista 🪙270 | Giaco di Pelle · Corazza di Cuoio 🪙240 |
| **Scudo** | Scudo · Scudo a Torre 🪙290 | — | — |
| **Calzature** | — | — | Scarpe di Corda · Stivali del Passo Lieve 🪙260 |

Il **rango 1 costa 0 ed e' quello che hai gia' addosso alla partenza**: non e' un oggetto vuoto, e' il metro
con cui si leggono gli altri. Nel pannello e' marcato **DI BASE**, non "🪙 0", che farebbe sembrare un affare
cio' che possiedi gia'.

Le tre armi del guerriero non sono la stessa arma piu' grande: **piu' e' lunga, piu' l'arco e' stretto**.
L'alabarda arriva a 152px ma copre 71°, lo spadone 122px per 94°, la spada 100px per 109°. Si sceglie fra
tenere lontano e coprire i fianchi. Le tre bacchette hanno invece **la stessa cadenza**: quella e' la firma
del mago e la alza l'Intelligenza, non il portafoglio — le bacchette migliori danno danno, velocita' e
grandezza della bolla, cioe' *quante ne vanno a segno*, che su un proiettile lento conta quanto il danno.

#### 🔁 Il cambio e' libero
Si compra qualunque oggetto dello slot in qualunque momento, a prezzo pieno, e il vecchio viene rimpiazzato.
Anche all'indietro: se l'alabarda non ti piace, torni allo spadone. Per questo i bonus **non si sommano man
mano**: il server li **ricalcola da zero** a ogni cambio, altrimenti il bonus del pezzo tolto resterebbe
attaccato al personaggio per sempre. C'e' un test apposta che compra, torna indietro e verifica che la
velocita' sia esattamente quella di prima.

#### 👁️ Cio' che si compra si vede
- **Scudo a torre**: arco piu' ampio, lamiera piu' spessa, seconda nervatura. E' l'unico pezzo d'armatura che
  cambia la sagoma vista dall'alto, quindi vale la pena disegnarlo diverso.
- **Arco lungo**: sporge davanti e dietro la sagoma, con la curva piu' profonda e il legno piu' chiaro.
- **Bacchette**: l'orbe cresce e cambia colore (viola per lo Scettro, ciano chiaro per il Bastone), e la
  **bolla che spara** e' quella dell'arma — raggio, velocita' e colore.
- **Fendente**: l'arco disegnato e' sempre *esattamente* l'area che ferisce, quindi cambiando arma si vede
  subito quanto arriva.

Armature, vesti e calzature restano invisibili per ora: da sopra, a questa scala, non si leggerebbero.

#### 💰 Prezzi tarati sull'economia vera
Misurata: **65-70 monete a ondata**, e il Mercato apre ogni 3 ondate. Al primo mercato si hanno ~200 monete
(un oggetto di rango 2), al secondo ~400 (un rango 3, oppure due rango 2). Nessun oggetto e' fuori portata,
nessuno e' regalato.

#### 🧪 Test
- **609 passati, 0 falliti** (+111): il catalogo e' verificato a tappeto — ogni oggetto sta in uno slot che la
  sua classe possiede, ogni rango superiore **costa di piu' E vale di piu'** (danni al secondo per le armi,
  somma pesata dei bonus per il resto), e nessuna classe puo' comprare la roba di un'altra.
- Nuovi controlli anche sul pannello del fabbro (`test/client.js`): il guerriero vede tre slot, il mago due,
  l'oggetto indosso e' marcato IN USO e non si ricompra, e il clic manda **l'id dell'oggetto**, non lo slot.
- Bilanciamento rimisurato: a parita' di tutto il resto, il guerriero passa da 35 uccisioni per partita con la
  spada a 38 con lo spadone e **46 con l'alabarda**, e sopravvive 95s invece di 73s. La scala funziona.

#### ➖ Rimosso
`Loot.GEAR`, `GEAR_BY_SLOT`, `gearCost`, `GEAR_RANK`, `GEAR_RARITY`: erano una scala di numeri uguale per
tutti. Con loro non serve piu' nessuna delle icone in `public/assets/gear/` (le carte ora portano il NOME
dell'oggetto e le sue statistiche, che e' cio' che si legge): i file sono ancora sul disco e si possono
cancellare a mano. Il catalogo vive in **`shared/gear.js`**, e aggiungere un oggetto e' una
riga sola — negozio, HUD, ricalcolo dei bonus e test lo pescano tutti da li'.

### [1.66.0] — 2026-08-28 · "Guerriero, Mago, Ladro"

Il gioco e' un dungeon con troll, lich e beholder, e i tre protagonisti erano un poliziotto cibernetico, un
sergente col fucile d'assalto e un hacker. **ENFORCER-7, SGT. VIPER e NULL sono stati sostituiti da GUERRIERO,
MAGO e LADRO**, e con loro e' cambiato tutto cio' che li riguardava: come attaccano, come crescono, cosa
comprano. E' la versione piu' invasiva dalla 1.51.

#### 🦸 Tre classi, tre modi di colpire
| | Arma | Come colpisce | Danno/s | PV |
|---|---|---|---:|---:|
| 🛡️ **GUERRIERO** | Spada | **semicerchio** davanti a se, 100px / 109° | 99 sul piu' vicino | 200 |
| 🔮 **MAGO** | Bolla di Energia | proiettile lento (430 px/s) e grosso | 96 | 100 |
| 🏹 **LADRO** | Arco | freccia veloce (900 px/s) che perfora 1 nemico | 93 | 112 |

Il **fendente** non e' un proiettile: colpisce chi sta nel settore davanti al personaggio. **Raggio e apertura
vengono dall'arma, non dall'eroe** — la spada corta fara' 74px/131°, l'alabarda 144px/71°: *piu' lunga = piu'
stretta*, che e' cio' che le rende diverse invece che solo piu' grandi. Il client disegna **esattamente** l'arco
che ferisce, quindi la portata si impara guardando.

Il fendente e' ad area ma **non illimitata**: il bersaglio piu' vicino incassa tutto, gli altri il 55%, e non
piu' di 5 per colpo. Senza questo tetto, misurato, il guerriero faceva **300-640 uccisioni** per partita contro
le ~50 dei due tiratori: le ondate avanzavano al doppio della velocita' e la squadra si autodistruggeva.

Il **mago** parte volutamente lento (1,5 colpi/s contro i 6,5-9,5/s dei vecchi fucilieri): e' l'Intelligenza a
fargli salire cadenza *e* danno. I PV del guerriero sono a 200 perche' e' l'unico che non puo' tenere le
distanze: a 150 moriva sistematicamente un'ondata prima degli altri due, e non per mancanza di danno (alzarlo
non cambiava niente) ma per il tempo passato a contatto.

#### 📊 Quattro statistiche da gioco di ruolo (al posto di sei da sparatutto)
Vitalita'/Potenza/Cadenza/Abilita'/Agilita'/Precisione sono sostituite da **FORZA, COSTITUZIONE, INTELLIGENZA,
DESTREZZA**, da 1 a **12** (prima 8).

| Statistica | Per livello |
|---|---|
| 💪 **Forza** | +9% danno in mischia, +3% rinculo |
| ❤️ **Costituzione** | +20 PV massimi, −1,2% danni subiti |
| 🔮 **Intelligenza** | +9% danno magico, **+7% cadenza delle magie** |
| 🏹 **Destrezza** | +8% danno dei dardi, +6% cadenza, **+2,5% velocita'** |

Il meccanismo che le lega agli attacchi e' la **scuola dell'arma** (`weapon.school`: `melee`, `magic`,
`ranged`). Ogni statistica alza danno e cadenza *della sua scuola*, non un danno generico. **Chiunque puo'
comprare qualunque statistica**: un guerriero che compra Intelligenza non guadagna niente sulla spada, ma
guadagnera' tutto sulla prima magia che gli si mette in mano — che e' esattamente cio' che serve alle classi
miste previste nella progressione dopo il boss.

**Curva rifatta su una regola sola**: con l'XP di **una run intera** (nell'ordine dei 18.000, misurato su
partita vera) si deve poter cappare **esattamente una** statistica.

| livello | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| costo | 60 | 100 | 160 | 250 | 380 | 560 | 820 | 1200 | 1750 | 2600 | 4000 | 6100 |
| salto | — | +67% | +60% | +56% | +52% | +47% | +46% | +46% | +46% | +49% | +54% | +53% |

Totale per una statistica al tetto: **17.980 XP**. Tutte e quattro: 71.920, cioe' quattro run pulite. Il
**gradino piatto** della vecchia tabella (il 7° livello costava solo il 13% piu' del 6°) e' sparito: la
crescita non scende mai sotto il +46%, quindi ogni livello e' sempre una rinuncia sentita.

#### ➖ Cosa e' stato tolto (per ora)
- **Abilita' Q ed E**: erano cucite sui tre eroi eliminati (torretta, granata, colpo del cecchino,
  bullet-time, rift). Vanno ripensate sulle nuove classi, dove i poteri arriveranno dall'**evoluzione dopo il
  boss** e non da uno slot fisso. Lo **scatto** (tasto destro) resta.
- **Armi a terra**: non si raccolgono piu' dalla mappa e non escono piu' dalle casse. Saranno solo da negozio.
- **Acquisto delle armi**: sospeso (via la Cassa Armi dal mercante) finche' l'arsenale non viene ripensato
  attorno alle tre scuole.

#### 🎨 Grafica
I tre eroi sono disegnati **dall'alto**, riusando l'impalcatura del vecchio `_hero` (stivali, braccia come
tratti, torso arrotondato, testa a `r*0.5`) — e' quella che si legge alla scala di gioco. Il **mago** ha il
mantello ampio con l'orlo mosso e il cappuccio a punta, bastone e orbe; il **guerriero** ha armatura abbozzata
(pochi solchi, non dettagli), spallacci scuri, elmo chiaro con feritoia e **scudo ad arco " ) "** davanti; il
**ladro** ha cappuccio, mantellina, faretra e **arco " ) " di lato** — di fronte sarebbe uno scudo. Nessuno dei
tre ha occhi disegnati: sotto la feritoia e dentro il cappuccio c'e' solo ombra.

Nuovi disegni anche per i proiettili: **bolla** translucida con membrana pulsante e riflesso, **freccia** con
asta, punta e impennaggio orientati sulla traiettoria. Il **fendente** e' un settore che si apre in 70ms, in
oro (bianco sui critici). Un timbro audio per scuola: colpo sordo, tono basso e morbido, schiocco secco.

#### 🐛 Due bug trovati dai test, non dal codice
- Il fendente usava `m.r` per il raggio del mostro, che **non esiste** (e' `m.radius`). In JavaScript non da'
  errore: `d > rad + undefined` e `diff > half + NaN` sono entrambi `false`, quindi il colpo **prendeva tutti i
  mostri della mappa, anche alle spalle**. Se n'e' accorto il test del bersaglio dietro le spalle.
- Il raggio dichiarato dall'arma (`weapon.r`) veniva ignorato: la bolla del mago, che deve essere grossa
  proprio perche' e' lenta, volava larga come un proiettile qualunque.

#### 🧪 Test
- **499 passati, 0 falliti** (+31 nuovi) + suite client aggiornata al tetto di 12 livelli.
- Il **bot** dei test e' stato istruito a giocare in mischia: prima indietreggiava sotto i 160px, quindi con
  un'arma da 100px non arrivava mai a contatto e "moriva disarmato". Ora tiene la distanza della *sua* arma,
  si stacca mentre l'arma e' in ricarica e si sgancia sotto il 40% dei PV. Senza questa correzione il dato
  diceva "la classe e' fragile" quando diceva "il bot non sa giocarla".
- Bilanciamento verificato **contro la versione precedente**, con lo stesso bot: in trio le nuove classi
  arrivano alle ondate 3-7 contro le 5-7 delle vecchie, in singolo restano entro un'ondata.

### [1.65.0] — 2026-08-27 · "Il fascio della Faglia"

I tentacoli della 1.64 erano troppo timidi: si vedevano appena, e un avviso che non si vede non e' un avviso.
Rifatto l'effetto con il **linguaggio visivo del fascio dello sguardo del Beholder**, che nel gioco funziona.

#### 🔮 Cosa cambia
- **Ventaglio pieno** che si apre dal punto della roccia piu' vicino a te, con gradiente forte alla radice —
  come il fascio del Beholder, non piu' quattro tratti sottili.
- **I filamenti ARRIVANO addosso al giocatore** invece di allungarsi a caso nel vuoto. E' la differenza che
  conta: la linea collega **causa ed effetto**, quindi si capisce a colpo d'occhio che e' *quel muro* a farti
  male, non "l'aria".
- **Nucleo pulsante ad alta frequenza** lungo l'asse (stesso trucco della linea centrale dello sguardo).
- **Bagliore alla radice**: la ferita nella roccia da cui esce tutto.
- In un **angolo** partono due fasci, uno per lato — coerente col fatto che li' la faglia morde il doppio.
- **Buco nel buio** alla radice: il bordo mappa e' la zona piu' buia, e senza aprire la nebbia proprio li'
  l'effetto restava invisibile esattamente dove serviva vederlo.

#### ⚡ Costo
Zero regressioni sulle prestazioni della 1.64: i gradienti del ventaglio e del bagliore sono **in cache**
(chiave sulla lunghezza arrotondata a 40px), e il fascio si disegna solo quando sei nei paraggi del bordo.
La guardia di prestazione in `test/client.js` misura **114 gradienti per frame** con 60 nemici, invariata.

#### 🧪 Test
- **475 passati, 0 falliti** + suite client invariata.

### [1.64.0] — 2026-08-27 · "Prestazioni: il singhiozzo era il garbage collector"

Il gioco scattava con molti nemici. Prima di toccare una riga ho profilato **server e client separatamente**.

#### 🔍 Il server non c'entrava niente
300 tick misurati per configurazione, budget di un tick = 33,3 ms:

| mostri | giocatori | `update` medio | % del budget |
|---:|---:|---:|---:|
| 60 | 1 | 0,35 ms | 1,1% |
| 100 | 4 | 0,52 ms | 1,5% |
| 150 | 6 | 0,75 ms | 2,3% |

#### 🔍 E il client non era *lento*: **singhiozzava**

| mostri | mediana | p95 | p99 | massimo |
|---:|---:|---:|---:|---:|
| 10 | 2,8 ms | 4,5 | 5,2 | 9,4 ms |
| 50 | 4,8 ms | 6,2 | 13,0 | 29,5 ms |
| 80 | 6,5 ms | 9,1 | 13,4 | **39,7 ms** |

Il frame peggiore era **6 volte** la mediana. Una mediana ottima con code lunghissime ha quasi sempre una
causa sola, e infatti: **558 gradienti creati a OGNI frame** con 80 nemici — **33.494 al secondo** — quasi
tutti identici a quelli del frame precedente. Non era il disegno, era il garbage collector.

#### ✅ 1. Cache dei gradienti
Un `CanvasGradient` e' un oggetto riusabile e le sue coordinate stanno nello **spazio utente**: basta
costruirlo attorno all'origine e disegnarlo col contesto gia' traslato sull'entita'. Quello che cambia a ogni
frame (il pulsare) si ottiene con `globalAlpha`, che non alloca. Applicato all'alone dei mostri, alla
funzione `light()` dell'illuminazione e agli aloni del buio.

**Risultato: da 558 a 184 gradienti per frame (−67%). Frame peggiore da 39,7 ms a 18,5 ms.**

#### ✅ 2. Il Nugolo di Pipistrelli era il nemico piu' caro del gioco
Misurato per singolo nemico per frame: **116 µs**, tre volte lo scheletro e quindici volte la melma. Colpa
mia (v1.61): 9 sagome × (2 gradienti lineari + una ventina di operazioni di path) = **18 gradienti e ~180
operazioni per nugolo, 60 volte al secondo**. Ma il battito d'ali e' una sinusoide, cioe' ha un numero finito
di pose: ora le 12 pose si disegnano **una volta sola** su canvas piccole (`_batFrames`) e a schermo si fa
`drawImage`, che e' una copia di pixel.

**Risultato: da 116 µs a 30,8 µs (−73%).** Da nemico piu' caro a meta' classifica.

| nemico | prima | dopo |
|---|---:|---:|
| Nugolo di Pipistrelli | 116 µs | **31 µs** |
| Zombie Putrido | 39 µs | 41 µs |
| Negromante | 28 µs | 30 µs |
| Melma | 7 µs | 7 µs |

#### ✅ 3. Scarto fuori inquadratura
Mostri e proiettili venivano disegnati **tutti**, anche fuori schermo: la canvas li ritagliava, ma il costo di
costruire i tracciati era gia' stato pagato. L'illuminazione lo faceva gia', il disegno no. **11-15% del frame.**

#### 🔢 4. Tetto di 50 nemici vivi
Non riduce l'ondata: la **ritma**. I nemici in eccesso restano in coda ed entrano man mano che gli altri
muoiono, quindi il totale da uccidere non cambia — cambia quanti ne hai addosso insieme. Il tetto vale anche
per **evocazioni e divisioni**, altrimenti "mai piu' di 50" sarebbe un auspicio e non una promessa.

#### 🟣 La Faglia adesso si vede nel mondo, non solo sullo schermo
La vignetta della v1.63 diceva "sei in pericolo" ma non diceva **da dove**: e' un effetto di interfaccia.
Ora ci sono due cose in piu', entrambe nel mondo di gioco:
- **La fascia dipinta sulla roccia**, cotta dentro l'immagine della mappa (costo a schermo: **zero**). Quattro
  sfumature, una per lato, che partono dal bordo e sfumano verso l'interno; negli **angoli si sovrappongono**,
  quindi il viola e' piu' carico esattamente dove la faglia morde il doppio. Si vede **prima** di entrarci.
- **I tentacoli**, che escono dalla roccia del bordo **piu' vicino a te** e si allungano mentre la carica sale.
  In un angolo escono da due lati. 18 tratti, nessun gradiente, e solo quando sei nei paraggi.

Scartato il cono: il gioco usa gia' il cono per il **campo visivo del Negromante**, e riusare la stessa forma
per un significato diverso confonde.

#### 🧪 Test
- Nuovo `testV164` (server): il tetto regge su un'ondata da 6 giocatori all'ondata 18, la coda **non perde
  nessuno**, e appena si fa spazio riprende a scorrere.
- Nuovo **[CLIENT 2]** in `test/client.js`: una **guardia di prestazione** vera. Carica il renderer con un
  contesto 2D finto che **conta le allocazioni**, disegna 60 nemici e pretende meno di 240 gradienti per frame
  (misurati: **115**) e meno di 3,2 per nemico (misurati: 1,92); verifica che i fotogrammi del Nugolo siano
  precotti e che un nemico fuori inquadratura non costi **niente**. Se qualcuno rimette un `createGradient`
  dentro un ciclo per-nemico, salta fuori subito invece che tra sei mesi giocando.
- Corrette due flakiness pre-esistenti: il test della Sfera d'Ossa metteva il giocatore accanto alla sfera
  **una volta sola** mentre la sfera stava rotolando via; e il conteggio dei mostri vivi ora esclude quelli
  gia' marcati morti (la rimozione dall'array avviene al tick dopo).
- **475 passati, 0 falliti** + suite client.

### [1.63.0] — 2026-08-27 · "La Faglia ai margini"

Chiude un exploit: restare attaccati al bordo esterno della mappa rendeva il gioco molto piu' facile.

#### 📐 Prima la misura
Bot fermo, 40 secondi, 5 prove, ondata 6:

| posizione | danno subito/s | arco occupato dai nemici | nemici a contatto |
|---|---:|---:|---:|
| centro | 85,7 | 243° | 4,7 |
| bordo | 27,6 | 76° | 1,3 |
| angolo | **17,7** | **79°** | 0,7 |

**Nell'angolo si subiva 4,8 volte meno.** La causa e' tutta nella terza colonna: al centro l'arco da
difendere e' 243°, nell'angolo 79°. E non e' solo difesa — con tutti i nemici dentro un ottavo di cerchio,
sono anche tutti dentro il cono di tiro. Meno danni in entrata **e** piu' danni in uscita insieme.

#### 🟣 La Faglia
L'anello esterno della mappa (3 tessere) carica una pressione mentre ci resti:
- **2,5s di grazia** a profondita' piena, poi un drenaggio che **cresce** da 3 a 20 PV/s in 6 secondi.
- La profondita' somma i **due assi**: un **angolo** vale il doppio di un bordo dritto, quindi li' la grazia
  dura 1,25s. Il posto piu' abusato e' il piu' punito.
- **Uscire ferma il danno sul colpo.** La carica invece resta e si riassorbe al doppio della velocita' con
  cui sale: attraversare il margine di corsa non costa niente, **accamparsi** si'.
- Solo in combattimento: nella sala del **Mercato** e' spenta (quella sala e' quasi tutta margine).
- **Avvisa prima di punire**: l'alone viola comincia a chiudersi appena entri nella fascia, cioe' 2,5s prima
  del primo danno; i filamenti compaiono solo quando il drenaggio morde davvero. La fascia e' anche segnata
  sulla **minimappa**, piu' marcata negli angoli: la regola si impara guardando, non leggendo.

#### 📦 Casse e armi solo al centro
Sono l'unico richiamo periodico del gioco: se compaiono ovunque, chi si accampa sul bordo se le ritrova
servite. Confinate nella zona centrale (36% del lato), ogni ondata obbliga ad attraversare lo spazio aperto.
E' la spinta che accompagna la spinta contraria.

#### 📊 Poi la verifica
Bot che **kita** (si allontana dalla minaccia e spara), fino alla morte, 6 prove:

| modalita' | Faglia | ondata raggiunta | secondi sopravvissuti |
|---|---|---:|---:|
| libero | OFF | 3,5 | 161 |
| libero | **ON** | 4,2 | 156 |
| bordo | OFF | 2,3 | 81 |
| bordo | **ON** | **1,0** | **26** |

Il gioco normale **non e' toccato** (161 → 156 s, rumore statistico). Chi resta incollato al bordo passa da
81 a 26 secondi. E' esattamente la forma voluta: nessuna tassa su chi gioca, un muro per chi si accampa.

#### 🧪 Test
- Nuovo `testV163`: geometria del margine (centro 0, bordo 3, **angolo 6**), grazia senza danno ma con la
  carica gia' visibile, drenaggio crescente misurato su due finestre, avviso `rift_edge` emesso **una volta
  sola**, riassorbimento uscendo, attraversamento ripetuto a costo zero, faglia spenta al Mercato, `eg`
  esposto nello snapshot, casse e armi tutte dentro il raggio centrale su 120 mappe.
- Scrivere questo test ha fatto emergere tre comportamenti del motore che vale la pena avere annotati:
  svuotare i mostri **chiude l'ondata e la stanza cura i giocatori**; un mostro puo' **morire nelle pozze**
  della v1.62; e il **recupero anti-stallo** (v1.43) teletrasporta i mostri a 240px dal giocatore se per 6
  secondi il conteggio non cala — cioe' esisteva gia' un anti-campeggio, solo molto piu' rozzo.
- **468 passati, 0 falliti** (verificato su 12 esecuzioni consecutive).

### [1.62.0] — 2026-08-27 · "Il terreno conta"

Primo blocco del lavoro sulla varieta' delle mappe: tutto quello che si poteva fare **senza toccare la pianta**.
Tre delle quattro cose erano gia' scritte nel progetto e non le usava nessuno.

#### 🔥 Le pozze di pericolo esistevano da sempre e non le generava nessuno
`T_HAZARD` era implementato **da cima a fondo**: il server toglie 6 PV ogni 0.25s ai giocatori e 8 ai mostri,
il renderer scava la conca, versa il liquido, ci mette riflesso e profondita', accende una luce del colore del
tema e lo disegna sulla minimappa. `mapgen` non ne piazzava **nemmeno uno**.
- Ora ogni mappa ne ha, in quantita' decisa da `theme.hazMul` — l'altro parametro dichiarato che moltiplicava
  il nulla. Misurato: lava **~18 tessere/mappa**, ghiaccio **~7**.
- Le pozze crescono come una **passeggiata casuale**: forma organica, mai un rettangolo.
- **Regola di sicurezza:** una pozza puo' nascere solo dove il 3×3 attorno non tocca muro. Cosi' non puo' mai
  tappare un corridoio — in un passaggio da 3 tessere solo la corsia centrale e' ammessa e le due laterali
  restano libere. Si deve sempre poter **girare intorno**, mai essere costretti a incassare.
- Mai sopra il portale d'uscita, mai entro 7 tessere dalla partenza.
- Fanno danno anche ai mostri: la pozza e' un alleato, non solo una trappola.

#### 🪨 Strato ambientale (`theme.propMix`)
Terzo parametro dichiarato in tutti i temi e mai letto. Non e' un doppione delle zone tematiche: quelle sono i
**punti di interesse** (grandi, max 3-4 per tipo, raccontano una scena), questo e' la **texture** fra un punto
e l'altro — oggetti piccoli (scala 0.6-0.9) sparsi lungo le pareti. Da ~30 a **~46 oggetti per mappa**.

#### 🧭 Partenza e uscita non sono piu' due costanti
- La partenza era il **centro geometrico esatto**, l'uscita **LA** cella piu' lontana: il percorso mentale era
  identico a ogni partita. Ora la partenza e' una **radura** scelta col seed fra le piu' ampie vicine al centro
  (68 posizioni distinte su 300 mappe), e l'uscita e' una a caso fra il **20% piu' lontano** — la traversata da
  fare non cambia, ma non finisce piu' sempre nello stesso angolo.
- Cambio di significato importante: **tutte le distanze a valle** — decorazioni, bracieri, casse, punti di
  spawn dei nemici — ora si misurano **dalla partenza** e non dal centro. Prima le due cose coincidevano solo
  perche' la partenza *era* il centro.

#### 🗺️ Il nome della zona si vede
"Cripta Dimenticata", "Caverne di Lava", "Tempio Arcano", "Sala dei Mercanti": erano scritti in `THEMES[].name`
e non comparivano da nessuna parte. Ora sono una didascalia sotto la barra in alto, nel colore d'accento del tema.

#### ⚠️ `blobMul` NON e' stato collegato, e non e' una dimenticanza
E' stato provato e **misurato**, e collegarlo non cambia niente. Il perche' e' annotato in `mapgen.js` perche'
e' la stessa ragione per cui tutte le mappe si somigliano:
1. **La posa satura.** `areaFree` pretende 2 tessere libere attorno a ogni masso: la mappa esaurisce i posti
   legali a **~15 blob** e i 700 tentativi finiscono sempre. Chiederne 20 o 38 e' identico — quindi dalla v1.22
   `blobCount` e' di fatto una **costante**, e anche il termine sul livello non fa nulla: la mappa dell'ondata
   20 ha la stessa roccia di quella dell'ondata 1.
2. **`widenForBoss` livella tutto.** Forzando la posa (pad 1 → 26 massi, 769 tessere di muro contro 611), il
   risultato finale non cambia: misurato su 60 mappe, **pad 1 → 513 muri, pad 2 → 536, pad 3 → 513**. Non e' un
   correttore di corridoi, e' un **regolatore di densita'**: cancella qualunque mappa piu' chiusa di "campo
   aperto con pilastri", che e' esattamente l'unica pianta che il gioco sa produrre.

La varieta' di pianta non si ottiene di qui: va rifatto `widenForBoss` (garantire il passaggio dei boss **lungo
un percorso**, non ovunque).

> **Nota (agosto 2026):** la varieta' di PIANTA e' stata poi **accantonata per scelta**. La misura qui sopra
> resta vera e utile — spiega perche' tutte le mappe si somigliano — ma non c'e' nessun lavoro in corso sugli
> archetipi. Se un giorno si riprende, si riparte da \`widenForBoss\`.

#### 🧪 Test
- Nuovo `testV162` su 240 mappe: pozze presenti in ogni tema, **zero** adiacenti a un muro, zero sull'uscita,
  zero entro 7 tessere dalla partenza, nessun giocatore che nasce dentro una; `hazMul` verificato (lava > 1.4×
  ghiaccio); oltre 30 oggetti per mappa e sacchetto del tema sempre usato; partenza e uscita variabili con
  uscita **sempre raggiungibile** e **sempre lontana**; nessuno spawn nemici a ridosso della partenza; danno
  della pozza verificato in partita su giocatore **e** mostro.
- Corretti tre test della 1.45/1.58 che erano **intermittenti**: piazzavano il nemico a un offset fisso dal
  giocatore (+90, +120, +260px) dando per scontato che li' ci fosse pavimento libero e linea di vista — cosa
  vera solo finche' la partenza era il centro sgombro. Ora usano `losSpot()`, che cerca un punto alla distanza
  voluta **senza muro e in vista**: e' la condizione che quei test volevano davvero esprimere.
- **448 passati, 0 falliti** (verificato su 10 esecuzioni consecutive).

### [1.61.1] — 2026-08-26 · "I due nuovi prendono posto nella rampa"

I nemici della 1.61 escono dalla prova e vanno alla loro soglia. Niente altro cambia: stesse def, stessa IA,
stesso render.

#### 🌊 Dove entrano, e perché lì
- **🦇 Nugolo di Pipistrelli → ondata 6** (peso 10). Sta **prima** della Sfera d'Ossa perché insegna la stessa
  lezione dal lato del tiro: il Nugolo chiede di **guidare il colpo** (serpeggia), la Sfera di **schivare di
  lato**. Prima si impara a mirare dove il nemico sarà, poi a togliersi dalla linea. Alla 6 il giocatore ha
  già l'arma evoluta e qualche potere: un nemico veloce e fragile lì è pressione, non muro.
- **🔵 Fuoco Fatuo → ondata 8** (peso 8). Arriva **dopo** perché il suo effetto è *togliere una risposta* —
  mettersi al riparo — e una regola si toglie solo dopo averla insegnata. Fino alla 7 spezzare la linea di
  vista funziona contro Negromante, Fungo e Sfera; dall'8 c'è una cosa a cui il muro non serve.
- Pesi **sotto** lo sciame base (40): sono nemici che cambiano il ritmo, non che riempiono il campo.

#### 📈 La rampa non ha più buchi
Un archetipo nuovo **per ogni ondata dalla 1 alla 8**, poi il Beholder alla 10:
`1 Zombie · 2 Melma · 3 Negromante · 4 Troll · 5 Fungo · 6 Nugolo · 7 Sfera d'Ossa · 8 Fuoco Fatuo · 10 Beholder`.
Prima la 6 e la 8 erano vuote.

#### 🧪 Test
- `testV150` torna a pretendere il **solo** scheletro nell'ondata 1 (l'eccezione `INPROVA` è stata rimossa) e
  verifica le due nuove soglie; aggiunto il controllo che il pool dell'ondata *w* contenga esattamente *w*
  archetipi da 1 a 8 — così un buco nella rampa fa fallire il test invece di passare inosservato.
- `testV161` verifica soglie e pesi al posto della comparsa in prova.
- Reso deterministico un test del Fungo (v1.58) che era **intermittente**: piantava il fungo a offset fisso
  dal giocatore, e se quel punto cadeva dentro un muro il server lo spostava — giustamente — con `_unstuck`,
  facendo fallire l'assertion "non si sposta di un pixel". Ora il punto libero viene cercato.
- **422 passati, 0 falliti.**

### [1.61.0] — 2026-08-26 · "Due nemici che non camminano: lo sciame e il fuoco fatuo"

Continuazione della linea aperta con la v1.58: nemici scelti **perché** il motore non ha cicli di camminata
disegnati a mano da spendere. Nessuno dei due ha gambe, nessuno dei due ha un asset.

> ⚠️ **(Superato dalla 1.61.1: Nugolo dall'ondata 6, Fuoco Fatuo dall'ondata 8.)** Sono in PROVA dall'ondata 1. Serve a vederli subito in partita per decidere da che tier farli
> comparire davvero. Quando la soglia è decisa, in `shared/waves.js` vanno riportati dietro un `if (w >= N)`
> e l'assertion `INPROVA` in `testV150` torna a pretendere il solo scheletro nell'ondata 1.

#### 🦇 Nugolo di Pipistrelli (`bat_swarm`)
- **Una sola entità** disegnata come **9 sagome** che orbitano attorno al centro, ognuna con fase e velocità
  proprie (angolo aureo: non si allineano mai). Le ali sono **una sinusoide di battito**, non fotogrammi.
- **Fragile e velocissimo** (76 PV, vel. 175): il primo nemico da cui non ti allontani camminando.
- **Ondeggia mentre insegue** (IA `flock`): al vettore d'inseguimento somma una componente perpendicolare
  sinusoidale e poi rinormalizza — la velocità resta quella, la traiettoria diventa una **serpentina**.
  Colpirlo in linea retta senza guidare il tiro non funziona. A contatto smette di ballare.
- In attacco il nugolo **si stringe** e scatta; alla morte **si sparpaglia**.
- Contrasto: su roccia quasi nera un pipistrello nero sparisce. Corpo **grigio-viola** con bordo chiaro,
  venature sulle ali e un **alone viola tenue** sotto la massa, così lo sciame si legge a colpo d'occhio.

#### 🔵 Fuoco Fatuo (`wisp`)
- **Il primo nemico che ignora i muri** (`def.phasing`): non lo semini rompendo la linea di vista, ti trova
  sempre. È **lento** (vel. 74), quindi la risposta è muoversi, non nascondersi.
- Quando ti raggiunge **drena**: danno più cura di sé (`leech 0.9`). Evento `drain` → il client disegna le
  scintille che risalgono **dal giocatore verso il fatuo**, così si vede chi sta rubando a chi.
- **Dentro la roccia accelera (×1.7) e non può drenare**: non ci resta mai dentro, e non può spararti da un
  punto dove non puoi rispondere.
- Reso come **fiamma fredda sospesa**: nucleo additivo, lingua di fuoco modulata da tre sinusoidi sfasate,
  tre scintille in orbita, ondeggio verticale lento e due occhietti vuoti dentro il nucleo.

#### 🔧 Server
- `Room.updateMonsters`: i mostri `phasing` si muovono **senza collisione** — niente `moveCircle`, niente
  `_unstuck`, niente anti-incastro (esistono tutti e tre per *rimettere fuori* dai muri). Resta il vincolo
  dei bordi mappa, altrimenti uscirebbero dalla griglia.
- `_separate` salta i `phasing`, così il fatuo non spinge in giro chi attraversa.
- **I nemici `immobile` non vengono più spinti** né dai giocatori (`_pushOff`) né dagli altri mostri
  (`_separate`): il Fungo Sporifero era piantato per design ma scivolava se lo urtavi, e un presidio del
  terreno che si sposta non presidia niente.

#### 🧪 Test
- Nuovo `testV161`: il fatuo **non viene espulso** dal muro (si sposta di meno di mezza tessera contro il
  salto secco di `_unstuck`) ed **esce da solo**; controprova con uno scheletro nella stessa tessera; il
  drenaggio fa danno **e** cura; il nugolo devia lateralmente **oltre 0.30** normalizzato (il solo jitter
  arriverebbe a ~0.08) **cambiando lato**; morso a contatto; niente NaN e nessuno fuori griglia.
- Il conteggio "nessun mostro dentro un muro" esclude ora i `phasing`.
- **408 passati, 0 falliti.**

### [1.60.0] — 2026-08-26 · "Il Troll smette di essere legnoso"

Lastre nuove fornite dall'artista (stessa griglia 5×5 @256px). Prima di toccare il codice le ho **misurate
frame per frame** con Pillow: l'alpha di ogni cella dice dove sono i piedi, la testa e il centro. Tre difetti
venivano dai numeri, non dal disegno.

#### 📏 L'ancora dell'attacco era sbagliata di 11px
- Misurato sui PNG: piedi a y **196-199** (idle), **196-202** (walk), **215-221** (attack). Il manifest
  dichiarava `ay 205` per l'attacco: il troll **saltava di 11px** ogni volta che colpiva, e ne rientrava
  finita l'animazione. È il classico difetto che si legge come "legnoso" senza che si capisca perché.
- Corretto a **216**. Ora le tre animazioni poggiano sulla stessa linea del terreno.

#### 🔨 La martellata arrivava tre fotogrammi prima del danno
- L'impatto visivo è al **fotogramma 15** (misurato: piedi a 221, il punto più basso; testa che crolla da 5 a
  88). Il server infligge il danno a `slamHit 0.72`, che con la mappatura lineare mostrava il **fotogramma
  18** — la posa di recupero. Vedevi colpire e incassavi un attimo dopo.
- Nuova mappatura a **due tratti** ancorata a `hitFrame`: 0→15 su 0→slamHit, 15→24 su slamHit→1. L'impatto
  cade esattamente sul danno **qualunque** valore abbia `slamHit`.
- I primi **7 fotogrammi sono una posa ferma** (area e posizione identiche): la curva `^0.72` li brucia in
  fretta e indugia sul caricamento, dove l'anticipo serve davvero.

#### 👣 Il passo è agganciato al terreno
- La camminata non va più a fps fisso ma a **distanza percorsa** (`cyclePx`, come per la Sfera d'Ossa). I
  piedi non slittano più, e se la velocità cambia — elite, rallentamenti, scaling d'ondata — la cadenza si
  adegua da sola invece di restare inchiodata a 13 fps.

#### 🎞️ Dissolvenza fra animazioni e giro del verso
- I cambi idle↔walk↔attack erano **tagli netti**. Ora c'è una dissolvenza di **0.14s** (`blend` nel manifest).
- Il verso non si ribalta di scatto: passa per lo zero, quindi il troll si **gira** schiacciandosi invece di
  specchiarsi in un fotogramma.

#### 👁️ Beholder dall'ondata 10
- Era alla 15, ora entra dalla **10** (secondo boss). Il tetto di 8 presenze resta.

#### 🧪 Test
- Nuovo **testV160**: verifica che il manifest descriva davvero le lastre, che le tre ancore stiano sulla
  linea dei piedi **misurata**, che la mappatura a due tratti mandi `hitFrame` esattamente su `slamHit` e
  non torni mai indietro, e che la cadenza del passo a velocità nominale sia plausibile.
  **384 passati, 0 falliti.**

---

### [1.59.0] — 2026-08-26 · "Il Beholder smette di essere una boa"

Nella 1.58 del Beholder erano cambiati solo i numeri (ondata 15, tetto di 8). Qui cambia come si muove.
**Nessuno sprite nuovo**: è tutta matematica sullo stesso PNG. Lo spritesheet è stato valutato e scartato —
il §1 di `ENEMIES.md` spiega perché il frame-by-frame perde contro il rig, e il Troll fu l'eccezione solo
perché una camminata bipede è difficile da fingere. Il Beholder non ha gambe.

Il difetto non era la mancanza di animazione: era che **si muoveva tutto insieme**. Quattro interventi:

#### 🦑 Gli eyestalks diventano appendici
- Erano **7 aloni fissi** disposti ad arco. Ora sono **steli curvi** che partono da dietro il bulbo, ognuno
  con **frequenza e fase proprie** (`rate 1.55 + (i%4)*0.47`), quindi non tornano mai in sincrono. In punta
  un occhietto con la sua pupilla, che guarda il bersaglio.
- Disegnati **prima** del corpo: spuntano da dietro invece di stare appiccicati sopra.

#### 👁️ Palpebra e microsaccadi
- **Ammicca** con periodo irregolare per entità (4.2s + un offset ricavato dall'eid): due palpebre che si
  chiudono e riaprono in 0.17s. Un occhio che non ammicca mai è un occhio finto.
- L'iride non insegue più il bersaglio in modo continuo: **scatta** ogni 0.3-0.6s e poi **tiene** la
  posizione, con un filo di jitter. È lo scatto a farlo sembrare vivo; il moto fluido lo faceva sembrare
  una torretta.

#### 🪁 Inclinazione nel movimento
- Si **inclina** nella direzione in cui si sposta, con smorzamento (`lean` interpolato, non istantaneo).
  Prima ondeggiava identico fermo o in corsa.

#### ⏳ Il cambio di sguardo si telegrafa sul corpo
- Il server espone `gt` nello snapshot: quanto manca al prossimo cambio, normalizzato 0-1. Serve per
  **anticipare**, non per reagire dopo.
- Nell'ultimo 16% del ciclo il corpo si **contrae** e gli steli si **drizzano e allungano**; al cambio parte
  un lampo (`flare`) che decade. Prima il cambio lo diceva solo il colore del fascio.

#### 🧪 Test
- Nuovo **testV159**: lo snapshot espone `gt` normalizzato, `gt` **cala** col tempo (il client può
  anticipare) e **riparte** dopo il cambio di sguardo. **367 passati, 0 falliti.**
- Reso e verificato con Chromium nei quattro stati (riposo, ammiccamento, movimento, telegrafo) prima di
  toccare il progetto.

---

### [1.58.0] — 2026-08-26 · "Due nemici senza gambe, la Melma che si divide, il Beholder col guinzaglio"

Tre aggiunte al bestiario scelte per **non richiedere cicli di camminata**: il vincolo tecnico diventa il
criterio di design invece di un ostacolo.

#### 🍄 Fungo Sporifero (`spore_fungus`) — ondata 5+
- **Immobile**: `speed 0`, IA `sentry`. Non insegue, non vaga, non cammina. Se ti vede (LOS libera,
  340px) semina **zone di spore telegrafate** dove ti trovi, due per volta.
- Riempie il buco meccanico che il roster aveva: **nessun nemico puniva lo stare fermi**. Ora il terreno
  sotto i piedi diventa una risorsa.
- Render vettoriale, **zero asset**: cappello che respira, lamelle luminose, gonfiata prima dello sbuffo.
- L'anti-incastro del server lo **ignora** (`def.immobile`): non è bloccato, sta fermo per design.

#### 💀 Sfera d'Ossa (`bone_roller`) — ondata 7+
- Niente gambe: si **carica** (telegrafo `roll_wind`, 0.62s), poi **corre in linea retta** rimbalzando sui
  muri per ~2.3s a 3.1× la sua velocità, e travolge chi trova.
- Anche qui un buco colmato: nessun nemico ti obbligava a **schivare di lato**.
- L'animazione è una **rotazione ricavata dallo spostamento reale**, non da frame: rotola davvero, e se sta
  ferma non gira. Scia di polvere in corsa, schiacciamento in carica.

#### 🟢 La Melma si divide
- `slime` alla morte lascia **2 Melme Minori** (`slime_mini`), che riusano lo stesso sprite a raggio
  ridotto — **nessun asset nuovo**, come lo Zombie Minore col ghoul.
- Le minori **non si dividono**: niente catena infinita. Verificato dal test.

#### 👁️ Beholder col guinzaglio
- Entra nel pool solo dall'**ondata 15** (prima: 6) e ha un **tetto di 8 presenze contemporanee**
  (`def.maxAlive`). Otto debuffer addosso non sono una sfida, sono un interruttore.
- Il tetto è un meccanismo **generico**: quando è pieno lo spawn ripiega sullo sciame base invece di
  saltare, così il conteggio dell'ondata resta quello previsto. Vale anche per la modalità Sopravvivenza.

#### 🌊 Rampa aggiornata
| Ondata | 1 | 2 | 3 | 4 | 5 | 7 | 15 |
|---|---|---|---|---|---|---|---|
| Entra | Zombie | Melma | Negromante | Troll | **Fungo** | **Sfera d'Ossa** | Beholder |

#### 🧪 Test
- Nuovo **testV158**: il Fungo non si sposta di un pixel e semina zone telegrafate; la Sfera si carica,
  parte, percorre distanza e travolge; la Melma lascia esattamente 2 minori e le minori non si dividono;
  il tetto del Beholder regge a 12 tentativi di spawn e ripiega sullo sciame; la rampa resta monotona.
  Aggiornati testV139/V149/V150 (Beholder spostato alla 15). **361 passati, 0 falliti.**

---

### [1.57.0] — 2026-08-25 · "Il mercato è una sala scavata, non un villaggio"

La v1.56 aveva un errore di ambientazione: case col tetto spiovente, alberi e staccionate **sottoterra**.
Rifatto da capo come camera scavata nella roccia.

#### ⛏️ Generatore ribaltato: si scava, non si costruisce
- `generateMarket()` parte da **roccia piena** e *scava* la sala, invece di partire da uno spiazzo e murarlo.
  Fuori dalla sala non c'è mappa: c'è pietra. Pareti **quasi nere** (`wall #050607`).
- **Un solo varco**, a sud, largo 3 tile, su un corridoio corto col **portale EXIT** in fondo. Nord, est e
  ovest sono chiusi — verificato dal test, non a occhio.
- Niente lastricato: il pavimento è la roccia nuda, come nel resto del dungeon.

#### 🔥 Buio, con la luce che nasce dal falò
- La maschera dell'oscurità **torna attiva** anche qui (in v1.56 era disattivata). La sala è illuminata da
  **un'unica grande sorgente circolare centrata sul falò** (`bigLight`, raggio 430px): scopre i cinque
  banchetti e si spegne contro le pareti. Le lanterne appese ai pali fanno da luci di appoggio.
- Il falò entra anche nel passaggio di luce colorata, così la sala è calda e non grigia.

#### 🛖 Banchetti e mercanti
- **Cinque banchetti** a ferro di cavallo attorno al fuoco, aperti verso il varco sud: bancone di pietra e
  legno, tendone a strisce, lanterna accesa sul palo, merce diversa per mestiere. Scalati **1.7×**: il banco
  è più grande del mercante, non viceversa.
- I **mercanti** sono al doppio della taglia della v1.56 e più dettagliati — mantellina, cintura con fibbia,
  pieghe della veste, due braccia con le mani, occhi accesi, l'attrezzo del mestiere in mano — mantenendo la
  silhouette incappucciata di prima.
- Stanno a **2.1 tile** dal proprio banco. A 1.75 finivano *dentro* il tendone: in vista dall'alto "stare
  dietro" vuol dire stare più in alto sullo schermo, ed è lì che sta la tenda.
- Targa del **Fabbro** corretta: era "🔨 Fabbro — Emporio" su una riga e sforava sul banco; ora è "Fabbro"
  con "— emporio —" sotto, come il "— chiuso —" degli altri quattro.

#### 🎛️ Menu di pausa
- Il pulsante diventa **"🏕️ VAI AL VILLAGGIO"** e i due pulsanti stanno **affiancati**: `button.primary` e
  `button.ghost` hanno `width:100%`, che li impilava — annullato dentro `#shopActions`.

#### 🧹 Pulizia
- Rimossi `_bakeBuilding` e i prop di superficie della v1.56 (`house`, `tree`, `fence`, `lamp_post`,
  `market_stall`): non li usava più nessuno.

#### 🧪 Test
- `testV157` sostituisce `testV156`: verifica che la sala sia scavata (niente pavimento fuori, niente muri
  dentro), che il varco sia **uno solo** e a sud, che dallo spawn si **raggiunga il portale a piedi**
  (flood fill), che i banchetti siano 5, tutti diversi e più grandi dei mercanti, che ogni mercante stia
  **dietro** il suo banco, che nessuno finisca dentro la roccia e che la mappa resti **buia**.
  **333 passati, 0 falliti.**
- La sala è stata renderizzata con Chromium e **approvata su anteprima prima** di toccare il codice del
  progetto: due giri di correzioni (mercanti dentro il tendone, targa che copriva la faccia) sono avvenuti
  in sandbox, non sul repository.

---

### [1.56.0] — 2026-08-25 · "Il mercato è un villaggio"

La sosta smette di essere una caverna riciclata: mappa dedicata, disegnata a mano.

#### 🏘️ Mappa dedicata, metà misura, senza muri
- Nuovo generatore `MapGen.generateMarket()`, separato da quello delle ondate. **32×24 tile contro 46×34**
  (il **49%** dell'area): una sosta va letta a colpo d'occhio, non esplorata.
- **Nessun muro interno.** Gli unici blocchi solidi sono i **5 edifici** — e sono solidi *nella griglia*, così la
  collisione arriva gratis dal sistema di tile invece di richiedere una collisione per-oggetto.
- **Villaggio illuminato** (`map.lit`): la maschera della torcia viene saltata. Un rifugio al buio pesto,
  con la lanterna che scopre un metro alla volta, contraddiceva l'idea stessa di posto sicuro.
- **Tema dedicato** (`village`), caldo, e piazza ripulita: nel mercato spariscono massi, buche e le crepe
  profonde del generatore da caverna, che facevano sembrare la piazza un crollo. Restano i ciottoli.

#### 🏠 Cinque costruzioni, cinque abitanti
- **Fucina · Locanda · Magazzino · Cappella · Torre della Gilda**, disposte attorno a una piazza col pozzo.
  Ognuna con tetto spiovente, finestre illuminate, insegna sopra la porta, lanterna accesa e targa col nome.
  La Fucina ha il comignolo che fuma.
- **5 NPC**: il **Fabbro** è l'unico che vende (i 3 slot dell'equipaggiamento); **Erborista, Locandiere,
  Cartomante e Banditore** sono botteghe **ancora chiuse** e lo dicono, così nessuno resta lì a premere tasti
  aspettando un pannello che non esiste. Sono i posti già pronti per le prossime destinazioni.
- Arredo: pozzo centrale, lampioni che illuminano davvero, banchi del mercato, casse, barili, alberi,
  staccionate, stendardi e il cartello **MERCATO**.
- Il percorso è leggibile: si arriva da sud, il fabbro è a **7 tile**, il portale **EXIT** a **13**, con la
  colonna centrale sgombra.

#### 🧪 Test
- Nuovo **testV156**: proporzione dell'area, assenza di muri interni oltre agli edifici, 5 costruzioni tutte
  diverse e solide nella griglia, 5 abitanti di cui uno solo attivo, **nessun abitante o arredo dentro un
  edificio**, corridoio centrale sgombro, mappa dichiarata illuminata e priva di spawn nemici e casse, e
  40 rigenerazioni di fila senza che un giocatore compaia dentro un muro. **334 passati, 0 falliti.**
- Verifica visiva: la mappa è stata renderizzata fuori dal gioco con Chromium per controllare il disegno di
  edifici, arredo e abitanti prima della consegna.

---

### [1.55.0] — 2026-08-25 · "Costi XP a tabella: primi sei ×3, ultimi due ×2"

#### 📏 Prima di tutto: il modello di reddito era sbagliato
Le tarature 1.51→1.54 sono state calcolate su una stima **senza combo**, che valutava l'ondata 2 a ~99 XP.
Misurata in partita vera ne frutta **240**: il modello sottostimava di circa **2.4×**. Una run non vale ~7.500
XP ma **~18.000**. Tutte le conclusioni precedenti su "quanto puoi permetterti" erano ottimistiche di
conseguenza — ed e' il motivo per cui il negozio continuava a sembrare facile nonostante due giri di rincari.

#### ✦ Nuova scaletta
| Livello | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|--:|--:|--:|--:|--:|--:|--:|--:|
| v1.54 (base 10) | 30 | 48 | 66 | 185 | 517 | 1449 | 2463 | 4187 |
| **v1.55** | **90** | **144** | **198** | **555** | **1551** | **4347** | **4926** | **8374** |
| rapporto | ×3 | ×3 | ×3 | ×3 | ×3 | ×3 | ×2 | ×2 |

- Portare **una** statistica al tetto: da 8.945 a **20.185 XP** — piu' di una run intera anche col reddito
  reale. L'albero completo: da 53.670 a **121.110**, cioe' fuori portata per progetto.
- Il primo livello costa **90** contro i ~130 XP della prima ondata: si compra una cosa sola, e si sceglie.

#### 🧰 I costi sono ora una TABELLA, non una formula
- `STAT_COST_STEPS` elenca un moltiplicatore per livello. La taratura procede per interventi diretti sui
  numeri ("triplica i primi sei, raddoppia gli ultimi due") e nessuna formula unica li segue senza distorcere
  il resto della curva — la v1.54 aveva gia' richiesto tre regimi e due costanti di raccordo. Con la tabella si
  tocca esattamente il livello che si vuole toccare, e la scaletta si legge a colpo d'occhio.

#### ⚠️ Nota sul 7° livello
Triplicando il tronco e raddoppiando la coda, il **7° costa solo il 13% piu' del 6°** (4.926 contro 4.347),
mentre ogni salto precedente era di +180%. E' un gradino piatto in mezzo al muro: dopo aver pagato il 6°, il 7°
sembra regalato. Se in partita da' fastidio, e' il primo numero da alzare — riga `STAT_COST_STEPS`, settimo
valore.

#### 🧪 Test
- `testV153` verifica il fattore ×3 sui primi sei livelli, il ×2 sugli ultimi due, la monotonia, la
  proporzionalita' al `base` della statistica e le soglie di costo complessivo. **309 passati, 0 falliti.**

---

### [1.54.0] — 2026-08-25 · "Esperienza: tronco triplicato, coda smorzata"

Ritaratura della sola curva del negozio XP: la v1.53 era ancora troppo generosa nel tratto in cui si spende
davvero. Nessun'altra modifica.

#### ✦ Tre regimi invece di due
- **Livelli 1-6 × 3.** Tutto il tronco costa il triplo della v1.53. La prima ondata frutta ~56 XP e il primo
  livello ne costa **30**: la spesa diventa una decisione dalla partita numero uno, non da metà run.
- **Livello 7 adeguato** al nuovo tronco (1.352 → **2.463**): triplicandolo sarebbe finito a 4.056, cioè sopra
  l'ottavo della v1.53 — la curva si sarebbe ribaltata.
- **Livello 8 solo ritoccato** (3.786 → **4.187**, +11%). Gli ultimi due livelli sono smorziati apposta
  (`STAT_TAIL_MULT` 1.7 invece di 2.8): triplicati sarebbero diventati **decorativi**, fuori portata in
  qualunque run. Così restano trofei di fine partita.

  | Livello | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
  |---|--:|--:|--:|--:|--:|--:|--:|--:|
  | v1.53 (base 10) | 10 | 16 | 22 | 62 | 172 | 483 | 1352 | 3786 |
  | **v1.54** | **30** | **48** | **66** | **185** | **517** | **1449** | **2463** | **4187** |
  | rapporto | ×3.00 | ×3.00 | ×3.00 | ×2.98 | ×3.01 | ×3.00 | ×1.82 | ×1.11 |

- Portare **una** statistica al tetto passa da 5.903 a **8.945 XP** — più dell'intera raccolta di una run
  (~7.500). L'albero completo da 35.418 a **53.670**. Il tetto di una singola statistica è ora raggiungibile
  solo giocando la **COMBO** (moltiplicatore XP fino a ×2.5), che diventa a tutti gli effetti la seconda
  economia del gioco.
- Segnale misurato: i bot dei test (che comprano a caso) passano da ondata 7 a ondata 4 nello stesso tempo
  simulato. Sono bot stupidi — indicatore di direzione, non verdetto.

#### 🧪 Test
- `testV153` aggiornato: verifica il fattore ×3 sui primi sei livelli, l'adeguamento del settimo, il ritocco
  contenuto dell'ottavo, la monotonia della curva e che il bottino della prima ondata basti per **un solo**
  livello. **312 passati, 0 falliti.**

---

### [1.53.0] — 2026-08-25 · "Il mercato si sceglie, il portale si vede, l'esperienza costa"

#### 🚪 Il portale EXIT del mercato ora si vede
- `mapgen` piazza l'uscita nella cella **più lontana dal centro**: in una mappa di combattimento ha senso, in
  una **sosta** no — atterri al centro e il portale è fuori schermo. Il mercato ora si dispone da sé
  (`_layoutMarket`): **fabbro a ~4 tile** dal punto di atterraggio, **portale a ~9 dalla parte opposta**.
  Appena arrivi vedi il fabbro; girandoti vedi la via d'uscita.
- La tile `T_EXIT` viene spostata **nella griglia**, non solo in `map.exit`: il client disegna il portale
  scandendo le tile quando riceve la mappa, quindi cambiare solo `map.exit` avrebbe lasciato il bagliore
  vecchio dov'era.

#### 🎯 Il mercato è una destinazione, non una cadenza
- Sparisce la regola "ogni 3 ondate". Il menu di pausa fra un'ondata e l'altra ha ora **due pulsanti**:
  **▶ PROSSIMA ONDATA** e **🔨 VAI DAL FABBRO**. Ci vai quando ti serve, a qualunque ondata.
- **Co-op:** vale la **prima scelta espressa**, coerente con la regola del portale ("il primo che entra decide").
- I pulsanti stanno in `#shopActions`: aggiungere una destinazione futura = un `<button>` in più lì e un
  valore di `dest` in più in `_afterShop()`. **Spazio** resta la scorciatoia per l'ondata successiva.

#### ✦ Esperienza: apertura più dolce, coda molto più dura
- La curva della v1.51 (`2.05^n` uniforme) era ripida **già al secondo livello** — 10 → 21 → 42 quando ancora
  non hai reddito — e comunque troppo mite in fondo. Ora è **spezzata**: i primi 3 livelli sono quasi lineari,
  poi si sale di **2.8× a livello**.

  | Livello | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
  |---|--:|--:|--:|--:|--:|--:|--:|--:|
  | v1.51 (base 10) | 10 | 21 | 42 | 86 | 177 | 362 | 742 | 1522 |
  | **v1.53** | 10 | **16** | **22** | 62 | 172 | **483** | **1352** | **3786** |

- Portare **una** statistica al tetto passa da **2.968** a **5.903 XP**, cioè circa **l'intera raccolta di una
  run**. L'albero completo passa da 17.760 a **35.418 XP**. Specializzarsi non è più consigliato: è obbligato,
  e la **COMBO** (moltiplicatore XP fino a ×2.5) diventa la leva che decide quanto puoi permetterti.
- Segnale misurato: i bot dei test, che compravano a caso, ora si fermano quasi sempre al **boss dell'ondata 5**
  invece di superarlo. Sono bot stupidi, quindi è un indicatore di direzione, non un verdetto — ma la direzione
  è quella richiesta.

#### 🧪 Test
- Nuovo **testV153**: destinazioni del menu di pausa, prima-scelta-vince in co-op, distanze di fabbro e portale
  dal punto di atterraggio, unicità della tile EXIT nella griglia, monotonia e severità della nuova curva XP.
  `testV18` e `testV152` aggiornati alla scelta esplicita; i bot dei full-run passano dal fabbro nel 25% dei
  casi. **309 passati, 0 falliti.**

---

### [1.52.0] — 2026-08-25 · "MERCATO: l'Emporio smette di essere un pannello e diventa un luogo"

L'acquisto diretto dell'equipaggiamento a fine ondata — nascosto in v1.51 — è sostituito da una **mappa di sosta**
in cui il mercante è un NPC a cui ci si avvicina, come il Mercante Errante.

#### 🏪 La mappa MERCATO
- Ogni **3 ondate** (`C.MARKET_EVERY`) si entra in una mappa **senza nemici**, col **fabbro dell'equipaggiamento**
  piazzato al **centro**.
- È **INTERSTIZIALE**: non consuma un numero d'ondata. Così la cadenza dei boss (ogni 5) resta intatta e sparisce
  la collisione all'ondata 15 — il mercato la **segue** invece di sostituirla. Ed è il momento giusto: **il 58%
  delle monete di una run arriva dai boss**, quindi la sosta cade quando sei appena diventato ricco.
- Niente **casse** (il 30% è una cassa-mima, cioè un nemico in una stanza che promette sicurezza) e niente
  **Mercante Errante**: quello resta un incontro delle ondate normali, con le sue offerte uniche.
- Si prosegue entrando nel **portale EXIT**: nel mercato è disegnato più grande, verde, con colonna di luce ed
  etichetta leggibile anche col buio della torcia. **Co-op: il primo che entra porta avanti tutti**; timeout
  anti-AFK a 120s solo in multiplayer, come già fa il negozio.
- Uscendo, la mappa viene **rigenerata a forza** (`_forceNewMap`): senza, l'ondata successiva si sarebbe
  combattuta dentro la stanza del fabbro, perché la rigenerazione avviene solo alle ondate dispari.

#### 🔨 Il fabbro dell'equipaggiamento
- I 3 slot (Armatura, Stivali, Arma) si comprano **solo** stando vicino a lui: `buyGear` verifica **fase e
  distanza**, non più solo la fase.
- Render dedicato `_drawGearMerchant`: forgia con carboni che tremolano, incudine con scintille, martello che
  batte. Beacon ambra sempre acceso e marker sulla minimappa.
- Il pannello riusa le carte `.gc` dell'Emporio e si ricostruisce **solo al cambio di offerta o monete** — la
  stessa precauzione del fix v1.34 sul Mercante Nero, che ricreando le card a ogni frame le rendeva invisibili.

#### 🐛 FIX — i mercanti erano invisibili sulla mappa
- `merch` e `merchD` non venivano **mai** copiati dallo snapshot dentro `buildWorld()`: `world.merch` restava
  `null` per sempre, quindi `_drawMerchant` e `_drawDarkMerchant` non venivano **mai** chiamati. Mercante
  Errante e Mercante Nero erano **invisibili** — beacon "sempre visibile" e marker sulla minimappa compresi —
  e li si trovava solo per caso, camminandoci addosso. Ora vengono aggiornati insieme al resto del mondo.

#### 🧪 Test
- Nuovo **testV152**: cadenza interstiziale, assenza di nemici/casse/mercante errante nel mercato, fabbro al
  centro, acquisto negato da lontano e concesso da vicino, apertura/chiusura del pannello per prossimità,
  uscita dal portale con rigenerazione della mappa. `testV18` aggiornato (l'equipaggiamento ora si compra dal
  fabbro) e i bot dei test sanno raggiungere il portale EXIT. **292 passati, 0 falliti.**

---

### [1.51.0] — 2026-08-25 · "Level up rivisto: 1 di 3 carte, dieci poteri nuovi, negozio XP che obbliga a scegliere"

Il momento fra un'ondata e l'altra chiedeva **tre** decisioni al giocatore, ma una sola era davvero una decisione.
Questa versione rimette al centro le **carte potere** e trasforma il negozio XP da rubinetto a scelta.

#### 🎴 Si sceglie 1 potere su 3 (erano 2 dalla v1.10)
- Il catalogo era stato ampliato a 23 poteri **riducendo** contemporaneamente le carte offerte da 3 a 2: catalogo più
  grande e meno pescate significa vedere una frazione sempre più piccola del design. Ora si torna a **3 carte**,
  sempre con **una sola selezionabile**.
- Con la composizione attuale del catalogo, un'estrazione è al 63% *non comune*, 28% *rara*, 9% *epica*: la terza
  carta è ciò che rende probabile vedere almeno qualcosa di raro quando conta.

#### ✨ Dieci poteri nuovi (catalogo da 23 → 33)

  | Potere | Rarità | Effetto | Ispirazione |
  |---|---|---|---|
  | ⛏️ **Piede di Porco** | non comune | +40% danno sui nemici sopra il 90% dei PV | *Risk of Rain* — Crowbar |
  | 🔭 **Tiro Lungo** | non comune | più lontano è il bersaglio, più fai male | *Risk of Rain* — Laser Scope |
  | 💃 **Passo di Danza** | non comune | +25% velocità per 2s a ogni uccisione | *Hades* |
  | 🧲 **Fame Vorace** | non comune | raggio di raccolta molto più ampio, +15% XP | *Vampire Survivors* |
  | 💢 **Rappresaglia** | raro | farsi colpire emette un'onda che danneggia e respinge | *Dead Cells* |
  | 🧿 **Egida Ostinata** | raro | annulla per intero un colpo ogni 8s | *Hades* — Stubborn Defiance |
  | ☄️ **Deflagrazione Cadaverica** | raro | i nemici uccisi esplodono | *Risk of Rain* — Gasoline |
  | 🗡️ **Colpo di Grazia** | epico | esegue i nemici sotto il 12% dei PV (mai i boss) | *Dead Cells* |
  | 🔊 **Eco Arcana** | epico | il 20% dei colpi parte una seconda volta, gratis | *Binding of Isaac* |
  | ⏳ **Ultima Occasione** | epico | invece di cadere risorgi al 50% dei PV | *Hades* — Death Defiance |

- Nessuno è un semplice "+X%": ognuno cambia **come** giochi — apri i tank, tieni la distanza, non ti fermi mai,
  ti fai colpire di proposito, chiudi le esecuzioni.
- **Due nuove sinergie** legano il nuovo al vecchio: 🎯 **Cacciatore di Teste** (Colpo di Grazia + Piede di Porco →
  soglia di esecuzione +6 punti) e 🌊 **Onda d'Urto** (Rappresaglia + Aura di Spine → onda molto più ampia).

#### ✦ Negozio XP: da rubinetto a scelta
- **Il problema, in numeri.** La curva era `base × 1.55^n` con livelli **illimitati**. Portare tutte e sei le
  statistiche a Lv.8 costava **3.526 XP**, contro le **~7.528 XP** raccolte in una run intera: si comprava tutto,
  e l'ordine degli acquisti non aveva conseguenze.
- **La correzione.** Curva a `2.05^n` e **tetto di 8 livelli** per statistica. L'albero completo costa ora
  **17.768 XP**: circa il **42%** è alla portata di una run normale, fino a **~84%** giocando la combo (che
  moltiplica l'XP fino a ×2.5). Specializzarsi diventa obbligatorio, e la **combo** smette di essere decorativa.
- Le carte del negozio mostrano ora `Lv.3/8` e diventano **MAX ★** quando la statistica è esaurita.

#### 🪙 Emporio a monete temporaneamente nascosto
- L'Emporio (Armatura / Stivali / Arma) **non compare più** a fine ondata: flag `C.SHOP_GEAR_ENABLED = false`.
  Nulla è stato cancellato — `offerGear`, `buyGear`, le icone e la UI restano al loro posto e si riaccendono
  rimettendo il flag a `true`. Le **monete continuano a cadere** e restano spendibili dai due **mercanti** in mappa.
- Motivo tecnico che rendeva l'Emporio ridondante: comprava quasi le stesse statistiche del negozio XP con una valuta
  diversa (Stivali +5% velocità ≡ Agilità +5% velocità; Arma +8% danno ≈ Potenza +9%).

#### 🎒 Barra dei poteri attivi (HUD)
- Nuova riga di gettoni sopra la barra abilità: mostra ogni potere posseduto con **icona, colore della rarità e
  moltiplicatore** (×2, ×3), più le **sinergie** attive evidenziate. Passandoci sopra compare nome e descrizione.
- Non passa dallo snapshot (che gira 20 volte al secondo): il server invia l'elenco solo **quando cambia**
  (scelta di un potere, sinergia sbloccata, inizio partita) con il nuovo messaggio `C.MSG.BOONS`.

#### 🧪 Test
- Nuovo **testV151**: le 3 carte, la presenza e applicabilità dei 10 poteri, l'assenza di id duplicati, il tetto di
  livello davvero invalicabile, il costo dell'albero completo, l'Emporio che non viene più offerto, il Colpo di
  Grazia che esegue, l'Ultima Occasione che consuma una carica, l'Egida che para una volta sola, e una run con
  **tutti e dieci** i poteri al massimo senza NaN. Aggiornato testV110 (2 → 3 carte). **273 passati, 0 falliti.**
- Nuova suite **`test/client.js`**: smoke test dell'interfaccia con un DOM finto (niente browser). `hud.js` non era
  coperto da nulla, e questa versione lo tocca parecchio. `npm test` ora lancia entrambe le suite.
- `ROSTER.md` ed `ENEMIES.md` non sono stati toccati: questa versione non modifica alcun nemico.

---

### [1.50.0] — 2026-08-25 · "Consolidamento: curva di difficoltà ripristinata, elite tarati, documentazione riallineata"

Versione di **consolidamento**: nessun mostro nuovo. Dalla 1.37 alla 1.49 — tredici versioni — il lavoro è stato
quasi interamente sul **rendering** dei nemici; nel frattempo si era accumulato debito su **bilanciamento** e
**documentazione**. Questa versione lo salda prima di rimettere mano al gameplay.

#### 🌊 Curva di introduzione dei nemici ripristinata (`shared/waves.js`)
- Le comparse **"dal primo stage"** aggiunte in v1.44 (Melma, Bruto) e v1.49 (Beholder) erano **temporanee**:
  servivano a valutare i nuovi sprite, ma sono rimaste nel codice. Risultato: all'ondata 1 il pool conteneva già
  **4 archetipi su 5**, tank tier 2 e debuffer tier 3 compresi, e la rampa di difficoltà era di fatto sparita.
- Nuova rampa — un archetipo nuovo ogni 1-2 ondate, coerente coi **tre pilastri** descritti in `ROSTER.md`:

  | Ondata | Entra nel pool | Archetipo |
  |---:|---|---|
  | 1 | 🟢 Zombie Putrido | sciame mischia |
  | 2 | 🟢 Melma Corrosiva | blob acido ravvicinato |
  | 3 | 🟣 Negromante | caster / evocatore |
  | 4 | 🟠 Troll delle Caverne | tank con slam ad area |
  | 6 | 👁️ Beholder | debuffer, dopo il primo boss |

#### ⚔️ Moltiplicatore PV degli elite reso PER-NEMICO (`def.eliteHp`)
- Il `2.4x` fisso sugli elite era tarato sui nemici da ~80-100 PV. Applicato ai più robusti produceva mostri
  fuori scala: un **Troll elite** all'ondata 4 arrivava a **~845 PV** contro l'arma iniziale.
- Ora ogni def può dichiarare `eliteHp` (default invariato `2.4`): **Troll `1.5`** (~528 PV all'ondata 4),
  **Beholder `1.9`**. Tutti gli altri nemici mantengono esattamente il comportamento precedente.

#### 📚 Documentazione riallineata
- **`ROSTER.md`** era il più arretrato (fermo alla 1.47): mancavano **Melma Corrosiva** e **Beholder** dalla tabella
  comparativa, il Troll era ancora chiamato "Bruto delle Caverne" e descritto come puppet (dalla 1.47 è uno
  **sprite sheet**), e l'intestazione dichiarava "tutti i nemici d'ondata usano il RENDER PUPPET". **Riscritto.**
- **`README.md`**: il titolo diceva ancora `v1.28.1`; sezione **Architettura** aggiornata (mancavano `public/assets`
  e `tools/`, cioè proprio le cartelle nate col metodo puppet).
- **`ENEMIES.md`** §12: la **checklist di release** conteneva ancora il punto *"ripacchettizzare come `.txt`
  (zip mascherato)"* — il workflow precedente al repository git. Sostituito col **commit**; aggiunti `ROSTER.md`
  ed `ENEMIES.md` fra i documenti da aggiornare (ROSTER **non era in lista**: è la causa del suo arretramento).
- Aggiunta alla checklist la **trappola degli id**: `skeleton` = Zombie Putrido · `cave_brute` = Troll ·
  `occhio` = Beholder.

#### 🧪 Test
- Nuovo **testV150**: verifica la rampa ondata per ondata, la sua **monotonia** (nessun archetipo che sparisce
  crescendo di ondata) e il tetto PV degli elite tank. Aggiornati testV142 / testV145 / testV149, che asserivano
  la vecchia comparsa "dal primo stage". **256 passati, 0 falliti.**

---

### [1.49.0] — 2026-08-11 · "Beholder: l'Occhio Tiranno torna nel roster (Sguardo multi-raggio)"

##### 👁️ Ritorna il BEHOLDER (id `occhio`)
- Reintrodotto l'**Occhio Vagante** come **BEHOLDER**: bulbo oculare fluttuante con **eye-stalks** e **tentacoli
  tutt'intorno**, aura emissiva magenta, iride che segue e pupilla che si dilata in attacco. Vista frontale (`_eyeF`).
- **Attacco = SGUARDO** (niente proiettili): se entri nel suo **campo visivo** (cono attorno allo sguardo, in
  gittata e con **LOS libera**) subisci un **debuff** che si rinnova finche resti "sotto gli occhi".
- **EYESTALKS CHE RUOTANO (novita):** il Beholder **alterna ciclicamente** i tre tipi di sguardo (multi-raggio)
  ogni ~4s — 🟠 **weaken** (attacco indebolito) · 🔵 **slow** (velocita ridotta) · 🟣 **sunder** (meno difesa) —
  e il **fascio si ricolora** in base al tipo attivo.
- **Stat:** tier 3, **130 PV**, gittata sguardo **340**, danno contatto 16, IA **gazer** (orbita a distanza).
  Aggiunto a `ORDER` e al **pool dal primo stage** (per valutazione), peso basso.

##### 🎨 Render RASTER PUPPET (metodo puppet, non piu vettoriale)
- Il Beholder usa il **RENDER PUPPET raster** (illustrazione ritagliata → manifest + profilo), come ghoul/negromante/
  bruto/melma: nuovo asset `public/assets/enemies/beholder/body.png` + `beholder.json` (slicer `tools/slice_beholder.py`).
- Render **dedicato** `_beholderPuppet`: corpo billboard che fluttua e "respira", **IRIDE centrale che SEGUE** il
  bersaglio e **pupilla che si dilata** in attacco, **eyestalks che avvampano** nel colore dello sguardo attivo,
  **edge-glow** magenta pulsante. Morte dedicata (l'occhio implode e svanisce). La meccanica IA (gazer) resta.

##### 🧪 Test
- Nuovo **testV149** (Sguardo debilitante nel campo visivo + eyestalks che ruotano) e testV139 aggiornato
  (occhio non e piu "rimosso"): **246 passati, 0 falliti**.

---

### [1.48.0] — 2026-08-10 · "Fix Troll sprite-sheet: cammina davvero, non fluttua, ombra ai piedi"

#### 🐛 Fix animazione & grounding dello sprite-sheet
- **Camminata che non partiva:** i mostri **lenti** (Troll, speed 60 ≈ 1px/frame; in vagabondaggio anche 0.5px)
  restavano in **idle mentre scivolavano** perché la soglia del rilevamento movimento (`pv.mv > 0.95`) era troppo alta.
  Ora le soglie con **isteresi** sono **0.28/0.10**: il Troll passa correttamente allo stato **walk** (verificato: 60px/s
  e 30px/s → animazione di camminata; 0px/s → idle).
- **"Fluttua" + ombra troppo distante:** lo sprite-sheet ancora i **piedi** su `(m.x, m.y)`, ma riceveva anche
  l'**ombra generica** disegnata a `y + rr·0.75` (~28px **sotto** i piedi) → sembrava galleggiare sopra la sua ombra.
  Ora lo sprite-sheet è **escluso** dall'ombra generica e disegna una **propria ombra sfocata esattamente ai piedi**:
  il Troll è ben "piantato" a terra, niente più fluttuazione.

#### 🧪 Test
- Nessuna regressione: **234 passati, 0 falliti**.

---

### [1.47.0] — 2026-08-10 · "Troll delle Caverne: SPRITE SHEET animato (idle/walk/attack) al posto del puppet"

#### 👹 Nuovo render: SPRITE SHEET frame-by-frame (stile 2.5D "da sala")
- Il **Troll delle Caverne** (ex Bruto, id `cave_brute`) non è più un puppet a pezzi: ora usa un **vero sprite sheet
  animato** disegnato a mano — **3 fogli 5×5 @256px** (idle, walk, attack). La camminata è **naturale** (nessun rig da
  tarare) e l'attacco è una **martellata** completa (25 frame).
- **Nuovo motore SPRITE SHEET** nel renderer (`SHEETS[key]` + `_drawSheet`): sceglie l'animazione dallo stato
  (idle/walk/attack), il frame dal tempo (loop, con sfasamento per‑nemico) o dalla fase d'attacco (one‑shot), ritaglia
  la cella dalla griglia e la disegna **ancorata ai piedi** con **mirror L/R** per la direzione. Hit‑flash e ombra inclusi.
- **Attacco pilotato dall'evento slam:** parte al `slam_wind` (con eid) e i 25 frame coprono l'intera martellata; il
  **danno ad area** e la scossa scattano al **72%** dello swing (`slamHit`) per coincidere con l'impatto a schermo.
- Il Troll mantiene l'IA v1.43 (vede/insegue, vagabondaggio, anti‑incastro). Rinominato in "Troll delle Caverne".

#### 🧪 Test
- Nuovo `testV147` (il Troll ora è `sheet:'troll'`, wind‑up + danno d'impatto): **234 passati, 0 falliti**.

---

### [1.46.0] — 2026-08-10 · "Bruto: camminata senza tremore + parti ritagliate meglio · Melma in vista TOP-DOWN"

#### 👹 Bruto — via il "tremore" (camminata rifatta) + nuovi ritagli
- **Camminata rifatta** per eliminare l'effetto "parkinson": **un solo dondolio lento e ampio**, braccia enormi che
  oscillano **in sincronia** (rimosso il rollio nervoso delle spalle), **sollevamento del piede morbido** (mezzo‑coseno,
  niente scatti) e **fase sempre continua**.
- **Anti‑sfarfallio:** il rilevamento movimento ora usa **isteresi + forte smoothing**. I mostri **lenti** (come il Bruto,
  che sfiorava la soglia) non alternano più di continuo idle↔camminata → niente più tremolio.
- **Parti ritagliate meglio:** sostituiti i 6 PNG del Bruto con i tuoi ritagli puliti (stesso manifest, cuciture migliori).

#### 🟢 Melma Corrosiva — ora in vista TOP‑DOWN (pozza fluo)
- La Melma non è più un blob "in piedi": è una **pozza fluorescente vista dall'alto** che **striscia** sul pavimento.
  Render dedicato `_slimePuddle` (niente billboard/ombra): **wobble gelatinoso**, **stiramento** nella direzione di
  marcia, leggero ondeggio e **edge‑glow verde** pulsante che avvampa in attacco/quando colpita; **bolle acide** che salgono.
  Morte: la pozza **si restringe e svanisce**. Invariata la meccanica (striscia lenta + **sputo di bolle d'acido** ad alto danno).

#### 🧪 Test
- Suite aggiornata (Melma top‑down): **226 passati, 0 falliti** · boss‑navigabilità **2100/2100 (100%)**.

---

### [1.45.0] — 2026-08-10 · "Melma Corrosiva: STRISCIA lenta + SALTA e SPUTA acido · sprite senza bocca + edge-glow"

#### 🟢 Movimento rifatto: la Melma STRISCIA (niente più saltelli)
- In movimento la Melma non fa più su‑e‑giù: ora **striscia** con un'onda **peristaltica** (si stira in avanti →
si contrae) **restando sempre a terra**. Movimento **lento** (velocità 66 → **52**).
- Il **SALTO** avviene **solo durante l'attacco** (unico momento in cui si stacca da terra).

#### 💥 Attacco: salta e SPUTA bolle d'acido ad ALTO danno (ravvicinato)
- Nuova IA **blob**: la Melma si avvicina strisciando e, **quando è vicina** (in gittata, con linea di vista libera),
**SALTA** e **sputa un ventaglio di bolle d'acido** ad **alto danno** (`acidMult 1.8`, 3 bolle, `atkRange 150`).
Il contatto ravvicinato fa comunque danno. Nuovo evento `acid` (salto + FX di sputo). Se non ti vede, **vaga**.

#### 🎨 Sprite & effetti
- Nuovo sprite **senza bocca** e senza nucleo centrale (solo occhi), con **bagliore verde sul bordo** (edge‑glow) che
maschera l'effetto ritaglio. **Occhi che si illuminano nella DIREZIONE DI MOVIMENTO** (più intensi in marcia, pupilla
spostata in avanti). Restano **aura verde** pulsante e **bolle acide** che salgono.

#### 🧪 Test
- `testV145` aggiornato (IA blob, sputo acido ostile ad alto danno, lentezza, primo stage): **226 passati, 0 falliti**.

---

### [1.44.0] — 2026-08-10 · "Melma Corrosiva (squash & stretch) + Bruto affinato (passo & slam) + entrambi nel primo stage"

#### 🟢 Nuovo nemico: Melma Corrosiva (render PUPPET, squash & stretch)
- Quarto puppet: un **blob acido** reso con **UN solo pezzo** animato in **SQUASH & STRETCH** (scala non uniforme
  attorno alla base), non a giunti. Idle: **gelatina che respira** (jiggle). Movimento: **saltello** — si **appiattisce**
  a terra (largo/basso) e si **allunga** in aria (stretto/alto). Attacco: si **comprime** (carica) poi **schizza** in avanti.
- **Effetti grafici** (come richiesto): **AURA VERDE** pulsante marcata (`def.aura`), **nucleo verde acido** che pulsa
  al centro (man.core), **occhi che avvampano** al colpo, e **bolle acide** che salgono (`def.bubbles`).
- Il motore puppet ora supporta lo **squash & stretch** (`pose` può restituire `sx/sy`), riusabile da tutti i puppet.
- **Stat:** tier 1, 90 PV, lento (66), danno 12. Nel pool **dal primo stage**.

#### 👹 Bruto — passo e slam affinati
- **Camminata: il piede si SOLLEVA da terra** (nuovo `WALK.lift`) e la **falcata è più ampia** (`leg` 22→34): ora si
  "muovono i piedi", il passo è ben leggibile.
- **SLAM più impattante:** affondo del corpo più **profondo e deciso** (bob/tilt/lungeX aumentati) e FX di **schianto
  potenziati** — **doppia onda d'urto** + **anello di polvere**, **burst di detriti**, **hit-stop** e **scossone più forte**.

#### 🧪 Test
- Nuovo `testV144` (Melma puppet, aura/bolle, slime+bruto nel primo stage): **221 passati, 0 falliti**.

---

### [1.43.0] — 2026-08-10 · "Bruto ridisegnato (camminata lumbering + slam overhead), vagabondaggio & anti-incastro"

#### 👹 Bruto delle Caverne — movimento e attacco rifatti
- **Camminata distinta dallo zombie:** niente più braccia in grande opposizione (troppo simili allo zombie). Ora è
  un **incedere lumbering** da ogre: le braccia **dondolano poco e in sincronia** (knuckle-drag), con **grande rollio
  delle spalle**, **waddle laterale marcato**, busto **proteso in avanti** e cadenza più lenta.
- **Attacco = SLAM overhead:** quando ti **VEDE** (campo visivo `sightRange` + linea di vista) ed sei a tiro, il Bruto
  **ALZA entrambi i pugni sopra la testa** (wind-up telegrafato) e li **SCHIANTA a terra** — danno ad **AREA** con
  **forte respinta** (ti scaglia via). Il telegrafo (~0.7s) ti dà il tempo di schivare. Nuovi parametri: `slamWind`,
  `slamKnock`, `slamRadius 104`, `atkRange 70`.

#### 🧭 Vagabondaggio quando il nemico non ti vede
- Se un nemico **non ti vede** (fuori dal `sightRange` o senza linea di vista) e non ha una posizione recente da
  investigare, ora **VAGA a caso** per la mappa (bersagli casuali raggiungibili) invece di puntarti sempre come un
  laser. Quando ti individua ti insegue; se ti perde di vista, **investiga** l'ultima posizione nota e poi torna a
  vagare. Applicato a Zombie e Bruto (perceive/investigate/wander in `ai.js`).

#### 🧱 Anti-incastro per TUTTI i nemici (boss compresi)
- Nuovo **rilevatore di incastro** per ogni mostro: se prova a muoversi ma **non avanza** (wedge in un angolo, pur non
  essendo dentro un muro) parte un **recupero** che lo fa **scivolare** nella direzione libera più utile; se persiste,
  un **piccolo salto** verso la cella libera più vicina. `_unstuck` potenziato. Verificato: **0 mostri/boss** restano
  dentro un muro dopo stress con tutti i boss in campo; boss-navigabilità mappe **2100/2100 (100%)**.

#### 🧪 Test
- Nuovo `testV143` (vagabondaggio, wind-up slam, anti-incastro con boss): **213 passati, 0 falliti**.

---

### [1.42.0] — 2026-08-10 · "Bruto delle Caverne (tank PUPPET con slam ad area) + artwork bestiario"

#### 👹 Nuovo nemico: Bruto delle Caverne (render PUPPET)
- Terzo puppet e **terzo pilastro** del roster: un **tank da mischia** enorme e ingobbito, scomposto in **6 pezzi**
  (testa con zanne, torso con spallacci d'osso, **due braccia enormi**, due gambe tozze) + overlay vettoriale
  (**occhi ambra** pulsanti). Accento **ambra** per distinguerlo dal verde zombie e dal viola negromante.
- **Animazione delle BRACCIA** (la sua firma, curata come richiesto): pivot alla **spalla** → grandi **dondolii in
  opposizione** durante la camminata pesante; **SLAM ad area in due tempi** (carica: si erge coi pugni cocked
  all'indietro → schianto: tutto il busto affonda in avanti/giù, i pugni guidano il colpo) con onda d'urto e respinta.
- **Stat (tank):** tier 2, **220 PV**, molto lento (**vel. 60**), raggio 24, **danno 28**, `ai 'brute'`, slam raggio 96.
  Entra nel **pool dall'ondata 4**, peso basso (raro ma temibile). Eredita hit-reaction, morte con crollo dei pezzi,
  tint elite (ambra) e ombra dinamica del motore puppet.
- **Client:** l'evento `slam` ora porta l'eid → il Bruto **riproduce l'animazione** dello slam (prima non animava).

#### 🖼️ Artwork del bestiario nel progetto
- Aggiunti in `public/assets/art/`: **`roster_overview.png`** (scheda illustrata del bestiario) e
  **`cave_brute_concept.png`** (concept del Bruto). Aggiornata la scheda **`ROSTER.md`** con il Bruto implementato
  (stat reali) e i riferimenti agli artwork.

#### 🟣 Incluso: sfere del Negromante +30% (da v1.41)
- Ri-applicata la taratura approvata: `darkmage.projSpeed` **250 → 325** (le sfere debilitanti sono più difficili
  da schivare). Era andata persa nel pacchetto v1.41.

#### 🧪 Test
- Nuovo `testV142` (roster, tank, slam ad area con eid, pool ondata 4): **206 passati, 0 falliti**.

---

### [1.40.0] — 2026-08-10 · "Taratura campo visivo del Negromante"

- **Cono visivo più stretto/focalizzato:** `fov` da **0.62 → 0.55** rad (cono totale **~71° → ~63°**). Premia il
  fiancheggiamento: è più facile restare fuori dalla sua vista aggirandolo.
- **Rotazione testa più lenta/deliberata:** `turn` ora **1.7 rad/s** (~97°/s, prima ~120°/s), reso **parametro
  esplicito** della def (`darkmage.turn`) così è tarabile in un unico punto. Telegrafa meglio e concede una finestra
  per rompere la linea di vista.
- Invariati `sightRange 360`, curse e tetto evocazioni. Test: **193 passati, 0 falliti**.

---

### [1.39.0] — 2026-08-10 · "Negromante PUPPET + motore puppet generico + migliorie animazioni/effetti"

#### 🧙 Nuovo nemico: Negromante (render PUPPET)
- Secondo puppet del gioco (mago incappucciato con bastone e orbe), scomposto in **5 pezzi** (cappuccio/testa,
  torso, veste a campana, braccio-bastone, mano ossuta) + overlay vettoriale (**occhi viola** + **orbe** che divampa in cast).
- **Fluttua** (niente camminata), con veste che ondeggia a pendolo; **attacco/cast in due tempi** (alza il bastone → proietta).
- **IA:** tiene la distanza (kiting), la testa **ruota lentamente** verso il bersaglio → il suo **CAMPO VISIVO** (cono fov)
  insegue con ritardo. **Spara SFERE DEBILITANTI** (curse: riduce danno e velocità del colpito) **solo** quando il bersaglio
  è **dentro il cono**, in gittata e con linea di vista libera. Un **cono-telegrafo** fioco si accende quando ti individua.
- **Evoca ZOMBI MINORI** (nuovo `zombie_mini`, puppet ghoul in miniatura) fino a un **massimo di 4** (minionCap):
  evoca solo per rimpiazzare i caduti. Entra nel pool ondate **dall'ondata 3**.

#### 🧩 Motore PUPPET generico (refactor)
- Astratto in `PUPPETS[key]` (registry asset) + `PROF[key]` (profilo animazione): aggiungere un nemico puppet ora è
  **"manifest + profilo"**. `_ghoulPuppet` → `_puppet(key, …)` generico; nuovo `_puppetDeath(key, …)`.

#### ✨ Migliorie animazioni & effetti (a tutti i puppet)
- **Hit-reaction del corpo:** al colpo il mostro fa uno **squash** verticale + piccolo **rinculo** all'indietro (oltre agli occhi che avvampano).
- **Morte PUPPET dedicata:** i pezzi **crollano** (gambe che cedono, testa che rotola, veste che si accascia) con dissolvenza e occhi che si spengono.
- **Inclinazione nel movimento:** il corpo si **inclina** leggermente nella direzione di marcia (più "presenza").
- **Ombra dinamica:** l'ombra a terra **si allunga** e segue la direzione del movimento/affondo.
- **Varianti ELITE:** i pezzi vengono **ritinti** (ctx.filter) per distinguere gli elite a colpo d'occhio.

#### 🧪 Test
- Suite aggiornata (nuovo `testV139`, roster + tetto evocazioni + campo visivo): **193 passati, 0 falliti**.

---

### [1.38.0] — 2026-08-10 · "Occhi che avvampano quando lo zombie è colpito · via il cerchio verde"

#### 👁️ Occhi verdi che avvampano al colpo (feedback di danno)
- Quando lo Zombie Putrido (puppet) viene **colpito**, gli **occhi verdi avvampano** con un lampo luminoso
  (pulse e raggio del glow aumentati per la durata dell'hit-flash). Sostituisce il flash bianco che il puppet
  raster non poteva mostrare. Anche **di spalle**, un colpo produce un lampo verde sulla nuca.

#### 🟢 Rimosso il "cerchio verde" attorno al nemico
- Eliminato il **disco verde** che compariva attorno allo zombie quando era **avvelenato** (indicatore veleno):
  ora il veleno si legge **solo** dalle piccole particelle verdi che salgono.
- Per i **puppet** l'**alone emissivo** generico è stato reso **molto più tenue e stretto** (niente più anello
  verde evidente); resta solo un filo di visibilità nel buio. L'alone pieno resta invariato per boss/elite.

#### 🧪 Test
- Nessuna regressione: **190 passati, 0 falliti**.

---

### [1.37.0] — 2026-08-10 · "Roster essenziale: SOLO lo Zombie Putrido (render PUPPET), attacco carica→colpo & ombra a terra"

#### 🧟 Un solo nemico: lo Zombie Putrido (PUPPET) sostituisce il vettoriale
- **Rimossi tutti gli altri nemici vettoriali** dal pool ondate: **Negromante**, **Spettro** e **Occhio Vagante**
  escono da `MONSTERS`, dall'`ORDER` e da `poolForWave`. Il bestiario d'ondata riparte da **un solo archetipo**.
- Lo **Zombie Putrido** (id `skeleton`, così boss/summon restano compatibili) ora è reso con il **RENDER PUPPET**
  (raster ibrido: 6 pezzi PNG + overlay vettoriale) e **sostituisce** il vecchio zombie vettoriale (shape `zombie`).
  Stat riviste: 78 PV, vel. 100, raggio 18, danno 14.

#### 🎞️ Nuova animazione d'ATTACCO in due tempi (carica → colpo)
- L'attacco non è più un semplice "protendersi": ora fa una **carica** (braccia alzate/indietro, busto reclinato,
  testa su) seguita dal **colpo** (braccia scagliate in avanti, **affondo del corpo in avanti**, testa protesa,
  spinta sulle gambe) e recupero. Guidato dall'evento `melee` esistente.

#### 🌑 Ombra a terra & maggiore realismo
- Aggiunta una **piccola ellisse nera sfocata alla base** dei piedi (Gaussian blur), che si **stringe** quando il
  passo solleva il corpo e **segue l'affondo** in attacco: il mostro appare **radicato sulla mappa**, non "appiccicato".
- La vecchia ombra generica dei mostri è **disattivata per i puppet** (niente doppia ombra).

#### 🚶 Camminata ritarata (più aggressiva e pesante)
- **Falcata più ampia** (`leg` 26→37, `arm` 20→26) e **cadenza più lenta** (`cad` 1.35→1.05), con più ondeggio e
  waddle: incedere da bruto. Costanti raggruppate in `WALK` dentro `_ghoulPuppet`.

#### 🧪 Test
- Suite aggiornata al nuovo roster: **190 passati, 0 falliti**.

---

## [1.35.0] — 2026-08-09 · "Troll rimosso · Mercante Nero riempito · Occhio Vagante: lo Sguardo"

### 🗑️ Troll delle Caverne rimosso
- Il **Troll** è stato **rimosso dal roster** (sprite non soddisfacente): tolto da `MONSTERS`, dall'`ORDER`
  del bestiario e dal pool delle ondate. Il pool passa a **4 archetipi** (zombie, spettro, negromante, occhio).

### 🖤 Fix Mercante Nero "vuoto"
- **Sintomo:** il box del Mercante Nero appariva **centrato ma senza offerte** (finestra vuota).
- **Causa:** `HUD._renderMerchant()` viene richiamato a **ogni snapshot** (~20/s) per aggiornare le monete e
  faceva `innerHTML=''` **ricreando le card** ogni frame. Le card del Nero hanno l'animazione d'ingresso
  `darkCardIn` (opacity 0→1 con delay): ricreandole in continuazione restavano di fatto a **opacity 0**.
- **Soluzione:** le card ora vengono **ricostruite solo quando cambia l'offerta** (firma degli id); a ogni
  frame si aggiorna **solo** il conteggio monete e lo stato "acquistabile". Nessun restart dell'animazione.

### 👁 Occhio Vagante — nuovo attacco "SGUARDO" (gaze debuff)
- **Niente più proiettili:** l'Occhio ora **non spara**. Il suo attacco è lo **Sguardo**: se il giocatore entra
  nel suo **campo visivo** (cono attorno alla direzione dello sguardo, entro gittata e con **LOS libera**) subisce
  un **debuff** che si rinnova finché resta "sotto gli occhi".
- **Tre tipi di sguardo** (uno fisso per ogni occhio, assegnato allo spawn):
  - 🟠 **weaken** — *attacco indebolito* (danno inflitto ridotto)
  - 🔵 **slow** — *velocità ridotta*
  - 🟣 **sunder** — *meno difesa* (danni subiti aumentati)
- **Grafica:** **sprite ridotto del 20%**, **tentacoli disposti tutt'intorno** al bulbo (a raggiera, ondeggianti),
  **cono/fascio dello sguardo** colorato per tipo e **aura tratteggiata** sul giocatore mentre è debuffato.
- IA `gazer` (sostituisce `strafer` per l'occhio): continua a fluttuare orbitando a distanza ("vagante").

---

## [1.33.0] — 2026-08-09 · "Mercante Nero: box centrato e cliccabile (fix definitivo)"

### 🖤 Fix Mercante Nero
- Il box con le 3 offerte del **Mercante Nero** ora appare **esattamente al centro dello schermo**,
  non più troppo in basso e **senza sovrapporsi alla barra delle abilità/oggetti**.
- **Causa risolta:** il centraggio dipendeva dallo stesso `transform` usato anche dall'animazione di
  scala; qualsiasi interferenza faceva ricadere il pannello sulla posizione base (`bottom:96px`).
- **Soluzione robusta:** centraggio disaccoppiato dal transform tramite `inset:0 + margin:auto`
  (con `!important`), mentre l'animazione usa ora **solo `scale()`** attorno al centro. Il box resta
  centrato in ogni condizione.
- Aggiunti `max-height:88vh` + `overflow:auto` per sicurezza su schermi piccoli.
- **Cliccabilità verificata:** `pointer-events:auto` su pannello e card, `z-index:36` (il più alto
  in-game: i menu a schermo intero sono nascosti durante la partita), overlay a `box-shadow` che non
  intercetta i click. Le 3 offerte restano selezionabili col mouse.

---

## [1.32.0] — 2026-08-09 · "Bestiario ampliato: Spettro & Occhio Vagante, Troll rifinito, Mercante Nero al top"

### 👻 Nuovo nemico — SPETTRO
- **Sprite etereo/translucido** in vista frontale: cappa spettrale che sfuma in **code ondulate**, scie/wisp
  emissive, artigli protesi e **occhi ardenti**. Corpo con alfa animata (respiro spettrale).
- **IA `wraith`** (nuova): avanza rapido in mischia e periodicamente **"sfasa" (phase-blink)** verso il
  bersaglio, riemergendo alle sue spalle **attraversando gli ostacoli**. Breve stordimento dopo il blink.
- Stat: tier 2, 92 PV, veloce (134), 19 dmg, mischia. Entra nel pool dall'**ondata 2**.

### 👁️ Nuovo nemico — OCCHIO VAGANTE
- **Sprite bulbo oculare** fluttuante con **eye-stalks** superiori e **tentacoli** inferiori, aura emissiva,
  vene rosse, **iride che segue** e **pupilla che dilata in attacco**, palpebre carnose a mandorla.
- **IA `strafer`**: orbita a distanza e scaglia **raggi arcani**. Stat: tier 3, 118 PV, 15 dmg, gittata 320.
  Entra nel pool dall'**ondata 4**.

### 🪓 Troll — sprite rifinito
- Confermata la resa v1.32 in vista frontale: braccia massicce **senza mani/artigli**, occhi **rossi**,
  niente fascia-occhi né zanne (non è un vampiro), passo e respiro animati.

### 💀 Mercante Nero — restyle "al top"
- Figura incappucciata più curata: **veste con gradiente**, **bordo runico pulsante**, **spalle a punta
  bordate**, **cappuccio definito**, volto-teschio con **occhi ardenti viola** e **mani ossute** che
  presentano la merce. Beacon a **doppia colonna** (viola + cremisi) e anello pulsante per individuarlo.

### 🧟 Pool ondate — 5 archetipi
- Pool aggiornato a **zombie · spettro · negromante · occhio vagante · troll** con sblocco progressivo.

### ✅ Qualità
- Suite: **177 test automatici, 0 falliti**.

---

## [1.31.0] — 2026-08-09 · "Ampolla della salute, Troll anticipato e Mercante Nero al centro"

### 🧪 HUD — Ampolla dei Punti Salute + Vite (a fianco della barra abilità)
- **Nuovo indicatore scenografico**: i **punti salute** ora sono mostrati come un'**ampolla/boccetta** di vetro
  che si riempie di liquido rosso in base alla percentuale di HP, con il **numero PV** al centro e il totale sotto.
- Sotto l'ampolla una **fila "VITE"** con i cuori corrispondenti alle vite rimanenti.
- Il gruppo è stato **spostato a fianco della barra abilità** ed è **molto più grande** di prima.
- **Effetto low-HP**: sotto il 30% il liquido diventa rosso acceso e l'ampolla **pulsa**.
- 🔴 **Ampolla rossa**: il liquido usa ora una gradiente **rosso vivo** (`#ff2e2e → #e01020 → #8a0410`) con superficie
  rossa più marcata; il low-HP passa al **rosso puro** (`#ff1520`).

### 🕯️ Mercante Nero — animazione d'ingresso
- La finestra `dark` ora **compare con un'animazione** (`darkMerchIn`): sale in scala con un piccolo overshoot e un
  leggero *rotate*, mentre l'**aura viola/cremisi pulsa** (`darkMerchAura`) e il titolo ha un **glow ritmico**
  (`darkHeadGlow`). Le tre carte entrano **sfalsate** dal basso (`darkCardIn`).
- I vecchi chip `❤️ hp/mhp` e `vite` sono stati **rimossi** dal blocco statistiche in basso a destra
  (restano uccisioni 💀, XP ✦ e monete 🪙).

### 👹 Troll dall'ondata 3 (prima era dall'ondata 5)
- Il **Troll delle Caverne** entra ora nel pool delle ondate a partire dalla **wave 3** (`poolForWave`).

### 🕯️ Mercante Nero al centro dello schermo
- La finestra del **Mercante Nero** (variante `dark`) ora compare **centrata verticalmente e orizzontalmente**
  con un leggero ingrandimento e un **velo scuro** di sfondo per farla risaltare come una scelta importante.
  Il **Mercante Errante** normale resta ancorato in basso.

---

## [1.30.0] — 2026-08-09 · "Bestiario essenziale: Zombie, Negromante, Troll in vista frontale"

### 👾 Roster ridotto a 3 archetipi (grigio molto molto scuro)
- **Rimossi tutti gli altri nemici**: via `orc`, `assassin`, `wyvern`, `lich` e il `dragon` regolare dal
  bestiario giocabile. Restano **solo tre** mostri d'ondata: **Zombie Putrido** (`skeleton`), **Negromante**
  (`darkmage`) e **Troll delle Caverne** (`troll`).
- 🪤 **Mimic MANTENUTO come cassa**: la **Bestia Mimica** (`mimic`) resta nel gioco **esclusivamente come cassa-mima**
  e nella modalità **TESORO**. È fuori dal pool delle ondate (`weight: 0`, flag `chestOnly`), quindi non appare mai
  tra i nemici normali ma solo quando una cassa si rivela un mimic. Recuperata la sua def (150 HP, IA `ambush`, sprite
  a forziere top-down): aprire una cassa-mima ora evoca di nuovo un **vero mimic** e non un ripiego.
- 🎨 **Nuova palette**: i tre mostri d'ondata ridipinti in **grigio molto molto scuro** (`#2c2e2c` / `#26272c` /
  `#2e302d`), con **occhi/accento luminosi** a dare personalità (zombie verde acido, negromante viola, troll ambra).

### 🖼️ Sprite in VISTA FRONTALE (billboard) — nuovo stile dark-cartoon
- I tre mostri non ruotano più con la direzione (top-down): sono **billboard frontali** che **guardano la camera**,
  si **specchiano** in orizzontale verso il movimento e mostrano il **dorso** quando si allontanano verso l'alto.
- 🧟 **Zombie**: corpo ingobbito, braccia penzolanti con mani ad artiglio, occhiaie nere con bagliore, **mascella che
  si spalanca** in attacco, ferite e punti di sutura.
- 🧙 **Negromante**: **veste a campana** con orlo ondeggiante e rune luminose, mantellina/colletto, **cappuccio-vuoto**
  con occhi ardenti, **cappello a punta** a tesa larga e **bastone con orbe** che divampa durante il cast.
- 👹 **Troll**: **torso a masso** ingobbito, **braccia lunghissime** con pugni enormi e artigli che sfiorano il suolo,
  gambe tozze, **zanne** e occhi ambra; alza il pugno per lo **slam**.
- ⚙️ Nuove routine `_front` / `_zombieF` / `_necroF` / `_trollF` nel `renderer.js`, con flag `front: true` sul def del
  mostro. La morte usa un **collasso frontale** dedicato (niente più rotazione).

### 🌊 Ondate & bilanciamento
- `poolForWave` semplificato al nuovo trio: **Zombie** (base, peso 40), **Negromante** (dall'ondata 3, peso 16),
  **Troll** (dall'ondata 5, peso 9). Il **mimic non è nel pool** (compare solo dalle casse). I boss restano invariati
  e continuano a evocare zombie.

### 🧪 Test
- **175 passati, 0 falliti** (`node test/simulate.js`).

---

## [1.29.0] — 2026-08-09 · "Negromante: proiettili in vista, evocazioni al buio"

### 💀 IA del Negromante ridisegnata (nuovo comportamento `necromancer`)
- Il **Negromante** (`darkmage`) ora adatta la tattica alla **linea di vista** verso il bersaglio:
  - **Se sei nel campo visivo** (LOS libera **e** entro gittata), lancia **proiettili magici** — colpo singolo con
    ogni terzo tiro a **ventaglio (3 proiettili)** — mantenendo le distanze (kiting) come prima.
  - **Se sei nascosto** (nessuna LOS), **evoca scheletri** a cadenza (`summonCount: 2` ogni `summonCd: 8s`) e
    **avanza** verso la tua ultima posizione per **stanarti** e riguadagnare la linea di tiro.
- ⚙️ Nuovi parametri sul def `darkmage`: `summon: 'skeleton'`, `summonCd: 8`, `summonCount: 2`, `ai: 'necromancer'`.
- 🎨 L'anello dell'evento `summon` è ora **color-aware**: l'evocazione del Negromante appare nel suo **viola** (`projColor`)
  invece del ciano del Lich (client `main.js`, evento `summon` con campo `c`).
- 🧪 Il vecchio comportamento generico `caster` resta nel codice ma non è più usato da nessun mostro.
- 🧪 Test: **180 passati, 0 falliti**.

## [1.28.1] — 2026-08-08 · "Assassino d'Ombra ridisegnato"

- 🗡️ Nuovo sprite per l'**Assassino d'Ombra** (shape `assassin`), nello stile dark-fantasy vettoriale:
**mantello a freccia** rivolto in avanti, **doppie lame** (ai lati a riposo, incrociate in avanti durante l'attacco),
**cappuccio a punta**, viso in ombra con **occhi magenta affilati** e una **scia di fumo/ombra** dietro che
sottolinea la sua agilità. Lo swing d'attacco è pilotato dall'evento `melee` già esistente (AI `flanker`).
- 🧪 Test: **180 passati, 0 falliti**.
- ℹ️ Nota: la proposta del **Troll** è stata scartata (nessuna modifica al Troll in questa release).

## [1.28.0] — 2026-08-08 · "Maledizione del Negromante + cunicoli a prova di boss"

### 💀 Maledizione del Negromante (danno + indebolimento)
- Gli incantesimi del **Negromante** ora, oltre a fare danno, **maledicono** il bersaglio: per **4,5s** il giocatore
è **indebolito** — danno inflitto **−40%** e velocità **−20%** (costanti `CURSE_TIME`, `CURSE_DMG_MULT`,
`CURSE_SPEED_MULT`).
- Compare la **notifica "💀 SEI STATO MALEDETTO"** (banner viola + floater), con **aura viola** e volute attorno al
personaggio finché dura l'effetto. Nuovo flag `cu` nello snapshot; evento `cursed` gestito dal client.
- Il flag viaggia sul proiettile (`curse`) partendo dalla def del mostro (`darkmage.curse = true`), quindi è
riutilizzabile per futuri lanciatori.

### 🕳️ Cunicoli a prova di boss (larghezza garantita)
- Nuova passata `widenForBoss()` nel mapgen: **allarga automaticamente i colli di bottiglia** portando ogni
corridoio ad **almeno 3 tile (144px)**, così anche il mega-boss (**AZ'GAROTH**, raggio 52) passa ovunque.
- **Prima:** solo **83,3%** delle mappe erano pienamente boss-navigabili (spawn↔uscita). **Ora: 100%**
(verificato su 2100 combinazioni seed×livello con `test/verify_boss_paths.js`).
- I blob-caverna restano intatti: la densità dei muri resta ~34% (nessuna mappa "svuotata").

### 🧪 Test
- **node test/simulate.js: 180 passati, 0 falliti** · **verify_boss_paths: 2100/2100 (100%)**.

## [1.27.1] — 2026-08-08 · "Braccia dello zombie con mani (staccate dal corpo)"

- 🖐️ Le braccia dello **Zombie Putrido** sono ora disegnate **sopra il corpo** (non più inglobate dall'ellisse):
hanno **spalla** distinta (tono scuro = stacco), **gomito** e una **mano** tonda con **artigli** in fondo.
A riposo pendono ai lati; in attacco si protendono in avanti con le mani. Niente più braccia "attaccate al corpo".
- 🧪 Test: **180 passati, 0 falliti**.

## [1.27.0] — 2026-08-08 · "Braccia ai lati & rimozione del Predone Goblin"

### 🦾 Zombie — braccia ai lati
- Le braccia dello **Zombie Putrido** ora scendono **lungo i fianchi** a riposo (idle/camminata) e si protendono
**in avanti solo durante l'attacco** (morso). Eliminato l'effetto "insettoide" delle braccia sempre protese.
La testa resta centrata (fix v1.26.1). Anche l'animazione di morte eredita la nuova posa.

### 🗑️ Rimosso il Predone Goblin
- Il nemico **goblin** (Predone Goblin) è stato **rimosso** dal roster: tolto da MONSTERS e dall'array ORDER.
- **Dipendenze gestite** per evitare crash:
  - Il **Signore della Guerra Orchesco** ora evoca **Zombie Putridi** (summon 'goblin' → 'skeleton').
  - Il **filler** delle ondate boss (server) e il **pool** delle ondate usano ora lo **Zombie Putrido** al posto
del goblin (peso ribilanciato: skeleton 34).
  - **Fallback** MONSTERS.goblin → MONSTERS.skeleton in Room.js e renderer.js.
- Roster attuale: **9 nemici** standard + 3 boss.

### 🧪 Test
- Suite aggiornata (riferimenti goblin → skeleton): **node test/simulate.js: 180 passati, 0 falliti**
(un test in meno nel "sanity" perché c'è un tipo di nemico in meno — atteso).

## [1.26.1] — 2026-08-08 · "Testa centrata (top-down con viso visibile)"

- 🎯 **Fix estetico** sui 3 nuovi sprite (`zombie`, `brute`/orco, `mage`/negromante): la **testa** era disegnata
troppo in avanti e "sporgeva" dal corpo. Ora è **centrata sopra il corpo** (offset all'indietro tramite `translate`),
per un effetto **vista dall'alto con volto visibile**. Braccia protese, ascia, bastone/orbe e animazioni di
attacco/morte restano invariati. Anche il Signore della Guerra (shape `brute`) eredita il fix.
- 🧪 Test: **181 passati, 0 falliti**.

## [1.26.0] — 2026-08-08 · "Nemici ridisegnati + animazioni di attacco e morte"

### 👹 3 nemici ridisegnati (stile dark-fantasy vettoriale)
- **🧟 Zombie Putrido** (ex "Guerriero Scheletro", id interno invariato) — corpo curvo con **braccia protese**,
**occhi neri vuoti** dal fioco bagliore verdastro, macchia di sangue e spina esposta. Ora **strascica** verso i
giocatori (AI `swarm`, niente più parata frontale) ed è un po' più coriaceo e lento.
- **🧙 Negromante** (ex "Mago Oscuro") — **cappuccio** profondo con **occhi viola ardenti**, **veste a campana** con
orlo runico e **bastone** con **orbe** che pulsa.
- **🪓 Orco Berserker** — **ascia a doppia lama** impugnata, **zanne**, **occhi rossi**, spalle con **spuntoni** e
muscolatura verde. (Anche il Signore della Guerra ne eredita la resa.)

### 🎞️ Animazioni di ATTACCO e MORTE (nuove)
- **Attacco** (parametrico, guidato dagli eventi del server): lo **zombie** spalanca la mascella e allunga le braccia
nel morso, il **negromante** fa **divampare l'orbe** mentre evoca, l'**orco** **alza e cala l'ascia** con un ruggito.
Nuovo evento `cast` per i lanciatori; gli eventi `melee`/`lunge` ora trasportano l'`eid` del mostro.
- **Morte**: ogni nemico ucciso lascia uno **sprite di morte effimero** che **crolla, si accascia e svanisce**
(dissolvenza + rotazione + schiacciamento). Il **negromante** si **dissolve in volute viola**. L'evento `mkill`
trasporta ora il `facing`.

### 🧰 Note tecniche
- Nessuna nuova dipendenza (Canvas 2D puro). Sprite **parametrici** `_shape(ctx, …, t, atk)`: idle/camminata dal
tempo, attacco dalla fase `atk`, morte gestita da sprite effimeri lato client (`R.mAtk` / `R.deaths`).
- Solo questi **3** nemici sono stati ridisegnati/animati in questa release (gli altri seguiranno).

### 🧪 Test
- **node test/simulate.js: 181 passati, 0 falliti** (stabile).

## [1.25.0] — 2026-08-04 · "Terzo lotto di oggetti scenografici"

### 🗿 6 nuovi oggetti scenografici (terzo lotto, per tema)
- **🌉 Ponti di legno** (`bridge`) — assi con travi e chiodi, sopra una fenditura scura.
- **🪜 Scale a chiocciola** (`spiral_stairs`) — gradini a spirale che scendono in un pozzo buio.
- **⛲ Pozzi / cisterne** (`well`) — con acqua che luccica (glow del tema), arco e carrucola.
- **⚙️ Grate / inferriate** (`grate`) — griglia metallica su un pozzo scuro nel pavimento.
- **💠 Cristalli giganti** (`giant_crystal`) — **landmark** luminoso a più facce (glow ampio del tema).
- **🗿 Statue rituali con gemma** (`gem_statue`) — figura incappucciata che regge una **gemma luminosa**.
- Nuove **zone tematiche** (passaggio, discesa, cisterna, officina, geode, reliquiario) legate ai **temi**
  (Cripta/Lava/Foresta/Ghiaccio/Arcano), sempre col **cap 3-4 istanze per tipo**.

### 📦 Totale scenografia
- Con i 3 lotti la mappa dispone ora di **18 oggetti scenografici** (oltre a bracieri, torce, tombe, casse, ecc.).

### 🧪 Test
- **`node test/simulate.js`: 181 passati, 0 falliti** (stabile); verificato su 200 mappe/5 temi: 0 crash, cap ≤4,
  tutti i nuovi oggetti presenti.

---

## [1.24.0] — 2026-08-04 · "Secondo lotto di oggetti scenografici"

### 🗿 6 nuovi oggetti scenografici (secondo lotto, per tema)
- **🏛️ Archi diroccati** (`arch`) — architettura in rovina, un pilastro spezzato.
- **🧊 Stalattiti** (`stalactite`) — pendono dal soffitto (con goccia; ghiaccioli nel tema Ghiaccio).
- **☠️ Forche / patiboli** (`gallows`) — con cappio e teschio appeso.
- **🔮 Obelischi arcani** (`obelisk`) — rune incise **pulsanti** ed emissione di **glow** del colore del tema.
- **🏮 Lanterne appese** (`hanging_lantern`) — **illuminano** con luce calda.
- **🩸 Macchie di sangue** (`bloodstain`) — decal piatte a terra (racconto ambientale).
- Distribuiti come **zone tematiche coerenti** (rovine, grotta, patibolo, santuario, sala illuminata, massacro) e
  legati ai **temi** (Cripta/Lava/Foresta/Ghiaccio/Arcano). Sempre col **cap 3-4 istanze per tipo**.

### 🧰 Note tecniche
- Tutto in **Canvas 2D puro, zero dipendenze**. Lanterne e obelischi si agganciano al sistema di luci (torce/glow).
- Aggiunto un **guard** nel piazzatore feature per robustezza (nomi zona sconosciuti ignorati).

### 🧪 Test
- **`node test/simulate.js`: 181 passati, 0 falliti** (stabile); verificato su 150 mappe/5 temi: 0 crash, cap ≤4,
  tutti i nuovi oggetti presenti.

---

## [1.23.0] — 2026-08-04 · "Muri neri, terreno vivo, nuovi oggetti & fix mercante"

### 🖤 Ambiente
- **Muri QUASI NERI** — contrasto muri/pavimento portato da `0.50` a **`0.15`**: la roccia dei muri è ora quasi nera
  e si stacca nettamente dal pavimento (invariato). Con l'ombra marcata di bordo lo stacco è fortissimo.
- **Terreno meno "piatto"** — il pavimento è ora punteggiato di **rocce, massi, ciottoli e buche/crateri** sparsi
  (dettagli cosmetici baked, non bloccanti) → varietà e profondità.
- **Crepe grandi (2-3 per mappa)** — rimosse le rune/glifi pulsanti (non piacevano); al loro posto **2-3 fissure**
  molto più **grandi** (≈5-6× più lunghe, ~2× più larghe), ramificate e scure, come vere spaccature del terreno.

### 🗿 Primo lotto di 6 nuovi oggetti scenografici (per tema)
- **🪨 Stalagmiti**, **💀 Pile di teschi (catacomba)**, **🧱 Macerie / muro crollato**, **🕸️ Ragnatele giganti
  d'angolo**, **💎 Cristalli luminosi** (emettono glow), **🔥 Altari rituali** con candele accese (illuminano).
- Distribuiti con **coerenza per tema** (Cripta/Lava/Foresta/Ghiaccio/Arcano) come **zone**, sempre col **cap 3-4
  istanze per tipo** (solo le torce restano numerose).

### 🐀 Animaletti
- **Più grandi (≈2×)** — ratti, ragni e scarafaggi ora ben visibili sul pavimento.

### 🛒 Mercante Errante (fix + visibilità)
- **Fix click**: il pannello del mercante non rispondeva ai click (ereditava `pointer-events:none` dall'HUD) →
  ora **`pointer-events:auto`**: si può acquistare cliccando le offerte.
- **Più visibile**: **beacon sempre acceso** sul mercante (colonna di luce dorata + anello pulsante + etichetta
  "🪙 Mercante" sempre visibile), **marker sulla minimappa** (oro per l'ufficiale, viola per il Nero) e alone più
  ampio nel buio della torcia.

### 🧪 Test
- **`node test/simulate.js`: 181 passati, 0 falliti** (stabile su run ripetute).

---

## [1.22.0] — 2026-08-04 · "Caverna organica, ombre nette, animaletti & decorazioni a cluster"

### 🗺️ Conformazione mappa (torna organica)
- **Generazione ORGANICA (caverna varia)** — abbandonato il layout a stanze (troppo "piatto/vuoto"): la mappa torna
  al metodo a **blob di roccia** con anfratti, nicchie e passaggi irregolari, **connettività garantita** (le sacche
  isolate vengono murate; verificato su run ripetute).

### 🖤 Muri & profondità
- **Contrasto muri/pavimento a 0.50** — la roccia dei muri è scurita al 50% del colore del tema: netta distinzione
  dal pavimento (invariato).
- **Ombra MARCATA muro→pavimento** — drop-shadow forte + **linea di contatto scura** al bordo: lo **stacco** tra
  muro e pavimento ora si legge chiaramente (profondità/rilievo).

### 🐀 Vita nel dungeon
- **Animaletti** — piccoli **ratti, ragni e scarafaggi** che sfrecciano a scatti sul pavimento (cosmetici, evitano
  i muri, si riciclano attorno alla telecamera). Puramente atmosferici.

### 🕯️ Decorazioni coerenti e limitate
- **A CLUSTER, non a caso** — le decorazioni sono ora raggruppate in **zone tematiche** coerenti: **cimitero**
  (tombe + ragnatele + sarcofago), **ossario** (falò + ossa/teschi + cadavere), **deposito** (casse/barili/sacchi +
  **cassa scenografica/forziere**), **fungaia** (funghi bioluminescenti), **gabbia** (con catene e resti), più
  **bracieri** sparsi come luce.
- **Cap 3-4 per tipo** — nessun oggetto ripetuto 20 volte: ogni tipo compare **al massimo 3-4 volte**. **Unica
  eccezione: le torce appese ai muri**, numerose e distribuite regolarmente.

### 👹 Mimic
- **Mimic più presenti** — compaiono già dall'**ondata 4** (peso aumentato) e le **casse-mima** salgono al **30%**
  (le casse scenografiche possono rivelare un mimic).

### 🧪 Test
- **`node test/simulate.js`: 181 passati, 0 falliti** (stabile); connettività della caverna organica e "giocatori
  mai nei muri" verificate.

---

## [1.21.0] — 2026-08-04 · "Muri quasi neri, nebbia volumetrica & rune pulsanti"

### 🖤 Muri più scuri
- **Muri MOLTO più scuri (quasi neri)** — la texture roccia dei muri è ora scurita al ~30% del colore del tema
  (`#080a10`-ish), così si **distingue nettamente** dal pavimento (rimasto invariato, che andava benissimo).

### 🌫️ Atmosfera
- **Nebbia volumetrica a strati** — banchi di foschia semitrasparenti che **derivano lentamente** in world-space,
  con leggera pulsazione: profondità e atmosfera. Si dirada nel buio della modalità torcia.
- **✨ Rune / crepe che pulsano sul pavimento** — decal luminose (crepe ramificate e sigilli runici) sparse sul
  terreno, del **colore del tema**, con **glow additivo pulsante**. Emettono luce (si intravedono anche col buio
  della torcia) e danno un tocco "arcano" al dungeon.

### 🗑️ Rimozioni (richieste)
- **Rimossi i laghi/pozze** (hazard `T_HAZARD`) dalla generazione.
- **Rimossi colonne, pilastri e statue** (incl. statue demoniache) da tutte le stanze e dal mix decorativo; al loro
  posto, al centro, qualche fungo bioluminescente. Restano bracieri, gabbie, depositi (casse/barili/sacchi) e fungaie.

### 🧪 Test
- **`node test/simulate.js`: 181 passati, 0 falliti** (stabile); connettività e "giocatori mai nei muri" ok.

### 🧰 Note tecniche
- Nessuna nuova dipendenza. Nebbia e rune sono **Canvas 2D puro**, disegnate a runtime (le rune pulsano). Le rune
  sono generate deterministicamente dal seed della mappa.

---

## [1.20.0] — 2026-08-04 · "Stanze grandi, pozze-lago & decorazioni ricche"

### 🏛️ Architettura mappa (niente più cunicoli stretti)
- **Layout a STANZE garantito** — ogni livello ha ora una **stanza centrale grande** con **4 stanze angolari**
  (NO / NE / SO / SE) collegate da **corridoi larghi 3 tile**: il **boss di fine livello passa ovunque** e i nemici
  non restano più incastrati. Un **anello** di corridoi opzionale fra le stanze aggiunge varietà.
- **Connettività garantita** (flood dal centro; sacche isolate murate). Spawn al centro, **uscita** nella stanza
  angolare più lontana, spawn nemici distribuiti nelle stanze.

### 💧 Pozze naturali (tipo lago)
- **Solo 1-2 pozze per mappa** (prima erano troppe), collocate **dentro le stanze** angolari.
- **Forma organica irregolare** cresciuta a random-walk (niente più "pallini"): resa più da **lago/stagno** —
  colore **desaturato** (meno fumettoso), profondità al centro, riflesso tenue in superficie. Del colore del tema,
  brilla intravedendosi nel buio. La meccanica (danno) resta.

### 🕯️ Decorazioni ricche e bilanciate
- Nuovi elementi scenografici disegnati in Canvas 2D: **🔥 bracieri** e **🕯️ candelabri** (che **illuminano** davvero),
  **🍄 funghi bioluminescenti** (glow nel buio), **📦 casse**, **🛢️ barili**, **🧺 sacchi**, **😈 statue demoniache**
  (occhi luminosi), **⛓️ gabbie sospese con scheletro** (teschio + costole), più **🏛️ pilastri**.
- Distribuite **con criterio**: bracieri/pilastri lungo i muri, una **feature caratteristica** per stanza angolare
  (statua / gabbia / stash di casse-barili-sacchi / fungaia / candelabro), una statua imponente al centro, e un
  leggero scatter macabro. Niente affollamento.

### 🎨 Texture
- Il pavimento e i muri mantengono la **texture roccia realistica** (rilievo/bump) della v1.19; le nuove decorazioni
  sono realizzate allo stesso livello di dettaglio (ombre, gradienti di volume, luci).

### 🧪 Test
- **`node test/simulate.js`: 181 passati, 0 falliti** (stabile su run ripetute); connettività e "giocatori mai nei
  muri" verificate sul nuovo layout a stanze.

---

## [1.19.0] — 2026-08-04 · "Texture roccia realistica, stanze attigue & niente glow"

### ✨ Grafica ambiente
- **🪨 Texture ROCCIA realistica** (pavimento e muri) — sostituito il vecchio "mottling" con vera roccia procedurale:
  - **Rilievo/bump**: una *heightmap* a rumore viene illuminata da una luce direzionale → superficie **scolpita in 3D**
    (creste chiare, incavi scuri, luccichii minerali).
  - **Domain warping** + **Voronoi**: massi irregolari e crepe organiche, **niente griglia**.
  - **Umidità** (macchie scure) e **muschio** (chiazze verdastre) sul pavimento; muri più scuri con crepe marcate.
  - Le texture sono **colorate sul tema** corrente (cripta/lava/foresta/ghiaccio/arcano) e generate una volta per mappa
    come *pattern* — **Canvas 2D puro, zero dipendenze**.
- **🚪 Mappa meno "quadratona" → STANZE minori attigue** — nuovi **tramezzi** parziali con **varchi/porte** che spezzano
  i grandi open-space in stanze comunicanti (agganciati ai muri, per sembrare pareti vere). **Connettività garantita**:
  ogni tramezzo è applicato solo se la mappa resta *interamente* percorribile, altrimenti annullato.
- **🚫 Glow rimosso** — eliminato il bloom/post-processing (e il tasto `B`): schermo più pulito e nitido, come richiesto.
  La modalità **torcia** (tasto `L`) e l'alone tondo restano.

### 🐛 Correzioni (test)
- Risolta la regressione di connettività introdotta dai tramezzi → **collaudo a 0 falliti** su 10 run consecutive.

### 🧪 Test
- **`node test/simulate.js`: 0 falliti** (stabile su 10 run).

---

## [1.18.0] — 2026-08-04 · "Caverna vera: terra/roccia, pozze uniche & decorazioni"

### ✨ Ambiente (revisione richiesta)
- **🕳️ Look da CAVERNA (niente più griglia)** — pavimento e muri completamente ridisegnati:
  - **Pavimento "terra"** organico: base uniforme + **mottling** morbido (macchie sovrapposte) + qualche ciottolo,
    **senza** più checkerboard né linee di piastrella.
  - **Muri "roccia"** grezza: chiazze chiare/scure, crepe sparse e **cresta illuminata** in cima ai muri esposti.
  - **Bordo caverna**: ombra morbida (ambient occlusion) sul pavimento accanto ai muri → senso di profondità.
- **🩸 Pozze come forma UNICA irregolare con profondità** — niente più "pallini attaccati": le celle-pozza
  adiacenti si **fondono in una sola macchia organica** (union di cerchi), con **conca scura** attorno (il pozzo
  scavato), **centro più scuro** (profondità) e riflesso sulla superficie. Restano del **colore del tema**
  (acido/fuoco/freddo/arcano) e brillano intravedendosi nel buio.

### 🧹 Decorazioni & torce (revisione richiesta)
- **🪦 Rimesse le decorazioni** — bare, scheletri, ossa, accampamenti, rocce, cadaveri, colonne, ecc. (mix per tema
  di nuovo ricco) e densità decori ripristinata (scatter 12 → **34+**).
- **🔥 Torce molto meno frequenti** — rimossa la passata casuale fitta sui muri; lungo i lati **poche** torce a
  **grande distanza e irregolari** (niente più griglia di aloni arancioni).

### 🐛 Correzione (test)
- Stabilizzati i test intermittenti (mercante + homing + soglia snapshot) → **collaudo a 0 falliti** su run ripetute.

### 🧪 Test
- **`node test/simulate.js`: 0 falliti** (stabile su più run).

---

## [1.17.0] — 2026-08-04 · "Dungeon di pietra: mappa ripulita, pozze & torce ai lati"

### ✨ Illuminazione
- **⭕ Alone tondo grande (niente più cono)** — rimosso il cono di luce direzionale; ora ogni eroe è avvolto da un
  **grande alone circolare** (raggio `haloR` 130 → **260**), morbido ai bordi. In co-op uno per ciascuno.
- **🌗 Mappa un filo meno scura** — `darkness` 0.94 → **0.86**, così si legge meglio l'ambiente attorno.
- **🔥 Torce ai LATI della mappa** — nuove torce disposte lungo il **perimetro** a intervalli regolari: illuminano
  i bordi e danno punti di riferimento nel buio.

### 🗺️ Mappa (stile pietra, più pulita)
- **🧱 Pavimento e muri in pietra** — bake ridisegnato: **lastre** di pietra con fughe/rilievo e variazione tonale,
  **muri a blocchi** con luce in alto, ombra in basso, giunzioni e crepe. Struttura del livello invariata (niente
  micro-stanze), solo resa migliore.
- **🧹 Meno "roba alla rinfusa"** — densità decorazioni ridotta drasticamente (scatter 42→**12**, meno oggetti negli
  accampamenti e nelle nicchie) e **mix per tema semplificato** (pochi elementi caratteristici invece di tanti
  ammassati).

### ☠️ Pericoli a pavimento
- **🗑️ Rimossi gli spuntoni** (trappole `T_TRAP`): non compaiono più sul pavimento.
- **🟢 Rimosso il "pavimento a pallini"**: l'hazard è ora una **pozza** vera.
- **🩸 Nuove pozze tematiche** — acido / fuoco / freddo / arcano **del colore della mappa** (verde, arancio, azzurro,
  viola a seconda del tema): forma organica, bordo luminoso, e **brillano** intravedendosi nel buio. La meccanica
  (danno calpestandole) resta.

### 🐛 Correzione (test)
- Stabilizzato il test intermittente del mercante (a fine round lo spawn è casuale ufficiale/nero) → **collaudo a
  0 falliti** su run ripetute.

### 🎛️ Parametri regolabili (`renderer.js`)
- `haloR` (alone attorno all'eroe), `darkness` (buio mappa), `bloomStrength` (glow). Facili da tarare.

### 🧪 Test
- **182 test** con `node test/simulate.js`: **182 passati, 0 falliti** (stabile su 5 run).

---

## [1.16.0] — 2026-08-04 · "Torcia nel buio: mappa oscura & cono di luce"

### ✨ Grafica (tema dungeon, atmosfera horror)
- **🔦 Modalità torcia** — la mappa è ora **quasi nera** e il giocatore la "buca" con un **cono di luce** nella
  direzione di mira + un **alone ravvicinato** attorno a sé (per non essere cieco ai lati). In co-op ogni alleato
  ha il proprio cono. Realizzato con una **dark-mask** offscreen (nero + `destination-out`) → leggera, zero dipendenze.
  - Le **sorgenti** (torce, falò, portale, mercanti) e i **proiettili** restano visibili nel buio.
  - **Boss / élite / scrigno** si **intravedono** col loro alone → tensione "cosa si nasconde nel buio".
  - **Tasto `L`** per attivare/disattivare la torcia (scelta salvata in `localStorage`).
- **🌑 Bloom più tenue** — su tua indicazione il glow generale è stato ridotto (`bloomStrength` 0.85 → **0.5**):
  resta bello attorno a nemici, spari, eroi ed effetti, senza "lavare" lo schermo.
- **✨ Pulviscolo ambientale** — leggere particelle di **polvere** fluttuano nell'aria e diventano visibili quando
  entrano nel fascio di luce → profondità e atmosfera (come nello screenshot di riferimento).

### 🎛️ Parametri regolabili (in `renderer.js`)
- `darkness` (quanto è nera la mappa), `coneLen` / `coneHalf` (lunghezza/apertura del cono), `haloR` (alone attorno
  al player), `bloomStrength` (intensità glow). Tutti facilmente tarabili.

### 🧪 Test
- **182 test** con `node test/simulate.js`: **182 passati, 0 falliti** (stabile su run ripetute).

---

## [1.15.0] — 2026-08-04 · "Dungeon neon: bloom & glow"

### ✨ Grafica (tema dungeon mantenuto)
- **🌟 Bloom post-processing** — nuovo effetto di **glow diffuso** su tutta la scena: le parti luminose (proiettili,
  torce, occhi/aure dei nemici, accenti degli eroi) "irradiano" luce come nei twin-stick moderni, restando nel
  **tema dungeon cupo**. Implementato in Canvas 2D puro con canvas offscreen **a bassa risoluzione** (~1/3) +
  blur additivo → **leggero** e **zero dipendenze**.
  - **Tasto `B`** per attivare/disattivare il bloom (impostazione salvata in `localStorage`), utile sui PC lenti.
- **🔫 Proiettili neon** — nucleo bianco incandescente + alone colorato saturo + scia più lunga (blend additivo):
  con il bloom diventano vere **scie luminose**.
- **👁️ Nemici emissivi** — ogni mostro ha ora un **alone di luce** del proprio colore (più intenso per élite/boss),
  che il bloom accende dando il look "orb neon" — il corpo dungeon resta invariato.

### 🧰 Note tecniche
- Nessuna nuova dipendenza npm, nessun asset esterno. Il bloom legge il frame già renderizzato, lo scala e lo
  ricompone in `lighter`; HUD e minimappa restano nitidi (bloom applicato prima di essi).
- Le aree scure contribuiscono in modo trascurabile al blend additivo → il bloom evidenzia **solo** ciò che è luminoso.

### 🧪 Test
- **182 test** con `node test/simulate.js`: **182 passati, 0 falliti** (stabile su run ripetute).

---

## [1.13.0] — 2026-08-05 · "Entità un po' più grandi (senza perdere fluidità) & Fix Mercante Nero"

### ✨ Modifiche
- **🔎 Entità e prop leggermente più grandi, ma il gioco resta fluido** — dopo il test del raddoppio 2× (troppo
  pesante), qui si adotta un ingrandimento **leggero e mirato**:
  - **Visivo +45%** (`VIS_SCALE = 1.45`) per giocatore, nemici, **boss** e **oggetti di scena** → colpo d'occhio
    più imponente.
  - **Collisione quasi invariata** (`COL_SCALE = 1.08`): la "hitbox" resta vicinissima a quella della v1.12, così
    movimento e immediatezza **non cambiano**.
  - **Nessuna modifica** a mappa, densità nemici o `moveCircle` (restano come la v1.12 fluida).
  - **+5% velocità base** del giocatore per un feel ancora più reattivo.
  - Proiettili resi un filo più grandi (solo visivamente) per leggibilità.

### 🐛 Correzioni
- **Fix Mercante Nero** — ora, al termine del round, compare **un solo mercante**, scelto a caso: **~30%** il
  **Nero al posto** di quello ufficiale, altrimenti l'ufficiale. **Mai entrambi insieme.** Il Mercante Nero spawna
  ora in una posizione **accessibile** (micro-area o vicino allo spawn), non più nascosto lontano.

### 🧪 Test
- Aggiornato il test del mercante (mutua esclusività: mai entrambi, sempre almeno uno) e aggiunto il test del
  ridimensionamento leggero (visivo > collisione, hitbox quasi invariata, velocità mostri invariata, +5% giocatore)
  → **182 test totali**, 0 falliti; invariante "giocatori mai nei muri" verificata su solo/trio/stress.

### 🧰 Note tecniche
- Nessuna nuova dipendenza. Costanti `VIS_SCALE`/`COL_SCALE` (valori leggeri); raggio **visivo** e di **collisione**
  separati; velocità mostri calcolata sul raggio originale (invariata). Nessuna modifica al protocollo di rete.

---

## [1.12.0] — 2026-08-04 · "Mercante Nero & HUD Ridisegnato"

### ✨ Aggiunte
- **💀 Secondo mercante: il Mercante Nero** — una figura sinistra (incappucciata dal **volto di teschio**, altare di
  pietra con rune, lanterna **viola** e relíquie fluttuanti) nettamente diversa dal Mercante Errante. Vende **patti
  rischio/ricompensa**: potenziamenti forti ma con una **maledizione** (es. *Patto del Berserker* +35% danno ma −25
  PV massimi; *Patto di Cristallo* +30% cadenza ma +12% danni subiti; *Offerta di Sangue* +2 vite ma dimezza le
  monete; *Reliquia Maledetta* un potere ma −20 PV; *Azzardo del Diavolo* effetto casuale benedizione/maledizione).
- **🎲 Apparizione casuale** — il Mercante Nero **non è sempre presente**: compare a caso (~35% delle mappe) e si
  nasconde nel punto **più lontano** dallo spawn. Il suo pannello ha uno **stile dedicato** (viola/rosso) e mostra
  chiaramente **beneficio** (verde) e **rischio** ⚠ (rosso) di ogni patto.
- **🎨 HUD ridisegnato** —
  - **Barra abilità più grande e caratteristica**: slot più ampi con **icone molto più grandi**, badge del tasto
    a pillola, **etichetta** dell'azione sotto ogni slot, cornice con vetro smerigliato e **pulsazione** quando
    l'abilità è pronta.
  - **Eventi al centro**: le notifiche (uccisioni boss, ondate, acquisti, combo, sinergie…) non compaiono più
    piccole in alto a destra, ma **al centro dello schermo**, grandi e molto visibili, con animazione di comparsa.

### 🧪 Test
- **12 nuovi test** (Mercante Nero: spawn/acquisto/prossimità, effetti rischio/ricompensa, differenziazione dal
  mercante normale, apparizione casuale, snapshot) → **172 test totali**, 0 falliti.

### 🧰 Note tecniche
- Nessuna nuova dipendenza. Riusa i messaggi `offer_merchant`/`buy_merchant` con un flag `dark`; nuovi campi
  snapshot `merchD` e `nmd`.

---

## [1.11.0] — 2026-08-04 · "Mercante, Creature & Attacchi alla Hades"

### ✨ Aggiunte
- **🧙 NPC Mercante Errante** — un venditore neutrale (con bancarella, tenda a strisce e lanterna) appare in mappa,
  preferibilmente in una **micro-area**. Avvicinandoti si apre un pannello con **3 offerte casuali** acquistabili
  con le **monete** (cura, +PV massimi, cassa armi, potere, vita extra, +danno, +velocità, riduzione danni).
  Neutrale: i nemici lo ignorano.
- **👹 Nemici ridisegnati** — i mostri non sono più "pallini": ora sono **creature dettagliate** con corpo, arti,
  gambe animate, corna, zanne, ali e occhi (goblin gobbo, orco muscoloso, scheletro con scudo e costole, mago/lich
  incappucciato con orbe, mimic con fauci e lingua, troll con braccione, assassino con pugnale e mantello, viverna
  e drago alati). Stile coerente con l'art degli eroi.
- **⚔️ Attacchi più vari (ispirati a Hades)** — nuovo sistema di **zone telegrafate a terra** (cerchi che si
  riempiono e poi esplodono). Il **Mago Oscuro** alterna colpo mirato, **ventaglio a 3**, e zona sotto i piedi;
  la **Viverna** spara **raffiche a 3**; il **Lich** piazza zone; i **Goblin** eseguono **affondi** rapidi.
- **🕯️ Micro-aree nel dungeon** — piccole nicchie/stanzette laterali scavate nei muri, arredate con oggetti macabri
  e una torcia: più esplorazione e nascondigli. La mappa è anche **più scura** (illuminazione più intima, vignetta marcata).

### 🐛 Correzioni
- **Fix bug "il personaggio si blocca e non si muove"** — era una **regressione della v1.10**: l'handler
  `contextmenu → azzera tasti` scattava a ogni **scatto col tasto destro**, cancellando il movimento. Rimosso.
  Aggiunta inoltre una **rete di sicurezza lato server** che libera il giocatore se dovesse incastrarsi in un muro.

### 🧪 Test
- **14 nuovi test** (mercante: spawn/acquisto/prossimità, zone telegrafate, ventagli, micro-aree, snapshot) →
  **160 test totali**, 0 falliti.

### 🧰 Note tecniche
- Nessuna nuova dipendenza. Nuovi messaggi di rete `buy_merchant`/`offer_merchant`; il mercante riusa lo snapshot.

---

## [1.10.0] — 2026-08-04 · "Icone Emporio, Poteri & Dungeon Tetri"

### ✨ Aggiunte
- **🎨 Icone dell'emporio generate e uniche per personaggio** — armatura, stivali e arma ora hanno **icone-immagine**
  dedicate e **diverse per ciascuno dei 3 eroi** (Enforcer blu/polizia, Recon verde/militare, Glitch cyan/hacker),
  al posto delle emoji. Renderizzate come `<img>` nell'emporio e nel killfeed di equipaggiamento.
- **🎴 Catalogo poteri ampliato, scelta tra 2** — aggiunti **6 nuovi boon** (Furia Cieca, Passo Rapido, Fortuna Sfacciata,
  Colosso, Giustiziere, Bombardiere → **23 totali**). A fine ondata ora si sceglie **1 di 2** carte (più mirato).
- **🪦 Dungeon più tetri** — nuovi elementi macabri: **tombe**, **cadaveri**, **strumenti di tortura** (ruota dentata),
  **gabbie sospese** con resti, oltre a più **ragnatele**, **catene**, **teschi** e **ossa**. Pavimenti e atmosfera
  **oscurati** per un tono più cupo.

### 🔧 Modifiche
- **Emporio ridotto a 3 slot**: rimossi **Anello** e **Amuleto** (restano Armatura, Stivali, Arma).
- **Oggetti molto più costosi**: costi base aumentati (~80/70/95 monete) e scaling per tier più ripido (×2.1–2.2),
  per rendere l'equipaggiamento una scelta di lungo periodo.

### 🐛 Correzioni
- **Fix "il personaggio si muove da solo"** — se la finestra perdeva il focus (alt-tab, click fuori, apertura chat)
  mentre tenevi un tasto, il `keyup` non arrivava e il tasto restava "premuto". Ora lo stato input viene **azzerato**
  su `blur`, cambio di visibilità della scheda, uscita del mouse dal canvas e all'apertura/chiusura della chat.
  Inoltre, mentre digiti in chat il movimento è **neutralizzato**.

### 🧪 Test
- **15 nuovi test** (scelta tra 2 poteri, nuovi boon, emporio a 3 slot costoso, icone per eroe) → **146 test totali**, 0 falliti.

### 🧰 Note tecniche
- Le icone sono PNG con trasparenza in `public/assets/gear/{eroe}_{slot}.png`, ottimizzate (~110 KB ciascuna).

---

## [1.9.0] — 2026-08-04 · "Pausa, Nuove Abilità & Scenografia"

### ✨ Aggiunte
- **⏸️ Pausa nel negozio** — quando l'ondata finisce e sei nel negozio / scelta poteri / emporio, **il mondo si
  congela** (nemici, proiettili e movimento fermi). In singolo giocatore non c'è timer forzato: il gioco riparte
  **solo** premendo **Continua** (in multiplayer resta un timeout anti-AFK). A fine ondata i drop rimasti a terra
  (XP e monete) vengono **raccolti automaticamente**, così la pausa non fa perdere nulla.
- **⚔️ Abilità riviste — 2 per eroe + nuove** (lo **scatto** universale col tasto destro resta invariato):
  - 🎯 **Torretta Schierabile** (Enforcer, E) — piazza una torretta che spara ai nemici per 8s *(stile TF2/Risk of Rain)*.
  - 🎯 **Colpo del Cecchino** (Recon, E) — proiettile perforante devastante a lunga gittata *(stile Overwatch/Valorant)*.
    Sostituisce il vecchio "Scatto di Combattimento", che era **ridondante** con lo scatto universale (tasto destro).
  - Glitch mantiene le sue due abilità già uniche (⏱️ Bullet-Time + 🌀 Frattura di Dati).
  - La barra abilità mostra le **icone specifiche** di ogni eroe.
- **🏛️ Più elementi scenografici nel dungeon** — nuovi prop tematici: **colonne**, **cristalli**, **statue**,
  **funghi luminescenti**, **catene**, **pozze**, **pozze di lava**, **stendardi**, **sarcofagi**. Densità aumentata
  e colonne appoggiate ai muri per maggiore profondità.
- **🏷️ Versione nel titolo** — il numero di versione compare nel titolo della scheda e come badge nel menu
  (sincronizzato da `C.VERSION`).
- **🧪 20 nuovi test** automatici (pausa, raccolta auto, torretta, cecchino, scatto universale, "2 abilità per eroe")
  → **130 test totali**; test homing reso deterministico (niente più flakiness).

### 🔧 Modifiche
- La simulazione del mondo è ora **gated** dalla fase: gira solo in combattimento/boss, non nel negozio/lobby/fine.
- Rimossa l'abilità ridondante di Recon; aggiunte `VERSION` e nuove voci abilità (con icone) in `heroes.js`.

### 🧰 Note tecniche
- Nessuna nuova dipendenza. La torretta riusa l'array `orbs` (nessun nuovo canale di rete).

---

## [1.8.0] — 2026-08-04 · "Monete & Emporio dell'Equipaggiamento"

### ✨ Aggiunte
- **🪙 Monete di vario taglio** — i nemici droppano **monete** oltre all'XP: 🟤 Bronzo (1), ⚪ Argento (5),
  🟡 Oro (20). I **boss** e le **élite** ne lasciano di più e di taglio superiore; lo **scrigno del tesoro**
  è una miniera. Raccolta con **calamita** come l'XP.
- **🏪 Emporio dell'equipaggiamento** — a fine ondata, un secondo negozio (a **monete**, parallelo a quello a XP)
  con **5 slot** potenziabili per **5 tier** (Lv. I → V, rarità crescente):
  - 🛡️ **Armatura** → riduzione danni + PV massimi
  - 👟 **Stivali** → velocità di movimento
  - ⚔️ **Arma** → danno + cadenza di fuoco
  - 💍 **Anello** → probabilità e moltiplicatore critico
  - 📿 **Amuleto** → potenza abilità + assorbimento vitale
  Ogni tier costa più del precedente: costruisci il tuo personaggio nel tempo.
- **🎨 Resa grafica** — monete animate a terra con luccichio e luce dedicata; contatore monete 🪙 nell'HUD;
  carte equipaggiamento con indicatori di tier (pip) e costo.
- **🧪 19 nuovi test** automatici (drop/raccolta monete, acquisto e stat degli slot, costo crescente, tier massimo,
  cap riduzione danni, snapshot) → **110 test totali**.

### 🔧 Modifiche
- Due economie **distinte e complementari**: **XP** per micro-potenziamenti ripetibili, **monete** per
  equipaggiamento a slot con tier discreti.
- Nuovi messaggi di rete `buy_gear` / `offer_gear`; `Room` traccia `coins` e `gear` per giocatore.
- La riduzione danni totale è ora **limitata all'85%** (per evitare invulnerabilità con più fonti cumulative).

### 🧰 Note tecniche
- Nessuna nuova dipendenza. Gli effetti dell'equipaggiamento si sommano ai campi statistici esistenti (delta additivo).

---

## [1.7.0] — 2026-08-04 · "Stats, Ricompense Combo & Sinergie"

### ✨ Aggiunte
- **🏆 Schermata di fine partita con statistiche** — riepilogo completo della run: **ondata** raggiunta,
  **durata** ⏱, e una **classifica co-op** (ordinata per uccisioni) con medaglie 🥇🥈🥉. Per ogni giocatore:
  **uccisioni**, **combo massima** 🔥, **danni totali**, numero di **boon** raccolti, **sinergie** attive 🔗 e
  **arma** (con evoluzione ✨). I caduti sono barrati.
- **🔥 Ricompense combo a soglie** — la combo non dà più solo XP: a **15** sblocchi la **Frenesia** (buff cadenza),
  a **25** una **Nova** ad area, a **40** una **Cura + Egida**. Mantenere la combo diventa una scelta tattica.
- **🔗 Sinergie tra Boon** — possedere due boon compatibili sblocca un effetto potenziato una tantum:
  - **🧪 Deflagrazione Tossica** (Tossina + Colpi Esplosivi) → le esplosioni diffondono veleno ad area.
  - **🧊 Catena Gelida** (Catena di Fulmini + Tocco Gelido) → le catene rallentano i nemici colpiti.
  - **🔮 Cercatore** (Mira Guidata + Perforazione) → i proiettili guidati perforano +1 nemico.
  - **🩸 Sete di Sangue** (Vampirismo + Adrenalina Pura) → +6% cura dal danno inflitto.
- **🧪 18 nuovi test** automatici (ricompense combo, sinergie, deflagrazione tossica, stats/classifica) → **91 test totali**.

### 🔧 Modifiche
- `Room` traccia `runStart`, `comboBest`, `damageDealt` e `synActive` per giocatore.
- Gli eventi `gameover`/`victory` ora trasportano `stats` (classifica) e `dur` (durata run).
- Nuovi eventi client: `combo_reward` (ricompense a soglie) e `synergy` (sinergia sbloccata).

### 🧰 Note tecniche
- Nessuna nuova dipendenza. Retro-compatibile con i salvataggi di logica della v1.6.

---

## [1.6.0] — 2026-08-04 · "Combo, Minimappa & Homing"

### ✨ Aggiunte
- **🔥 Sistema COMBO / streak** — le uccisioni consecutive riempiono un **combo meter** in alto al centro.
  Ogni catena aumenta un **moltiplicatore di XP** progressivo (fino a **x2.5**). Milestone ogni 5 uccisioni con
  feedback visivo/sonoro; oltre 20 combo compare un avviso nel killfeed.
- **⏳ Decadimento combo** — se non uccidi entro `COMBO_TIME` (3,6 s) la combo si azzera: premia il gioco aggressivo.
- **🗺️ Minimappa in tempo reale** — riquadro in basso a sinistra con muri, portale d'uscita, **alleati**,
  **nemici** (boss in rosso, élite in oro) e lo **scrigno del tesoro** 👑.
- **🎯 Boon "Mira Guidata" (homing)** — i proiettili curvano dolcemente verso il nemico più vicino (max 2 stack).
- **🪙 Boon "Avidità"** — +30% XP raccolta per stack (potenzia le combo).
- **🧱 Boon "Baluardo"** — -12% a tutti i danni subiti per stack (fino a -60%).
- **🧪 12 nuovi test** automatici (combo, homing, avidità, baluardo, snapshot combo) → **73 test totali**.

### 🔧 Modifiche
- `snapshot()` ora espone `cmb` (combo), `cmt` (frazione timer), `cmx` (moltiplicatore) per l'HUD.
- Statistiche giocatore estese con `xpMult` e `dmgReduce`.
- Descrizione e versione aggiornate in `package.json` e nella suite di test.

### 🧰 Note tecniche
- Nessuna nuova dipendenza (motore custom a dipendenze zero invariato).
- Retro-compatibile: le partite e i salvataggi di logica restano validi; nessuna modifica di rete "breaking".

---

## [1.5.0] — "Profondità & Game Feel"

### ✨ Aggiunte
- **🎴 Poteri a scelta (Boon, stile Hades)** — a fine ondata scegli 1 di 3 carte con effetti unici e impilabili
  (Rimbalzo, Perforazione, Catena di Fulmini, Tossina, Colpi Esplosivi, Onda di Ritorno, Vampirismo, Sdoppiamento,
  Occhio di Falco, Proiettili Giganti, Tocco Gelido, Aura di Spine, Adrenalina Pura, Scudo Vitale).
- **💥 Hit-stop + evoluzione armi** — micro freeze-frame sui critici/uccisioni di boss; armi a Lv.3 con la statistica
  giusta si evolvono (Uragano d'Acciaio, Tempesta di Piombo, Lancia del Giudizio).
- **🌊 Modalità ondata** — Orda, Caccia, Sopravvivenza, Tesoro 👑, Assalto.

### Incluse dalle versioni precedenti
- Sistema di **vite** (2), **XP raccoglibile + negozio statistiche**, **item drop**, **20 livelli** con
  **MEGA boss finale AZ'GAROTH**, **temi mappa** (Cripta, Lava, Foresta, Ghiaccio, Arcano), dash che attraversa
  i nemici, 3 armi raccoglibili, musica procedurale, 3 eroi, 10 mostri + boss, netcode autoritativo.

---

> Formato ispirato a [Keep a Changelog](https://keepachangelog.com) · Versioni secondo [SemVer](https://semver.org).
> Ad ogni nuova versione aggiungi qui in cima una sezione con la data e le modifiche.
