/* renderer.js — Canvas 2D: temi, omini, orb XP, item, casse, fuoco, boon-fx, luci */
(function () {
  'use strict';
  const C = window.GAME.Constants, MU = window.GAME.Math, MON = window.GAME.Monsters.MONSTERS, BOSSES = window.GAME.Monsters.BOSSES, HERO = window.GAME.Heroes.HEROES, ITEMS = window.GAME.Loot.ITEMS;

  // ============================================================================================
  // v2.18 — LO STILE DI DISEGNO DELLE SETTE CLASSI
  // ============================================================================================
  // Quattro voci per classe e nient'altro: `testa` (elmo chiuso, elmo aperto, testa nuda, cappuccio,
  // cappello a tesa), `spalle` (acciaio o pelliccia), `arma` (ascia, spada+scudo, due spade, due
  // pugnali, arco, bastone, sigillo) e la TINTA. E' il patto della bozza approvata: le sagome si
  // distinguono senza che nasca una quarta impalcatura, e l'equipaggiamento continua a ridipingere gli
  // stessi pezzi di sempre (la tinta di un oggetto arriva dopo, in `_palGear`, e vince su questa).
  //
  // Vive qui e non in heroes.js perche' e' roba di DISEGNO: heroes.js decide quanto fa male una
  // classe, il renderer come si vede.
  const STILE = {
    barbaro:   { corpo: 'guerriero', testa: 'nuda',       spalle: 'pelliccia', arma: 'ascia',      piastra: 0, criniera: '#5a3a1e', pelo: '#6a5a44', pelle: '#c08050', metallo: '#8a7a63', cloth: '#6b4a2a', clothDk: '#3a2716', orlo: '#d8a33a' },
    paladino:  { corpo: 'guerriero', testa: 'elmoChiuso', spalle: 'acciaio',   arma: 'spadascudo', piastra: 1, tabarro: '#e8edf5', cresta: '#5a6272', metallo: '#9aa3b0', cloth: '#2e4a86', clothDk: '#16264a', orlo: '#e0b64a' },
    maestro:   { corpo: 'guerriero', testa: 'elmoAperto', spalle: 'acciaio',   arma: 'doppia',     piastra: 1, fascia: '#b4463c', mantello: '#4a2622', metallo: '#7e838d', cloth: '#3a2f2a', clothDk: '#1e1917', orlo: '#c8a23a', pelle: '#c79b6a' },
    assassino: { corpo: 'ladro', arma: 'pugnali', scia: 1, cloth: '#2b2f42', clothDk: '#14172a', mant: '#191d30', capp: '#242840', pelle: '#c2a184', lama: '#cfd8dc', buio: '#0a0a14' },
    arciere:   { corpo: 'ladro', arma: 'arco',            cloth: '#3c5140', clothDk: '#1d2a22', mant: '#25342b', capp: '#33443a', pelle: '#c99a6a', legno: '#a37a41', buio: '#0d1512' },
    mago:      { corpo: 'mago',  arma: 'bastone', cappello: 'tesa', rune: 1, body: '#2a3a6a', bodyDk: '#141c36', accent: '#5aa8ff', orlo: 'rgba(120,180,255,.8)', capp: '#1b2445', pelle: '#d8d2c8' },
    // il warlock NON ha occhi accesi sotto il cappuccio: c'erano nella prima bozza e Paolo li ha fatti
    // togliere. Sotto il cappuccio c'e' solo la fessura buia. Non vanno rimessi.
    warlock:   { corpo: 'mago',  arma: 'sigillo', cappello: 'punta', stracciato: 1, tentacoli: 1, body: '#3a1f52', bodyDk: '#1a0e28', accent: '#c06bff', orlo: 'rgba(190,110,255,.75)', capp: '#25123a', pelle: '#4c3a60' },
  };
  const ITEM_BY_ID = {}; for (const it of ITEMS) ITEM_BY_ID[it.id] = it;
  const COIN_COL = {}; for (const c of (C.COINS || [])) COIN_COL[c.id] = { color: c.color, r: c.r };

  // ===== v1.19 — TEXTURE ROCCIA procedurale (bump/rilievo + domain-warp) =====
  function _mkNoise(seed) {
    const perm = new Uint8Array(512); let s = (seed >>> 0) || 1; const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
    const base = []; for (let i = 0; i < 256; i++) base[i] = i;
    for (let i = 255; i > 0; i--) { const j = (rnd() * (i + 1)) | 0; const t = base[i]; base[i] = base[j]; base[j] = t; }
    for (let i = 0; i < 512; i++) perm[i] = base[i & 255];
    const fade = t => t * t * t * (t * (t * 6 - 15) + 10); const lerp = (a, b, t) => a + (b - a) * t; const grad = (h, x, y) => ((h & 1) ? x : -x) + ((h & 2) ? y : -y);
    return (x, y) => { const X = Math.floor(x) & 255, Y = Math.floor(y) & 255; x -= Math.floor(x); y -= Math.floor(y); const u = fade(x), v = fade(y); const A = perm[X] + Y, B = perm[X + 1] + Y; return lerp(lerp(grad(perm[A], x, y), grad(perm[B], x - 1, y), u), lerp(grad(perm[A + 1], x, y - 1), grad(perm[B + 1], x - 1, y - 1), u), v) * 0.5 + 0.5; };
  }
  function _mkFbm(seed) { const n = _mkNoise(seed); return (x, y, oct, pers, scale) => { oct = oct || 5; pers = pers || 0.55; scale = scale || 1; let a = 1, f = scale, sum = 0, nm = 0; for (let o = 0; o < oct; o++) { sum += n(x * f, y * f) * a; nm += a; a *= pers; f *= 2; } return sum / nm; }; }
  function _mkWorley(seed, cell) { let s = (seed >>> 0) || 7; const h = (i, j) => { let v = ((i * 73856093) ^ (j * 19349663) ^ (s * 83492791)) >>> 0; v = (v ^ (v >> 13)) >>> 0; return v / 4294967296; }; return (x, y) => { const gx = Math.floor(x / cell), gy = Math.floor(y / cell); let d1 = 1e9, d2 = 1e9; for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) { const cx = gx + i, cy = gy + j, fx = (cx + h(cx, cy)) * cell, fy = (cy + h(cy + 5, cx + 9)) * cell, dd = Math.hypot(x - fx, y - fy); if (dd < d1) { d2 = d1; d1 = dd; } else if (dd < d2) d2 = dd; } return (d2 - d1) / cell; }; }
  const _hex = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  const _cl = (v) => v < 0 ? 0 : v > 255 ? 255 : v;
  const _toHex2 = (n) => { n = _cl(Math.round(n)); return n.toString(16).padStart(2, '0'); };
  const _darkenHex = (hex, f) => { const c = _hex(hex); return '#' + _toHex2(c[0] * f) + _toHex2(c[1] * f) + _toHex2(c[2] * f); }; // v1.21 — muri quasi neri
  // genera un canvas quadrato di roccia illuminata (heightmap -> bump). size ~192. moss opzionale.
  function _rockTile(seed, size, baseHex, o) {
    const cv = document.createElement('canvas'); cv.width = size; cv.height = size; const g = cv.getContext('2d');
    const img = g.createImageData(size, size), d = img.data;
    const fbm = _mkFbm(seed), wor = _mkWorley(seed + 3, o.cell), sc = o.scale, warp = o.warp, bump = o.bump, base = _hex(baseHex);
    // 1) heightmap (una passata pesante)
    const hm = new Float32Array(size * size);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const wx = x + (fbm(x * sc * 0.6 + 50, y * sc * 0.6, 4) - 0.5) * warp; const wy = y + (fbm(x * sc * 0.6, y * sc * 0.6 + 90, 4) - 0.5) * warp;
      let hh = fbm(wx * sc, wy * sc, 6); hh = hh * 0.7 + fbm(wx * sc * 2.4 + 11, wy * sc * 2.4, 4) * 0.3;
      const e = wor(wx, wy); if (e < 0.06) hh -= (0.06 - e) * 3.0;
      const cr = fbm(wx * sc * 0.9 + 100, wy * sc * 0.9, 5); if (cr < 0.26) hh -= (0.26 - cr) * 2.0;
      hm[y * size + x] = hh;
    }
    // 2) shading da normali (luce alto-sinistra)
    const Lx = -0.55, Ly = -0.7, Lz = 0.45; const ll = Math.hypot(Lx, Ly, Lz); const lx = Lx / ll, ly = Ly / ll, lz = Lz / ll;
    const at = (x, y) => hm[((y + size) % size) * size + ((x + size) % size)];
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const hC = hm[y * size + x]; const hX = at(x + 1, y) - at(x - 1, y), hY = at(x, y + 1) - at(x, y - 1);
      let nx = -hX * bump, ny = -hY * bump, nz = 1; const nl = Math.hypot(nx, ny, nz); nx /= nl; ny /= nl; nz /= nl;
      let diff = nx * lx + ny * ly + nz * lz; if (diff < 0) diff = 0; const lightF = 0.4 + diff * 0.95; const spec = Math.pow(diff, 22) * 0.5 * 255;
      const tone = 0.8 + hC * 0.5; let r = base[0] * tone, gg = base[1] * tone, b = base[2] * tone;
      const wet = fbm(x * sc * 0.5 + 40, y * sc * 0.5 + 70, 4); if (wet < 0.36) { const k = (0.36 - wet) * 1.4; r *= (1 - 0.32 * k); gg *= (1 - 0.30 * k); b *= (1 - 0.20 * k); }
      if (o.moss) { const ms = fbm(x * sc * 0.6 + 300, y * sc * 0.6 + 200, 4); if (ms > 0.74) { const k = (ms - 0.74) * 2.4; r = r * (1 - 0.4 * k) + 42 * k; gg = gg * (1 - 0.1 * k) + 78 * k; b = b * (1 - 0.4 * k) + 32 * k; } }
      r = r * lightF + spec; gg = gg * lightF + spec; b = b * lightF + spec;
      const gr = fbm(x * 0.9 + 11, y * 0.9 + 3, 2); if (gr > 0.93) { r += 26; gg += 26; b += 30; }
      const px = (y * size + x) * 4; d[px] = _cl(r); d[px + 1] = _cl(gg); d[px + 2] = _cl(b); d[px + 3] = 255;
    }
    g.putImageData(img, 0, 0); return cv;
  }
  // ===== v1.36→v1.39 — RENDER PUPPET (raster ibrido): sprite scomposto in pezzi (PNG) + overlay vettoriale =====
  // Registry generico dei puppet: ogni voce carica manifest + immagini una sola volta.
  // v1.39 — astratto in PUPPETS[key] + PROF[key] (profilo animazione) così aggiungere un nemico = "manifest + profilo".
  function makePuppet(base, file) {
    return {
      ready: false, man: null, imgs: {}, _started: false, base, file,
      load() {
        if (this._started) return; this._started = true; const self = this;
        fetch(this.base + this.file).then(r => r.json()).then(man => {
          self.man = man; let need = man.parts.length, got = 0;
          man.parts.forEach(p => {
            const im = new Image();
            im.onload = () => { self.imgs[p.name] = im; if (++got >= need) self.ready = true; };
            im.onerror = () => { if (++got >= need) self.ready = (Object.keys(self.imgs).length >= need); };
            im.src = self.base + p.name + '.png';
          });
        }).catch(() => {});
      }
    };
  }
  const PUPPETS = {
    ghoul: makePuppet('assets/enemies/ghoul/', 'ghoul.json'),
    mage:  makePuppet('assets/enemies/mage/',  'mage.json'),
    brute: makePuppet('assets/enemies/brute/', 'brute.json'),
    slime: makePuppet('assets/enemies/slime/', 'slime.json'),
    beholder: makePuppet('assets/enemies/beholder/', 'beholder.json'),  // v1.49 — BEHOLDER (raster puppet)
    padrone: makePuppet('assets/enemies/padrone/', 'padrone.json'),    // v2.23 — IL PADRONE (marionetta dal disegno di Paolo, ali e coda in codice)
  };
  const GHOUL = PUPPETS.ghoul; // alias di compatibilità
  // ===== v1.47 — SPRITE SHEET (frame-by-frame): personaggi animati "alla vecchio 2.5D" (griglia di frame) =====
  // Ogni sheet carica il manifest + i PNG (uno per animazione). L'anchor (ax,ay) nella cella è ai PIEDI (grounding).
  function makeSheet(base, file) {
    return {
      ready: false, man: null, imgs: {}, _started: false, base, file,
      load() {
        if (this._started) return; this._started = true; const self = this;
        fetch(this.base + this.file).then(r => r.json()).then(man => {
          self.man = man; const names = Object.keys(man.anims); let need = names.length, got = 0;
          names.forEach(k => { const im = new Image(); im.onload = () => { self.imgs[k] = im; if (++got >= need) self.ready = true; }; im.onerror = () => { if (++got >= need) self.ready = (Object.keys(self.imgs).length >= need); }; im.src = self.base + man.anims[k].file; });
        }).catch(() => {});
      }
    };
  }
  const SHEETS = {
    troll: makeSheet('assets/enemies/troll_sheet/', 'troll.json'),
  };
  const _SIN = Math.sin, _TAU = Math.PI * 2, _PI = Math.PI;
  const _bump = (x, c, w) => Math.max(0, 1 - Math.abs(x - c) / w);
  // ---- PROFILI DI ANIMAZIONE per-nemico ----
  // Ogni profilo espone: OY0 (riga d'ancoraggio verticale), K (scala), order (ordine di disegno),
  // gait ('walk'|'float'), eliteFilter (ctx.filter per gli elite) e pose(t,moving,atk) → {P,bob,lungeX,tilt}.
  const PROF = {
    // ===== v2.23 — IL PADRONE =============================================================
    // La marionetta viene dal disegno di Paolo, tagliato in otto pezzi. Le ALI del disegno sono
    // state tolte apposta e rifatte qui in vettoriale: attaccate al raster sarebbero rimaste
    // ferme, e un demone con le ali immobili e' una statua. La CODA e' un pezzo raster ma ondeggia
    // di suo, sfasata rispetto al passo, perche' e' l'unica parte che non ha motivo di stare ferma.
    // Va LENTO: e' il comandante, non l'assaltatore. Il passo e' largo e pesante (cadenza 0.52
    // contro 1.05 dello zombi) e il busto dondola poco — chi comanda non corre.
    padrone: {
      OY0: 1103, K: 5.0, gait: 'float', ali: true, eliteFilter: 'hue-rotate(-18deg) saturate(1.7) brightness(1.1)',
      order: ['coda', 'gambaSx', 'gambaDx', 'cintura', 'torso', 'testa', 'braccioSx', 'braccioDx'],
      WALK: { cad: 0.52, leg: 21, arm: 13, torso: 4, head: 2.4, bob: 9, sway: 3.4 },
      pose(t, moving, atk) {
        const S = _SIN, TAU = _TAU, PI = _PI, W = this.WALK;
        const ph = moving ? (t * W.cad) % 1 : (t * 0.34) % 1;
        const a = atk || 0, wind = _bump(a, 0.32, 0.32), strike = _bump(a, 0.66, 0.30);
        const P = { coda: [0, 0, 0], gambaSx: [0, 0, 0], gambaDx: [0, 0, 0], cintura: [0, 0, 0],
                    torso: [0, 0, 0], testa: [0, 0, 0], braccioSx: [0, 0, 0], braccioDx: [0, 0, 0] };
        let bob = 0, lungeX = 0, tilt = 0;
        // il respiro: c'e' sempre, fermo o in marcia. Senza, quando sta fermo sembra in pausa.
        const resp = S(TAU * ((t * 0.30) % 1));
        if (moving) {
          // v2.23.1 — NIENTE FALCATA. Paolo: *«le gambe devono restare ferme altrimenti sembra una
          // marionetta appena»*. Aveva ragione: la falcata di due pezzi raster tagliati da un
          // disegno piatto e' esattamente la cosa che fa vedere il cartone. Le gambe restano ferme
          // e il Padrone SCIVOLA, che per un demone alato e' anche piu' giusto di una camminata.
          // Il movimento lo raccontano il galleggio, l'inclinazione in avanti e le ali, che battono
          // piu' forte quando avanza.
          bob = -2.5 + 5.5 * S(TAU * ph * 0.55);
          const lat = W.sway * S(TAU * ph * 0.55);
          P.braccioSx = [-W.arm * 0.5 * S(TAU * ph * 0.55), 0, 0];
          P.braccioDx = [-W.arm * 0.5 * S(TAU * ph * 0.55 + PI), 0, 0];
          P.torso = [W.torso * 0.5 * S(TAU * ph * 0.55), lat, 0];
          P.testa = [-W.head * 0.5 * S(TAU * ph * 0.55), lat * 0.6, 0];
          P.cintura = [2.6 * S(TAU * ph * 0.55 - 0.9), lat * 0.6, 0];
          tilt = 3.2;                                     // si protende in avanti: e' lui che avanza
        } else {
          bob = 4 * S(TAU * ph);
          P.testa = [2 * S(TAU * ph), 0, 1.6 * S(TAU * ph + 0.5)];
          P.braccioSx = [3 * S(TAU * ph), 0, 0]; P.braccioDx = [-3 * S(TAU * ph), 0, 0];
          P.torso = [1.2 * S(TAU * ph), 0, 0];
          P.cintura = [1.4 * S(TAU * ph - 0.7), 0, 0];
        }
        P.torso[2] += resp * 1.6; P.testa[2] += resp * 1.2;          // il petto che sale e scende
        // v2.23.1 — FLUTTUA. Paolo: *«fallo fluttuare con le gambe ferme»*. Il corpo si alza di un
        // pezzo fisso e l'ombra resta dov'e', a terra: e' quel distacco, non il galleggio, a dire
        // che i piedi non toccano. Col passo tolto era anche l'unica lettura sensata rimasta.
        bob -= 30;
        // LA CODA: sfasata dal passo e piu' lenta. Se battesse a tempo col passo si leggerebbe come
        // un pezzo rigido attaccato al bacino invece che come una coda.
        P.coda = [11 * S(TAU * ((t * 0.37) % 1)) + 4 * S(TAU * ph + 1.4), 0, 0];
        if (a > 0.001) {
          // la frustata: il braccio destro va indietro e poi taglia in avanti, il busto lo segue
          P.braccioDx[0] += -46 * wind; P.braccioDx[2] += -18 * wind;
          P.torso[0] += -6 * wind; P.testa[2] += -8 * wind; P.coda[0] += -22 * wind;
          P.braccioDx[0] += 96 * strike; P.braccioDx[2] += 22 * strike;
          P.braccioSx[0] += -34 * strike;
          P.torso[0] += 13 * strike; P.testa[2] += 18 * strike; P.coda[0] += 30 * strike;
          lungeX += 26 * strike; tilt += 5 * strike;
        }
        return { P, bob, lungeX, tilt, swing: Math.max(wind * 0.5, strike), ali: { wind, strike, ph, moving } };
      },
      death(p) {
        const P = { coda: [50 * p, 0, 24 * p], gambaSx: [34 * p, -5 * p, 26 * p], gambaDx: [-34 * p, 5 * p, 26 * p],
                    cintura: [0, 0, 30 * p], torso: [9 * p, 0, 32 * p], testa: [58 * p, 30 * p, 38 * p],
                    braccioSx: [44 * p, 0, 18 * p], braccioDx: [-44 * p, 0, 18 * p] };
        return { P, bob: 30 * p, lungeX: 0, tilt: 8 * p, alpha: 1 - p * 0.75 };
      },
    },
    ghoul: {
      OY0: 890, K: 2.7, gait: 'walk', eliteFilter: 'hue-rotate(-38deg) saturate(1.5) brightness(1.05)',
      order: ['legR', 'legL', 'torso', 'head', 'armR', 'armL'],
      WALK: { cad: 1.05, leg: 37, arm: 26, torso: 7, head: 3, bob: 11, sway: 4.5 },
      pose(t, moving, atk) {
        const S = _SIN, TAU = _TAU, PI = _PI, W = this.WALK;
        const ph = moving ? (t * W.cad) % 1 : (t * 0.55) % 1;
        const a = atk || 0, wind = _bump(a, 0.30, 0.30), strike = _bump(a, 0.62, 0.30);
        const P = { legR: [0, 0, 0], legL: [0, 0, 0], torso: [0, 0, 0], head: [0, 0, 0], armR: [0, 0, 0], armL: [0, 0, 0] };
        let bob = 0, lungeX = 0, tilt = 0;
        if (moving) {
          bob = -W.bob + W.bob * Math.abs(S(TAU * ph));
          const lat = W.sway * S(TAU * ph);
          P.legR = [W.leg * S(TAU * ph), 0, 0]; P.legL = [W.leg * S(TAU * ph + PI), 0, 0];
          P.armR = [-W.arm * S(TAU * ph), 0, 0]; P.armL = [-W.arm * S(TAU * ph + PI), 0, 0];
          P.torso = [W.torso * S(TAU * ph), lat, 0]; P.head = [-W.head * S(TAU * ph), lat * 0.6, 0];
          tilt = 3.5; // v1.39 — leggera inclinazione in avanti nel movimento
        } else {
          bob = 6 * S(TAU * ph);
          P.head = [3 * S(TAU * ph), 0, 2 * S(TAU * ph + 0.5)];
          P.armR = [4 * S(TAU * ph), 0, 0]; P.armL = [-4 * S(TAU * ph), 0, 0];
          P.torso = [1.5 * S(TAU * ph), 0, 0];
        }
        if (a > 0.001) {
          P.armR[0] += -30 * wind; P.armR[2] += -30 * wind; P.armL[0] += 30 * wind; P.armL[2] += -30 * wind;
          P.torso[0] += -5 * wind; P.head[2] += -10 * wind;
          P.armR[0] += 74 * strike; P.armR[2] += 26 * strike; P.armL[0] += -74 * strike; P.armL[2] += 26 * strike;
          P.torso[0] += 11 * strike; P.head[2] += 24 * strike; P.legR[0] += 10 * strike; P.legL[0] += -10 * strike;
          lungeX += 30 * strike; tilt += 6 * strike;
        }
        return { P, bob, lungeX, tilt, swing: Math.max(wind * 0.5, strike) };
      },
      death(p) { // crollo: gambe cedono, busto affonda, testa rotola via
        const P = { legR: [40 * p, -6 * p, 30 * p], legL: [-40 * p, 6 * p, 30 * p], torso: [10 * p, 0, 34 * p], head: [70 * p, 46 * p, 40 * p], armR: [50 * p, 0, 20 * p], armL: [-50 * p, 0, 20 * p] };
        return { P, bob: 26 * p, lungeX: 0, tilt: 0, alpha: 1 - p };
      }
    },
    mage: {
      OY0: 900, K: 2.7, gait: 'float', eliteFilter: 'hue-rotate(20deg) saturate(1.6) brightness(1.12)',
      order: ['robe', 'armStaff', 'torso', 'armHand', 'head'],
      pose(t, moving, atk) {
        const S = _SIN, TAU = _TAU;
        const a = atk || 0, wind = _bump(a, 0.32, 0.30), strike = _bump(a, 0.66, 0.28);
        const fl = t * 0.9; // fluttuazione lenta
        const P = { robe: [0, 0, 0], armStaff: [0, 0, 0], torso: [0, 0, 0], armHand: [0, 0, 0], head: [0, 0, 0] };
        let bob = 5 * S(TAU * fl * 0.5), lungeX = 0, tilt = 0;              // galleggia su/giù
        P.robe = [2.6 * S(TAU * fl * 0.42), 0, 0];                          // veste a campana ondeggia (pendolo)
        P.torso = [1.4 * S(TAU * fl * 0.42), 0, 0];
        P.head = [2.2 * S(TAU * fl * 0.5 + 0.6), 0, 1.5 * S(TAU * fl * 0.5)];
        P.armStaff = [3 * S(TAU * fl * 0.5), 0, 2 * S(TAU * fl * 0.5)];     // bastone dondola
        P.armHand = [-5 * S(TAU * fl * 0.46), 0, 0];
        if (moving) tilt = 2.5;
        if (a > 0.001) { // CAST: alza il bastone (wind) poi proietta (strike) con leggero rinculo
          P.armStaff[0] += -34 * wind; P.armStaff[2] += -16 * wind; P.head[2] += -8 * wind; P.torso[0] += -4 * wind;
          P.armStaff[0] += 18 * strike; P.armHand[0] += -30 * strike; P.armHand[2] += 22 * strike;
          P.head[2] += 12 * strike; P.torso[0] += 6 * strike; bob += -6 * strike; lungeX += 10 * strike; tilt += 4 * strike;
        }
        return { P, bob, lungeX, tilt, swing: Math.max(wind * 0.6, strike), cast: Math.max(wind, strike) };
      },
      death(p) { // la veste si accascia, il cappuccio cade, il bastone crolla
        const P = { robe: [0, 0, 40 * p], armStaff: [-46 * p, -20 * p, 26 * p], torso: [8 * p, 0, 30 * p], armHand: [40 * p, 10 * p, 24 * p], head: [60 * p, 34 * p, 46 * p] };
        return { P, bob: 30 * p, lungeX: 0, tilt: 0, alpha: 1 - p };
      }
    },
    // v1.42 — BRUTO DELLE CAVERNE: tank pesante. Le BRACCIA sono la firma → pivot alla SPALLA, grandi
    // dondolii in camminata e SLAM a due tempi (carica all'indietro → schianto del busto in avanti/giù).
    brute: {
      OY0: 760, K: 2.55, gait: 'walk', eliteFilter: 'hue-rotate(-12deg) saturate(1.6) brightness(1.12)',
      order: ['legR', 'legL', 'torso', 'armR', 'armL', 'head'],   // braccia enormi davanti al busto, testa in cima
      // v1.43 — camminata LUMBERING (distinta dallo zombie): braccia che dondolano poco e IN SINCRONIA (knuckle-drag),
      // grande rollio delle spalle, waddle laterale marcato, busto perennemente proteso in avanti.
      // v1.46 — camminata RIFATTA per togliere il "tremore": UN solo dondolio lento e ampio, gambe con sollevamento
      // MORBIDO (mezzo-coseno, niente scatti), niente rollio nervoso delle spalle, fase SEMPRE continua.
      WALK: { cad: 0.9, leg: 30, lift: 18, armSwing: 14, torso: 3, head: 1.5, bob: 9, sway: 4.5, lean: 6 },
      pose(t, moving, atk) {
        const S = _SIN, TAU = _TAU, PI = _PI, W = this.WALK;
        const ph = (t * W.cad) % 1;                                  // fase CONTINUA (mai reset → niente scatti)
        const a = atk || 0, wind = _bump(a, 0.30, 0.28), strike = _bump(a, 0.66, 0.26);
        const P = { legR: [0, 0, 0], legL: [0, 0, 0], torso: [0, 0, 0], armR: [0, 0, 0], armL: [0, 0, 0], head: [0, 0, 0] };
        let bob = 0, lungeX = 0, tilt = 0;
        if (moving) {
          const s2 = S(TAU * ph), c2 = S(TAU * ph + PI);
          bob = -W.bob * 0.5 + W.bob * Math.abs(s2);                 // ondeggio verticale MORBIDO
          const lat = W.sway * s2;                                   // waddle contenuto
          // gambe: falcata + sollevamento del piede con MEZZO-COSENO (0→1→0 liscio, senza kink)
          const liftR = -W.lift * (0.5 - 0.5 * Math.cos(TAU * ph)), liftL = -W.lift * (0.5 - 0.5 * Math.cos(TAU * ph + PI));
          P.legR = [W.leg * s2, 0, liftR]; P.legL = [W.leg * c2, 0, liftL];
          // braccia enormi: UNICO dondolio lento IN SINCRONIA (niente rollio delle spalle che tremolava)
          P.armR = [W.armSwing * s2, 0, 0]; P.armL = [W.armSwing * s2, 0, 0];
          P.torso = [W.torso * s2, lat, 0]; P.head = [-W.head * s2, lat * 0.6, 0];
          tilt = W.lean;                                             // busto proteso in avanti (knuckle-drag)
        } else { // IDLE: respiro pesante, spalle su/giù, braccia che ciondolano lente
          bob = 7 * S(TAU * ph);
          P.armR = [4 * S(TAU * ph), 0, 0]; P.armL = [4 * S(TAU * ph), 0, 0];
          P.torso = [1.4 * S(TAU * ph), 0, 0]; P.head = [2 * S(TAU * ph + 0.5), 0, 1.4 * S(TAU * ph)]; tilt = 2;
        }
        if (a > 0.001) { // v1.43 — SLAM: ALZA i pugni SOPRA LA TESTA (wind) → li SCHIANTA a terra (strike)
          // WIND: si erge sulle punte, si inarca all'indietro, entrambe le braccia ruotano IN ALTO oltre la testa
          P.armR[0] += 140 * wind; P.armL[0] += -140 * wind;         // pugni sopra la testa (simmetrico)
          P.head[2] += -20 * wind; P.torso[0] += -8 * wind; bob += -16 * wind; tilt += -8 * wind;
          // STRIKE: dai pugni-in-alto SCENDONO a martello convergendo avanti-basso; il corpo SI ABBATTE con forza
          P.armR[0] += 40 * strike; P.armL[0] += -40 * strike;
          P.head[2] += 32 * strike; P.torso[0] += 16 * strike; P.legR[0] += 10 * strike; P.legL[0] += -10 * strike;
          bob += 34 * strike; lungeX += 30 * strike; tilt += 22 * strike; // v1.44 — affondo più profondo e deciso
        }
        return { P, bob, lungeX, tilt, swing: Math.max(wind * 0.6, strike) };
      },
      death(p) { // crolla in avanti: braccia si accasciano, testa cade, il corpo si abbatte
        const P = { legR: [24 * p, -6 * p, 24 * p], legL: [-24 * p, 6 * p, 24 * p], torso: [10 * p, 0, 30 * p], armR: [40 * p, 0, 26 * p], armL: [-40 * p, 0, 26 * p], head: [50 * p, 30 * p, 40 * p] };
        return { P, bob: 30 * p, lungeX: 8 * p, tilt: 10 * p, alpha: 1 - p };
      }
    },
    // v1.45 — MELMA CORROSIVA: un solo pezzo (blob) animato con SQUASH & STRETCH (sx/sy attorno alla base).
    // MOVIMENTO = STRISCIA (peristaltico, resta a terra, NIENTE salto). SALTO solo in ATTACCO (sputa acido).
    // Overlay: occhi che si illuminano nella DIREZIONE DI MOVIMENTO + aura/edge-glow verde + bolle acide.
    beholder: {  // profilo minimale: il render VIVO e' dedicato (_beholderPuppet); qui serve solo alla morte generica
      OY0: 0, K: 2.6, gait: 'float', eliteFilter: 'hue-rotate(-16deg) saturate(1.6) brightness(1.12)',
      order: ['body'],
      pose(t, moving, atk) { const S = _SIN; return { P: { body: [0, 0, 0] }, bob: 4 * S(t * 1.6), lungeX: 0, tilt: 0, sx: 1, sy: 1, swing: 0 }; },
      death(p) { return { P: { body: [0, 0, 0] }, bob: 0, lungeX: 0, tilt: 0, sx: 1 + 0.25 * p, sy: Math.max(0.05, 1 - 0.9 * p), alpha: 1 - p }; }
    },
    slime: {
      OY0: 700, K: 2.5, gait: 'crawl', eliteFilter: 'hue-rotate(-18deg) saturate(1.7) brightness(1.12)',
      order: ['body'],
      pose(t, moving, atk) {
        const S = _SIN, TAU = _TAU;
        const a = atk || 0, wind = _bump(a, 0.32, 0.28), strike = _bump(a, 0.66, 0.26);
        const P = { body: [0, 0, 0] };
        let bob = 0, lungeX = 0, sx = 1, sy = 1;
        if (moving) { // STRISCIA: onda peristaltica — si allunga in avanti poi si contrae, SEMPRE a terra (no hop)
          const ph = (t * 1.15) % 1, cr = S(TAU * ph);
          sx = 1 + 0.16 * cr;                 // si stira/contrae in orizzontale
          sy = 1 - 0.11 * cr;                 // resta basso e schiacciato
          bob = 1.5 * Math.abs(cr);           // pochissimo: NON salta
          lungeX = 6 * S(TAU * ph - 0.6);     // avanzamento pulsante (scivola)
        } else { // IDLE: gelatina che "respira" (jiggle morbido)
          const j = S(TAU * (t * 0.8));
          sx = 1 + 0.045 * j; sy = 1 - 0.045 * j; bob = 1.4 * S(TAU * (t * 0.8) + 1);
        }
        if (a > 0.001) { // ATTACCO: si comprime (carica) → SALTA in alto sputando l'acido (unico momento in cui si stacca da terra)
          sx += 0.22 * wind - 0.16 * strike;
          sy += -0.22 * wind + 0.30 * strike;   // si allunga verso l'alto nel salto
          bob += -34 * strike;                   // SALTO (solo in attacco)
          lungeX += 12 * strike;
        }
        return { P, bob, lungeX, tilt: 0, sx, sy, swing: Math.max(wind * 0.5, strike), moving: !!moving };
      },
      death(p) { // si scioglie: si appiattisce a terra e svanisce
        return { P: { body: [0, 0, 0] }, bob: 6 * p, lungeX: 0, tilt: 0, sx: 1 + 0.55 * p, sy: Math.max(0.05, 1 - 0.85 * p), alpha: 1 - p };
      }
    }
  };
  const R = {
    canvas: null, ctx: null, w: 0, h: 0, dpr: 1, cam: { x: 0, y: 0 }, shake: 0,
    particles: [], floaters: [], flashes: [], chains: [], swings: [], pare: [], atk: {}, levelUps: [], map: null, mapCanvas: null, minimapCanvas: null, mm: null, torches: [], campfires: [], theme: null, time: 0,
    torch: true, darkCv: null, darkCtx: null, darkScale: 0.5, darkness: 0.86, haloR: 260, dust: [], fog: [], critters: [],  // v1.17/1.23 — torcia + nebbia + animaletti (rune rimosse)
    mAtk: {}, deaths: [],  // v1.26 — animazioni di attacco (per eid) e di morte (sprite effimeri)
    init(canvas) { this.canvas = canvas; this.ctx = canvas.getContext('2d'); for (const k in PUPPETS) PUPPETS[k].load(); for (const k in SHEETS) SHEETS[k].load(); this.resize(); window.addEventListener('resize', () => this.resize()); try { this.torch = localStorage.getItem('dr_torcia') !== '0'; } catch (_) {} window.addEventListener('keydown', (e) => { if (document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return; if (e.code === 'KeyL') { this.torch = !this.torch; try { localStorage.setItem('dr_torcia', this.torch ? '1' : '0'); } catch (_) {} } }); },
    // v2.1.4 — LA TORCIA E' ACCESA DI SUA INIZIATIVA. Lo strato del tasto L c'era dalla v1.16 e il suo
    // valore predefinito era gia' 'acceso' — ma chi l'aveva spento anche una volta sola si ritrovava un
    // '0' salvato nel browser, e da li' in poi il gioco partiva senza. Con il campo visivo della v2.1 i
    // due strati insieme sono l'illuminazione giusta, quindi il vecchio '0' non deve piu' comandare: la
    // chiave e' cambiata nome (dr_torch -> dr_torcia). Chi aveva spento riparte acceso, una volta; il
    // tasto L continua a spegnere e ad accendere, e continua a ricordarselo. Cambiare nome alla chiave e'
    // il modo pulito di dare un valore predefinito nuovo senza buttare via la memoria della scelta.
    resize() { this.dpr = Math.min(2, window.devicePixelRatio || 1); this.w = innerWidth; this.h = innerHeight; this.canvas.width = this.w * this.dpr; this.canvas.height = this.h * this.dpr; this.canvas.style.width = this.w + 'px'; this.canvas.style.height = this.h + 'px'; this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); if (!this.darkCv) { this.darkCv = document.createElement('canvas'); this.darkCtx = this.darkCv.getContext('2d'); } this.darkCv.width = Math.max(1, Math.round(this.w * this.darkScale)); this.darkCv.height = Math.max(1, Math.round(this.h * this.darkScale)); },
    setMap(map) { this.map = map; this.theme = map.theme || {};
      // v2.21 — le grate aperte. Vive qui e non nello snapshot: sono uno o due oggetti per partita e
      // cambiano una volta sola. Si azzera con la mappa, se no la grata della mappa precedente
      // resterebbe aperta su quella nuova.
      this.grateAperte = new Set();
      this._bake(); this._bakeMinimap(); },
    // =====================================================================================
    // v1.76 — LA CAVERNA DIPINTA. Vale solo per le mappe di COMBATTIMENTO: il villaggio ha il suo
    // aspetto e resta com'e'.
    //
    // Le tre regole, misurate sulle battlemap disegnate invece che scelte a occhio:
    //   1. GERARCHIA DEL RUMORE. Il pavimento e' QUIETO (macchie morbide, crepe lunghe, nessun
    //      contorno), i muri sono RUMOROSI (massa scura, massi col contorno spesso, ombra proiettata
    //      dentro la stanza). Se pavimento e muri hanno la stessa grana l'occhio non capisce dove si
    //      cammina — l'ho sbagliato due volte prima di capirlo.
    //   2. LUMINOSITA'. Le battlemap dipinte hanno luminanza mediana 44. Il gioco stava a 18: era
    //      cosi' buio che non si vedeva niente di quello che c'era.
    //   3. DENSITA' DI CONTORNI. Nei riferimenti il 6,6% dei pixel e' un bordo forte; nel gioco
    //      l'1,3%. E' quella la differenza fra "disegnato" e "sfumato".
    //
    // Si cuoce UNA volta quando nasce la mappa, in una tela fuori schermo: a fotogramma e' un solo
    // drawImage, esattamente come prima.
    _bakeCaverna(g, m, T, th) {
      const W = m.w, H = m.h, PW = W * T, PH = H * T;
      let _s = ((m.seed >>> 0) || 1) ^ 0x9e3779b9;
      const rnd = () => (_s = (_s * 1664525 + 1013904223) >>> 0) / 4294967296;
      const rr = (a, b) => a + rnd() * (b - a), ri = (a, b) => Math.floor(rr(a, b + 1));
      // v1.97 — CIMITERO. Le lapidi e gli alberi secchi sono tessere-muro (cosi' collisioni, linea di
      // vista e campo di flusso funzionano senza sapere niente di loro), ma NON sono roccia: se la
      // cottura ci dipinge sopra la sua massa di pietra, il cimitero diventa una grotta con dei bozzi.
      // Qui valgono come suolo — la roccia non le tocca — e poi ci si dipinge sopra la lapide vera.
      const _mur = m.muri || null;
      // v2.21 — anche le tessere chiuse da una grata valgono come suolo: la saracinesca la disegna il
      // render a ogni fotogramma, e il giorno che la leva la apre sotto ci deve essere gia' il
      // pavimento cotto. Se le cuocessimo come roccia, aprire la grata scoprirebbe un buco nero.
      const _gr = new Set(); for (const q of (m.grate || [])) for (const t of q.tiles) _gr.add(t);
      const _leggero = (x, y) => { if (_gr.has(y * W + x)) return true; if (!_mur) return false; const t = _mur[y * W + x]; return t === 1 || t === 4; };
      const suolo = (x, y) => x >= 0 && y >= 0 && x < W && y < H && (m.grid[y * W + x] !== C.T_WALL || _leggero(x, y));
      const mix = (h1, h2, t) => { const a = this._hexToRgb(h1), b = this._hexToRgb(h2);
        return 'rgb(' + Math.round(a.r + (b.r - a.r) * t) + ',' + Math.round(a.g + (b.g - a.g) * t) + ',' + Math.round(a.b + (b.b - a.b) * t) + ')'; };
      // la palette esce dal TEMA, cosi' cripta, lava, ghiaccio, foresta e arcano restano diversi:
      // cambia il modo di disegnare, non l'identita' della mappa
      // v2.20.3 — IL CHIARO E LO SCURO VENGONO DAL TEMA. Erano due costanti uguali per tutte e cinque
      // le grotte, ed erano il motivo per cui si somigliavano: qualunque colore avesse il tema, la
      // pietra finiva sempre impastata verso lo stesso grigio-azzurro. I valori di prima restano come
      // ripiego — cosi' il villaggio, che non li porta, resta identico a com'era.
      const base = th.floorB || '#151a26', chiaro = th.chiaro || '#c9d2dc', scuro = th.scuro || '#0a0e14';
      const PAV = [mix(base, chiaro, .34), mix(base, chiaro, .28), mix(base, chiaro, .40), mix(base, chiaro, .23), mix(base, chiaro, .45)];
      const ROC = [mix(th.wall || '#1b2036', chiaro, .18), mix(th.wall || '#1b2036', chiaro, .12), mix(th.wallTop || '#262d4a', chiaro, .16)];
      const ROC_T = mix(th.wallTop || '#262d4a', chiaro, .34), ROC_S = mix(th.wall || '#1b2036', scuro, .45);
      const INK = mix(scuro, th.wall || '#1b2036', .18);
      const MUSCO = mix(th.accent || '#4d6b46', scuro, .35);
      const blob = (cx, cy, r, n, jit, ovalY) => { g.beginPath();
        for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2, rad = r * (1 - jit / 2 + rnd() * jit);
          const x = cx + Math.cos(a) * rad, y = cy + Math.sin(a) * rad * (ovalY || 1);
          i ? g.lineTo(x, y) : g.moveTo(x, y); } g.closePath(); };
      const inchiostro = (w) => { g.strokeStyle = INK; g.lineWidth = w; g.lineJoin = 'round'; g.stroke(); };

      // ---- 1. PAVIMENTO, quieto. Si cuoce a parte e si ritaglia sul calpestabile.
      const pav = document.createElement('canvas'); pav.width = PW; pav.height = PH;
      const p = pav.getContext('2d');
      p.fillStyle = PAV[0]; p.fillRect(0, 0, PW, PH);
      const nMac = Math.round(PW * PH / 1750);
      for (let i = 0; i < nMac; i++) { const x = rr(0, PW), y = rr(0, PH), r = rr(34, 150);
        const gr = p.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, PAV[(rnd() * PAV.length) | 0]); gr.addColorStop(1, 'rgba(0,0,0,0)');
        p.globalAlpha = rr(.05, .15); p.fillStyle = gr; p.beginPath(); p.arc(x, y, r, 0, 7); p.fill(); }
      p.globalAlpha = 1; p.lineCap = 'round';
      // crepe: poche, lunghe, sottili. Sono il dettaglio, non il rumore.
      for (let k = 0, nk = Math.round(PW * PH / 82000); k < nk; k++) {
        let x = rr(0, PW), y = rr(0, PH), a = rr(0, 6.28);
        p.strokeStyle = 'rgba(18,24,30,' + rr(.22, .46).toFixed(3) + ')'; p.lineWidth = rr(1.2, 3.2);
        p.beginPath(); p.moveTo(x, y);
        for (let i = 0; i < 16; i++) { a += rr(-.5, .5); x += Math.cos(a) * rr(16, 38); y += Math.sin(a) * rr(16, 38); p.lineTo(x, y); }
        p.stroke(); }
      // giunti di lastrone appena accennati: danno la scala senza fare reticolo
      for (let k = 0, nk = Math.round(PW * PH / 150000); k < nk; k++) {
        let x = rr(0, PW), y = rr(0, PH), a = (ri(0, 1) ? 0 : 1.5708) + rr(-.12, .12);
        p.strokeStyle = 'rgba(26,34,42,.26)'; p.lineWidth = rr(2, 4.5);
        p.beginPath(); p.moveTo(x, y);
        for (let i = 0; i < 6; i++) { a += rr(-.13, .13); x += Math.cos(a) * rr(44, 100); y += Math.sin(a) * rr(44, 100); p.lineTo(x, y); }
        p.stroke(); }
      // terra battuta attorno alle camere: e' quella che disegna i passaggi consumati
      for (const c of (m.camere || [])) { const cx = c.x * T, cy = c.y * T;
        for (let i = 0; i < 40; i++) { const x = cx + rr(-240, 240), y = cy + rr(-175, 175), r = rr(45, 115);
          const gr = p.createRadialGradient(x, y, 0, x, y, r);
          gr.addColorStop(0, mix(base, '#8a7a58', .55)); gr.addColorStop(1, 'rgba(0,0,0,0)');
          p.globalAlpha = rr(.07, .18); p.fillStyle = gr; p.beginPath(); p.arc(x, y, r, 0, 7); p.fill(); } }
      p.globalAlpha = 1;
      g.save(); g.beginPath();
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (suolo(x, y)) g.rect(x*T - 6, y*T - 6, T + 12, T + 12);
      g.clip(); g.drawImage(pav, 0, 0); g.restore();

      // ---- 2. MURI, rumorosi.
      const bordo = [];
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { if (suolo(x, y)) continue;
        for (const d of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]])
          if (suolo(x + d[0], y + d[1])) { bordo.push([x, y]); break; } }
      // 2a — l'ombra che la parete getta DENTRO la stanza: e' quella che da' l'altezza alla roccia
      for (let k = 0; k < bordo.length; k++) { const cx = bordo[k][0]*T + T/2, cy = bordo[k][1]*T + T/2;
        const gr = g.createRadialGradient(cx, cy + 16, 6, cx, cy + 16, T * 1.6);
        gr.addColorStop(0, 'rgba(4,7,11,.8)'); gr.addColorStop(1, 'rgba(4,7,11,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(cx, cy + 16, T * 1.6, 0, 7); g.fill(); }
      // 2b — la massa, quasi nera: e' cosi' che la caverna si stacca di netto dal fondo
      g.fillStyle = mix(th.wall || '#1b2036', scuro, .55);
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (!suolo(x, y)) g.fillRect(x*T - 1, y*T - 1, T + 2, T + 2);
      // 2c — i massi, SOLO sul bordo, in ordine di profondita' cosi' quelli davanti coprono i dietro
      const massi = [];
      for (let k = 0; k < bordo.length; k++) for (let q = 0; q < 3; q++)
        massi.push({ x: bordo[k][0]*T + T/2 + rr(-19, 19), y: bordo[k][1]*T + T/2 + rr(-19, 19), r: rr(22, 42) });
      massi.sort((a, b) => a.y - b.y);
      for (const mm of massi) {
        g.fillStyle = 'rgba(6,10,14,.5)'; g.beginPath();
        g.ellipse(mm.x + 6, mm.y + mm.r * .5, mm.r, mm.r * .42, 0, 0, 7); g.fill();
        blob(mm.x, mm.y, mm.r, 10, .3, .84); g.fillStyle = ROC[(rnd() * ROC.length) | 0]; g.fill(); inchiostro(3.2);
        blob(mm.x - mm.r*.14, mm.y - mm.r*.26, mm.r*.6, 9, .34, .76);
        g.fillStyle = ROC_T; g.globalAlpha = .5; g.fill(); g.globalAlpha = 1;
        g.strokeStyle = ROC_S; g.lineWidth = 2.2;
        for (let k = 0; k < 2; k++) { g.beginPath();
          let px = mm.x + rr(-mm.r*.6, mm.r*.6), py = mm.y - mm.r*.55;
          g.moveTo(px, py); for (let i = 0; i < 3; i++) { px += rr(-11, 11); py += rr(8, 18); g.lineTo(px, py); } g.stroke(); }
        if (rnd() < .3) { blob(mm.x + rr(-mm.r*.5, mm.r*.5), mm.y - mm.r*.5, rr(7, 14), 8, .5, .7);
          g.fillStyle = MUSCO; g.globalAlpha = .45; g.fill(); g.globalAlpha = 1; }
      }

      // ---- 3. IL PIETRISCO. Senza, il pavimento resta un piazzale: misurato, la densita' di
      // contorni si ferma al 3,5% contro il 6,6% delle battlemap disegnate. Sono massi, macerie e
      // ossa sparse, e valgono la regola gia' pagata sui pilastri del villaggio: un oggetto
      // appoggiato per terra dev'essere PIU' CHIARO del pavimento, se no dall'alto e' una buca.
      const OGG = [mix(base, chiaro, .52), mix(base, chiaro, .46), mix(base, chiaro, .58)];
      const OGG_T = mix(base, chiaro, .70), OGG_S = mix(base, scuro, .30), OSSO = mix(chiaro, '#e8e2c8', .6);
      const masso = (gx, gy, r) => {
        g.fillStyle = 'rgba(8,12,16,.42)'; g.beginPath();
        g.ellipse(gx + 4, gy + r * .5, r, r * .4, 0, 0, 7); g.fill();
        blob(gx, gy, r, 9, .34, .82); g.fillStyle = OGG[(rnd() * OGG.length) | 0]; g.fill(); inchiostro(2.4);
        blob(gx - r*.16, gy - r*.24, r*.55, 8, .36, .74);
        g.fillStyle = OGG_T; g.globalAlpha = .42; g.fill(); g.globalAlpha = 1;
        // la crepa va misurata SUL SASSO: a passo fisso usciva dal contorno e ogni pietra si
        // ritrovava un antenna attaccata. Solo sui massi abbastanza grandi da mostrarla.
        if (r > 9) { g.strokeStyle = OGG_S; g.lineWidth = 1.6; g.beginPath();
          let px2 = gx + rr(-r*.35, r*.35), py2 = gy - r*.5;
          g.moveTo(px2, py2);
          for (let i = 0; i < 3; i++) { px2 += rr(-r*.22, r*.22); py2 += r * .33; g.lineTo(px2, py2); }
          g.stroke(); }
      };
      // dove si puo' appoggiare: serve il 3x3 libero, cosi' niente pietrisco a meta' dentro la roccia
      const posabile = (wx, wy) => { const tx = (wx / T) | 0, ty = (wy / T) | 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (!suolo(tx + dx, ty + dy)) return false;
        return true; };
      const occ = [];
      const posto = (distMin) => { for (let k = 0; k < 60; k++) {
          const wx = rr(T * 2, PW - T * 2), wy = rr(T * 2, PH - T * 2);
          if (!posabile(wx, wy)) continue;
          let male = false;
          for (const o of occ) if (Math.hypot(wx - o[0], wy - o[1]) < distMin) { male = true; break; }
          if (male) continue;
          occ.push([wx, wy]); return [wx, wy]; }
        return null; };
      const K = PW * PH / (1400 * 1000);
      const quanti = (n) => Math.round(n * K);
      // massi singoli, sparsi
      for (let i = 0; i < quanti(15); i++) { const q = posto(95); if (q) masso(q[0], q[1], rr(7, 17)); }
      // grappoli di macerie
      for (let i = 0; i < quanti(7); i++) { const q = posto(210); if (!q) continue;
        for (let k = 0, n = ri(4, 8); k < n; k++) masso(q[0] + rr(-40, 40), q[1] + rr(-30, 30), rr(6, 15)); }
      // ossa: il contrasto chiaro che rompe il grigio
      for (let i = 0; i < quanti(6); i++) { const q = posto(230); if (!q) continue;
        for (let k = 0, n = ri(2, 5); k < n; k++) {
          g.save(); g.translate(q[0] + rr(-38, 38), q[1] + rr(-28, 28)); g.rotate(rr(0, 6.28));
          g.fillStyle = OSSO; g.strokeStyle = INK; g.lineWidth = 1.9;
          g.beginPath(); g.roundRect(-8, -2, 16, 4, 2); g.fill(); g.stroke();
          g.beginPath(); g.arc(-8,-1.8,2.3,0,7); g.arc(-8,1.8,2.3,0,7); g.arc(8,-1.8,2.3,0,7); g.arc(8,1.8,2.3,0,7);
          g.fill(); g.stroke(); g.restore(); } }
      // chiazze scure: sporco, muffa, bruciato. Non hanno contorno: sono pavimento, non oggetti.
      for (let i = 0; i < quanti(11); i++) { const wx = rr(T, PW - T), wy = rr(T, PH - T);
        if (!posabile(wx, wy)) continue;
        blob(wx, wy, rr(30, 62), 11, .4, .68); g.fillStyle = 'rgba(20,26,24,.24)'; g.fill(); }
    },
    // v1.97 — LE LAPIDI, GLI ALBERI SECCHI E LA PIETRA SQUADRATA del cimitero. Si dipinge DOPO la
    // cottura della caverna, sulla stessa tela fuori schermo: costa una volta per mappa, zero a
    // fotogramma. La tecnica e' quella di casa — massa scura, corpo, luce dall'alto a sinistra, poi
    // pochi bordi netti — perche' un cimitero disegnato a poligoni piatti stonerebbe con tutto il resto.
    _dipingiCimitero(g, m, T, th) {
      const mur = m.muri; if (!mur) return;
      const W = m.w, H = m.h;
      let _s = ((m.seed >>> 0) || 7) ^ 0x85ebca6b;
      const rnd = () => (_s = (_s * 1664525 + 1013904223) >>> 0) / 4294967296;
      const rr = (a, b) => a + rnd() * (b - a);
      const mix = (h1, h2, t) => { const a = this._hexToRgb(h1), b = this._hexToRgb(h2);
        return 'rgb(' + Math.round(a.r + (b.r - a.r) * t) + ',' + Math.round(a.g + (b.g - a.g) * t) + ',' + Math.round(a.b + (b.b - a.b) * t) + ')'; };
      const chiaro = '#c9d2dc', scuro = '#0a0e14';
      const PIETRA = mix(th.wallTop || '#262d4a', chiaro, .40);
      const PIETRA_S = mix(th.wall || '#1b2036', scuro, .30);
      const PIETRA_L = mix(th.wallTop || '#262d4a', chiaro, .62);
      const INK = mix(scuro, th.wall || '#1b2036', .18);
      const LEGNO = mix('#3a2c22', chiaro, .18), LEGNO_L = mix('#3a2c22', chiaro, .42);
      const MUSCO = mix(th.accent || '#4d6b46', scuro, .42);

      // (1) LE LAPIDI. Una tessera ciascuna, un po' storte, tre sagome diverse: stele arrotondata,
      //     croce, lastra spezzata. L'ombra cade sempre dallo stesso lato — e' quella a farle "stare in
      //     piedi" invece che sembrare disegnate sul pavimento.
      const lapide = (px, py) => {
        const cx = px + T / 2 + rr(-4, 4), cy = py + T / 2 + rr(-3, 3);
        const w = T * rr(0.40, 0.52), h = T * rr(0.52, 0.68);
        const rot = rr(-0.16, 0.16);
        const forma = rnd();
        g.save(); g.translate(cx, cy); g.rotate(rot);
        g.fillStyle = 'rgba(0,0,0,.42)';                     // l'ombra, prima di tutto
        g.beginPath(); g.ellipse(w * 0.22, h * 0.42, w * 0.62, h * 0.24, 0, 0, 6.29); g.fill();
        g.fillStyle = PIETRA; g.strokeStyle = INK; g.lineWidth = 2.1; g.lineJoin = 'round';
        g.beginPath();
        if (forma < 0.62) {                                   // stele: spalle tonde
          g.moveTo(-w / 2, h / 2); g.lineTo(-w / 2, -h * 0.18);
          g.quadraticCurveTo(-w / 2, -h / 2, 0, -h / 2);
          g.quadraticCurveTo(w / 2, -h / 2, w / 2, -h * 0.18);
          g.lineTo(w / 2, h / 2); g.closePath();
        } else if (forma < 0.85) {                            // croce
          const b = w * 0.30, br = w * 0.52, ay = -h * 0.06;
          g.moveTo(-b, h / 2); g.lineTo(-b, ay + b); g.lineTo(-br, ay + b); g.lineTo(-br, ay - b * 0.5);
          g.lineTo(-b, ay - b * 0.5); g.lineTo(-b, -h / 2); g.lineTo(b, -h / 2); g.lineTo(b, ay - b * 0.5);
          g.lineTo(br, ay - b * 0.5); g.lineTo(br, ay + b); g.lineTo(b, ay + b); g.lineTo(b, h / 2); g.closePath();
        } else {                                              // lastra spezzata: manca un angolo
          g.moveTo(-w / 2, h / 2); g.lineTo(-w / 2, -h * 0.38); g.lineTo(w * 0.10, -h / 2);
          g.lineTo(w / 2, -h * 0.10); g.lineTo(w / 2, h / 2); g.closePath();
        }
        g.fill(); g.stroke();
        g.fillStyle = PIETRA_L;                               // la luce sul bordo sinistro
        g.fillRect(-w / 2 + 2, -h * 0.30, w * 0.16, h * 0.72);
        g.fillStyle = PIETRA_S;                               // e l'ombra propria a destra
        g.fillRect(w / 2 - w * 0.20, -h * 0.24, w * 0.16, h * 0.70);
        if (rnd() < 0.45) { g.fillStyle = MUSCO; g.globalAlpha = 0.5;   // muschio alla base
          g.beginPath(); g.ellipse(rr(-w * 0.2, w * 0.2), h * 0.36, w * 0.3, h * 0.10, 0, 0, 6.29); g.fill(); g.globalAlpha = 1; }
        g.restore();
      };

      // (2) GLI ALBERI SECCHI: due o tre rami storti che partono da un tronco. Niente foglie — quelle
      //     coprirebbero il gioco, e un cimitero d'inverno e' piu' credibile.
      const albero = (px, py) => {
        const cx = px + T / 2, cy = py + T / 2;
        g.save(); g.translate(cx, cy);
        g.fillStyle = 'rgba(0,0,0,.38)';
        g.beginPath(); g.ellipse(4, 6, T * 0.34, T * 0.16, 0, 0, 6.29); g.fill();
        g.strokeStyle = INK; g.lineCap = 'round'; g.lineJoin = 'round';
        g.lineWidth = T * 0.20; g.beginPath(); g.moveTo(0, T * 0.30); g.lineTo(rr(-3, 3), -T * 0.10); g.stroke();
        g.strokeStyle = LEGNO; g.lineWidth = T * 0.13;
        g.beginPath(); g.moveTo(0, T * 0.30); g.lineTo(rr(-3, 3), -T * 0.10); g.stroke();
        for (let k = 0, n = 2 + (rnd() < 0.5 ? 1 : 0); k < n; k++) {
          const a = -1.9 + rr(-0.7, 0.7) + k * 1.2, L = T * rr(0.22, 0.36);
          g.strokeStyle = INK; g.lineWidth = T * 0.11;
          g.beginPath(); g.moveTo(0, -T * 0.06); g.lineTo(Math.cos(a) * L, -T * 0.06 + Math.sin(a) * L); g.stroke();
          g.strokeStyle = LEGNO_L; g.lineWidth = T * 0.06;
          g.beginPath(); g.moveTo(0, -T * 0.06); g.lineTo(Math.cos(a) * L, -T * 0.06 + Math.sin(a) * L); g.stroke();
        }
        g.restore();
      };

      // (3) LA PIETRA SQUADRATA: mausolei, cappelle, muro di cinta. Sopra la roccia gia' cotta si
      //     disegnano i CONCI — e' il solo modo di distinguere un muro costruito da una parete di grotta.
      const concio = (px, py, x, y) => {
        const dentro = (dx, dy) => { const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= W || ny >= H) return true;
          return m.grid[ny * W + nx] === C.T_WALL; };
        g.save(); g.beginPath(); g.rect(px, py, T, T); g.clip();
        g.fillStyle = PIETRA_S; g.fillRect(px, py, T, T);
        const rows = 2, hh = T / rows;
        for (let r = 0; r < rows; r++) {
          const off = ((y * rows + r) % 2) * (T * 0.25);
          for (let bx = -1; bx <= 2; bx++) {
            const X = px + off + bx * (T * 0.5), Y = py + r * hh;
            g.fillStyle = mix(PIETRA, PIETRA_S, rnd() * 0.55);
            g.fillRect(X + 1.2, Y + 1.2, T * 0.5 - 2.4, hh - 2.4);
            g.fillStyle = 'rgba(255,255,255,.06)';
            g.fillRect(X + 1.2, Y + 1.2, T * 0.5 - 2.4, 2);
          }
        }
        if (!dentro(0, -1)) { g.fillStyle = PIETRA_L; g.fillRect(px, py, T, 3); }      // la faccia in luce
        if (!dentro(0, 1)) { g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(px, py + T - 3, T, 3); }
        g.strokeStyle = INK; g.lineWidth = 1.6; g.strokeRect(px + 0.8, py + 0.8, T - 1.6, T - 1.6);
        g.restore();
      };

      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x, t = mur[i];
        if (!t) continue;
        if (m.grid[i] !== C.T_WALL && t !== 1 && t !== 4) continue;   // demolita da allargaPerBoss: non c'e' piu'
        if (m.grid[i] !== C.T_WALL) continue;
        const px = x * T, py = y * T;
        if (t === 1) lapide(px, py);
        else if (t === 4) albero(px, py);
        else concio(px, py, x, y);
      }
    },
    _bake() {
      const m = this.map; if (!m) return; const T = m.tile; const th = this.theme || {};
      const fA = th.floorA || '#12161f', fB = th.floorB || '#151a26', wl = th.wall || '#1b2036', wt = th.wallTop || '#262d4a', hz = th.hazard || '#ff5a1e', tint = th.tint || 'rgba(60,90,60,.15)';
      const cv = document.createElement('canvas'); cv.width = m.w * T; cv.height = m.h * T; const g = cv.getContext('2d');
      g.fillStyle = '#0a0c14'; g.fillRect(0, 0, cv.width, cv.height);
      // v1.18 — CAVERNA organica: pavimento "terra" + muri "roccia" (niente griglia), pozze uniche con profondità
      const HSH = (x, y) => { let h = (x * 374761393 + y * 668265263) >>> 0; h = (h ^ (h >> 13)) >>> 0; return (h % 1000) / 1000; };
      const gt = (gx, gy) => (gx < 0 || gy < 0 || gx >= m.w || gy >= m.h) ? C.T_WALL : m.grid[gy * m.w + gx];
      this.hazards = [];
      // STEP A — v1.19 TEXTURE ROCCIA: pavimento e muri con roccia realistica (bump + domain-warp), colorata sul tema
      const seedBase = (m.seed >>> 0) || 1;
      const floorTex = _rockTile(seedBase + 101, 192, fB, { scale: 0.055, warp: 26, bump: 3.4, cell: 96, moss: true });
      const wlDark = _darkenHex(wl, 0.15); // v1.23 — muri quasi neri (contrasto forte col pavimento)
      const wallTex = _rockTile(seedBase + 202, 192, wlDark, { scale: 0.05, warp: 30, bump: 4.0, cell: 110, moss: false });
      const floorPat = g.createPattern(floorTex, 'repeat'), wallPat = g.createPattern(wallTex, 'repeat');
      // pavimento ovunque (sotto ai muri), poi roccia-muro sopra le celle muro
      // v1.76 — le mappe di COMBATTIMENTO passano dalla cottura nuova (caverna dipinta). Il
      // villaggio (m.market) teneva la sua, piatta: un motivo di roccia ripetuto sotto tutto e un
      // rettangolo di pietra sopra ogni tessera-muro.
      // v2.6 — ADESSO CI PASSA ANCHE IL VILLAGGIO, ed e' questa la riga che ha tolto la patina. Il
      // paese e' scavato nella stessa roccia delle grotte, quindi va cotto allo stesso modo: pavimento
      // di grotta, massi tondi, ombre proiettate vere. La cottura piatta non era solo un'altra grafica —
      // era una tinta uniforme senza nero e senza contrasto, ed e' esattamente quello che si vedeva come
      // pellicola. I pavimenti delle stanze si dipingono sopra come sempre, quindi dentro le case non
      // cambia niente: le assi restano assi.
      const _nuova = true;
      if (_nuova) this._bakeCaverna(g, m, T, th);
      else { g.fillStyle = floorPat; g.fillRect(0, 0, cv.width, cv.height); }
      // v1.97.1 — QUESTA RIGA VA DOPO L'ELSE, e la prima volta l'avevo messa in mezzo: l'else di
      // _bakeCaverna e' finito attaccato a lei, quindi su OGNI mappa senza cimitero (dalla terza ondata
      // in poi) scattava il riempimento piatto e cancellava la caverna appena cotta.
      if (_nuova && m.muri) this._dipingiCimitero(g, m, T, th);   // lapidi, alberi secchi, conci
      if (!_nuova) for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) { if (m.grid[y * m.w + x] !== C.T_WALL) continue; const px = x * T, py = y * T; g.save(); g.beginPath(); g.rect(px, py, T, T); g.clip(); g.fillStyle = wallPat; g.fillRect(px, py, T, T); g.restore(); }
      // v1.75 — IL PAVIMENTO DI OGNI STANZA. Il villaggio non e' piu' una sala sola: la taverna ha le assi,
      // la fucina la pietra bruciata, l'antro il suo colore. Senza questo le sei stanze sarebbero sei
      // scatole con lo stesso fondo, e la pianta non si leggerebbe.
      for (const f of (m.floors || [])) {
        // v2.6 — LA TERRA NON HA IL BORDO DRITTO. Il primo battuto era un rettangolo pieno, e da lassu'
        // si leggeva come un tappeto srotolato sulla roccia: una piazza si consuma dove ci si cammina,
        // quindi il bordo va SFRANGIATO e un po' di terra va anche oltre. Qui si allarga il giro di una
        // tessera e si copre in modo irregolare: piena dentro, a chiazze sull'orlo, qualche macchia fuori.
        const terra = f.kind === 'terra';
        const y0 = f.y0 - (terra ? 1 : 0), y1 = f.y1 + (terra ? 1 : 0);
        const x0 = f.x0 - (terra ? 1 : 0), x1 = f.x1 + (terra ? 1 : 0);
        for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
          if (x < 0 || y < 0 || x >= m.w || y >= m.h) continue;
          if (m.grid[y * m.w + x] === C.T_WALL) continue;
          const px = x * T, py = y * T;
          if (terra) {
            // quanto e' lontano dal bordo: 0 fuori, 1 sull'orlo, 2 dentro
            const d = Math.min(x - f.x0, f.x1 - x, y - f.y0, f.y1 - y);
            const hb = (a) => { let v = (px * 40503 ^ py * 12289 ^ a * 6151) >>> 0; v = (v ^ (v >>> 11)) >>> 0; return (v % 1000) / 1000; };
            g.save(); g.beginPath();
            if (d >= 1) { g.rect(px, py, T, T); }
            else {
              // sull'orlo (d===0) e fuori (d<0) si copre a chiazze, sempre meno mano a mano che si esce
              const n = d === 0 ? 5 : 2, sc = d === 0 ? 0.42 : 0.24;
              for (let i = 0; i < n; i++) { const cx2 = px + hb(i * 3 + 1) * T, cy2 = py + hb(i * 3 + 2) * T;
                g.moveTo(cx2 + T * sc, cy2); g.arc(cx2, cy2, T * sc * (0.6 + hb(i * 3 + 3) * 0.7), 0, 7); }
            }
            g.clip();
            g.fillStyle = f.col; g.fillRect(px, py, T, T);
          } else {
            g.fillStyle = f.col; g.fillRect(px, py, T, T);
          }
          if (f.kind === 'lastre') {  // lastroni squadrati: la piazza e le stanze in pietra
            g.strokeStyle = 'rgba(0,0,0,.24)'; g.lineWidth = 1.4; g.strokeRect(px + 1.5, py + 1.5, T - 3, T - 3);
            g.strokeStyle = 'rgba(255,255,255,.05)'; g.lineWidth = 1; g.strokeRect(px + 2.5, py + 2.5, T - 5, T - 5);
          } else if (f.kind === 'terra') {
            // v2.6 — TERRA BATTUTA VERA. Prima erano dieci trattini scuri su una tinta al 58%: sotto la
            // luce della piazza quella tinta diventava una lastra di grigio uniforme, ed e' la stessa
            // cosa che chiamavamo patina — manca il NERO. Il battuto ha bisogno di tre cose: chiazze piu'
            // scure (la terra non e' omogenea), ghiaia (punti chiari e punti scuri, non solo scuri) e un
            // solco ogni tanto. Costa una volta sola, in cottura.
            const hs = (a, b) => { let v = (px * 73856093 ^ py * 19349663 ^ a * 83492791 ^ b * 2654435761) >>> 0;
              v = (v ^ (v >>> 13)) >>> 0; return (v % 10000) / 10000; };
            for (let i = 0; i < 3; i++) {                       // le chiazze
              const cx2 = px + hs(i, 1) * T, cy2 = py + hs(i, 2) * T, rr2 = T * (0.16 + hs(i, 3) * 0.24);
              g.fillStyle = 'rgba(0,0,0,' + (0.07 + hs(i, 4) * 0.10).toFixed(3) + ')';
              g.beginPath(); g.ellipse(cx2, cy2, rr2, rr2 * 0.72, hs(i, 5) * 3, 0, 7); g.fill();
            }
            for (let i = 0; i < 16; i++) {                      // la ghiaia: chiara E scura, se no e' fuliggine
              const gx = px + hs(i, 6) * T, gy = py + hs(i, 7) * T, gr2 = 0.9 + hs(i, 8) * 1.5;
              g.fillStyle = hs(i, 9) > 0.55 ? 'rgba(214,198,170,.22)' : 'rgba(0,0,0,.30)';
              g.beginPath(); g.arc(gx, gy, gr2, 0, 7); g.fill();
            }
            if (hs(0, 11) > 0.62) {                             // e ogni tanto un solco
              g.strokeStyle = 'rgba(0,0,0,.20)'; g.lineWidth = 2.2;
              g.beginPath(); g.moveTo(px, py + hs(0, 12) * T); g.lineTo(px + T, py + hs(0, 13) * T); g.stroke();
            }
          }
          if (terra) g.restore();   // il ritaglio della frangia vale per la tessera, non per tutta la cottura
        }
        // il LEGNO va disegnato sulla stanza intera, non tile per tile: assi lunghe che l'attraversano,
        // con le giunzioni sfalsate. Fatto a mattoncini sembrava un muro appoggiato per terra.
        if (f.kind === 'legno') {
          const X0 = f.x0 * T, Y0 = f.y0 * T, W = (f.x1 - f.x0 + 1) * T, H = (f.y1 - f.y0 + 1) * T;
          g.save(); g.beginPath();
          for (let y = f.y0; y <= f.y1; y++) for (let x = f.x0; x <= f.x1; x++)
            if (m.grid[y * m.w + x] !== C.T_WALL) g.rect(x * T, y * T, T, T);
          g.clip();
          const asse = T * 0.62;
          for (let yy = Y0; yy < Y0 + H; yy += asse) {
            g.fillStyle = ((yy / asse) | 0) % 2 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.05)';
            g.fillRect(X0, yy, W, asse);
            g.strokeStyle = 'rgba(0,0,0,.34)'; g.lineWidth = 1.6;
            g.beginPath(); g.moveTo(X0, yy); g.lineTo(X0 + W, yy); g.stroke();
            g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = 1;
            g.beginPath(); g.moveTo(X0, yy + 1.6); g.lineTo(X0 + W, yy + 1.6); g.stroke();
            const off = (((yy / asse) | 0) % 3) * T * 1.1;
            g.strokeStyle = 'rgba(0,0,0,.30)'; g.lineWidth = 1.4;
            for (let jx = X0 + off; jx < X0 + W; jx += T * 3.2) { g.beginPath(); g.moveTo(jx, yy); g.lineTo(jx, yy + asse); g.stroke(); }
          }
          g.restore();
        }
      }

      // v1.76 — STEP C e C2 sono allineati alla TESSERA: sopra i massi tondi della caverna dipinta
      // uscivano come rettangoli chiari incollati alla roccia. La cottura nuova fa gia' la sua ombra
      // proiettata e la sua faccia in luce, quindi per le mappe di combattimento si saltano.
      if (!_nuova) {
      // STEP C — v1.22 OMBRA MARCATA muro→pavimento: drop-shadow forte + linea di contatto scura = stacco netto
      for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
        if (m.grid[y * m.w + x] === C.T_WALL) continue; const px = x * T, py = y * T;
        if (gt(x, y - 1) === C.T_WALL) { const gr = g.createLinearGradient(0, py, 0, py + T * 0.62); gr.addColorStop(0, 'rgba(0,0,0,.86)'); gr.addColorStop(0.4, 'rgba(0,0,0,.42)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(px, py, T, T * 0.62); g.fillStyle = 'rgba(0,0,0,.9)'; g.fillRect(px, py, T, 3); }
        if (gt(x, y + 1) === C.T_WALL) { const gr = g.createLinearGradient(0, py + T, 0, py + T * 0.55); gr.addColorStop(0, 'rgba(0,0,0,.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(px, py + T * 0.55, T, T * 0.45); g.fillStyle = 'rgba(0,0,0,.8)'; g.fillRect(px, py + T - 3, T, 3); }
        if (gt(x - 1, y) === C.T_WALL) { const gr = g.createLinearGradient(px, 0, px + T * 0.55, 0); gr.addColorStop(0, 'rgba(0,0,0,.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(px, py, T * 0.55, T); g.fillStyle = 'rgba(0,0,0,.8)'; g.fillRect(px, py, 3, T); }
        if (gt(x + 1, y) === C.T_WALL) { const gr = g.createLinearGradient(px + T, 0, px + T * 0.45, 0); gr.addColorStop(0, 'rgba(0,0,0,.7)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(px + T * 0.45, py, T * 0.55, T); g.fillStyle = 'rgba(0,0,0,.8)'; g.fillRect(px + T - 3, py, 3, T); }
      }
      // STEP C2 — cresta illuminata in cima ai muri esposti
      for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) { if (m.grid[y * m.w + x] !== C.T_WALL) continue; if (gt(x, y - 1) !== C.T_WALL) { const px = x * T, py = y * T; const gr = g.createLinearGradient(0, py, 0, py + T * 0.6); gr.addColorStop(0, 'rgba(255,255,255,.10)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(px, py, T, T * 0.6); } }
      // v1.23 — DETTAGLI TERRENO: rocce, ciottoli, buche/crateri (pavimento meno piatto, non bloccanti)
      // v1.56 — nel VILLAGGIO restano solo i ciottoli: massi, buche e crepe facevano sembrare la piazza
      // un crollo, non un posto dove qualcuno vive e vende.
      const village = !!m.market;
      for (let y = 2; y < m.h - 2; y++) for (let x = 2; x < m.w - 2; x++) {
        if (m.grid[y * m.w + x] !== C.T_FLOOR) continue; const px = x * T, py = y * T;
        const r1 = HSH(x * 5 + 1, y * 7 + 2), r2 = HSH(x * 3 + 9, y * 11 + 4), r3 = HSH(x * 13 + 5, y * 2 + 7);
        const cx = px + T * (0.22 + r1 * 0.56), cy = py + T * (0.22 + r2 * 0.56);
        if (r3 < 0.11 && !village) { // masso / roccia
          const ss = 5 + r1 * 6; const gr = g.createLinearGradient(cx, cy - ss, cx, cy + ss); gr.addColorStop(0, '#474d5a'); gr.addColorStop(1, '#232935'); 
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(cx, cy + ss * 0.85, ss * 0.95, ss * 0.4, 0, 0, 7); g.fill();
          g.fillStyle = gr; g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(cx - ss, cy + ss * 0.4); g.lineTo(cx - ss * 0.4, cy - ss); g.lineTo(cx + ss * 0.6, cy - ss * 0.6); g.lineTo(cx + ss, cy + ss * 0.3); g.lineTo(cx + ss * 0.2, cy + ss); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1; g.beginPath(); g.moveTo(cx - ss * 0.4, cy - ss); g.lineTo(cx - ss * 0.5, cy + ss * 0.6); g.stroke();
        } else if (r3 < 0.22 && !village) { // buca / cratere
          const ss = 6 + r2 * 7; g.fillStyle = 'rgba(0,0,0,.5)'; g.beginPath(); g.ellipse(cx, cy, ss, ss * 0.72, 0, 0, 7); g.fill();
          const ig = g.createRadialGradient(cx, cy - 1, 1, cx, cy, ss); ig.addColorStop(0, 'rgba(0,0,0,.55)'); ig.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = ig; g.beginPath(); g.ellipse(cx, cy, ss, ss * 0.72, 0, 0, 7); g.fill();
          g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1; g.beginPath(); g.ellipse(cx, cy - 1.5, ss * 0.92, ss * 0.62, 0, Math.PI, 0); g.stroke();
        } else if (r3 < 0.48) { // ciottoli sparsi
          g.fillStyle = r1 > 0.5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.22)'; for (let k = 0; k < 3; k++) { const a = r1 * 6.28 + k * 2.1; g.beginPath(); g.arc(cx + Math.cos(a) * 6, cy + Math.sin(a) * 6, 1.3 + r2 * 1.4, 0, 7); g.fill(); }
        }
      }
      // v1.23 — 2-3 CREPE grandi (fissure profonde, non luminose): molto piu lunghe e larghe delle vecchie
      if (!village) { const sc0 = (m.seed >>> 0) || 1; const rr = (n) => { let z = (sc0 + n * 99991) >>> 0; z = ((z ^ (z >> 13)) * 1274126177) >>> 0; return (z >>> 0) / 4294967296; };
        const nCr = 2 + (rr(0) < 0.5 ? 1 : 0); let made = 0, tries = 0;
        while (made < nCr && tries < 160) { tries++;
          const gx = 3 + ((rr(tries * 3) * (m.w - 6)) | 0), gy = 3 + ((rr(tries * 3 + 1) * (m.h - 6)) | 0);
          if (m.grid[gy * m.w + gx] !== C.T_FLOOR) continue;
          let x = gx * T + T / 2, y = gy * T + T / 2, a = rr(tries + 7) * 6.28; const len = 5.5 + rr(tries + 9) * 0.6; const seg = 26; const pts = [];
          for (let i = 0; i < seg; i++) { pts.push([x, y]); a += (rr(tries * seg + i) - 0.5) * 0.5; x += Math.cos(a) * (len * T / seg); y += Math.sin(a) * (len * T / seg); const cgx = (x / T) | 0, cgy = (y / T) | 0; if (cgx < 1 || cgy < 1 || cgx >= m.w - 1 || cgy >= m.h - 1 || m.grid[cgy * m.w + cgx] === C.T_WALL) break; }
          if (pts.length < 9) continue;
          g.lineCap = 'round'; g.lineJoin = 'round';
          g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 6; g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.9)'; g.lineWidth = 3; g.stroke();
          for (let i = 5; i < pts.length - 2; i += 6) { const bx = pts[i][0], by = pts[i][1]; const ba = Math.atan2(pts[i][1] - pts[i - 1][1], pts[i][0] - pts[i - 1][0]) + (rr(i) < 0.5 ? 1.15 : -1.15); const bl = T * (1.1 + rr(i + 3) * 1.2); g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 4; g.beginPath(); g.moveTo(bx, by); g.lineTo(bx + Math.cos(ba) * bl, by + Math.sin(ba) * bl); g.stroke(); g.strokeStyle = 'rgba(0,0,0,.85)'; g.lineWidth = 1.8; g.stroke(); }
          g.lineCap = 'butt'; made++;
        }
      }
      }   // fine del blocco saltato quando vale la cottura nuova
      // STEP D — POZZE: forma UNICA irregolare (union di cerchi, nessun contorno a "bolle") + conca scura per la PROFONDITÀ
      { const seen = new Uint8Array(m.w * m.h);
        const union = (cells, k) => { g.beginPath(); for (const cc of cells) { const cx = cc[0], cy = cc[1]; const h1 = HSH(cx, cy), h2 = HSH(cx + 5, cy + 9); const ox = (h1 - 0.5) * T * 0.16, oy = (h2 - 0.5) * T * 0.16; const rr = T * k * (1.0 + h1 * 0.14); const bxp = cx * T + T / 2 + ox, byp = cy * T + T / 2 + oy; g.moveTo(bxp + rr, byp); g.arc(bxp, byp, rr, 0, 7); } };
        for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
          if (m.grid[y * m.w + x] !== C.T_HAZARD || seen[y * m.w + x]) continue;
          const cells = []; const st = [[x, y]]; seen[y * m.w + x] = 1; let sx = 0, sy = 0, minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9;
          while (st.length) { const cur = st.pop(); const cx = cur[0], cy = cur[1]; cells.push([cx, cy]); sx += cx; sy += cy; if (cx < minx) minx = cx; if (cx > maxx) maxx = cx; if (cy < miny) miny = cy; if (cy > maxy) maxy = cy; const nb = [[1,0],[-1,0],[0,1],[0,-1]]; for (const d of nb) { const nx = cx + d[0], ny = cy + d[1]; if (nx < 0 || ny < 0 || nx >= m.w || ny >= m.h) continue; const ni = ny * m.w + nx; if (m.grid[ni] === C.T_HAZARD && !seen[ni]) { seen[ni] = 1; st.push([nx, ny]); } } }
          const ccx = (sx / cells.length + 0.5) * T, ccy = (sy / cells.length + 0.5) * T; const bx = (minx - 1) * T, by = (miny - 1) * T, bw = (maxx - minx + 3) * T, bh = (maxy - miny + 3) * T;
          // 1) conca scura scavata nel terreno (bordo del pozzo, un filo più grande)
          union(cells, 1.06); g.fillStyle = 'rgba(0,0,0,0.55)'; g.fill();
          // 2) liquido colorato = UNA forma piena (union), poi profondità (scuro al centro)
          g.save(); union(cells, 0.9); g.clip();
          g.globalAlpha = 0.82; g.fillStyle = hz; g.fillRect(bx, by, bw, bh); g.globalAlpha = 0.34; g.fillStyle = 'rgba(10,14,20,1)'; g.fillRect(bx, by, bw, bh);
          const maxR = Math.max(bw, bh) * 0.6; const dg = g.createRadialGradient(ccx, ccy, 2, ccx, ccy, maxR); dg.addColorStop(0, 'rgba(0,0,0,0.68)'); dg.addColorStop(0.65, 'rgba(0,0,0,0.32)'); dg.addColorStop(1, 'rgba(0,0,0,0)'); g.globalAlpha = 1; g.fillStyle = dg; g.fillRect(bx, by, bw, bh);
          // riflesso sul bordo alto (dà volume/superficie), niente contorni interni
          const rg = g.createLinearGradient(0, by, 0, by + bh); rg.addColorStop(0, 'rgba(255,255,255,0.09)'); rg.addColorStop(0.35, 'rgba(255,255,255,0)'); g.fillStyle = rg; g.fillRect(bx, by, bw, bh);
          g.fillStyle = 'rgba(255,255,255,.10)'; for (const cc of cells) { if (HSH(cc[0] + 2, cc[1] + 2) < 0.3) { g.beginPath(); g.ellipse(cc[0] * T + T / 2 + (HSH(cc[0], cc[1]) - 0.5) * T * 0.4, cc[1] * T + T / 2 - 2, T * 0.16, T * 0.06, 0, 0, 7); g.fill(); } }
          g.restore();
          this.hazards.push({ x: ccx, y: ccy, col: hz, r: Math.min(120, 34 + cells.length * 8) });
        }
      }

      // STEP E — portale (exit)
      for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) { if (m.grid[y * m.w + x] !== C.T_EXIT) continue; const cx = x * T + T / 2, cy = y * T + T / 2; const gr = g.createRadialGradient(cx, cy, 3, cx, cy, T * .7); gr.addColorStop(0, th.accent || '#8be9ff'); gr.addColorStop(1, 'rgba(60,160,255,0)'); g.fillStyle = gr; g.fillRect(cx - T, cy - T, T * 2, T * 2); }

      this.runes = [];
      if (!this.grateAperte) this.grateAperte = new Set();
      this.torches = []; this.campfires = []; this.glows = []; this.bigLight = null;
      for (const p of (m.props || [])) {
        if (p.type === 'stall') { this._bakeStall(g, p); continue; }     // v1.57 — banchetto del mercante
        if (p.type === 'bonfire') { this.campfires.push({ x: p.x, y: p.y - 4 }); this.bigLight = { x: p.x, y: p.y - 4, r: 340 }; this._bakeBonfire(g, p); continue; }
        // v2.6 — il falo' era a 430 (x1,45 = 624 px): con la vecchia sala calda era la luce della
        // stanza, sul pavimento freddo della grotta e' diventato un alone bianco largo mezzo schermo —
        // e quella e' la patina che si vedeva ancora. A 340 illumina la PIAZZA e si spegne prima delle
        // vie, che e' quello che deve fare un fuoco acceso in mezzo a uno spiazzo.
        if (p.type === 'torch') { this.torches.push(p); continue; }
        if (p.type === 'camp') { this.campfires.push(p); this._bakeCamp(g, p); continue; }
        // v2.0 — il focolare di casa: la pietra e le braci si cuociono, la fiamma no. E' viva, e con lei
        // la luce che esce dalla porta aperta: e' l'unica cosa che dice da fuori che la casa e' abitata.
        if (p.type === 'focolare') { this._bakeProp(g, p); this.campfires.push({ x: p.x, y: p.y - 3, fs: 0.85 }); continue; }
        if (p.type === 'brazier') { this._bakeProp(g, p); this.torches.push({ x: p.x, y: p.y - 6 }); continue; }
        if (p.type === 'candelabra') { this._bakeProp(g, p); const V = window.GAME.Constants.VIS_SCALE || 1; for (const ox of [-10, 0, 10]) this.torches.push({ x: p.x + ox * V, y: p.y - 22 * V }); continue; }
        // v1.75 — prop INVISIBILE: porta solo una luce. Serve a staccare il mercante dalla roccia col
        // suo colore, senza mettergli accanto un oggetto che non c'entra nulla.
        if (p.type === 'glowspot') { this.glows.push({ x: p.x, y: p.y, col: p.col || '#ffb14a', rad: p.gr || 78, a: p.ga || 0.17 }); continue; }
        if (p.type === 'mushroom') { this._bakeProp(g, p); this.glows.push({ x: p.x, y: p.y - 4, col: p.col || (this.theme && this.theme.accent) || '#8bff9a', rad: p.gr || 46, a: p.ga || 0.30 }); continue; }
        if (p.type === 'crystal_cluster') { this._bakeProp(g, p); this.glows.push({ x: p.x, y: p.y - 10, col: p.col || (this.theme && this.theme.accent) || '#8be9ff', rad: p.gr || 64, a: p.ga || 0.34 }); continue; }
        if (p.type === 'altar') { this._bakeProp(g, p); const V = window.GAME.Constants.VIS_SCALE || 1; const sc = (p.s || 1) * V; this.torches.push({ x: p.x - 13 * sc, y: p.y - 15 * sc }); this.torches.push({ x: p.x + 13 * sc, y: p.y - 15 * sc }); this.glows.push({ x: p.x, y: p.y - 1, col: (this.theme && this.theme.accent) || '#ff5a3b', rad: 40, a: 0.22 }); continue; }
        if (p.type === 'hanging_lantern') { this._bakeProp(g, p); const V = window.GAME.Constants.VIS_SCALE || 1; this.torches.push({ x: p.x, y: p.y - 8 * (p.s || 1) * V }); continue; } // v1.24 — lanterna + luce calda
        if (p.type === 'obelisk') { this._bakeProp(g, p); this.glows.push({ x: p.x, y: p.y - 14, col: (this.theme && this.theme.accent) || '#c56bff', rad: 54, a: 0.26 }); continue; }
        if (p.type === 'giant_crystal') { this._bakeProp(g, p); this.glows.push({ x: p.x, y: p.y - 18, col: (this.theme && this.theme.accent) || '#8be9ff', rad: 96, a: 0.4 }); continue; } // v1.25 — landmark luminoso
        if (p.type === 'gem_statue') { this._bakeProp(g, p); this.glows.push({ x: p.x, y: p.y - 2, col: (this.theme && this.theme.accent) || '#c56bff', rad: 46, a: 0.26 }); continue; }
        if (p.type === 'well') { this._bakeProp(g, p); this.glows.push({ x: p.x, y: p.y + 5, col: (this.theme && this.theme.accent) || '#7de0ff', rad: 40, a: 0.18 }); continue; }
        this._bakeProp(g, p);
      }
      // v1.64 — LA FASCIA DELLA FAGLIA dipinta direttamente sulla mappa cotta: il giocatore deve poter
      // vedere DOVE comincia il pericolo prima di entrarci, altrimenti la punizione arriva senza preavviso.
      // Quattro sfumature, una per lato, che partono dalla roccia del bordo e sfumano verso l'interno; negli
      // angoli si sovrappongono e quindi il viola e' piu' carico — esattamente dove la faglia morde il doppio.
      // Essendo cotta qui dentro, a schermo non costa niente: e' gia' dentro l'immagine di sfondo.
      // v2.6 — nel VILLAGGIO no. La fascia viola e' il segno di un pericolo che li' non esiste, ed e'
      // gia' spenta a schermo dalla v2.1 (_drawEdgeVignette) — ma questa e' COTTA nella mappa, quindi
      // restava: un velo viola largo due tessere tutto attorno al paese. Un altro pezzo di patina.
      if (!m.lit) { const M = (C.EDGE_MARGIN || 3) * T, x1 = m.w * T, y1 = m.h * T;
        const stops = (q) => { q.addColorStop(0, 'rgba(122,40,196,0.26)'); q.addColorStop(0.32, 'rgba(122,40,196,0.05)'); q.addColorStop(1, 'rgba(122,40,196,0)'); return q; };
        const d = 2 * T + M;
        g.fillStyle = stops(g.createLinearGradient(0, 0, d, 0)); g.fillRect(0, 0, d, y1);
        g.fillStyle = stops(g.createLinearGradient(x1, 0, x1 - d, 0)); g.fillRect(x1 - d, 0, d, y1);
        g.fillStyle = stops(g.createLinearGradient(0, 0, 0, d)); g.fillRect(0, 0, x1, d);
        g.fillStyle = stops(g.createLinearGradient(0, y1, 0, y1 - d)); g.fillRect(0, y1 - d, x1, d);
      }
      this.mapCanvas = cv;
    },
    _bakeMinimap() {
      const m = this.map; if (!m) return; const px = 3; this.mm = { px, w: m.w, h: m.h };
      const cv = document.createElement('canvas'); cv.width = m.w * px; cv.height = m.h * px; const g = cv.getContext('2d');
      const th = this.theme || {}; const wl = th.wall || '#2a3350';
      g.fillStyle = 'rgba(8,10,18,.92)'; g.fillRect(0, 0, cv.width, cv.height);
      for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
        const t = m.grid[y * m.w + x];
        if (t === C.T_WALL) { g.fillStyle = wl; g.fillRect(x * px, y * px, px, px); }
        else if (t === C.T_HAZARD) { g.fillStyle = 'rgba(255,90,30,.5)'; g.fillRect(x * px, y * px, px, px); }
        else { g.fillStyle = 'rgba(150,170,210,.10)'; g.fillRect(x * px, y * px, px, px); }
        // v1.63 — la FASCIA della faglia e' segnata sulla minimappa: cosi' la regola si impara guardando,
        // senza doverla leggere. Tinta piu' forte negli angoli, dove la profondita' e' doppia.
        if (t !== C.T_WALL) {
          const M = C.EDGE_MARGIN || 3;
          const dx = Math.min(x - 2, (m.w - 3) - x), dy = Math.min(y - 2, (m.h - 3) - y);
          const dep = Math.max(0, M - dx) + Math.max(0, M - dy);
          if (dep > 0) { g.fillStyle = 'rgba(170,80,240,' + (0.025 + 0.018 * dep).toFixed(3) + ')'; g.fillRect(x * px, y * px, px, px); }
        }
      }
      this.minimapCanvas = cv;
    },
    _drawMinimap(ctx, world) {
      if (!this.minimapCanvas || !this.mm || !world) return; const px = this.mm.px, T = this.map.tile;
      const mw = this.minimapCanvas.width, mh = this.minimapCanvas.height;
      const pad = 12, ox = pad, oy = this.h - mh - pad - 6;
      ctx.save();
      ctx.globalAlpha = 0.9; ctx.fillStyle = 'rgba(6,8,14,.6)'; this._rr(ctx, ox - 4, oy - 4, mw + 8, mh + 8, 6); ctx.fill();
      ctx.strokeStyle = 'rgba(140,180,255,.35)'; ctx.lineWidth = 1.5; this._rr(ctx, ox - 4, oy - 4, mw + 8, mh + 8, 6); ctx.stroke();
      ctx.globalAlpha = 1; ctx.drawImage(this.minimapCanvas, ox, oy);
      const w2m = (wx, wy) => ({ x: ox + (wx / T) * px, y: oy + (wy / T) * px });
      // exit
      if (this.map.exit) { const e = w2m(this.map.exit.x * T + T / 2, this.map.exit.y * T + T / 2); ctx.fillStyle = '#8be9ff'; ctx.beginPath(); ctx.arc(e.x, e.y, 2.6 + Math.sin(this.time * 4) * 0.8, 0, 7); ctx.fill(); }
      // v1.23 — mercanti sulla minimappa (sempre visibili quando presenti)
      if (world.merch) { const q = w2m(world.merch.x, world.merch.y); ctx.strokeStyle = '#ffcf4a'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(q.x, q.y, 4.5 + Math.sin(this.time * 4) * 1.2, 0, 7); ctx.stroke(); ctx.fillStyle = '#ffd24a'; ctx.beginPath(); ctx.arc(q.x, q.y, 2.4, 0, 7); ctx.fill(); }
      if (world.merchD) { const q = w2m(world.merchD.x, world.merchD.y); ctx.strokeStyle = '#c77dff'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(q.x, q.y, 4.5 + Math.sin(this.time * 4) * 1.2, 0, 7); ctx.stroke(); ctx.fillStyle = '#ff2d6b'; ctx.beginPath(); ctx.arc(q.x, q.y, 2.6, 0, 7); ctx.fill(); }
      // v1.52 — il fabbro sul minimappa · v2.19 — e adesso tutte e tre le botteghe, ognuna del colore
      // del suo catalogo: sul minimappa del villaggio sono i tre punti che si cercano davvero.
      { const COLB = { guerriero: ['#ffa63c', '#ffcf4a'], ladro: ['#7fc94e', '#a6e86a'], mago: ['#8a6ef0', '#c8b4ff'] };
        const lista = (world.gmerchs && world.gmerchs.length) ? world.gmerchs : (world.gmerch ? [world.gmerch] : []);
        for (const b of lista) { const q = w2m(b.x, b.y); const cc = COLB[b.k] || COLB.guerriero;
          ctx.strokeStyle = cc[0]; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(q.x, q.y, 5 + Math.sin(this.time * 4) * 1.2, 0, 7); ctx.stroke();
          ctx.fillStyle = cc[1]; ctx.beginPath(); ctx.arc(q.x, q.y, 2.8, 0, 7); ctx.fill(); } }
      // monsters
      for (const mo of world.mon) { const q = w2m(mo.x, mo.y); if (mo.tr) { ctx.fillStyle = '#ffd24a'; ctx.beginPath(); ctx.arc(q.x, q.y, 2.6, 0, 7); ctx.fill(); } else if (mo.b) { ctx.fillStyle = mo.mg ? '#ff2d55' : '#ff5a5a'; ctx.beginPath(); ctx.arc(q.x, q.y, 3.4, 0, 7); ctx.fill(); } else { ctx.fillStyle = mo.el ? '#ffb020' : 'rgba(255,90,90,.85)'; ctx.fillRect(q.x - 1, q.y - 1, 2, 2); } }
      // players
      // v1.84.1 — sulla minimappa c'e' solo la FAGLIA d'uscita. Ne' la chiave ne' il recinto: la
      // deviazione dei prigionieri si trova ESPLORANDO, e una mappa che te la segna te la toglie.
      if (world.fg) { const q = w2m(world.fg.x, world.fg.y);
        ctx.fillStyle = '#c9a8ff'; ctx.beginPath(); ctx.arc(q.x, q.y, 3.4, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(190,150,255,' + (0.45 + 0.4 * Math.sin(this.time * 4)) + ')'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(q.x, q.y, 6.2, 0, 7); ctx.stroke(); }
      for (const p of world.players) { if (p.d) continue; const h = HERO[p.h] || HERO.barbaro; const q = w2m(p.x, p.y); const me = world.me && p.i === world.me.i; ctx.fillStyle = me ? '#ffffff' : (h.accent || '#8bd6ff'); ctx.beginPath(); ctx.arc(q.x, q.y, me ? 3 : 2.4, 0, 7); ctx.fill(); if (me) { ctx.strokeStyle = h.accent || '#8bd6ff'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(q.x, q.y, 4.6, 0, 7); ctx.stroke(); } }
      ctx.restore();
    },
    // v1.57 — FALO' della sala: cerchio di pietre, cenere, legna. La fiamma la mette _flame() a runtime.
    _bakeBonfire(g, p) {
      g.save(); g.translate(p.x, p.y); g.scale(p.s || 1, p.s || 1);
      g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.ellipse(0, 8, 44, 17, 0, 0, 7); g.fill();
      for (let i = 0; i < 12; i++) { const a = i / 12 * 6.283, rx = Math.cos(a) * 38, ry = Math.sin(a) * 20 + 4;
        const ss = 7 + ((i * 37) % 5); const gr = g.createLinearGradient(rx, ry - ss, rx, ry + ss);
        gr.addColorStop(0, '#5a5348'); gr.addColorStop(1, '#2d2822');
        g.fillStyle = gr; g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 2;
        g.beginPath(); g.ellipse(rx, ry, ss, ss * 0.75, a, 0, 7); g.fill(); g.stroke(); }
      const ash = g.createRadialGradient(0, 2, 2, 0, 2, 30); ash.addColorStop(0, '#3a2a1c'); ash.addColorStop(1, 'rgba(40,30,20,0)');
      g.fillStyle = ash; g.beginPath(); g.ellipse(0, 2, 30, 16, 0, 0, 7); g.fill();
      g.strokeStyle = '#4a3520'; g.lineWidth = 7; g.lineCap = 'round';
      for (const a of [-0.5, 0.4, 1.4, 2.4]) { g.save(); g.rotate(a); g.beginPath(); g.moveTo(-22, 6); g.lineTo(20, -6); g.stroke(); g.restore(); }
      g.lineCap = 'butt';
      const em = g.createRadialGradient(0, -2, 1, 0, -2, 26); em.addColorStop(0, 'rgba(255,190,80,.95)'); em.addColorStop(.45, 'rgba(255,110,30,.55)'); em.addColorStop(1, 'rgba(255,70,10,0)');
      g.fillStyle = em; g.beginPath(); g.arc(0, -2, 26, 0, 7); g.fill();
      g.restore();
    },
    // v1.57 — BANCHETTO: deve essere piu' GRANDE del mercante che ci sta dietro (scala dal manifest).
    _bakeStall(g, p) {
      const PAL = {
        smith:     { cloth: '#8a3b2a', cloth2: '#e8d9b0', accent: '#ffb14a' },
        herbalist: { cloth: '#3f6b34', cloth2: '#dfe8b0', accent: '#9fe06a' },
        innkeeper: { cloth: '#8a6a2a', cloth2: '#e8dcb0', accent: '#ffd97a' },
        oracolo:  { cloth: '#2f5a52', cloth2: '#cfe6df', accent: '#7fd6c0' },
        crier:     { cloth: '#6b3a3a', cloth2: '#e8c9b0', accent: '#ff9a8a' },
      };
      const c = PAL[p.kind] || PAL.crier;
      g.save(); g.translate(p.x, p.y); g.scale(p.s || 1, p.s || 1);
      g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.ellipse(0, 20, 40, 12, 0, 0, 7); g.fill();
      g.strokeStyle = '#3a2a18'; g.lineWidth = 5; g.lineCap = 'round';
      g.beginPath(); g.moveTo(-32, 18); g.lineTo(-32, -40); g.moveTo(32, 18); g.lineTo(32, -40); g.stroke(); g.lineCap = 'butt';
      for (let i = 0; i < 8; i++) { g.fillStyle = (i % 2) ? c.cloth : c.cloth2;
        g.beginPath(); g.moveTo(-34 + i * 8.5, -40); g.lineTo(-34 + (i + 1) * 8.5, -40); g.lineTo(-34 + i * 8.5 + 4.2, -26); g.closePath(); g.fill(); }
      g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 2; g.beginPath(); g.moveTo(-34, -40); g.lineTo(34, -40); g.stroke();
      g.fillStyle = '#3b352e'; g.strokeStyle = '#1c1815'; g.lineWidth = 2; this._rr(g, -30, 2, 60, 18, 3); g.fill(); g.stroke();
      const wg = g.createLinearGradient(0, -6, 0, 4); wg.addColorStop(0, '#6b4d2c'); wg.addColorStop(1, '#43301b');
      g.fillStyle = wg; g.strokeStyle = '#241a10'; g.lineWidth = 2; this._rr(g, -34, -8, 68, 12, 3); g.fill(); g.stroke();
      g.save(); g.translate(0, -12);
      if (p.kind === 'smith') { g.fillStyle = '#8f959f'; for (const dx of [-16, -8, 0]) { g.beginPath(); g.moveTo(dx, 4); g.lineTo(dx + 3, -10); g.lineTo(dx + 6, 4); g.closePath(); g.fill(); }
        g.fillStyle = '#5b616b'; this._rr(g, 8, -6, 16, 10, 2); g.fill(); g.strokeStyle = '#2a2e35'; g.lineWidth = 1.5; this._rr(g, 8, -6, 16, 10, 2); g.stroke(); }
      else if (p.kind === 'herbalist') { for (const [dx, col] of [[-18, '#7fd06a'], [-8, '#b06ad0'], [2, '#6ad0c8'], [12, '#d0b86a']]) {
          g.fillStyle = col; this._rr(g, dx, -8, 7, 12, 2); g.fill(); g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(dx + 1, -6, 2, 6); }
        g.strokeStyle = '#4e7a3c'; g.lineWidth = 2; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(22, 2); g.lineTo(20 + i * 4, -10); g.stroke(); } }
      else if (p.kind === 'innkeeper') { for (const dx of [-16, -4, 8]) { g.fillStyle = '#c9a35a'; this._rr(g, dx, -8, 9, 12, 2); g.fill(); g.fillStyle = '#f0e2b8'; g.fillRect(dx + 1, -8, 7, 3); }
        g.fillStyle = '#6b4d2c'; this._rr(g, 20, -10, 12, 14, 3); g.fill(); }
      else if (p.kind === 'oracolo') {  // v2.6 — sul banco dell’oracolo: la ciotola dei fumi e le ossa
        g.fillStyle = '#2a3a35'; g.beginPath(); g.ellipse(0, -1, 11, 6, 0, 0, 7); g.fill();
        const og = g.createRadialGradient(-2, -4, 1, 0, -2, 13); og.addColorStop(0, 'rgba(127,214,192,.85)'); og.addColorStop(1, 'rgba(60,140,120,.12)');
        g.fillStyle = og; g.beginPath(); g.arc(0, -4, 12, 0, 7); g.fill();
        g.fillStyle = '#e8e0cc'; for (const [dx, rr] of [[-22, -0.4], [-15, 0.3]]) { g.save(); g.translate(dx, 0); g.rotate(rr); this._rr(g, -1.6, -8, 3.2, 13, 1.4); g.fill(); g.restore(); }
        g.fillStyle = '#8a6a38'; g.beginPath(); g.arc(17, -2, 5, 0, 7); g.fill(); }
      else { g.fillStyle = '#d9c8a0'; g.strokeStyle = '#8a7a55'; g.lineWidth = 1.5; this._rr(g, -20, -8, 14, 11, 1); g.fill(); g.stroke();
        g.fillStyle = '#b8862a'; g.beginPath(); g.arc(2, -2, 5, 0, 7); g.fill(); g.fillStyle = '#8f959f'; g.beginPath(); g.arc(14, -1, 4, 0, 7); g.fill(); }
      g.restore();
      const lg = g.createRadialGradient(-32, -34, 1, -32, -34, 14); lg.addColorStop(0, 'rgba(255,205,120,.9)'); lg.addColorStop(1, 'rgba(255,150,40,0)');
      g.fillStyle = lg; g.beginPath(); g.arc(-32, -34, 14, 0, 7); g.fill();
      g.fillStyle = '#2a2018'; this._rr(g, -35.5, -39, 7, 10, 2); g.fill(); g.fillStyle = c.accent; this._rr(g, -34, -37, 4, 6, 1); g.fill();
      g.restore();
      const S = p.s || 1;
      this.torches.push({ x: p.x - 32 * S, y: p.y - 34 * S });
    },
    _bakeProp(g, p) { const VIS = (window.GAME.Constants.VIS_SCALE || 1); g.save(); g.translate(p.x, p.y); g.scale((p.s || 1) * VIS, (p.s || 1) * VIS); const rot = (p.r || 0) * Math.PI * 2;
      switch (p.type) {
        case 'signpost': { // v1.56 — cartello del villaggio
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 14, 8, 4, 0, 0, 7); g.fill();
          g.strokeStyle = '#3a2a18'; g.lineWidth = 4; g.beginPath(); g.moveTo(0, 13); g.lineTo(0, -14); g.stroke();
          g.fillStyle = '#5a4326'; g.strokeStyle = '#241a10'; g.lineWidth = 2; this._rr(g, -22, -22, 44, 15, 2); g.fill(); g.stroke();
          g.fillStyle = '#f0dcae'; g.font = 'bold 11px Segoe UI'; g.textAlign = 'center'; g.fillText(p.txt || 'MERCATO', 0, -11); g.textAlign = 'left'; break; }
        case 'rock': case 'rockSmall': { const s = p.type === 'rock' ? 14 : 8; g.fillStyle = '#3a4152'; g.strokeStyle = '#242a38'; g.lineWidth = 2; g.beginPath(); g.moveTo(-s, s * .5); g.lineTo(-s * .5, -s); g.lineTo(s * .6, -s * .7); g.lineTo(s, s * .4); g.lineTo(s * .2, s); g.closePath(); g.fill(); g.stroke(); break; }
        case 'bones': { g.strokeStyle = '#cfc9b6'; g.lineWidth = 3; g.lineCap = 'round'; g.rotate(rot); for (let i = 0; i < 3; i++) { g.save(); g.rotate(i * 1.1); g.beginPath(); g.moveTo(-9, 0); g.lineTo(9, 0); g.stroke(); g.restore(); } break; }
        case 'skull': { g.rotate(rot * .3); g.fillStyle = '#d8d2c0'; g.strokeStyle = '#8f8874'; g.lineWidth = 1.5; g.beginPath(); g.arc(0, -1, 7, 0, 7); g.fill(); g.stroke(); g.fillRect(-5, 4, 10, 5); g.fillStyle = '#1a1a22'; g.beginPath(); g.arc(-2.6, -1, 2, 0, 7); g.arc(2.6, -1, 2, 0, 7); g.fill(); break; }
        // ===== v1.75 — L'ARREDO DELLE BOTTEGHE ==============================================
        // Otto mobili nuovi. Prima il gioco aveva solo roba da caverna (casse, barili, ossa, cristalli):
        // con quella non si arreda una taverna ne' una fucina, e le stanze restavano scatole vuote.
        // Tutti visti DALL'ALTO come il resto della mappa, e tutti "cotti" una volta sola nel fondo.
        case 'credenza': { // credenza da taverna: il mobile alto contro il muro, con le bottiglie in fila
          g.rotate(rot > 0.5 ? Math.PI / 2 : 0);
          g.fillStyle = 'rgba(0,0,0,.45)'; this._rr(g, -26, -10, 52, 24, 2); g.fill();
          const cg = g.createLinearGradient(0, -14, 0, 12); cg.addColorStop(0, '#6b4a28'); cg.addColorStop(1, '#33220f');
          g.fillStyle = cg; g.strokeStyle = '#1e1408'; g.lineWidth = 2.2; this._rr(g, -27, -13, 54, 25, 2); g.fill(); g.stroke();
          g.fillStyle = 'rgba(255,255,255,.10)'; this._rr(g, -25, -12, 50, 4, 2); g.fill();
          const BOT = ['#8bd6ff', '#9fe06a', '#ffd97a', '#ff9a8a', '#c9a0ff'];
          for (let i = 0; i < 9; i++) { const bx = -22 + i * 5.4;
            g.fillStyle = BOT[i % BOT.length]; g.globalAlpha = 0.85;
            this._rr(g, bx, -7, 3.2, 8.5, 1); g.fill(); g.globalAlpha = 1;
            g.fillStyle = '#2a1d10'; g.fillRect(bx + 0.9, -9.5, 1.4, 2.6); }
          g.strokeStyle = 'rgba(0,0,0,.30)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(-25, 3); g.lineTo(25, 3); g.stroke();
          g.fillStyle = '#c9a35a'; for (const dx of [-13, 13]) { g.beginPath(); g.arc(dx, 8, 1.8, 0, 7); g.fill(); } break; }
        case 'aiuola': {   // mini piantagione: un riquadro di terra con le erbe in FILA, non funghi a caso
          g.fillStyle = 'rgba(0,0,0,.4)'; this._rr(g, -22, -18, 44, 38, 2); g.fill();
          g.fillStyle = '#4a3520'; g.strokeStyle = '#241708'; g.lineWidth = 2.4; this._rr(g, -23, -20, 46, 38, 2); g.fill(); g.stroke();
          g.fillStyle = '#2e2318'; this._rr(g, -19, -16, 38, 30, 1); g.fill();
          for (let i = 0; i < 34; i++) { g.fillStyle = 'rgba(0,0,0,' + (0.06 + Math.random() * 0.10).toFixed(3) + ')';
            g.fillRect(-19 + Math.random() * 38, -16 + Math.random() * 30, 3, 2); }
          const cl3 = p.col || '#9fe06a';
          for (let ry = 0; ry < 3; ry++) for (let cx2 = 0; cx2 < 3; cx2++) {
            const px2 = -12 + cx2 * 12, py2 = -10 + ry * 10;
            g.strokeStyle = 'rgba(30,60,35,.9)'; g.lineWidth = 1.6;
            for (let k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(px2, py2 + 3); g.quadraticCurveTo(px2 + k * 2.5, py2 - 1, px2 + k * 4.5, py2 - 4); g.stroke(); }
            g.fillStyle = cl3; g.globalAlpha = 0.9;
            for (let k = -1; k <= 1; k++) { g.beginPath(); g.ellipse(px2 + k * 4.5, py2 - 4.5, 2.3, 3.4, k * 0.5, 0, 7); g.fill(); }
            g.globalAlpha = 1; }
          break; }
        case 'mortaio': {  // mortaio e pestello: lo strumento che dice "qui si prepara"
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 4, 10, 5, 0, 0, 7); g.fill();
          const mg2 = g.createRadialGradient(-2, -2, 1, 0, 0, 10); mg2.addColorStop(0, '#9aa1ad'); mg2.addColorStop(1, '#4a5058');
          g.fillStyle = mg2; g.strokeStyle = '#22262d'; g.lineWidth = 1.8; g.beginPath(); g.arc(0, 0, 9, 0, 7); g.fill(); g.stroke();
          g.fillStyle = '#2a2f36'; g.beginPath(); g.arc(0, 0, 5.6, 0, 7); g.fill();
          g.fillStyle = p.col || '#9fe06a'; g.globalAlpha = 0.7; g.beginPath(); g.arc(0, 0, 4, 0, 7); g.fill(); g.globalAlpha = 1;
          g.strokeStyle = '#8d97a5'; g.lineWidth = 2.6; g.lineCap = 'round';
          g.beginPath(); g.moveTo(1, -1); g.lineTo(8, -8); g.stroke(); g.lineCap = 'butt'; break; }
        case 'tavolo': {   // tavolo tondo della taverna: piano di assi, ombra, boccali
          g.fillStyle = 'rgba(0,0,0,.42)'; g.beginPath(); g.ellipse(0, 6, 20, 8, 0, 0, 7); g.fill();
          g.fillStyle = '#2e1f10'; g.beginPath(); g.arc(0, 0, 20, 0, 7); g.fill();          // bordo scuro spesso
          const tg = g.createRadialGradient(-6, -7, 2, 0, 0, 19); tg.addColorStop(0, '#b98d54'); tg.addColorStop(1, '#6d4b28');
          g.fillStyle = tg; g.strokeStyle = '#241708'; g.lineWidth = 1.6; g.beginPath(); g.arc(0, 0, 17, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.30)'; g.lineWidth = 1.2;
          for (const dx of [-11, -4, 3, 10]) { g.beginPath(); g.moveTo(dx, -Math.sqrt(Math.max(0, 361 - dx * dx))); g.lineTo(dx, Math.sqrt(Math.max(0, 361 - dx * dx))); g.stroke(); }
          g.strokeStyle = 'rgba(255,255,255,.10)'; g.lineWidth = 2; g.beginPath(); g.arc(0, 0, 16, Math.PI * 1.1, Math.PI * 1.75); g.stroke();
          const boccale = (bx, by) => { g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(bx + 1, by + 1.5, 4.4, 3.4, 0, 0, 7); g.fill();
            g.fillStyle = '#8a6a30'; g.strokeStyle = '#4a3512'; g.lineWidth = 1.2; g.beginPath(); g.arc(bx, by, 4.2, 0, 7); g.fill(); g.stroke();
            g.fillStyle = '#ffe9a8'; g.beginPath(); g.arc(bx, by, 2.6, 0, 7); g.fill(); };
          boccale(-7, -5); boccale(6, 4); break; }
        case 'panca': {    // SGABELLO tondo: attorno a un tavolo tondo un'asse non si legge, un cerchio si'
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(1, 2.5, 7.5, 6, 0, 0, 7); g.fill();
          const pg = g.createRadialGradient(-2, -2, 1, 0, 0, 7.5); pg.addColorStop(0, '#8a6238'); pg.addColorStop(1, '#4a331b');
          g.fillStyle = pg; g.strokeStyle = '#241708'; g.lineWidth = 1.6; g.beginPath(); g.arc(0, 0, 7, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.28)'; g.lineWidth = 1; g.beginPath(); g.moveTo(-5, 0); g.lineTo(5, 0); g.stroke(); break; }
        // ===== v2.0 — I TRE MOBILI DEL VILLAGGIO =====
        // Disegnati come tutto il resto: ombra a terra, base scura, sfumatura sopra, contorno nero
        // sottile. Il contorno non e' un vezzo — e' quello che li stacca dalla roccia quando la luce del
        // focolare li prende di taglio.
        case 'pozzo': {    // IL POZZO della piazza: anello di conci, il buco nero in mezzo, la trave e il secchio
          g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.ellipse(1, 7, 27, 12, 0, 0, 7); g.fill();
          g.fillStyle = '#23262e'; g.beginPath(); g.arc(0, 0, 25, 0, 7); g.fill();          // il bordo scuro spesso
          const pw = g.createRadialGradient(-7, -8, 3, 0, 0, 24); pw.addColorStop(0, '#8b8f9a'); pw.addColorStop(1, '#4a4e58');
          g.fillStyle = pw; g.strokeStyle = '#15181e'; g.lineWidth = 2.2; g.beginPath(); g.arc(0, 0, 23, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1.4;                              // i conci, uno per uno
          for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2 + 0.2;
            g.beginPath(); g.moveTo(Math.cos(a) * 14, Math.sin(a) * 14); g.lineTo(Math.cos(a) * 23, Math.sin(a) * 23); g.stroke(); }
          g.fillStyle = '#0a0c10'; g.beginPath(); g.arc(0, 1, 13.5, 0, 7); g.fill();         // il buco: nero, e' profondo
          const ac = g.createRadialGradient(-3, -3, 1, 0, 1, 13); ac.addColorStop(0, 'rgba(90,130,150,.32)'); ac.addColorStop(1, 'rgba(20,40,60,0)');
          g.fillStyle = ac; g.beginPath(); g.arc(0, 1, 13, 0, 7); g.fill();                  // il barlume dell'acqua, in fondo
          g.fillStyle = '#5a3f22'; g.strokeStyle = '#241708'; g.lineWidth = 1.8;             // la trave sopra
          this._rr(g, -26, -5, 52, 7, 2); g.fill(); g.stroke();
          g.strokeStyle = '#c9b98a'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(4, -1); g.lineTo(4, 9); g.stroke();
          g.fillStyle = '#6b4a28'; g.strokeStyle = '#241708'; g.lineWidth = 1.4;             // e il secchio appeso
          g.beginPath(); g.arc(4, 12, 5, 0, 7); g.fill(); g.stroke();
          g.fillStyle = 'rgba(255,255,255,.10)'; this._rr(g, -24, -4, 48, 2, 1); g.fill(); break; }
        case 'focolare': { // IL FOCOLARE di casa: anello di pietre e braci. La fiamma la disegna _flame, viva
          g.fillStyle = 'rgba(0,0,0,.42)'; g.beginPath(); g.ellipse(1, 5, 22, 10, 0, 0, 7); g.fill();
          g.fillStyle = '#1a1c22'; g.beginPath(); g.arc(0, 0, 19, 0, 7); g.fill();
          for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2 + 0.35;
            const sx = Math.cos(a) * 16, sy = Math.sin(a) * 13;
            const sg = g.createRadialGradient(sx - 1.5, sy - 2, 0.5, sx, sy, 6); sg.addColorStop(0, '#8b8f9a'); sg.addColorStop(1, '#3f434c');
            g.fillStyle = sg; g.strokeStyle = '#14171c'; g.lineWidth = 1.5;
            g.beginPath(); g.ellipse(sx, sy, 5.4, 4.4, a, 0, 7); g.fill(); g.stroke(); }
          g.fillStyle = '#241a12'; g.beginPath(); g.ellipse(0, 0, 12, 9, 0, 0, 7); g.fill();   // il letto di cenere
          for (let i = 0; i < 7; i++) { const a = i * 1.7, dd = 3 + (i % 3) * 3;
            g.fillStyle = i % 2 ? 'rgba(255,150,50,.75)' : 'rgba(255,90,30,.55)';
            g.beginPath(); g.arc(Math.cos(a) * dd, Math.sin(a) * dd * 0.8, 1.9, 0, 7); g.fill(); }
          g.strokeStyle = '#3a2a18'; g.lineWidth = 2.6; g.lineCap = 'round';                  // due ciocchi incrociati
          g.beginPath(); g.moveTo(-7, 3); g.lineTo(6, -3); g.moveTo(-5, -4); g.lineTo(7, 2); g.stroke(); g.lineCap = 'butt'; break; }
        case 'letto': {    // IL LETTO: telaio di legno, pagliericcio, coperta e cuscino. Dice "qui si dorme"
          g.rotate(rot > 0.5 ? Math.PI / 2 : 0);
          g.fillStyle = 'rgba(0,0,0,.45)'; this._rr(g, -29, -13, 60, 30, 3); g.fill();
          g.fillStyle = '#4a3319'; g.strokeStyle = '#1e1408'; g.lineWidth = 2.2;              // il telaio
          this._rr(g, -31, -16, 62, 32, 3); g.fill(); g.stroke();
          g.fillStyle = '#c9bb95'; g.strokeStyle = '#6b5f3f'; g.lineWidth = 1.2;              // il pagliericcio
          this._rr(g, -27, -12, 54, 24, 2); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.16)'; g.lineWidth = 1;
          for (let dx = -20; dx <= 20; dx += 8) { g.beginPath(); g.moveTo(dx, -11); g.lineTo(dx, 11); g.stroke(); }
          const cg2 = g.createLinearGradient(0, -12, 0, 12); cg2.addColorStop(0, '#7d4a3c'); cg2.addColorStop(1, '#4a2820');
          g.fillStyle = cg2; g.strokeStyle = '#241008'; g.lineWidth = 1.6;                    // la coperta, tirata su
          this._rr(g, -6, -12, 33, 24, 2); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1.6;
          g.beginPath(); g.moveTo(-4, -10); g.lineTo(-4, 10); g.stroke();
          g.fillStyle = '#e8e0cc'; g.strokeStyle = '#8b8067'; g.lineWidth = 1.4;              // il cuscino
          this._rr(g, -25, -8, 16, 16, 3); g.fill(); g.stroke(); break; }
        case 'bancarella': { // v2.5 — la bottega di contorno: banco, tendone a righe, merce, cassette
          g.rotate(rot > 0.5 ? Math.PI / 2 : 0);
          const cl = p.col || '#d9a55c', me = p.mest || 'pane';
          g.fillStyle = 'rgba(0,0,0,.48)'; this._rr(g, -34, -14, 70, 34, 3); g.fill();
          // il TENDONE, che e' quello che si vede da lontano: due righe chiare e due scure.
          // v2.6 — la riga scura prende il colore della MERCE. Con dodici banchi in giro alla piazza un
          // tendone rosso uguale per tutti li faceva leggere come dodici copie: da lassu' il tendone e'
          // quasi tutto quello che si vede, quindi e' li' che deve stare la differenza.
          g.fillStyle = _darkenHex(cl, 0.62); g.strokeStyle = '#2a1210'; g.lineWidth = 2;
          this._rr(g, -36, -22, 72, 15, 3); g.fill(); g.stroke();
          g.fillStyle = '#e8ddc8';
          for (let i = 0; i < 4; i++) { g.fillRect(-34 + i * 18, -21, 9, 13); }
          g.fillStyle = 'rgba(0,0,0,.22)'; this._rr(g, -36, -11, 72, 5, 2); g.fill();
          // il BANCO
          const bgz = g.createLinearGradient(0, -8, 0, 12);
          bgz.addColorStop(0, '#8a6238'); bgz.addColorStop(1, '#3e2a15');
          g.fillStyle = bgz; g.strokeStyle = '#241708'; g.lineWidth = 2.1;
          this._rr(g, -34, -8, 68, 20, 3); g.fill(); g.stroke();
          g.fillStyle = 'rgba(255,255,255,.12)'; this._rr(g, -32, -7, 64, 3.5, 2); g.fill();
          // LA MERCE, e qui cambia il mestiere. Non si tratta di realismo: serve che a colpo d'occhio
          // due bancarelle vicine non sembrino la stessa bancarella.
          g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 1.2;
          if (me === 'pane') {                       // pagnotte: ovali con il taglio in mezzo
            for (const [mx, my] of [[-20, 1], [-6, 2], [8, 1], [21, 2]]) {
              g.fillStyle = cl; g.beginPath(); g.ellipse(mx, my, 7, 4.6, 0.2, 0, 7); g.fill(); g.stroke();
              g.strokeStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.moveTo(mx - 4, my - 1); g.lineTo(mx + 4, my + 1); g.stroke();
              g.strokeStyle = 'rgba(0,0,0,.45)';
            }
          } else if (me === 'carne') {               // tagli appesi al tendone, e il ceppo sul banco
            for (const mx of [-22, -8, 6, 20]) {
              g.strokeStyle = '#6b5a3c'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(mx, -19); g.lineTo(mx, -12); g.stroke();
              g.fillStyle = cl; g.strokeStyle = '#3a1414'; g.lineWidth = 1.2;
              g.beginPath(); g.ellipse(mx, -8, 5, 7, 0, 0, 7); g.fill(); g.stroke();
            }
            g.fillStyle = '#6b4a28'; g.beginPath(); g.arc(14, 3, 7, 0, 7); g.fill(); g.stroke();
          } else if (me === 'pesce') {               // pesci in fila, tutti nello stesso verso
            for (const [mx, my] of [[-20, 0], [-6, 3], [8, 0], [21, 3]]) {
              g.fillStyle = cl; g.beginPath(); g.ellipse(mx, my, 8, 3.6, -0.15, 0, 7); g.fill(); g.stroke();
              g.beginPath(); g.moveTo(mx + 7, my); g.lineTo(mx + 12, my - 3); g.lineTo(mx + 12, my + 3); g.closePath(); g.fill(); g.stroke();
              g.fillStyle = '#1a1a22'; g.beginPath(); g.arc(mx - 5, my - 0.6, 1.1, 0, 7); g.fill();
            }
          } else if (me === 'vasi') {                // orci di tre misure
            for (const [mx, my, rr2] of [[-21, 1, 7], [-5, 2, 5], [9, 1, 8], [23, 2, 5.5]]) {
              g.fillStyle = cl; g.beginPath(); g.ellipse(mx, my, rr2 * 0.8, rr2, 0, 0, 7); g.fill(); g.stroke();
              g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(mx, my - rr2 * 0.72, rr2 * 0.42, rr2 * 0.2, 0, 0, 7); g.fill();
            }
          } else if (me === 'tessuti') {             // pezze arrotolate, a colori diversi
            const COL = [cl, '#b06b8a', '#6b9bb0', '#c8a24a'];
            for (let i = 0; i < 4; i++) {
              g.fillStyle = COL[i]; this._rr(g, -30 + i * 16, -5, 13, 14, 3); g.fill(); g.stroke();
              g.fillStyle = 'rgba(255,255,255,.16)'; this._rr(g, -30 + i * 16, -5, 13, 3, 2); g.fill();
            }
          } else if (me === 'candele') {             // candele: file di steli con la fiammella spenta
            for (let i = 0; i < 7; i++) {
              const mx = -27 + i * 9;
              g.fillStyle = cl; this._rr(g, mx, -6, 4.4, 15, 1.6); g.fill(); g.stroke();
              g.fillStyle = '#5a4a2e'; g.fillRect(mx + 1.5, -8.5, 1.4, 3);
            }
          // v2.6 — SEI MESTIERI NUOVI. Il ramo finale non e' piu' "candele o quello che capita": chi
          // arrivava qui senza il suo caso vendeva candele, e con dodici banchi l'avrei scoperto tardi.
          } else if (me === 'frutta') {              // ceste colme: tre mucchi di tondi
            for (const [mx, my] of [[-22, 2], [0, 2], [22, 2]]) {
              g.fillStyle = '#6b4a28'; g.beginPath(); g.ellipse(mx, my + 3, 11, 6, 0, 0, 7); g.fill(); g.stroke();
              for (const [ox, oy] of [[-5, -2], [0, -4], [5, -2], [-2, 1], [3, 1]]) {
                g.fillStyle = cl; g.beginPath(); g.arc(mx + ox, my + oy, 3.2, 0, 7); g.fill(); g.stroke();
              }
            }
          } else if (me === 'formaggi') {            // forme intere e uno spicchio tagliato
            for (const [mx, rr2] of [[-22, 9], [-2, 7], [17, 8]]) {
              g.fillStyle = cl; g.beginPath(); g.arc(mx, 2, rr2, 0, 7); g.fill(); g.stroke();
              g.fillStyle = 'rgba(0,0,0,.18)';
              for (const [ox, oy] of [[-3, -2], [2, 1], [0, 4]]) { g.beginPath(); g.arc(mx + ox, 2 + oy, 1.5, 0, 7); g.fill(); }
            }
            g.fillStyle = cl; g.beginPath(); g.moveTo(30, 2); g.lineTo(30, -6); g.lineTo(24, 5); g.closePath(); g.fill(); g.stroke();
          } else if (me === 'spezie') {              // sacchi aperti con il cono di polvere colorata
            const COL = [cl, '#c8a24a', '#7a3a2a', '#5a6b3a'];
            for (let i = 0; i < 4; i++) {
              const mx = -24 + i * 16;
              g.fillStyle = '#8a7048'; g.beginPath(); g.ellipse(mx, 4, 7, 5, 0, 0, 7); g.fill(); g.stroke();
              g.fillStyle = COL[i]; g.beginPath(); g.moveTo(mx - 6, 1); g.lineTo(mx, -7); g.lineTo(mx + 6, 1); g.closePath(); g.fill(); g.stroke();
            }
          } else if (me === 'pellami') {             // pelli stese sul banco e una appesa al tendone
            for (const [mx, my] of [[-20, 1], [4, 2]]) {
              g.fillStyle = cl; g.beginPath();
              g.moveTo(mx - 11, my); g.quadraticCurveTo(mx - 6, my - 9, mx + 2, my - 6);
              g.quadraticCurveTo(mx + 12, my - 4, mx + 10, my + 5);
              g.quadraticCurveTo(mx, my + 10, mx - 11, my); g.fill(); g.stroke();
            }
            g.fillStyle = _darkenHex(cl, 0.8); this._rr(g, 20, -18, 13, 22, 3); g.fill(); g.stroke();
          } else if (me === 'ferro') {               // ferramenta: chiodi, un ferro di cavallo, una lama
            g.fillStyle = cl;
            for (let i = 0; i < 6; i++) { const mx = -30 + i * 6; this._rr(g, mx, -2, 2, 11, 1); g.fill(); g.stroke(); }
            g.strokeStyle = cl; g.lineWidth = 3.2; g.beginPath(); g.arc(8, 3, 7, Math.PI * 0.15, Math.PI * 0.85, true); g.stroke();
            g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 1.2;
            g.fillStyle = cl; g.beginPath(); g.moveTo(22, -6); g.lineTo(31, 0); g.lineTo(22, 6); g.closePath(); g.fill(); g.stroke();
          } else {                                   // vino: botticelle in fila e due boccali
            for (const mx of [-24, -6, 12]) {
              g.fillStyle = cl; this._rr(g, mx, -6, 15, 15, 4); g.fill(); g.stroke();
              g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(mx, -2, 15, 2.4); g.fillRect(mx, 3, 15, 2.4);
            }
            g.fillStyle = '#cbbfa4'; g.beginPath(); g.arc(29, 3, 4.2, 0, 7); g.fill(); g.stroke();
          }
          // due cassette ai piedi del banco: dicono che la merce arriva e riparte
          g.fillStyle = '#5a4326'; g.strokeStyle = '#241708'; g.lineWidth = 1.5;
          this._rr(g, -33, 12, 14, 9, 2); g.fill(); g.stroke();
          this._rr(g, 19, 12, 14, 9, 2); g.fill(); g.stroke();
          break; }
        case 'bancone': {  // bancone: piano lungo, bordo chiaro e la fascia scura del davanti
          g.rotate(rot > 0.5 ? Math.PI / 2 : 0);
          g.fillStyle = 'rgba(0,0,0,.45)'; this._rr(g, -30, -8, 60, 22, 3); g.fill();
          const bg2 = g.createLinearGradient(0, -12, 0, 12); bg2.addColorStop(0, '#8a6238'); bg2.addColorStop(1, '#3e2a15');
          g.fillStyle = bg2; g.strokeStyle = '#241708'; g.lineWidth = 2.2; this._rr(g, -32, -12, 64, 22, 3); g.fill(); g.stroke();
          g.fillStyle = 'rgba(255,255,255,.12)'; this._rr(g, -30, -11, 60, 4, 2); g.fill();
          g.strokeStyle = 'rgba(0,0,0,.28)'; g.lineWidth = 1.1;
          for (let dx = -22; dx <= 22; dx += 11) { g.beginPath(); g.moveTo(dx, -10); g.lineTo(dx, 8); g.stroke(); } break; }
        case 'scaffale': { // scaffale a muro: tre ripiani e le boccette/libri colorati
          g.rotate(rot > 0.5 ? Math.PI / 2 : 0);
          g.fillStyle = 'rgba(0,0,0,.45)'; this._rr(g, -24, -12, 48, 26, 2); g.fill();
          g.fillStyle = '#3a2a18'; g.strokeStyle = '#1e1408'; g.lineWidth = 2; this._rr(g, -25, -14, 50, 26, 2); g.fill(); g.stroke();
          const COL = p.col ? [p.col, '#d8cdb4', p.col, '#8a6238'] : ['#9fe06a', '#c9a0ff', '#ffd97a', '#8bd6ff'];
          for (let r2 = 0; r2 < 3; r2++) {
            const yy = -11 + r2 * 8.5;
            g.fillStyle = '#5a4226'; g.fillRect(-23, yy + 6, 46, 2);
            for (let i = 0; i < 6; i++) { const xx = -21 + i * 7.2 + ((r2 * 3 + i) % 2) * 1.6;
              g.fillStyle = COL[(i + r2) % COL.length]; g.globalAlpha = 0.85;
              this._rr(g, xx, yy, 4.4, 6.4, 1); g.fill(); g.globalAlpha = 1; } }
          break; }
        case 'incudine': { // incudine: il corno e il ceppo, vista dall'alto
          g.rotate(rot * 0.3);
          g.fillStyle = 'rgba(0,0,0,.5)'; g.beginPath(); g.ellipse(0, 8, 17, 7, 0, 0, 7); g.fill();
          g.fillStyle = '#3a2a18'; g.strokeStyle = '#1e1408'; g.lineWidth = 2; g.beginPath(); g.ellipse(0, 6, 15, 8, 0, 0, 7); g.fill(); g.stroke();
          const ig = g.createLinearGradient(0, -10, 0, 8); ig.addColorStop(0, '#7b828e'); ig.addColorStop(1, '#33383f');
          g.fillStyle = ig; g.strokeStyle = '#181b21'; g.lineWidth = 2;
          g.beginPath(); g.moveTo(-13, -6); g.lineTo(9, -7); g.quadraticCurveTo(19, -3.5, 9, 0); g.lineTo(-13, 3); g.closePath(); g.fill(); g.stroke();
          g.fillStyle = 'rgba(255,255,255,.20)'; this._rr(g, -11, -5.4, 18, 2.6, 1); g.fill();
          g.fillStyle = '#ff8a2b'; g.globalAlpha = 0.55; g.beginPath(); g.arc(-2, -2, 3.4, 0, 7); g.fill(); g.globalAlpha = 1; break; }
        case 'alambicco': { // alambicco dell'erborista: caldaia, collo, boccia verde
          g.fillStyle = 'rgba(0,0,0,.42)'; g.beginPath(); g.ellipse(0, 9, 14, 6, 0, 0, 7); g.fill();
          g.fillStyle = '#4a4e57'; g.strokeStyle = '#1a1d22'; g.lineWidth = 1.8; this._rr(g, -9, 0, 18, 9, 2); g.fill(); g.stroke();
          const cl = p.col || '#9fe06a';
          const vg = g.createRadialGradient(-2, -6, 1, 0, -4, 10); vg.addColorStop(0, '#ffffff'); vg.addColorStop(0.45, cl); vg.addColorStop(1, 'rgba(20,40,25,.85)');
          g.fillStyle = vg; g.strokeStyle = 'rgba(220,235,255,.55)'; g.lineWidth = 1.4;
          g.beginPath(); g.arc(0, -4, 9, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = '#6b6f78'; g.lineWidth = 2.4; g.lineCap = 'round';
          g.beginPath(); g.moveTo(7, -8); g.quadraticCurveTo(15, -10, 14, -1); g.stroke(); g.lineCap = 'butt';
          g.fillStyle = cl; g.globalAlpha = 0.5; g.beginPath(); g.arc(14, 2, 2.6, 0, 7); g.fill(); g.globalAlpha = 1; break; }
        case 'tappeto': {  // tappeto: la stanza della cartomante deve avere un pavimento suo
          g.rotate(rot * 0.06);
          const cl2 = p.col || '#6b3a7a';
          g.globalAlpha = 0.9; g.fillStyle = cl2; this._rr(g, -30, -22, 60, 44, 3); g.fill();
          g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 2.4; this._rr(g, -26, -18, 52, 36, 2); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.30)'; g.lineWidth = 1.4; this._rr(g, -21, -13, 42, 26, 2); g.stroke();
          g.fillStyle = 'rgba(255,255,255,.13)'; g.beginPath(); g.ellipse(0, 0, 11, 8, 0, 0, 7); g.fill();
          g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2;
          for (const sx of [-30, 30]) { g.beginPath(); for (let i = -20; i <= 20; i += 5) { g.moveTo(sx, i); g.lineTo(sx + (sx < 0 ? -4 : 4), i + 2); } g.stroke(); }
          g.globalAlpha = 1; break; }
        case 'rastrelliera': { // rastrelliera d'armi del fabbro: il legno e tre lame appese
          g.rotate(rot > 0.5 ? Math.PI / 2 : 0);
          g.fillStyle = 'rgba(0,0,0,.42)'; this._rr(g, -22, -6, 44, 16, 2); g.fill();
          g.fillStyle = '#4a331b'; g.strokeStyle = '#241708'; g.lineWidth = 2; this._rr(g, -23, -8, 46, 15, 2); g.fill(); g.stroke();
          for (let i = -1; i <= 1; i++) {
            const xx = i * 13;
            g.strokeStyle = '#8d97a5'; g.lineWidth = 3; g.lineCap = 'round';
            g.beginPath(); g.moveTo(xx, -6); g.lineTo(xx, 6); g.stroke();
            g.strokeStyle = '#c2c9d4'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(xx, -5); g.lineTo(xx, 4); g.stroke();
            g.fillStyle = '#5a3d22'; this._rr(g, xx - 2.2, 4, 4.4, 4, 1); g.fill();
          }
          g.lineCap = 'butt'; break; }
        // v2.19 — IL BERSAGLIO da tiro dell'archeria. E' il mobile che dice cos'e' quella stanza: dal
        // vano della porta si vedono tre cerchi di paglia con le frecce piantate dentro, e non serve
        // leggere l'insegna. Le frecce sono tre e sempre nello stesso punto — niente casualita': il
        // villaggio dev'essere identico a ogni partita, se no e' un paese che si riarreda da solo.
        case 'bersaglio': {
          g.fillStyle = 'rgba(0,0,0,.38)'; g.beginPath(); g.ellipse(0, 17, 14, 5, 0, 0, 7); g.fill();
          g.strokeStyle = '#4a331b'; g.lineWidth = 3; g.lineCap = 'round';
          g.beginPath(); g.moveTo(-7, 17); g.lineTo(-2, 4); g.moveTo(7, 17); g.lineTo(2, 4); g.stroke();
          const bgP = g.createRadialGradient(-4, -8, 2, 0, -3, 15);
          bgP.addColorStop(0, '#e6d49a'); bgP.addColorStop(1, '#9a7f45');
          g.fillStyle = bgP; g.strokeStyle = '#3a2c12'; g.lineWidth = 2;
          g.beginPath(); g.arc(0, -3, 14, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(58,44,18,.55)'; g.lineWidth = 1.6; g.beginPath(); g.arc(0, -3, 10, 0, 7); g.stroke();
          g.strokeStyle = '#b8402e'; g.lineWidth = 2.4; g.beginPath(); g.arc(0, -3, 6.5, 0, 7); g.stroke();
          g.fillStyle = '#b8402e'; g.beginPath(); g.arc(0, -3, 2.6, 0, 7); g.fill();
          for (const fr of [[-5, -8, -0.5], [4, 1, 0.35], [6, -9, -0.15]]) {
            g.save(); g.translate(fr[0], fr[1]); g.rotate(fr[2]);
            g.strokeStyle = '#6b5432'; g.lineWidth = 1.8; g.beginPath(); g.moveTo(0, 0); g.lineTo(13, -4); g.stroke();
            g.fillStyle = '#d8d2c0'; g.beginPath(); g.moveTo(13, -4); g.lineTo(11, -7.4); g.lineTo(16.4, -5); g.closePath(); g.fill();
            g.restore();
          }
          g.lineCap = 'butt'; break; }
        case 'barrel': { g.fillStyle = '#5a3d22'; g.strokeStyle = '#31210f'; g.lineWidth = 2; this._rr(g, -8, -11, 16, 22, 3); g.fill(); g.stroke(); g.strokeStyle = '#8a6a3a'; g.beginPath(); g.moveTo(-8, -4); g.lineTo(8, -4); g.moveTo(-8, 4); g.lineTo(8, 4); g.stroke(); break; }
        case 'web': { g.strokeStyle = 'rgba(220,225,235,.18)'; g.lineWidth = 1; g.rotate(rot); for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(i) * 16, Math.sin(i * 1.7) * 16); g.stroke(); } for (let r = 5; r <= 15; r += 5) { g.beginPath(); g.arc(0, 0, r, 0, 7); g.stroke(); } break; }
        case 'pillar': { const th = this.theme || {}; g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 16, 15, 6, 0, 0, 7); g.fill(); g.fillStyle = th.wallTop || '#39406a'; g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 2; this._rr(g, -8, 12, 16, 6, 2); g.fill(); g.stroke(); const gr = g.createLinearGradient(-9, 0, 9, 0); gr.addColorStop(0, th.wall || '#2a2f4a'); gr.addColorStop(.5, th.wallTop || '#3d4570'); gr.addColorStop(1, th.wall || '#2a2f4a'); g.fillStyle = gr; this._rr(g, -9, -20, 18, 34, 2); g.fill(); g.stroke(); for (let i = -6; i <= 6; i += 4) { g.strokeStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.moveTo(i, -18); g.lineTo(i, 12); g.stroke(); } this._rr(g, -11, -26, 22, 8, 2); g.fillStyle = th.wallTop || '#3d4570'; g.fill(); g.stroke(); break; }
        case 'crystal': { const th = this.theme || {}; const col = th.accent || '#8be9ff'; g.rotate(rot * .2); g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 12, 12, 5, 0, 0, 7); g.fill(); const spikes = [[0, -22, 6, 12], [-9, -12, 4, 10], [8, -14, 5, 11]]; for (const sp of spikes) { const cx = sp[0], ty = sp[1], w = sp[2], h = sp[3]; g.save(); g.translate(cx, 6); const grd = g.createLinearGradient(0, ty, 0, 0); grd.addColorStop(0, '#ffffff'); grd.addColorStop(.4, col); grd.addColorStop(1, 'rgba(0,0,0,.4)'); g.fillStyle = grd; g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, ty); g.lineTo(w, ty + h); g.lineTo(0, 0); g.lineTo(-w, ty + h); g.closePath(); g.fill(); g.stroke(); g.restore(); } break; }
        case 'mushroom': { g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(0, 10, 9, 4, 0, 0, 7); g.fill(); g.fillStyle = '#d8cdb4'; g.strokeStyle = '#0a0c12'; g.lineWidth = 1.5; this._rr(g, -3, -2, 6, 12, 2); g.fill(); g.stroke(); const _th = this.theme || {}; const _gc = p.col || _th.accent || '#8bff9a'; const cap = g.createLinearGradient(0, -12, 0, 0); cap.addColorStop(0, _gc); cap.addColorStop(1, 'rgba(20,40,30,.92)'); g.fillStyle = cap; g.beginPath(); g.ellipse(0, -3, 11, 8, 0, Math.PI, 0); g.fill(); g.stroke(); g.fillStyle = 'rgba(255,255,255,.85)'; for (const d of [[-5, -5], [4, -6], [0, -3], [7, -3]]) { g.beginPath(); g.arc(d[0], d[1], 1.6, 0, 7); g.fill(); } break; }
        case 'chain': { g.rotate(rot); g.strokeStyle = 'rgba(150,160,175,.5)'; g.fillStyle = 'rgba(120,130,145,.5)'; g.lineWidth = 1.5; for (let i = -14; i <= 14; i += 6) { g.beginPath(); g.ellipse(0, i, 3.2, 4.5, 0, 0, 7); g.stroke(); } break; }
        case 'statue': { const th = this.theme || {}; g.fillStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.ellipse(0, 16, 14, 6, 0, 0, 7); g.fill(); g.fillStyle = th.wallTop || '#3a4260'; g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 2; this._rr(g, -11, 10, 22, 8, 2); g.fill(); g.stroke(); const bd = g.createLinearGradient(-10, 0, 10, 0); bd.addColorStop(0, '#4a5170'); bd.addColorStop(.5, '#6b7398'); bd.addColorStop(1, '#4a5170'); g.fillStyle = bd; g.beginPath(); g.moveTo(-9, 10); g.lineTo(-6, -10); g.quadraticCurveTo(0, -26, 6, -10); g.lineTo(9, 10); g.closePath(); g.fill(); g.stroke(); g.fillStyle = '#5a6288'; g.beginPath(); g.arc(0, -16, 6, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#3a4058'; g.fillRect(-2.2, -18, 1.6, 4); g.fillRect(1, -18, 1.6, 4); break; }
        case 'puddle': { const th = this.theme || {}; const col = th.accent || '#7de0ff'; g.globalAlpha = .5; g.rotate(rot); const grd = g.createRadialGradient(0, 0, 2, 0, 0, 18); grd.addColorStop(0, col); grd.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = grd; g.beginPath(); g.ellipse(0, 0, 18, 10, 0, 0, 7); g.fill(); g.globalAlpha = .35; g.strokeStyle = col; g.lineWidth = 1; g.beginPath(); g.ellipse(0, 0, 12, 6, 0, 0, 7); g.stroke(); g.globalAlpha = 1; break; }
        case 'lavapool': { g.rotate(rot); const grd = g.createRadialGradient(0, 0, 2, 0, 0, 20); grd.addColorStop(0, '#ffd24a'); grd.addColorStop(.5, '#ff5a1e'); grd.addColorStop(1, 'rgba(120,20,0,0)'); g.fillStyle = grd; g.beginPath(); g.ellipse(0, 0, 20, 12, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(255,120,30,.5)'; for (const d of [[-6, -2], [5, 1], [0, 3]]) { g.beginPath(); g.arc(d[0], d[1], 2.4, 0, 7); g.fill(); } break; }
        case 'flag': { const th = this.theme || {}; const col = p.col || th.accent || '#c56bff'; g.strokeStyle = '#3a2a18'; g.lineWidth = 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(-6, 16); g.lineTo(-6, -20); g.stroke(); const wave = Math.sin((p.r || 0) * 6) * 2; g.fillStyle = col; g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 1; g.beginPath(); g.moveTo(-6, -20); g.lineTo(12, -17 + wave); g.lineTo(12, -3 - wave); g.lineTo(-6, -6); g.closePath(); g.fill(); g.stroke(); g.lineCap = 'butt'; break; }
        case 'coffin': { g.rotate(rot); g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 16, 13, 5, 0, 0, 7); g.fill(); g.fillStyle = '#4a3722'; g.strokeStyle = '#22160b'; g.lineWidth = 2; g.beginPath(); g.moveTo(-8, -16); g.lineTo(8, -16); g.lineTo(11, 2); g.lineTo(0, 16); g.lineTo(-11, 2); g.closePath(); g.fill(); g.stroke(); g.fillStyle = '#6b533a'; g.beginPath(); g.moveTo(-2, -12); g.lineTo(2, -12); g.lineTo(2, -2); g.lineTo(5, -2); g.lineTo(0, 6); g.lineTo(-5, -2); g.lineTo(-2, -2); g.closePath(); g.fill(); break; }
        case 'tomb': { g.fillStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.ellipse(0, 15, 13, 5, 0, 0, 7); g.fill(); const gr = g.createLinearGradient(0, -20, 0, 14); gr.addColorStop(0, '#6a7080'); gr.addColorStop(1, '#3a3f4c'); g.fillStyle = gr; g.strokeStyle = '#20242e'; g.lineWidth = 2; g.beginPath(); g.moveTo(-11, 14); g.lineTo(-11, -8); g.quadraticCurveTo(-11, -20, 0, -20); g.quadraticCurveTo(11, -20, 11, -8); g.lineTo(11, 14); g.closePath(); g.fill(); g.stroke(); g.strokeStyle = 'rgba(20,22,28,.7)'; g.lineWidth = 2; g.beginPath(); g.moveTo(-6, -6); g.lineTo(6, -6); g.moveTo(0, -12); g.lineTo(0, -1); g.stroke(); g.fillStyle = 'rgba(30,60,40,.5)'; g.fillRect(-11, 10, 22, 4); break; }
        case 'corpse': { g.rotate(rot); g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(0, 6, 15, 5, 0, 0, 7); g.fill(); g.strokeStyle = '#d8d2bf'; g.fillStyle = '#cfc7b0'; g.lineWidth = 2; g.lineCap = 'round'; g.beginPath(); g.arc(-8, 0, 4.5, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#1a1a20'; g.beginPath(); g.arc(-9, -1, 1, 0, 7); g.arc(-6.5, -1, 1, 0, 7); g.fill(); g.strokeStyle = '#c9c1aa'; g.lineWidth = 3; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(-3, -3 + i * 2); g.lineTo(8, -4 + i * 2.2); g.stroke(); } g.lineWidth = 2; g.beginPath(); g.moveTo(2, 1); g.lineTo(11, 6); g.moveTo(2, 3); g.lineTo(10, 9); g.stroke(); g.lineCap = 'butt'; break; }
        case 'torture': { g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 16, 12, 5, 0, 0, 7); g.fill(); g.strokeStyle = '#3a2a18'; g.fillStyle = '#5a4326'; g.lineWidth = 3; this._rr(g, -3, -18, 6, 34, 1); g.fill(); g.stroke(); g.strokeStyle = '#2a1e10'; g.lineWidth = 3; g.beginPath(); g.moveTo(-14, -12); g.lineTo(14, -12); g.stroke(); g.save(); g.translate(0, -6); g.rotate((p.r || 0) * 6.28); g.strokeStyle = '#6b6f78'; g.fillStyle = '#4a4e57'; g.lineWidth = 2; g.beginPath(); g.arc(0, 0, 11, 0, 7); g.stroke(); for (let k = 0; k < 8; k++) { g.save(); g.rotate(k * Math.PI / 4); g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -11); g.stroke(); g.beginPath(); g.moveTo(-2, -11); g.lineTo(0, -15); g.lineTo(2, -11); g.fill(); g.restore(); } g.restore(); break; }
        case 'cage': { g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 18, 10, 4, 0, 0, 7); g.fill(); g.strokeStyle = '#2a1e10'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, -26); g.lineTo(0, -16); g.stroke(); g.strokeStyle = '#4a4e57'; g.fillStyle = 'rgba(20,22,28,.25)'; g.lineWidth = 2; const sway = Math.sin((p.r || 0) * 6.28 + this.time) * 0.12; g.save(); g.rotate(sway); g.beginPath(); g.arc(0, -14, 9, Math.PI, 0); g.stroke(); for (let x = -9; x <= 9; x += 4.5) { g.beginPath(); g.moveTo(x, -14); g.lineTo(x * 0.7, 10); g.stroke(); } g.beginPath(); g.ellipse(0, 10, 7, 3, 0, 0, 7); g.stroke(); g.fillStyle = '#d8d2c0'; g.beginPath(); g.arc(0, -1, 3.4, 0, 7); g.fill(); g.fillRect(-2.4, 2.2, 4.8, 3); g.fillStyle = '#1a1a22'; g.beginPath(); g.arc(-1.2, -1, 0.9, 0, 7); g.arc(1.2, -1, 0.9, 0, 7); g.fill(); g.strokeStyle = 'rgba(207,199,176,.85)'; g.lineWidth = 1; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(-2.6, 4 + i * 1.7); g.lineTo(2.6, 4 + i * 1.7); g.stroke(); } g.restore(); break; }
        case 'brazier': {
          g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(0, 15, 15, 6, 0, 0, 7); g.fill();
          g.strokeStyle = '#26262e'; g.lineWidth = 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(-8, 15); g.lineTo(-3, 2); g.moveTo(8, 15); g.lineTo(3, 2); g.moveTo(0, 16); g.lineTo(0, 2); g.stroke();
          const bg = g.createLinearGradient(0, -6, 0, 9); bg.addColorStop(0, '#4a4e57'); bg.addColorStop(1, '#22252b'); g.fillStyle = bg; g.strokeStyle = '#14161b'; g.lineWidth = 2; g.beginPath(); g.moveTo(-12, -4); g.quadraticCurveTo(0, 11, 12, -4); g.quadraticCurveTo(0, -1, -12, -4); g.closePath(); g.fill(); g.stroke();
          g.fillStyle = '#6b6f78'; g.beginPath(); g.ellipse(0, -4, 12, 4, 0, 0, 7); g.fill();
          g.fillStyle = '#5a2a12'; g.beginPath(); g.ellipse(0, -4, 9, 3, 0, 0, 7); g.fill();
          g.fillStyle = '#ff7a2b'; for (const d of [[-5, -4], [3, -5], [0, -3], [6, -3]]) { g.beginPath(); g.arc(d[0], d[1], 2, 0, 7); g.fill(); }
          g.fillStyle = '#ffd24a'; g.beginPath(); g.arc(0, -4, 2.4, 0, 7); g.fill(); g.lineCap = 'butt'; break; }
        case 'candelabra': {
          g.fillStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.ellipse(0, 16, 9, 4, 0, 0, 7); g.fill();
          g.strokeStyle = '#3a2f1e'; g.lineWidth = 3.4; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 16); g.lineTo(0, -14); g.stroke();
          g.lineWidth = 2.6; g.beginPath(); g.moveTo(0, -8); g.quadraticCurveTo(-10, -10, -10, -16); g.moveTo(0, -8); g.quadraticCurveTo(10, -10, 10, -16); g.stroke();
          g.fillStyle = '#5a4a2e'; g.beginPath(); g.ellipse(0, 16, 6, 2.4, 0, 0, 7); g.fill();
          g.fillStyle = '#e8dcc0'; g.strokeStyle = '#0a0c12'; g.lineWidth = 1.2; for (const cx of [-10, 0, 10]) { this._rr(g, cx - 2, -22, 4, 7, 1); g.fill(); g.stroke(); }
          g.fillStyle = '#ffd24a'; for (const cx of [-10, 0, 10]) { g.beginPath(); g.arc(cx, -23, 1.4, 0, 7); g.fill(); }
          g.lineCap = 'butt'; break; }
        case 'sack': {
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 12, 11, 5, 0, 0, 7); g.fill();
          const bg = g.createLinearGradient(0, -10, 0, 12); bg.addColorStop(0, '#a9925f'); bg.addColorStop(1, '#6e5c37'); g.fillStyle = bg; g.strokeStyle = '#3d3320'; g.lineWidth = 2;
          g.beginPath(); g.moveTo(-9, 12); g.quadraticCurveTo(-13, -4, -6, -8); g.quadraticCurveTo(-3, -11, 0, -8); g.quadraticCurveTo(3, -11, 6, -8); g.quadraticCurveTo(13, -4, 9, 12); g.quadraticCurveTo(0, 15, -9, 12); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = '#4a3d24'; g.lineWidth = 2; g.beginPath(); g.moveTo(-6, -8); g.lineTo(6, -8); g.stroke();
          g.fillStyle = '#c9b483'; g.beginPath(); g.moveTo(-3, -8); g.lineTo(0, -13); g.lineTo(3, -8); g.fill();
          g.strokeStyle = 'rgba(0,0,0,.2)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, -6); g.lineTo(0, 12); g.stroke(); break; }
        case 'cratebox': {
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 13, 13, 5, 0, 0, 7); g.fill();
          const bg = g.createLinearGradient(0, -12, 0, 12); bg.addColorStop(0, '#7a5630'); bg.addColorStop(1, '#4a341c'); g.fillStyle = bg; g.strokeStyle = '#241708'; g.lineWidth = 2; this._rr(g, -12, -12, 24, 24, 2); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.28)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(-12, -4); g.lineTo(12, -4); g.moveTo(-12, 4); g.lineTo(12, 4); g.stroke();
          g.strokeStyle = '#3a2a16'; g.lineWidth = 2.4; g.beginPath(); g.moveTo(-12, 12); g.lineTo(12, -12); g.stroke();
          g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1; g.strokeRect(-11, -11, 22, 22); break; }
        case 'demon_statue': {
          const th = this.theme || {}; const eyecol = th.accent || '#ff5a3b';
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 20, 16, 7, 0, 0, 7); g.fill();
          g.fillStyle = '#3a3540'; g.strokeStyle = '#17141c'; g.lineWidth = 2; this._rr(g, -13, 14, 26, 8, 2); g.fill(); g.stroke();
          const bg = g.createLinearGradient(-10, -10, 10, 20); bg.addColorStop(0, '#4a4450'); bg.addColorStop(1, '#26222c'); g.fillStyle = bg;
          g.beginPath(); g.moveTo(-10, 14); g.lineTo(-7, -6); g.quadraticCurveTo(-9, -14, -3, -16); g.lineTo(3, -16); g.quadraticCurveTo(9, -14, 7, -6); g.lineTo(10, 14); g.closePath(); g.fill(); g.stroke();
          g.fillStyle = '#332e3a'; g.beginPath(); g.moveTo(-7, -4); g.lineTo(-16, -10); g.lineTo(-14, 2); g.lineTo(-8, 6); g.closePath(); g.fill(); g.stroke();
          g.beginPath(); g.moveTo(7, -4); g.lineTo(16, -10); g.lineTo(14, 2); g.lineTo(8, 6); g.closePath(); g.fill(); g.stroke();
          g.fillStyle = '#3a3540'; g.beginPath(); g.arc(0, -18, 5, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = '#1a1720'; g.lineWidth = 2.4; g.lineCap = 'round'; g.beginPath(); g.moveTo(-4, -21); g.quadraticCurveTo(-10, -26, -7, -30); g.moveTo(4, -21); g.quadraticCurveTo(10, -26, 7, -30); g.stroke(); g.lineCap = 'butt';
          g.fillStyle = eyecol; g.shadowColor = eyecol; g.shadowBlur = 6; g.beginPath(); g.arc(-2, -18, 1.2, 0, 7); g.arc(2, -18, 1.2, 0, 7); g.fill(); g.shadowBlur = 0; break; }
        case 'stalagmite': { // v1.23 — stalagmite rocciosa dal pavimento
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 10, 10, 4, 0, 0, 7); g.fill();
          const gr = g.createLinearGradient(0, -26, 0, 10); gr.addColorStop(0, '#6a7180'); gr.addColorStop(1, '#2c313d'); g.fillStyle = gr; g.strokeStyle = '#191d26'; g.lineWidth = 2;
          g.beginPath(); g.moveTo(-8, 10); g.quadraticCurveTo(-5, -6, -1, -27); g.quadraticCurveTo(3, -6, 8, 10); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(255,255,255,.14)'; g.lineWidth = 1; g.beginPath(); g.moveTo(-1, -27); g.lineTo(-3, 8); g.stroke();
          g.strokeStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.moveTo(-1, -27); g.lineTo(3, 7); g.stroke();
          g.fillStyle = gr; g.strokeStyle = '#191d26'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(6, 10); g.quadraticCurveTo(8, 0, 10, -9); g.quadraticCurveTo(12, 2, 13, 10); g.closePath(); g.fill(); g.stroke(); break; }
        case 'skullpile': { // v1.23 — pila di teschi
          g.fillStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.ellipse(0, 12, 18, 6, 0, 0, 7); g.fill();
          const sk = (sx, sy, ss) => { g.save(); g.translate(sx, sy); g.scale(ss, ss); g.fillStyle = '#d8d2c0'; g.strokeStyle = '#8f8874'; g.lineWidth = 1.2; g.beginPath(); g.arc(0, -1, 6, 0, 7); g.fill(); g.stroke(); g.fillRect(-4, 3, 8, 4); g.fillStyle = '#1a1a22'; g.beginPath(); g.arc(-2.2, -1, 1.7, 0, 7); g.arc(2.2, -1, 1.7, 0, 7); g.fill(); g.restore(); };
          sk(-8, 8, 0.9); sk(9, 9, 0.85); sk(0, 10, 1.0); sk(-4, 2, 0.8); sk(6, 1, 0.75); sk(0, -5, 0.72);
          g.strokeStyle = '#cfc9b6'; g.lineWidth = 2.4; g.lineCap = 'round'; g.beginPath(); g.moveTo(-15, 10); g.lineTo(-6, 6); g.moveTo(12, 11); g.lineTo(17, 4); g.stroke(); g.lineCap = 'butt'; break; }
        case 'rubble': { // v1.23 — muro crollato / macerie
          const th = this.theme || {}; const bc = th.wallTop || '#39406a', bd = th.wall || '#242a40';
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 12, 21, 6, 0, 0, 7); g.fill();
          const blk = (bx, by, bw, bh, ang) => { g.save(); g.translate(bx, by); g.rotate(ang); const gr = g.createLinearGradient(0, -bh / 2, 0, bh / 2); gr.addColorStop(0, bc); gr.addColorStop(1, bd); g.fillStyle = gr; g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 1.5; this._rr(g, -bw / 2, -bh / 2, bw, bh, 2); g.fill(); g.stroke(); g.strokeStyle = 'rgba(255,255,255,.08)'; g.beginPath(); g.moveTo(-bw / 2 + 1, -bh / 2 + 1); g.lineTo(bw / 2 - 1, -bh / 2 + 1); g.stroke(); g.restore(); };
          blk(-10, 6, 16, 11, -0.15); blk(9, 8, 15, 10, 0.2); blk(0, -2, 17, 11, 0.05); blk(-4, 11, 12, 8, 0.32); blk(11, -1, 10, 8, -0.26);
          g.fillStyle = bd; for (const d of [[-17, 10], [17, 12], [-2, 13], [6, -9]]) { g.beginPath(); g.arc(d[0], d[1], 2.2, 0, 7); g.fill(); } break; }
        case 'bigweb': { // v1.23 — ragnatela gigante d'angolo
          g.strokeStyle = 'rgba(225,230,240,.22)'; g.lineWidth = 1.2; g.rotate(rot); const R2 = 28, spk = 7;
          for (let i = 0; i < spk; i++) { const a = (i / spk) * Math.PI * 2; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * R2, Math.sin(a) * R2); g.stroke(); }
          for (let ring = 6; ring <= R2; ring += 6) { g.beginPath(); for (let i = 0; i <= spk; i++) { const a = (i / spk) * Math.PI * 2; const rr2 = ring + Math.sin(a * 3) * 1.6; const x = Math.cos(a) * rr2, y = Math.sin(a) * rr2; if (i === 0) g.moveTo(x, y); else g.lineTo(x, y); } g.stroke(); }
          g.fillStyle = '#1a1620'; g.beginPath(); g.arc(R2 * 0.4, R2 * 0.22, 2.4, 0, 7); g.fill();
          g.strokeStyle = '#0a0810'; g.lineWidth = 0.8; for (let l = 0; l < 4; l++) { const a = l * 1.4; g.beginPath(); g.moveTo(R2 * 0.4, R2 * 0.22); g.lineTo(R2 * 0.4 + Math.cos(a) * 4, R2 * 0.22 + Math.sin(a) * 4); g.stroke(); } break; }
        case 'crystal_cluster': { // v1.23 — grappolo di cristalli luminosi (v1.75: colore proprio, se il prop ne ha uno)
          const th = this.theme || {}; const col = p.col || th.accent || '#8be9ff'; g.rotate(rot * 0.1);
          g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(0, 12, 16, 6, 0, 0, 7); g.fill();
          const sp = (cx, ty, w, h) => { g.save(); g.translate(cx, 8); const grd = g.createLinearGradient(0, ty, 0, 0); grd.addColorStop(0, '#ffffff'); grd.addColorStop(.4, col); grd.addColorStop(1, 'rgba(0,0,0,.5)'); g.fillStyle = grd; g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, ty); g.lineTo(w, ty + h * 0.5); g.lineTo(0, 0); g.lineTo(-w, ty + h * 0.5); g.closePath(); g.fill(); g.stroke(); g.restore(); };
          sp(0, -30, 7, 14); sp(-11, -18, 5, 12); sp(10, -22, 6, 13); sp(-6, -12, 4, 9); sp(6, -10, 4, 8); break; }
        case 'altar': { // v1.23 — altare rituale con candele
          const th = this.theme || {}; const acc = th.accent || '#ff5a3b';
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 16, 22, 7, 0, 0, 7); g.fill();
          g.fillStyle = '#3a3540'; g.strokeStyle = '#17141c'; g.lineWidth = 2; this._rr(g, -20, 10, 40, 8, 2); g.fill(); g.stroke(); this._rr(g, -16, 4, 32, 8, 2); g.fill(); g.stroke();
          const gr = g.createLinearGradient(0, -8, 0, 6); gr.addColorStop(0, '#5a5560'); gr.addColorStop(1, '#2c2833'); g.fillStyle = gr; this._rr(g, -15, -6, 30, 12, 2); g.fill(); g.stroke();
          g.fillStyle = 'rgba(150,20,30,.5)'; g.beginPath(); g.ellipse(0, 0, 9, 4, 0, 0, 7); g.fill();
          const cand = (cx) => { g.fillStyle = '#e8dcc0'; g.strokeStyle = '#0a0c12'; g.lineWidth = 1; this._rr(g, cx - 1.5, -14, 3, 8, 1); g.fill(); g.stroke(); g.fillStyle = '#ffd24a'; g.beginPath(); g.arc(cx, -15, 1.7, 0, 7); g.fill(); };
          cand(-13); cand(13);
          g.fillStyle = acc; g.globalAlpha = 0.5; g.beginPath(); g.arc(0, -1, 3.2, 0, 7); g.fill(); g.globalAlpha = 1; break; }
        case 'arch': { // v1.24 — arco diroccato (architettura)
          const th = this.theme || {}; const bc = th.wallTop || '#39406a', bd = th.wall || '#242a40';
          g.fillStyle = 'rgba(0,0,0,.32)'; g.beginPath(); g.ellipse(0, 20, 30, 8, 0, 0, 7); g.fill();
          const col = (x, w, h) => { const gr = g.createLinearGradient(x, 0, x + w, 0); gr.addColorStop(0, bc); gr.addColorStop(1, bd); g.fillStyle = gr; g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 2; this._rr(g, x, 20 - h, w, h, 2); g.fill(); g.stroke(); g.strokeStyle = 'rgba(0,0,0,.3)'; for (let yy = 20 - h + 8; yy < 20; yy += 8) { g.beginPath(); g.moveTo(x + 1, yy); g.lineTo(x + w - 1, yy); g.stroke(); } };
          col(-24, 12, 40); col(12, 12, 34);   // pilastri (destro spezzato)
          g.fillStyle = bc; g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 2; g.beginPath(); g.arc(0, -20, 24, Math.PI, Math.PI * 1.7, false); g.arc(0, -20, 12, Math.PI * 1.7, Math.PI, true); g.closePath(); g.fill(); g.stroke(); // arco spezzato
          g.fillStyle = bd; for (const d of [[18, 16], [-6, 19], [22, -2]]) { g.beginPath(); g.arc(d[0], d[1], 2.4, 0, 7); g.fill(); } break; }
        case 'stalactite': { // v1.24 — stalattite dal soffitto (appesa in alto)
          const gr = g.createLinearGradient(0, -30, 0, 6); gr.addColorStop(0, '#2c313d'); gr.addColorStop(1, '#6a7180'); g.fillStyle = gr; g.strokeStyle = '#191d26'; g.lineWidth = 2;
          g.beginPath(); g.moveTo(-7, -30); g.quadraticCurveTo(-4, -8, -1, 6); g.quadraticCurveTo(3, -8, 7, -30); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1; g.beginPath(); g.moveTo(-1, 6); g.lineTo(-3, -28); g.stroke();
          g.fillStyle = gr; g.strokeStyle = '#191d26'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(6, -30); g.quadraticCurveTo(8, -14, 10, -4); g.quadraticCurveTo(12, -16, 13, -30); g.closePath(); g.fill(); g.stroke();
          const th = this.theme || {}; if (th.id === 'ice') { g.fillStyle = 'rgba(180,230,255,.25)'; g.beginPath(); g.moveTo(-4, -20); g.lineTo(0, 4); g.lineTo(4, -20); g.fill(); }
          g.fillStyle = 'rgba(120,160,200,.35)'; g.beginPath(); g.arc(-1, 7, 1.4, 0, 7); g.fill(); break; } // goccia
        case 'gallows': { // v1.24 — forca / patibolo
          g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(0, 20, 20, 7, 0, 0, 7); g.fill();
          g.strokeStyle = '#3a2a18'; g.lineWidth = 5; g.lineCap = 'round'; g.beginPath(); g.moveTo(-14, 20); g.lineTo(-14, -26); g.lineTo(10, -26); g.stroke(); // palo + trave
          g.lineWidth = 3; g.beginPath(); g.moveTo(-14, -14); g.lineTo(-4, -20); g.stroke(); // rinforzo
          g.strokeStyle = '#151515'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(8, -26); g.lineTo(8, -12); g.stroke(); // corda
          g.strokeStyle = '#1a1a1a'; g.lineWidth = 2; g.beginPath(); g.arc(8, -9, 3.4, 0, 7); g.stroke(); // cappio
          g.fillStyle = '#d8d2c0'; g.strokeStyle = '#8f8874'; g.lineWidth = 1; g.beginPath(); g.arc(8, -3, 3, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#1a1a22'; g.beginPath(); g.arc(6.8, -3.4, 0.9, 0, 7); g.arc(9.2, -3.4, 0.9, 0, 7); g.fill(); break; } // teschio appeso
        case 'obelisk': { // v1.24 — obelisco arcano (rune incise, glow)
          const th = this.theme || {}; const acc = th.accent || '#c56bff';
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 20, 16, 7, 0, 0, 7); g.fill();
          g.fillStyle = '#2a2433'; g.strokeStyle = '#141019'; g.lineWidth = 2; this._rr(g, -12, 14, 24, 8, 2); g.fill(); g.stroke();
          const gr = g.createLinearGradient(-8, 0, 8, 0); gr.addColorStop(0, '#3a3448'); gr.addColorStop(0.5, '#4e4660'); gr.addColorStop(1, '#2a2434'); g.fillStyle = gr;
          g.beginPath(); g.moveTo(-9, 14); g.lineTo(-5, -26); g.lineTo(0, -32); g.lineTo(5, -26); g.lineTo(9, 14); g.closePath(); g.fill(); g.strokeStyle = '#141019'; g.lineWidth = 2; g.stroke();
          g.strokeStyle = acc; g.lineWidth = 1.4; g.globalAlpha = 0.5 + 0.3 * Math.sin(this.time * 2);
          g.beginPath(); g.moveTo(-2, -6); g.lineTo(2, -10); g.lineTo(-2, -14); g.moveTo(0, 0); g.lineTo(0, -20); g.moveTo(-2, -18); g.lineTo(2, -22); g.stroke(); g.globalAlpha = 1;
          g.fillStyle = acc; g.shadowColor = acc; g.shadowBlur = 8; g.beginPath(); g.arc(0, -30, 2, 0, 7); g.fill(); g.shadowBlur = 0; break; }
        case 'hanging_lantern': { // v1.24 — lanterna appesa (luce calda)
          g.strokeStyle = '#2a2418'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(0, -30); g.lineTo(0, -14); g.stroke();
          const sw = Math.sin(this.time * 1.5 + p.x) * 1.5; g.save(); g.translate(sw, 0);
          const lg = g.createRadialGradient(0, -8, 1, 0, -8, 16); lg.addColorStop(0, 'rgba(255,200,90,.85)'); lg.addColorStop(1, 'rgba(255,160,40,0)'); g.fillStyle = lg; g.beginPath(); g.arc(0, -8, 16, 0, 7); g.fill();
          g.fillStyle = '#2a2018'; g.strokeStyle = '#0a0c12'; g.lineWidth = 1.4; this._rr(g, -5, -16, 10, 15, 2); g.fill(); g.stroke();
          g.fillStyle = 'rgba(255,214,106,.95)'; this._rr(g, -3, -14, 6, 11, 1); g.fill();
          g.fillStyle = '#3a3018'; g.beginPath(); g.moveTo(-5, -16); g.lineTo(0, -20); g.lineTo(5, -16); g.fill(); g.stroke();
          g.strokeStyle = '#0a0c12'; g.beginPath(); g.arc(0, -21, 2, Math.PI, 0); g.stroke(); g.restore(); break; }
        case 'bloodstain': { // v1.24 — decal a terra (macchia scura irregolare, piatta)
          g.rotate(rot); g.fillStyle = 'rgba(60,10,14,.5)';
          g.beginPath(); for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2; const rr = 10 + Math.sin(i * 2.3) * 5 + (p.r * 4); const x = Math.cos(a) * rr, y = Math.sin(a) * rr * 0.72; if (i === 0) g.moveTo(x, y); else g.lineTo(x, y); } g.closePath(); g.fill();
          g.fillStyle = 'rgba(40,6,10,.55)'; for (const d of [[13, 6], [-15, -4], [10, -10], [-8, 12]]) { g.beginPath(); g.ellipse(d[0], d[1], 2.6 + p.r * 2, 1.8, 0, 0, 7); g.fill(); }
          g.fillStyle = 'rgba(90,16,20,.35)'; g.beginPath(); g.ellipse(-2, 1, 5, 3.4, 0, 0, 7); g.fill(); break; }
        case 'bridge': { // v1.25 — ponte di legno sopra una fenditura
          g.rotate(rot < 0.5 ? 0 : Math.PI / 2);
          g.fillStyle = 'rgba(0,0,0,.55)'; this._rr(g, -30, -13, 60, 26, 3); g.fill(); // fenditura sotto
          const pg = g.createLinearGradient(0, -13, 0, 13); pg.addColorStop(0, '#7a5630'); pg.addColorStop(1, '#4a341c');
          for (let x = -28; x < 30; x += 8) { g.fillStyle = pg; g.strokeStyle = '#241708'; g.lineWidth = 1.4; this._rr(g, x, -13, 7, 26, 1); g.fill(); g.stroke(); } // assi
          g.strokeStyle = '#2a1c0e'; g.lineWidth = 3; g.beginPath(); g.moveTo(-30, -11); g.lineTo(30, -11); g.moveTo(-30, 11); g.lineTo(30, 11); g.stroke(); // travi laterali
          g.fillStyle = '#8a6a3a'; for (const bx of [-28, -12, 4, 20]) { g.beginPath(); g.arc(bx + 3.5, -11, 1.2, 0, 7); g.arc(bx + 3.5, 11, 1.2, 0, 7); g.fill(); } // chiodi
          g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 1; for (let x = -24; x < 30; x += 8) { g.beginPath(); g.moveTo(x, -12); g.lineTo(x, 12); g.stroke(); } break; }
        case 'spiral_stairs': { // v1.25 — scala a chiocciola che scende nel buio
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 14, 24, 8, 0, 0, 7); g.fill();
          const rg = g.createRadialGradient(0, 0, 3, 0, 0, 22); rg.addColorStop(0, 'rgba(0,0,0,1)'); rg.addColorStop(0.6, 'rgba(0,0,0,.85)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; g.beginPath(); g.arc(0, 0, 22, 0, 7); g.fill(); // pozzo buio
          for (let i = 0; i < 9; i++) { const a = i * 0.62, r0 = 22 - i * 1.9; const gr = g.createLinearGradient(0, -3, 0, 3); gr.addColorStop(0, '#5a6070'); gr.addColorStop(1, '#2a3040'); g.save(); g.rotate(a); g.fillStyle = gr; g.strokeStyle = '#171b26'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(r0 * 0.35, -3.4); g.lineTo(r0, -5); g.lineTo(r0, 5); g.lineTo(r0 * 0.35, 3.4); g.closePath(); g.fill(); g.stroke(); g.restore(); } // gradini a spirale
          g.fillStyle = '#3a4050'; g.strokeStyle = '#171b26'; g.lineWidth = 1.5; g.beginPath(); g.arc(0, 0, 4, 0, 7); g.fill(); g.stroke(); break; } // colonna centrale
        case 'well': { // v1.25 — pozzo/fontana diroccato
          const th = this.theme || {}; const wc = th.accent || '#7de0ff';
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 16, 22, 8, 0, 0, 7); g.fill();
          const sg = g.createLinearGradient(0, -4, 0, 16); sg.addColorStop(0, '#5a5f6c'); sg.addColorStop(1, '#2c313c'); g.fillStyle = sg; g.strokeStyle = '#171b24'; g.lineWidth = 2; g.beginPath(); g.ellipse(0, 8, 20, 10, 0, 0, 7); g.fill(); g.stroke(); // base
          g.fillStyle = '#0a1016'; g.beginPath(); g.ellipse(0, 5, 14, 7, 0, 0, 7); g.fill(); // buco
          g.fillStyle = wc; g.globalAlpha = 0.35 + 0.15 * Math.sin(this.time * 2); g.beginPath(); g.ellipse(0, 5, 11, 5.4, 0, 0, 7); g.fill(); g.globalAlpha = 1; // acqua
          g.fillStyle = 'rgba(255,255,255,.25)'; g.beginPath(); g.ellipse(-3, 3.5, 3.5, 1.6, 0, 0, 7); g.fill();
          // mattoni sul bordo
          g.strokeStyle = '#171b24'; g.lineWidth = 1.2; for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2; g.beginPath(); g.moveTo(Math.cos(a) * 16, 8 + Math.sin(a) * 8); g.lineTo(Math.cos(a) * 20, 8 + Math.sin(a) * 10); g.stroke(); }
          // arco e carrucola
          g.strokeStyle = '#3a2a18'; g.lineWidth = 3; g.beginPath(); g.moveTo(-16, 4); g.lineTo(-14, -18); g.lineTo(14, -18); g.lineTo(16, 4); g.stroke(); g.fillStyle = '#5a4630'; g.beginPath(); g.arc(0, -18, 3, 0, 7); g.fill(); g.strokeStyle = '#1a1a1a'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, -15); g.lineTo(0, 2); g.stroke(); break; }
        case 'grate': { // v1.25 — grata/inferriata sul pavimento con vapore
          g.rotate(rot < 0.5 ? 0 : Math.PI / 2);
          g.fillStyle = '#0a0d12'; this._rr(g, -18, -14, 36, 28, 2); g.fill();
          g.fillStyle = 'rgba(0,0,0,.6)'; this._rr(g, -16, -12, 32, 24, 2); g.fill(); // pozzo scuro
          g.strokeStyle = '#2e343f'; g.lineWidth = 3; g.lineCap = 'round';
          for (let x = -14; x <= 14; x += 7) { g.beginPath(); g.moveTo(x, -12); g.lineTo(x, 12); g.stroke(); }
          for (let y = -10; y <= 10; y += 7) { g.beginPath(); g.moveTo(-15, y); g.lineTo(15, y); g.stroke(); }
          g.strokeStyle = '#4a5260'; g.lineWidth = 2.5; g.strokeRect(-16, -12, 32, 24); // cornice
          g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1; for (let x = -14; x <= 14; x += 7) { g.beginPath(); g.moveTo(x - 1, -12); g.lineTo(x - 1, 12); g.stroke(); }
          g.fillStyle = '#5a6270'; for (const c of [[-16, -12], [16, -12], [-16, 12], [16, 12]]) { g.beginPath(); g.arc(c[0], c[1], 2, 0, 7); g.fill(); } g.lineCap = 'butt'; break; } // il vapore lo emette il render
        case 'giant_crystal': { // v1.25 — cristallo gigante (landmark luminoso)
          const th = this.theme || {}; const col = th.accent || '#8be9ff';
          g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.ellipse(0, 20, 20, 8, 0, 0, 7); g.fill();
          const face = (pts, lite) => { g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.closePath(); const gr = g.createLinearGradient(0, -46, 0, 18); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.4, col); gr.addColorStop(1, 'rgba(0,0,0,.55)'); g.fillStyle = gr; g.globalAlpha = lite; g.fill(); g.globalAlpha = 1; g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 1.2; g.stroke(); };
          face([[0, -48], [12, -6], [0, 18], [-3, -6]], 1);      // faccia principale
          face([[0, -48], [-3, -6], [0, 18], [-13, -2]], 0.72);  // faccia sinistra (piu scura)
          face([[0, -48], [12, -6], [7, -30]], 0.9);
          // schegge alla base
          for (const s of [[-16, 10, 6, 16], [15, 12, 5, 12]]) { g.save(); g.translate(s[0], 8); const gr = g.createLinearGradient(0, -s[3], 0, 0); gr.addColorStop(0, '#ffffff'); gr.addColorStop(.5, col); gr.addColorStop(1, 'rgba(0,0,0,.5)'); g.fillStyle = gr; g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, -s[3]); g.lineTo(s[2], -s[3] * 0.4); g.lineTo(0, 4); g.lineTo(-s[2], -s[3] * 0.4); g.closePath(); g.fill(); g.stroke(); g.restore(); }
          g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.moveTo(2, -30); g.lineTo(4, -16); g.lineTo(0, -20); g.closePath(); g.fill(); break; }
        case 'gem_statue': { // v1.25 — statua rituale con gemma incastonata (luminosa)
          const th = this.theme || {}; const gem = th.accent || '#c56bff';
          g.fillStyle = 'rgba(0,0,0,.42)'; g.beginPath(); g.ellipse(0, 22, 18, 7, 0, 0, 7); g.fill();
          g.fillStyle = '#33303a'; g.strokeStyle = '#17141c'; g.lineWidth = 2; this._rr(g, -14, 16, 28, 8, 2); g.fill(); g.stroke(); // base
          const bg = g.createLinearGradient(-10, 0, 10, 0); bg.addColorStop(0, '#4a4652'); bg.addColorStop(.5, '#6a6474'); bg.addColorStop(1, '#3a3640'); g.fillStyle = bg; g.strokeStyle = '#17141c'; g.lineWidth = 2;
          g.beginPath(); g.moveTo(-9, 16); g.lineTo(-7, -8); g.quadraticCurveTo(-9, -18, -4, -22); g.lineTo(4, -22); g.quadraticCurveTo(9, -18, 7, -8); g.lineTo(9, 16); g.closePath(); g.fill(); g.stroke(); // corpo incappucciato
          g.fillStyle = '#2c2833'; g.beginPath(); g.arc(0, -24, 5.5, 0, 7); g.fill(); g.stroke(); // testa
          // braccia che reggono la gemma al petto
          g.strokeStyle = '#4a4652'; g.lineWidth = 4; g.lineCap = 'round'; g.beginPath(); g.moveTo(-6, -6); g.lineTo(0, -2); g.lineTo(6, -6); g.stroke(); g.lineCap = 'butt';
          // GEMMA luminosa
          g.save(); g.shadowColor = gem; g.shadowBlur = 12; const gg = g.createRadialGradient(0, -2, 0, 0, -2, 6); gg.addColorStop(0, '#ffffff'); gg.addColorStop(0.5, gem); gg.addColorStop(1, 'rgba(0,0,0,.3)'); g.fillStyle = gg; g.beginPath(); g.moveTo(0, -8); g.lineTo(5, -2); g.lineTo(0, 4); g.lineTo(-5, -2); g.closePath(); g.fill(); g.restore();
          g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 1; g.stroke(); break; }
        // ===== v2.21 — GLI OGGETTI CHE APPARTENGONO A UN TEMA SOLO ==========================
        // Fino a qui le 24 scene della grotta erano quasi tutte condivise fra due o piu' temi: solo
        // la `fungaia` era della sola foresta. Il risultato e' che lava, ghiaccio e arcano non avevano
        // un oggetto che parlasse di loro, e cambiare il colore della roccia non bastava a farli
        // sembrare posti diversi. Questi disegni servono a quello: due scene esclusive per tema.
        case 'chest': { // v2.21 — LA CASSA. Esisteva da sempre nella scena `deposito` (putC('chest', ...))
          // ma nel renderer non c'era il suo ramo: cadeva in fondo allo switch e non disegnava niente.
          // Per tutto quel tempo il deposito ha avuto un oggetto invisibile.
          g.rotate(rot < 0.5 ? 0 : Math.PI / 2);
          g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(2, 13, 17, 6, 0, 0, 7); g.fill();
          const cg = g.createLinearGradient(0, -14, 0, 13); cg.addColorStop(0, '#7a5630'); cg.addColorStop(1, '#3f2c16');
          g.fillStyle = cg; g.strokeStyle = '#1e1408'; g.lineWidth = 2; this._rr(g, -16, -13, 32, 26, 2); g.fill(); g.stroke();
          g.fillStyle = '#8a6438'; this._rr(g, -16, -13, 32, 11, 2); g.fill(); g.stroke();   // il coperchio bombato
          g.strokeStyle = '#c9a24a'; g.lineWidth = 2.4;                                       // le bande di ferro dorato
          g.beginPath(); g.moveTo(-9, -13); g.lineTo(-9, 13); g.moveTo(9, -13); g.lineTo(9, 13); g.stroke();
          g.fillStyle = '#c9a24a'; g.strokeStyle = '#6a4d14'; g.lineWidth = 1.2;
          this._rr(g, -4, -5, 8, 9, 1.5); g.fill(); g.stroke();                               // la serratura
          g.fillStyle = '#2a1e08'; g.beginPath(); g.arc(0, -1, 1.6, 0, 7); g.fill();
          g.strokeStyle = 'rgba(255,225,160,.22)'; g.lineWidth = 1.2;
          g.beginPath(); g.moveTo(-15, -12); g.lineTo(15, -12); g.stroke(); break; }
        // ---- CRIPTA -------------------------------------------------------------------------
        case 'loculo': { // nicchia murata nella parete: la lastra sigillata con la targa
          g.fillStyle = 'rgba(0,0,0,.40)'; this._rr(g, -20, -15, 42, 32, 2); g.fill();
          g.fillStyle = '#2a2d36'; g.strokeStyle = '#141720'; g.lineWidth = 2; this._rr(g, -21, -16, 42, 32, 2); g.fill(); g.stroke();
          const lg = g.createLinearGradient(-16, 0, 16, 0); lg.addColorStop(0, '#6e7484'); lg.addColorStop(.5, '#555b69'); lg.addColorStop(1, '#3c414d');
          g.fillStyle = lg; g.strokeStyle = '#161922'; g.lineWidth = 2; this._rr(g, -17, -12, 34, 24, 1.5); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(20,23,32,.6)'; g.lineWidth = 1.4;                               // l'iscrizione consumata
          for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(-11, -5 + i * 5); g.lineTo(-11 + 8 + (i * 5) % 11, -5 + i * 5); g.stroke(); }
          g.fillStyle = '#8f9099'; g.strokeStyle = '#161922'; g.lineWidth = 1.2;                // i quattro chiodi
          for (const d of [[-14, -9], [14, -9], [-14, 9], [14, 9]]) { g.beginPath(); g.arc(d[0], d[1], 2, 0, 7); g.fill(); g.stroke(); }
          g.fillStyle = 'rgba(30,60,40,.45)'; g.fillRect(-21, 10, 42, 6); break; }
        case 'urna': { // urna cineraria sul suo piedistallo. E' anche l'oggetto rompibile (v2.21)
          g.fillStyle = 'rgba(0,0,0,.36)'; g.beginPath(); g.ellipse(2, 14, 13, 5, 0, 0, 7); g.fill();
          g.fillStyle = '#3e434f'; g.strokeStyle = '#181b24'; g.lineWidth = 2; this._rr(g, -11, 8, 22, 8, 1.5); g.fill(); g.stroke();
          const ug = g.createLinearGradient(-9, 0, 9, 0); ug.addColorStop(0, '#8a7a5c'); ug.addColorStop(.45, '#b6a37c'); ug.addColorStop(1, '#6d6047');
          g.fillStyle = ug; g.strokeStyle = '#2a2418'; g.lineWidth = 2; g.lineJoin = 'round';
          g.beginPath(); g.moveTo(-6, 8); g.quadraticCurveTo(-12, -2, -8, -10); g.lineTo(8, -10);
          g.quadraticCurveTo(12, -2, 6, 8); g.closePath(); g.fill(); g.stroke();
          g.fillStyle = '#c9b68c'; g.strokeStyle = '#2a2418'; g.lineWidth = 1.8;
          g.beginPath(); g.ellipse(0, -11, 10, 4, 0, 0, 7); g.fill(); g.stroke();               // il coperchio
          g.fillStyle = '#8a7a5c'; g.beginPath(); g.arc(0, -13, 2.6, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(42,36,24,.55)'; g.lineWidth = 1.3;
          g.beginPath(); g.moveTo(-9, -3); g.lineTo(9, -3); g.stroke(); break; }
        case 'catafalco': { // il catafalco col sudario: un morto che nessuno ha mai seppellito
          g.rotate(rot < 0.5 ? 0 : Math.PI / 2);
          g.fillStyle = 'rgba(0,0,0,.38)'; this._rr(g, -22, -12, 48, 28, 3); g.fill();
          g.fillStyle = '#4a4028'; g.strokeStyle = '#231c0e'; g.lineWidth = 2;                  // il cavalletto di legno
          for (const dx of [-16, 14]) { this._rr(g, dx, -13, 6, 26, 1); g.fill(); g.stroke(); }
          const pg = g.createLinearGradient(0, -14, 0, 14); pg.addColorStop(0, '#5d5238'); pg.addColorStop(1, '#382f1c');
          g.fillStyle = pg; g.strokeStyle = '#231c0e'; g.lineWidth = 2; this._rr(g, -24, -9, 48, 18, 2); g.fill(); g.stroke();
          const sg = g.createLinearGradient(0, -8, 0, 8); sg.addColorStop(0, '#cfc7b2'); sg.addColorStop(1, '#8e8877');
          g.fillStyle = sg; g.strokeStyle = '#4a463c'; g.lineWidth = 1.6; g.lineJoin = 'round';  // il sudario
          g.beginPath(); g.moveTo(-20, -6); g.quadraticCurveTo(-14, -10, -6, -7); g.quadraticCurveTo(4, -10, 12, -6);
          g.quadraticCurveTo(20, -3, 20, 3); g.quadraticCurveTo(10, 8, -2, 6); g.quadraticCurveTo(-14, 8, -20, 4);
          g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(74,70,60,.7)'; g.lineWidth = 1.2;                                // le pieghe
          for (const dx of [-12, -3, 7]) { g.beginPath(); g.moveTo(dx, -6); g.lineTo(dx + 2, 5); g.stroke(); }
          g.strokeStyle = '#6b5a3a'; g.lineWidth = 2;                                            // le corde che lo legano
          g.beginPath(); g.moveTo(-10, -9); g.lineTo(-10, 9); g.moveTo(9, -9); g.lineTo(9, 9); g.stroke(); break; }
        // ---- LAVA ---------------------------------------------------------------------------
        case 'colata': { // colata rappresa: crosta nera con le crepe ancora vive sotto
          g.rotate(rot);
          const cr = g.createRadialGradient(0, 0, 2, 0, 0, 24); cr.addColorStop(0, '#ff8a2b'); cr.addColorStop(.35, '#7a2408'); cr.addColorStop(1, 'rgba(60,20,8,0)');
          g.fillStyle = cr; g.beginPath(); g.ellipse(0, 0, 24, 15, 0, 0, 7); g.fill();
          g.fillStyle = '#211613'; g.strokeStyle = '#0e0907'; g.lineWidth = 2; g.lineJoin = 'round';
          g.beginPath();                                                                        // la crosta, un lobo irregolare
          const pt = [[-20, -3], [-13, -10], [-2, -12], [9, -9], [19, -2], [16, 7], [4, 12], [-8, 11], [-18, 5]];
          pt.forEach((q, i) => i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = '#ff6a1e'; g.lineWidth = 2.2; g.lineCap = 'round';                     // le crepe che bruciano
          g.beginPath(); g.moveTo(-15, 1); g.lineTo(-5, -3); g.lineTo(3, 2); g.lineTo(14, -1); g.stroke();
          g.strokeStyle = '#ffc24a'; g.lineWidth = 1.1;
          g.beginPath(); g.moveTo(-6, -6); g.lineTo(-2, -2); g.moveTo(6, 6); g.lineTo(10, 3); g.stroke();
          g.fillStyle = '#ffd88a'; for (const d of [[-9, -2], [2, 0], [11, 1]]) { g.beginPath(); g.arc(d[0], d[1], 1.4, 0, 7); g.fill(); }
          g.lineCap = 'butt'; break; }
        case 'sfiatatoio': { // la fumarola: un buco che respira
          g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(0, 8, 18, 7, 0, 0, 7); g.fill();
          g.fillStyle = '#332420'; g.strokeStyle = '#140c09'; g.lineWidth = 2; g.lineJoin = 'round';
          g.beginPath();                                                                        // il cono di scorie
          for (let k = 0; k <= 13; k++) { const a = k / 13 * 6.283, rd = 17 * (.82 + ((k * 37) % 11) / 44);
            const x = Math.cos(a) * rd, y = Math.sin(a) * rd * .68; k ? g.lineTo(x, y) : g.moveTo(x, y); }
          g.closePath(); g.fill(); g.stroke();
          g.fillStyle = '#4a342c'; g.beginPath(); g.ellipse(0, 0, 12, 8, 0, 0, 7); g.fill();
          const bg2 = g.createRadialGradient(0, 0, 0, 0, 0, 9); bg2.addColorStop(0, '#ffd24a'); bg2.addColorStop(.45, '#ff5a1e'); bg2.addColorStop(1, '#2a1008');
          g.fillStyle = bg2; g.beginPath(); g.ellipse(0, 0, 8, 5, 0, 0, 7); g.fill();            // la bocca incandescente
          g.fillStyle = '#ffe9a8'; g.beginPath(); g.ellipse(-1, -1, 2.6, 1.6, 0, 0, 7); g.fill();
          g.strokeStyle = 'rgba(255,120,40,.35)'; g.lineWidth = 1.4;
          g.beginPath(); g.ellipse(0, 0, 11, 7, 0, 0, 7); g.stroke(); break; }
        // ---- FORESTA ------------------------------------------------------------------------
        case 'tronco': { // tronco caduto, coperto di muschio: e' lungo, e da' una direzione alla radura
          g.rotate(rot);
          g.fillStyle = 'rgba(0,0,0,.34)'; this._rr(g, -26, -7, 56, 20, 8); g.fill();
          const tg = g.createLinearGradient(0, -11, 0, 11); tg.addColorStop(0, '#6a543a'); tg.addColorStop(.55, '#4a3a26'); tg.addColorStop(1, '#2c2114');
          g.fillStyle = tg; g.strokeStyle = '#1a1209'; g.lineWidth = 2; this._rr(g, -28, -11, 56, 22, 10); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(26,18,9,.5)'; g.lineWidth = 1.2;                                 // le venature
          for (const dy of [-5, 0, 5]) { g.beginPath(); g.moveTo(-24, dy); g.lineTo(22, dy + (dy ? 1 : 0)); g.stroke(); }
          g.fillStyle = '#7d6a4a'; g.strokeStyle = '#1a1209'; g.lineWidth = 1.8;                 // il taglio in testa
          g.beginPath(); g.ellipse(-28, 0, 4.5, 11, 0, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = '#5a4a32'; g.lineWidth = 1; for (const rr2 of [3, 6, 9]) { g.beginPath(); g.ellipse(-28, 0, rr2 * .42, rr2, 0, 0, 7); g.stroke(); }
          g.fillStyle = 'rgba(96,148,70,.55)'; g.globalAlpha = .85;                               // il muschio sul dorso
          for (const d of [[-14, -7, 9, 3.4], [2, -8, 11, 3], [17, -6, 7, 3]]) { g.beginPath(); g.ellipse(d[0], d[1], d[2], d[3], 0, 0, 7); g.fill(); }
          g.globalAlpha = 1;
          g.fillStyle = '#8fbf5a'; for (const d of [[-6, -9], [10, -9]]) { g.beginPath(); g.arc(d[0], d[1], 2.2, 0, 7); g.fill(); } break; }
        case 'felce': { // felce: tre fronde dentellate. Bassa, non copre niente
          g.rotate(rot);
          g.fillStyle = 'rgba(0,0,0,.24)'; g.beginPath(); g.ellipse(0, 7, 13, 5, 0, 0, 7); g.fill();
          const fr = (ang, L, col) => { g.save(); g.rotate(ang);
            g.strokeStyle = col; g.lineWidth = 1.8; g.lineCap = 'round';
            g.beginPath(); g.moveTo(0, 6); g.quadraticCurveTo(1, 6 - L * .6, 0, 6 - L); g.stroke();
            g.lineWidth = 1.1;
            for (let i = 1; i <= 6; i++) { const t = i / 7, yy = 6 - L * t, ww = 5.5 * (1 - t) + 1.5;
              g.beginPath(); g.moveTo(0, yy); g.lineTo(-ww, yy - 2.2); g.moveTo(0, yy); g.lineTo(ww, yy - 2.2); g.stroke(); }
            g.restore(); };
          fr(-0.55, 15, '#2f5a28'); fr(0.55, 15, '#2f5a28'); fr(0, 18, '#3f7a34');
          g.lineCap = 'butt'; break; }
        case 'radice': { // radici che hanno sfondato il pavimento: il bosco si riprende la cripta
          g.rotate(rot);
          g.fillStyle = 'rgba(0,0,0,.30)'; g.beginPath(); g.ellipse(0, 2, 22, 14, 0, 0, 7); g.fill();
          g.fillStyle = '#231a10'; g.beginPath(); g.ellipse(0, 0, 15, 9, 0, 0, 7); g.fill();      // il buco nel pavimento
          const th2 = this.theme || {}; g.fillStyle = th2.wallTop || '#3a4260'; g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1.4;
          for (const d of [[-17, -6, 9, 6, -.3], [15, -8, 8, 5, .25], [-13, 9, 8, 5, .4], [16, 7, 7, 5, -.2]]) {
            g.save(); g.translate(d[0], d[1]); g.rotate(d[4]); this._rr(g, -d[2] / 2, -d[3] / 2, d[2], d[3], 1.5); g.fill(); g.stroke(); g.restore(); }
          g.strokeStyle = '#4a3a24'; g.lineCap = 'round'; g.lineJoin = 'round';                   // le radici
          for (let i = 0; i < 6; i++) { const a = i / 6 * 6.283 + .4;
            g.lineWidth = 4.5 - i % 3; g.beginPath(); g.moveTo(0, 0);
            g.quadraticCurveTo(Math.cos(a) * 11, Math.sin(a) * 8, Math.cos(a + .35) * 22, Math.sin(a + .35) * 15); g.stroke(); }
          g.strokeStyle = '#6a5436'; g.lineWidth = 1.4;
          for (let i = 0; i < 4; i++) { const a = i / 4 * 6.283 + .9;
            g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * 14, Math.sin(a) * 10); g.stroke(); }
          g.fillStyle = '#4a3a24'; g.beginPath(); g.arc(0, 0, 4, 0, 7); g.fill();
          g.lineCap = 'butt'; break; }
        // ---- GHIACCIO -----------------------------------------------------------------------
        case 'congelato': { // una sagoma dentro il ghiaccio. Si vede che era qualcuno, non si vede chi
          g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(2, 18, 16, 6, 0, 0, 7); g.fill();
          const ig = g.createLinearGradient(-12, -24, 12, 18); ig.addColorStop(0, 'rgba(190,232,248,.92)');
          ig.addColorStop(.5, 'rgba(120,180,210,.82)'); ig.addColorStop(1, 'rgba(46,86,110,.90)');
          g.fillStyle = ig; g.strokeStyle = '#16303e'; g.lineWidth = 2; g.lineJoin = 'round';
          g.beginPath(); g.moveTo(-13, 18); g.lineTo(-10, -14); g.lineTo(-2, -25); g.lineTo(8, -20);
          g.lineTo(13, 2); g.lineTo(10, 18); g.closePath(); g.fill(); g.stroke();
          g.globalAlpha = .40; g.fillStyle = '#0d2530';                                            // la sagoma, sfocata dal ghiaccio
          g.beginPath(); g.arc(-1, -12, 4.6, 0, 7); g.fill();
          g.beginPath(); g.moveTo(-6, -7); g.lineTo(5, -7); g.lineTo(7, 9); g.lineTo(-7, 9); g.closePath(); g.fill();
          g.beginPath(); g.moveTo(-6, -6); g.lineTo(-11, 3); g.lineTo(-8, 4); g.lineTo(-4, -4); g.closePath(); g.fill();
          g.globalAlpha = 1;
          g.strokeStyle = 'rgba(232,250,255,.55)'; g.lineWidth = 1.6;                               // i riflessi sul blocco
          g.beginPath(); g.moveTo(-8, -12); g.lineTo(-5, 10); g.moveTo(6, -16); g.lineTo(9, 4); g.stroke();
          g.strokeStyle = 'rgba(232,250,255,.85)'; g.lineWidth = 2.4;
          g.beginPath(); g.moveTo(-10, -13); g.lineTo(-2, -24); g.lineTo(8, -19); g.stroke(); break; }
        case 'ghiacciolo': { // colonna di ghiaccio dal pavimento al soffitto
          const th3 = this.theme || {}; const acc = th3.accent || '#a8f0ff';
          g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(0, 12, 11, 5, 0, 0, 7); g.fill();
          const kg = g.createLinearGradient(-7, -26, 7, 12); kg.addColorStop(0, 'rgba(226,248,255,.95)');
          kg.addColorStop(.55, 'rgba(126,196,222,.85)'); kg.addColorStop(1, 'rgba(40,86,112,.9)');
          g.fillStyle = kg; g.strokeStyle = '#173444'; g.lineWidth = 1.8; g.lineJoin = 'round';
          g.beginPath(); g.moveTo(-8, 12); g.lineTo(-4, -10); g.lineTo(-1, -28); g.lineTo(3, -10); g.lineTo(8, 12); g.closePath(); g.fill(); g.stroke();
          g.beginPath(); g.moveTo(6, 12); g.lineTo(9, -4); g.lineTo(12, -13); g.lineTo(13, 12); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(240,253,255,.75)'; g.lineWidth = 1.4;
          g.beginPath(); g.moveTo(-1, -27); g.lineTo(-4, 10); g.stroke();
          g.strokeStyle = 'rgba(20,50,66,.55)'; g.lineWidth = 1.2;
          g.beginPath(); g.moveTo(-1, -26); g.lineTo(3, 10); g.stroke();
          g.save(); g.globalAlpha = .28; g.fillStyle = acc; g.beginPath(); g.ellipse(0, -6, 9, 20, 0, 0, 7); g.fill(); g.restore(); break; }
        // ---- ARCANO -------------------------------------------------------------------------
        case 'cerchio': { // il cerchio rituale dipinto sul pavimento, con le candele consumate
          const th4 = this.theme || {}; const arc = th4.accent || '#d59bff';
          g.rotate(rot);
          g.save(); g.globalAlpha = .22; const ag = g.createRadialGradient(0, 0, 4, 0, 0, 30);
          ag.addColorStop(0, arc); ag.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = ag;
          g.beginPath(); g.arc(0, 0, 30, 0, 7); g.fill(); g.restore();
          g.strokeStyle = arc; g.globalAlpha = .55; g.lineWidth = 2;
          g.beginPath(); g.arc(0, 0, 25, 0, 7); g.stroke();
          g.lineWidth = 1.2; g.beginPath(); g.arc(0, 0, 20, 0, 7); g.stroke();
          g.lineWidth = 1.6; g.beginPath();                                                        // il pentacolo
          for (let k = 0; k <= 5; k++) { const a = -1.5708 + k * 2 * 6.283 / 5, x = Math.cos(a) * 20, y = Math.sin(a) * 20; k ? g.lineTo(x, y) : g.moveTo(x, y); }
          g.closePath(); g.stroke();
          g.lineWidth = 1; for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283;                   // le rune sul bordo
            g.save(); g.translate(Math.cos(a) * 22.5, Math.sin(a) * 22.5); g.rotate(a + 1.5708);
            g.beginPath(); g.moveTo(-1.6, -2.2); g.lineTo(1.6, -2.2); g.moveTo(0, -2.2); g.lineTo(0, 2.2); g.moveTo(-1.4, 2.2); g.lineTo(1.4, 2.2); g.stroke(); g.restore(); }
          g.globalAlpha = 1;
          for (const k of [0, 1, 2, 3]) { const a = -1.5708 + k * 1.5708;                           // quattro moccoli
            const cx = Math.cos(a) * 25, cy = Math.sin(a) * 25;
            g.fillStyle = '#e8dcc0'; g.strokeStyle = '#3a3428'; g.lineWidth = 1.2;
            this._rr(g, cx - 2, cy - 5, 4, 8, 1); g.fill(); g.stroke();
            g.fillStyle = '#ffd24a'; g.beginPath(); g.arc(cx, cy - 6, 1.5, 0, 7); g.fill(); }
          break; }
        case 'leggio': { // leggio con il libro aperto: qualcuno stava leggendo quando e' successo
          const th5 = this.theme || {}; const arc2 = th5.accent || '#d59bff';
          g.fillStyle = 'rgba(0,0,0,.36)'; g.beginPath(); g.ellipse(2, 16, 14, 6, 0, 0, 7); g.fill();
          g.fillStyle = '#3a2c1c'; g.strokeStyle = '#1c1409'; g.lineWidth = 2;
          g.beginPath(); g.ellipse(0, 14, 11, 4.5, 0, 0, 7); g.fill(); g.stroke();                 // il piede
          g.fillStyle = '#4a3a26'; this._rr(g, -3.5, -6, 7, 19, 1.5); g.fill(); g.stroke();        // l'asta
          g.save(); g.rotate(-.06);
          const bg3 = g.createLinearGradient(0, -14, 0, 2); bg3.addColorStop(0, '#6a5436'); bg3.addColorStop(1, '#3f3120');
          g.fillStyle = bg3; g.strokeStyle = '#1c1409'; g.lineWidth = 2; this._rr(g, -17, -14, 34, 16, 2); g.fill(); g.stroke();
          g.fillStyle = '#e4dcc4'; g.strokeStyle = '#8a8270'; g.lineWidth = 1.2;                    // le due pagine
          g.beginPath(); g.moveTo(-15, -12); g.lineTo(-1, -13); g.lineTo(-1, -1); g.lineTo(-15, -2); g.closePath(); g.fill(); g.stroke();
          g.beginPath(); g.moveTo(1, -13); g.lineTo(15, -12); g.lineTo(15, -2); g.lineTo(1, -1); g.closePath(); g.fill(); g.stroke();
          g.strokeStyle = 'rgba(70,60,44,.6)'; g.lineWidth = .9;
          for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(-13, -10 + i * 2.4); g.lineTo(-3, -10.4 + i * 2.4);
            g.moveTo(3, -10.4 + i * 2.4); g.lineTo(13, -10 + i * 2.4); g.stroke(); }
          g.strokeStyle = '#2c2418'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(0, -13); g.lineTo(0, -1); g.stroke();
          g.save(); const rg = g.createRadialGradient(0, -7, 1, 0, -7, 14);                          // la luce che sale dal testo
          rg.addColorStop(0, arc2); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.globalAlpha = .5;
          g.fillStyle = rg; g.beginPath(); g.arc(0, -7, 14, 0, 7); g.fill(); g.restore();
          g.restore(); break; }
        // ---- v2.21 — I TRE OGGETTI CHE FANNO QUALCOSA --------------------------------------
        case 'barile': { // BARILE ESPLOSIVO. Deve distinguersi a colpo d'occhio dal `barrel` normale,
          // altrimenti il giocatore non puo' scegliere se colpirlo: doghe scure, cerchi rossi, la
          // miccia accesa. Se si somigliassero, l'esplosione sarebbe una punizione arrivata dal nulla.
          g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(2, 12, 12, 5, 0, 0, 7); g.fill();
          const bb = g.createLinearGradient(-9, 0, 9, 0); bb.addColorStop(0, '#2a1a14'); bb.addColorStop(.45, '#4a2c1e'); bb.addColorStop(1, '#22150f');
          g.fillStyle = bb; g.strokeStyle = '#140b07'; g.lineWidth = 2; this._rr(g, -10, -12, 20, 24, 3); g.fill(); g.stroke();
          g.strokeStyle = '#b8402a'; g.lineWidth = 2.6;                                             // i cerchi rossi
          g.beginPath(); g.moveTo(-10, -5); g.lineTo(10, -5); g.moveTo(-10, 5); g.lineTo(10, 5); g.stroke();
          g.strokeStyle = 'rgba(255,150,90,.30)'; g.lineWidth = 1;
          g.beginPath(); g.moveTo(-9, -6); g.lineTo(9, -6); g.moveTo(-9, 4); g.lineTo(9, 4); g.stroke();
          g.fillStyle = '#e8b13a'; g.strokeStyle = '#140b07'; g.lineWidth = 1.4;                    // il tappo
          g.beginPath(); g.arc(0, -12, 4, 0, 7); g.fill(); g.stroke();
          g.strokeStyle = '#7a6a4a'; g.lineWidth = 2; g.lineCap = 'round';                          // la miccia
          g.beginPath(); g.moveTo(0, -13); g.quadraticCurveTo(5, -19, 9, -17); g.stroke();
          g.fillStyle = '#ff9a3a'; g.beginPath(); g.arc(9.5, -17, 2, 0, 7); g.fill();
          g.fillStyle = '#ffe08a'; g.beginPath(); g.arc(9.5, -17, 1, 0, 7); g.fill();
          g.lineCap = 'butt'; break; }
        case 'saracinesca': { // la grata che chiude il ripostiglio. Sotto e' pavimento gia' cotto:
          // quando la leva la apre basta smettere di disegnarla — la mappa sotto c'e' gia'.
          g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(-24, -24, 48, 48);
          g.strokeStyle = '#4a5260'; g.lineWidth = 5; g.lineCap = 'round';
          for (let x = -17; x <= 17; x += 11.5) { g.beginPath(); g.moveTo(x, -22); g.lineTo(x, 22); g.stroke(); }
          g.strokeStyle = '#2e343f'; g.lineWidth = 2.4;
          for (let x = -17; x <= 17; x += 11.5) { g.beginPath(); g.moveTo(x - 1.2, -22); g.lineTo(x - 1.2, 22); g.stroke(); }
          g.strokeStyle = '#5a6270'; g.lineWidth = 4;
          for (const y of [-14, 0, 14]) { g.beginPath(); g.moveTo(-22, y); g.lineTo(22, y); g.stroke(); }
          g.strokeStyle = '#6e7684'; g.lineWidth = 3; g.strokeRect(-23, -23, 46, 46);
          g.fillStyle = '#8f98a6'; for (const d of [[-17, -14], [0, -14], [17, -14], [-17, 14], [0, 14], [17, 14]]) { g.beginPath(); g.arc(d[0], d[1], 2, 0, 7); g.fill(); }
          g.lineCap = 'butt'; break; }
        case 'leva': { // la catena da tirare. Il braccio cambia posa quando la grata e' aperta: e'
          // l'unico modo che ha il giocatore, tornando indietro, di sapere di averla gia' tirata.
          const giu = !!p.tirata;
          g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(2, 15, 12, 5, 0, 0, 7); g.fill();
          g.fillStyle = '#3a4048'; g.strokeStyle = '#161a20'; g.lineWidth = 2; this._rr(g, -10, 8, 20, 9, 2); g.fill(); g.stroke();
          const mg = g.createLinearGradient(-7, 0, 7, 0); mg.addColorStop(0, '#565d68'); mg.addColorStop(.5, '#7a828e'); mg.addColorStop(1, '#3f4550');
          g.fillStyle = mg; g.strokeStyle = '#161a20'; g.lineWidth = 2; this._rr(g, -7, -14, 14, 24, 2); g.fill(); g.stroke();
          g.save(); g.translate(0, -12); g.rotate(giu ? 0.95 : -0.55);
          g.strokeStyle = '#8a929e'; g.lineWidth = 4; g.lineCap = 'round';
          g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -16); g.stroke();
          g.fillStyle = '#c9a24a'; g.strokeStyle = '#5a4514'; g.lineWidth = 1.4;
          g.beginPath(); g.arc(0, -18, 3.6, 0, 7); g.fill(); g.stroke();
          g.restore();
          g.strokeStyle = '#6e7684'; g.lineWidth = 1.6;                                             // la catena che scende
          for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(giu ? 11 + i * 1.2 : -11 - i * 1.2, -6 + i * 4.5, 2.2, 3.2, 0, 0, 7); g.stroke(); }
          g.fillStyle = giu ? '#7de08a' : '#e0b23a'; g.beginPath(); g.arc(0, -2, 2.6, 0, 7); g.fill();
          g.lineCap = 'butt'; break; }
      }
      g.restore();
    },
    _bakeCamp(g, p) { g.save(); g.translate(p.x, p.y); g.fillStyle = '#4a4030'; g.strokeStyle = '#2a2418'; g.lineWidth = 2; g.beginPath(); g.moveTo(-30, 14); g.lineTo(-14, -14); g.lineTo(2, 14); g.closePath(); g.fill(); g.stroke(); g.strokeStyle = '#1a160e'; g.beginPath(); g.moveTo(-14, -14); g.lineTo(-14, 14); g.stroke(); g.fillStyle = '#3a4152'; for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; g.beginPath(); g.arc(18 + Math.cos(a) * 12, 4 + Math.sin(a) * 8, 3.5, 0, 7); g.fill(); } g.strokeStyle = '#3a2a18'; g.lineWidth = 4; g.lineCap = 'round'; g.beginPath(); g.moveTo(12, 6); g.lineTo(24, 2); g.moveTo(13, 2); g.lineTo(23, 8); g.stroke(); g.restore(); p.fx = p.x + 18; p.fy = p.y + 4; },
    burst(x, y, c, n, spd, life) { for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, s = MU.rand(spd * 0.3, spd); this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: life || 0.5, t: life || 0.5, color: c, r: MU.rand(1.5, 3.5) }); } },
    // v1.61 — DRENAGGIO del Fuoco Fatuo: scintille che RISALGONO dal giocatore verso il fatuo (direzione
    // = chi sta rubando a chi). Riusa il sistema particellare esistente: nessuna passata di disegno nuova.
    drain(fx, fy, tx, ty, c) {
      const col = c || '#7dffea'; const dx = tx - fx, dy = ty - fy; const d = Math.hypot(dx, dy) || 1;
      const nx = dx / d, ny = dy / d;
      for (let i = 0; i < 9; i++) {
        const k = i / 9, sp = MU.rand(150, 260);
        const jx = -ny * MU.rand(-9, 9), jy = nx * MU.rand(-9, 9);
        this.particles.push({ x: fx + nx * d * k * 0.35 + jx, y: fy + ny * d * k * 0.35 + jy,
          vx: nx * sp + jx * 2, vy: ny * sp + jy * 2, life: 0.34, t: 0.34, color: col, r: MU.rand(1.4, 2.8), over: true });
      }
      this.ring(fx, fy, col, 3, 22, 0.3);
    },
    ring(x, y, c, r0, r1, life) { this.flashes.push({ x, y, color: c, r0, r1, life, t: life }); },
    // v1.83 — LA PARATA. Non un anello (l'anello e' tondo, e direbbe "da ogni parte"): un ARCO, largo
    // quanto il cono dello scudo e messo dove stai guardando. Serve a far vedere la regola mentre
    // succede — hai incassato meno perche' eri girato di la'.
    para(x, y, a, semi) { this.pare.push({ x, y, a, semi: semi || 1.22, life: 0.3, t: 0.3 }); },
    _drawPare(ctx) {
      for (const p of this.pare) {
        const k = p.t / p.life;
        ctx.save(); ctx.globalAlpha = 0.25 + k * 0.6; ctx.strokeStyle = '#dbe6f2'; ctx.lineCap = 'round';
        ctx.lineWidth = 3 + (1 - k) * 3;
        ctx.beginPath(); ctx.arc(p.x, p.y, 24 + (1 - k) * 8, p.a - p.semi, p.a + p.semi); ctx.stroke();
        ctx.globalAlpha = (0.18 + k * 0.35); ctx.strokeStyle = '#8fb6d8'; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(p.x, p.y, 30 + (1 - k) * 10, p.a - p.semi * 0.8, p.a + p.semi * 0.8); ctx.stroke();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
    },
    // v1.66 — FENDENTE del guerriero. Il server manda raggio e apertura REALI dell'area che ferisce: il
    // disegno usa quelli e non un'approssimazione, cosi' il giocatore impara la portata guardando, non
    // provando. Dura poco (0.22s) perche' deve leggersi come un colpo, non come una zona.
    swing(x, y, a, rad, half, crit) { this.swings.push({ x, y, a, rad, half, crit: !!crit, t: 0, dur: 0.22 }); },
    // v1.70 — LEVEL UP sopra la testa. Non e' un floater qualunque: resta agganciato al GIOCATORE (che
    // nel frattempo si muove e continua a combattere), sale piano, e sotto ha il numero del livello.
    // Dura 1,6s perche' deve farsi leggere anche in mezzo a un'ondata.
    levelUp(who, lv) { this.levelUps.push({ who, lv: lv || 0, t: 0, dur: 1.6 }); },
    _drawLevelUps(ctx, world) {
      if (!this.levelUps.length) return;
      const r = C.PLAYER_RADIUS * (C.VIS_SCALE || 1);
      for (const L of this.levelUps) {
        const p = (world.players || []).find(x => x.i === L.who); if (!p || p.d) continue;
        const u = L.t / L.dur;
        const su = u < 0.18 ? (u / 0.18) : 1;                 // scatto d'ingresso
        const sc = 0.6 + 0.4 * Math.min(1, su * 1.35);
        const a = u > 0.72 ? (1 - (u - 0.72) / 0.28) : 1;
        const y = p.y - r - 54 - u * 26;
        ctx.save(); ctx.globalAlpha = Math.max(0, a);
        ctx.translate(p.x, y); ctx.scale(sc, sc); ctx.textAlign = 'center';
        ctx.font = 'bold 22px Segoe UI';
        ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(10,12,18,.92)'; ctx.strokeText('LEVEL UP', 0, 0);
        const g = this._grad('lvup', () => { const q = ctx.createLinearGradient(0, -16, 0, 6); q.addColorStop(0, '#fff6d0'); q.addColorStop(0.55, '#ffd27a'); q.addColorStop(1, '#e0a52c'); return q; });
        ctx.fillStyle = g; ctx.fillText('LEVEL UP', 0, 0);
        if (L.lv) { ctx.font = 'bold 14px Segoe UI'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,12,18,.92)';
          ctx.strokeText('Lv. ' + L.lv, 0, 17); ctx.fillStyle = '#ffe9a8'; ctx.fillText('Lv. ' + L.lv, 0, 17); }
        ctx.textAlign = 'left'; ctx.restore();
      }
      ctx.globalAlpha = 1;
    },
    // v1.66 — memoria dell'ultimo attacco, per animare l'arco del ladro e il bastone del mago.
    heroAtk(id) { if (id != null) this.atk[id] = 0.20; },
    floater(x, y, text, c, big) { this.floaters.push({ x, y, text, color: c, life: big ? 1.0 : 0.7, t: big ? 1.0 : 0.7, big }); },
    chain(x1, y1, x2, y2) { this.chains.push({ x1, y1, x2, y2, t: 0.18 }); },
    addShake(v) { this.shake = Math.min(20, this.shake + v); },
    fire(x, y, n, up) { for (let i = 0; i < n; i++) { const a = MU.rand(-0.5, 0.5); this.particles.push({ x: x + MU.rand(-6, 6), y: y + MU.rand(-3, 3), vx: Math.sin(a) * 18, vy: -(up || 40) - Math.random() * 30, life: MU.rand(0.4, 0.8), t: 0, fire: true, r: MU.rand(3, 7), over: true }); } },
    render(dt, world) {
      this.frameN = (this.frameN || 0) + 1;   // v1.90.2 — serve a spalmare le cotture delle pose
      this.time += dt; const ctx = this.ctx; ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); ctx.clearRect(0, 0, this.w, this.h); if (!this.map || !world) return;
      // v2.0.2 — SOLO NEL VILLAGGIO: fuori dai bordi della mappa si vedeva il fondo viola della pagina.
      // Prima non si notava perche' il velo scuro copriva tutto; adesso che il villaggio e' illuminato
      // quell'angolo di viola stonava. Si riempie di roccia: fuori dal paese c'e' la montagna, non il vuoto.
      if (this.map.lit) { ctx.fillStyle = (this.theme && this.theme.wall) || '#15171c'; ctx.fillRect(0, 0, this.w, this.h); }
      // v2.3 — le lanterne dei girovaghi si azzerano QUI, a ogni fotogramma, non quando si disegnano.
      // Se si azzerassero solo la' dentro, uscendo dal villaggio l'elenco resterebbe pieno e in mezzo
      // alla grotta si accenderebbero delle lanterne senza nessuno che le porta. Era gia' successo.
      if (this._giroLuci) this._giroLuci.length = 0;
      const me = world.me; if (me) { this.cam.x += (me.x - this.cam.x) * Math.min(1, dt * 8); this.cam.y += (me.y - this.cam.y) * Math.min(1, dt * 8); }
      let sx = 0, sy = 0; if (this.shake > 0.1) { sx = MU.rand(-this.shake, this.shake); sy = MU.rand(-this.shake, this.shake); this.shake *= 0.86; }
      const camX = this.cam.x - this.w / 2 + sx, camY = this.cam.y - this.h / 2 + sy; ctx.save(); ctx.translate(-camX, -camY);
      if (this.mapCanvas) ctx.drawImage(this.mapCanvas, 0, 0);
      this._drawEdgeTendrils(ctx, world);   // v1.64 — i tentacoli escono dalla roccia vicino a te
      // v2.0.1 — LE FIAMME SI RITAGLIANO SUL RIQUADRO. Fino a qui ogni torcia della mappa veniva disegnata
      // a ogni fotogramma, fuori schermo comprese, e ognuna semina scintille: con le 11 torce di una
      // caverna non si notava, col villaggio illuminato (oltre cento) sarebbero state cento fiamme e ~29
      // particelle nuove per fotogramma buttate via. La luce (_drawLighting) si ritagliava gia' cosi'.
      const _vis = (x, y, m) => x > camX - m && y > camY - m && x < camX + this.w + m && y < camY + this.h + m;
      for (const tc of this.torches) if (_vis(tc.x, tc.y, 40)) this._flame(ctx, tc.x, tc.y, 0.8);
      for (const cf of this.campfires) { const fx = cf.fx || cf.x, fy = cf.fy || cf.y; if (_vis(fx, fy, 70)) this._flame(ctx, fx, fy, 1.5); }
      // v2.0 — nel VILLAGGIO questo cerchio verde non si disegna piu': al centro della piazza c'e' la
      // faglia vera (world.fg), disegnata da _drawFaglia come a fine ondata. Due portali sovrapposti
      // sarebbero stati due modi diversi di dire la stessa cosa nello stesso punto.
      if (this.map.exit && !(world.phase === 'market' && world.fg)) {
        const ex = this.map.exit.x * this.map.tile + this.map.tile / 2, ey = this.map.exit.y * this.map.tile + this.map.tile / 2;
        // v1.52 — nel MERCATO il portale e' l'unica via d'uscita: piu' grande, verde, con etichetta EXIT.
        const market = world.phase === 'market';
        const pr = (market ? 46 : 22) + Math.sin(this.time * 3) * (market ? 9 : 5);
        const gr = ctx.createRadialGradient(ex, ey, 2, ex, ey, pr);
        gr.addColorStop(0, market ? 'rgba(180,255,190,.95)' : 'rgba(140,233,255,.9)');
        gr.addColorStop(1, market ? 'rgba(60,220,120,0)' : 'rgba(60,160,255,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ex, ey, pr, 0, 7); ctx.fill();
        if (market) {
          const pu = 0.55 + 0.45 * Math.sin(this.time * 3);
          ctx.save();
          ctx.strokeStyle = 'rgba(120,255,170,' + (0.45 + pu * 0.45).toFixed(3) + ')'; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.arc(ex, ey, 34 + pu * 4, 0, 7); ctx.stroke();
          ctx.globalCompositeOperation = 'lighter';
          const cg = ctx.createLinearGradient(ex, ey - 130, ex, ey);
          cg.addColorStop(0, 'rgba(120,255,170,0)'); cg.addColorStop(1, 'rgba(120,255,170,' + (0.10 + pu * 0.12).toFixed(3) + ')');
          ctx.fillStyle = cg; ctx.fillRect(ex - 17, ey - 130, 34, 130);
          ctx.restore();
          ctx.save(); ctx.textAlign = 'center';
          ctx.font = 'bold 26px Segoe UI'; ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(0,0,0,.85)';
          ctx.strokeText('EXIT', ex, ey - 54);
          ctx.fillStyle = 'rgba(170,255,205,' + (0.75 + pu * 0.25).toFixed(3) + ')'; ctx.fillText('EXIT', ex, ey - 54);
          ctx.font = 'bold 12px Segoe UI'; ctx.lineWidth = 4;
          ctx.strokeText('entra per proseguire', ex, ey - 38);
          ctx.fillStyle = 'rgba(205,255,225,.9)'; ctx.fillText('entra per proseguire', ex, ey - 38);
          ctx.restore(); ctx.textAlign = 'left';
        }
      }
      for (const o of (world.xp || [])) this._drawXp(ctx, o);
      for (const o of (world.coins || [])) this._drawCoin(ctx, o);
      for (const it of (world.items || [])) this._drawItem(ctx, it);
      for (const c of (world.crates || [])) this._drawCrate(ctx, c);
      // v2.21 — grate ancora chiuse, oggetti rompibili, leve. Vengono dallo snapshot e non dalla mappa
      // cotta: devono poter sparire (l'urna rotta, il barile scoppiato, la grata aperta) e cambiare
      // posa (la leva tirata), e il fondo cotto una volta sola non sa fare ne' l'una ne' l'altra cosa.
      { const mp = this.map || {};
        for (const q of (mp.grate || [])) if (!this.grateAperte.has(q.id)) this._bakeProp(ctx, { type: 'saracinesca', x: q.x, y: q.y, s: 1, r: 0 });
        for (const l of (mp.leve || [])) this._bakeProp(ctx, { type: 'leva', x: l.x, y: l.y, s: 1, r: 0, tirata: this.grateAperte.has(l.gid) }); }
      for (const o of (world.ogg || [])) this._bakeProp(ctx, { type: o.k ? 'barile' : 'urna', x: o.x, y: o.y, s: (o.s || 100) / 100, r: 0 });
      if (world.merch) this._drawMerchant(ctx, world.merch, me);
      if (world.merchD) this._drawDarkMerchant(ctx, world.merchD, me);
      // v2.19 — I MERCANTI LI DISEGNA QUESTA RIGA, TUTTI E SETTE. Prima il fabbro era saltato qui e
      // ridisegnato piu' sotto da `_drawGearMerchant`, che si pescava la posizione dallo snapshot: con
      // un negozio solo era un dettaglio, con tre sarebbero tre casi speciali. Adesso il banco lo
      // segnala l'ALONE (`_beaconBottega`), disegnato sotto al mercante subito prima di lui, e il
      // mercante e' un mercante come gli altri. Un caso speciale in meno, e due negozi in piu'.
      if (this.map && this.map.village) { for (const n of this.map.village.npcs) { if (n.shop) this._beaconBottega(ctx, n); this._drawVendor(ctx, n); }
        for (const e of (this.map.village.extras || [])) this._drawVendor(ctx, e, { noLabel: 1 });   // v1.75 — gente del villaggio
        // v2.3 — e quelli che camminano. Il tempo e' quello della PARTITA, non quello del client: cosi'
        // in cooperativa tutti li vedono nello stesso punto senza che il server mandi una riga.
        { const gir = this.map.village.girovaghi || [], tt = (world.tick != null ? world.tick : this.time);
          const luci = this._giroLuci || (this._giroLuci = []);
          const P = this._giroP || (this._giroP = { x: 0, y: 0, face: 0, fermo: false, kind: 'patron', act: '' });
          for (const g of gir) { this._rottaPunto(g, tt, P);
            if (P.x < camX - 90 || P.y < camY - 90 || P.x > camX + this.w + 90 || P.y > camY + this.h + 90) continue;
            P.act = P.fermo ? 'guarda' : '';
            this._drawVendor(ctx, P, { noLabel: 1 });
            // v2.3 — LA LANTERNA. Col villaggio buio (v2.4: VILL_BUIO) chi cammina diventava una sagoma
            // nera: la vita c'era e non si vedeva. Ognuno se la porta dietro, e la luce la fa la passata
            // degli aloni piu' sotto — qui si segna solo dove sta. E' anche il motivo per cui adesso le
            // strade si leggono: le percorre della gente con la luce in mano.
            luci.push(P.x, P.y); } } }
      // v2.19 — la riga che disegnava il fabbro dallo snapshot non c'e' piu': i mercanti li disegna
      // il giro degli npc qui sopra, alone compreso. Lo snapshot continua a mandare le posizioni
      // (`gmerchs`) perche' servono al minimappa, che il villaggio disegnato non ce l'ha.
      for (const wd of (world.wdrops || [])) this._drawWeapon(ctx, wd);
      // v1.81 — LE RAGNATELE. Sono pavimento, non un effetto: si disegnano sotto a tutto, con i fili
      // veri (raggi + spirali irregolari) e non un cerchio pieno, se no si confondono con le zone che
      // fanno danno. Sbiadiscono man mano che scadono: quanto e' pallida dice quanto le resta.
      for (const w of (world.tele || [])) {
        // I FILI SONO BIANCHI, non del colore del ragno. Con tre ragni in campo tre tele colorate una
        // sopra l'altra sembravano un incantesimo; la seta e' seta. Del ragno resta solo un velo di
        // tinta nel riempimento, che dice QUALE tela e' senza gridarlo.
        const a = 0.14 + w.p * 0.36;
        ctx.save(); ctx.translate(w.x, w.y); ctx.globalAlpha = a;
        const gr = ctx.createRadialGradient(0, 0, 2, 0, 0, w.r);
        gr.addColorStop(0, this._rgba(w.c || '#cfe0ea', 0.10)); gr.addColorStop(0.7, this._rgba(w.c || '#cfe0ea', 0.05)); gr.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(0, 0, w.r, w.r * 0.62, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#e6eef4'; ctx.lineWidth = 0.9; ctx.globalAlpha = a * 0.60;
        const NR = 9;
        for (let i = 0; i < NR; i++) { const an = (i / NR) * Math.PI * 2 + (w.x % 7) * 0.1; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(an) * w.r, Math.sin(an) * w.r * 0.62); ctx.stroke(); }
        for (let k = 1; k <= 4; k++) {
          const q = k / 4; ctx.beginPath();
          for (let i = 0; i <= NR; i++) { const an = (i / NR) * Math.PI * 2 + (w.x % 7) * 0.1; const d = q * (1 + Math.sin(an * 3 + k) * 0.07); const px = Math.cos(an) * w.r * d, py = Math.sin(an) * w.r * 0.62 * d; if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
          ctx.closePath(); ctx.stroke();
        }
        ctx.restore(); ctx.globalAlpha = 1;
      }
      for (const z of (world.zones || [])) { const cc = z.c || '#ff3b3b'; const gr = ctx.createRadialGradient(z.x, z.y, 2, z.x, z.y, z.r); gr.addColorStop(0, 'rgba(255,60,60,' + (0.10 + z.p * 0.28) + ')'); gr.addColorStop(0.75, 'rgba(255,60,60,' + (0.06 + z.p * 0.18) + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, 7); ctx.fill(); ctx.strokeStyle = cc; ctx.globalAlpha = 0.4 + z.p * 0.55; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.arc(z.x, z.y, z.r * z.p, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
      for (const mt of world.met) { ctx.strokeStyle = 'rgba(255,120,40,' + (0.4 + mt.p * 0.5) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(mt.x, mt.y, mt.r, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgba(255,80,20,' + (mt.p * 0.35) + ')'; ctx.beginPath(); ctx.arc(mt.x, mt.y, mt.r * mt.p, 0, 7); ctx.fill(); }
      for (const o of world.orbs) this._drawOrb(ctx, o);
      this._drawMuri(ctx, world, dt); this._drawTrappole(ctx, world);   // v1.85 — muri di fuoco e tagliole
      this._drawCritters(ctx, camX, camY, dt); // v1.22 — animaletti
      this._drawParticles(ctx, false);
      // v1.64 — SCARTO FUORI INQUADRATURA. Finora mostri e proiettili venivano disegnati TUTTI, anche quelli
      // fuori schermo: la canvas li ritagliava, ma il costo di costruire i tracciati era gia' stato pagato.
      // L'illuminazione lo faceva gia' (light() ha il suo test), il disegno no. Misurato: 11-15% del frame.
      const vx0 = camX - 90, vy0 = camY - 90, vx1 = camX + this.w + 90, vy1 = camY + this.h + 90;
      for (const b of world.bul) { if (b.x < vx0 || b.x > vx1 || b.y < vy0 || b.y > vy1) continue; this._drawBullet(ctx, b); }
      for (const m of world.mon) { if (m.x < vx0 || m.x > vx1 || m.y < vy0 || m.y > vy1) continue; this._drawMonster(ctx, m); }
      this._drawDeaths(ctx); // v1.26 — sprite di morte (crollo/dissolvenza)
      if (world.rec) this._drawRecinto(ctx, world.rec, world.chIn || 0);
      // v1.84.1 — LA CHIAVE NON SI VEDE. Prima aveva un alone giallo che la indicava da mezzo schermo:
      // cosi' non la trovavi esplorando, la vedevi e ci andavi. Adesso compare solo quando ci sei quasi
      // sopra (e sfuma negli ultimi metri), che e' il modo in cui si trova una cosa nascosta: passandoci.
      if (world.chv && world.me) {
        const dch = Math.hypot(world.chv.x - world.me.x, world.chv.y - world.me.y);
        if (dch < 118) this._drawChiave(ctx, world.chv, Math.max(0, Math.min(1, (118 - dch) / 46)));
      }
      if (world.fg) this._drawFaglia(ctx, world.fg);
      this._drawNebbie(ctx, world);                                     // v1.85 — il velo copre anche chi ci sta dentro
      for (const p of world.players) this._drawPlayer(ctx, p, me && p.i === me.i);
      this._drawChains(ctx);
      this._drawParticles(ctx, true); this._drawSwings(ctx); this._drawFlashes(ctx); this._drawPare(ctx); this._drawFloaters(ctx); this._drawLevelUps(ctx, world);
      this._drawDust(ctx, camX, camY, dt); // v1.16 — pulviscolo ambientale (world-space)
      // v2.5 — LA NEBBIA NON VA NEL VILLAGGIO, ed e' LEI la patina. Sono quattordici macchie grigio-azzurre
      // (rgba(150,160,185)) stese sull'inquadratura a ogni fotogramma: in una grotta sono nebbia e ci stanno,
      // in un paese illuminato a fuoco sono una pellicola sporca appoggiata sopra il disegno. Nella v2.4
      // avevo tolto la velatura e la patina restava: era questa, e non l'avevo guardata.
      if (!this.map.lit) this._drawFog(ctx, camX, camY, dt); // v1.21 — nebbia volumetrica a strati
      ctx.restore(); this._drawLighting(ctx, world, camX, camY);
      this._drawDarkness(world, camX, camY); // v1.16 — cono torcia + mappa scura (tasto L)
      this._drawTempo(ctx, world, dt);   // v2.17 — TEMPO RUBATO: tinta fredda, vignettatura, anelli lenti
      // v2.1 — nel villaggio no: la fascia viola della faglia e' il segno di un pericolo che li' non
      // esiste, e su una mappa illuminata si vedeva eccome (prima la copriva il buio).
      if (!this.map.lit) this._drawEdgeVignette(ctx, world);   // v1.63 — la faglia si chiude dai bordi dello schermo
      this._drawMinimap(ctx, world);
      this._drawMirino(ctx, world);
    },
    // v2.10 — IL MIRINO. Prima non c'era: il mirino era il cursore del sistema (`cursor:crosshair` nel
    // CSS). Adesso che il guinzaglio lo tiene a 200px il cursore vero non basta piu' — o e' nascosto dal
    // pointer lock, o sta piu' in la' del mirino e i due si separerebbero sotto gli occhi.
    //
    // SI DISEGNA IN COORDINATE SCHERMO, non di mondo: il personaggio e' al centro e il mirino e' uno
    // scostamento da li'. Passare per il mondo vorrebbe dire sommare la camera e sottrarla subito dopo.
    //
    // v2.11.1 — NIENTE ANELLO. Nella v2.10 compariva un cerchio a 200px mentre il mirino premeva contro il
    // limite, per spiegare perche' non andasse piu' in la'. All'occhio non funzionava — un cerchio che si
    // accende e si spegne addosso al personaggio e' rumore, e il limite si capisce comunque dal mirino che
    // si ferma. Tolto.
    //
    // v2.11.1 — E NEL VILLAGGIO NON SI DISEGNA AFFATTO: li' comanda il cursore del sistema (serve per
    // cliccare sui banchi), e disegnarne un secondo vorrebbe dire due puntatori a schermo.
    _drawMirino(ctx, world) {
      const I = window.Input; if (!I || !I.mira || !world || !world.me) return;
      if (!I.guinzaglio) return;
      if (this.w < 2) return;
      const cx = this.w / 2, cy = this.h / 2, mx = cx + I.mira.x, my = cy + I.mira.y;
      ctx.save();
      const a = I.alBordo ? 0.95 : 0.7;
      ctx.strokeStyle = 'rgba(10,12,18,.55)'; ctx.lineWidth = 4.5;  // il contorno scuro: si legge su tutto
      for (let pass = 0; pass < 2; pass++) {
        if (pass) { ctx.strokeStyle = 'rgba(226,236,255,' + a + ')'; ctx.lineWidth = 1.8; }
        ctx.beginPath();
        ctx.arc(mx, my, 7, 0, 7);
        ctx.moveTo(mx - 13, my); ctx.lineTo(mx - 4, my);
        ctx.moveTo(mx + 4, my);  ctx.lineTo(mx + 13, my);
        ctx.moveTo(mx, my - 13); ctx.lineTo(mx, my - 4);
        ctx.moveTo(mx, my + 4);  ctx.lineTo(mx, my + 13);
        ctx.stroke();
      }
      ctx.fillStyle = 'rgba(226,236,255,' + a + ')';
      ctx.beginPath(); ctx.arc(mx, my, 1.6, 0, 7); ctx.fill();
      ctx.restore();
    },
    _flame(ctx, x, y, sc) { const t = this.time; const f = 1 + Math.sin(t * 12 + x) * 0.14 + Math.sin(t * 7.3 + y) * 0.1; const s = sc * f; let gr = ctx.createRadialGradient(x, y, 0, x, y, 26 * s); gr.addColorStop(0, 'rgba(255,150,40,.5)'); gr.addColorStop(1, 'rgba(255,80,0,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, 26 * s, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,120,30,.9)'; ctx.beginPath(); ctx.moveTo(x - 6 * s, y + 4 * s); ctx.quadraticCurveTo(x - 7 * s, y - 8 * s, x, y - 16 * s); ctx.quadraticCurveTo(x + 7 * s, y - 8 * s, x + 6 * s, y + 4 * s); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,225,120,.95)'; ctx.beginPath(); ctx.moveTo(x - 3 * s, y + 2 * s); ctx.quadraticCurveTo(x - 3.5 * s, y - 5 * s, x, y - 11 * s); ctx.quadraticCurveTo(x + 3.5 * s, y - 5 * s, x + 3 * s, y + 2 * s); ctx.closePath(); ctx.fill(); if (Math.random() < 0.25 * sc) this.particles.push({ x: x + MU.rand(-3, 3), y: y - 6 * s, vx: MU.rand(-8, 8), vy: -MU.rand(20, 50), life: MU.rand(0.4, 0.9), t: 0, fire: true, r: MU.rand(1.5, 3) * sc, over: true }); },
    _drawMerchant(ctx, mrc, me) {
      const t = this.time; const x = mrc.x, y = mrc.y; const bob = Math.sin(t * 2) * 1.5;
      // v1.23 — beacon SEMPRE visibile per individuarlo sulla mappa
      const bt = 0.5 + 0.5 * Math.sin(t * 3);
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; const bmg = ctx.createLinearGradient(x, y - 78, x, y - 8); bmg.addColorStop(0, 'rgba(255,207,74,0)'); bmg.addColorStop(1, 'rgba(255,207,74,' + (0.10 + bt * 0.12) + ')'); ctx.fillStyle = bmg; ctx.fillRect(x - 7, y - 78, 14, 66); ctx.restore();
      ctx.strokeStyle = 'rgba(255,207,74,' + (0.35 + bt * 0.45) + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y + 4, 30 + bt * 5, 0, 7); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(x, y + 18, 26, 8, 0, 0, 7); ctx.fill();
      ctx.save(); ctx.translate(x, y);
      ctx.fillStyle = '#3a2a18'; ctx.strokeStyle = '#20160b'; ctx.lineWidth = 2; ctx.fillRect(-24, -2, 48, 20); ctx.strokeRect(-24, -2, 48, 20);
      ctx.fillStyle = '#ffcf4a'; ctx.beginPath(); ctx.arc(-14, 2, 3, 0, 7); ctx.arc(-6, 3, 3, 0, 7); ctx.fill();
      ctx.fillStyle = '#7dffea'; this._rr(ctx, 6, -2, 8, 7, 2); ctx.fill(); ctx.fillStyle = '#ff5a7a'; ctx.beginPath(); ctx.arc(18, 2, 3.4, 0, 7); ctx.fill();
      ctx.strokeStyle = '#5a3d20'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-26, -2); ctx.lineTo(-30, -34); ctx.moveTo(26, -2); ctx.lineTo(30, -34); ctx.stroke();
      for (let i = 0; i < 6; i++) { ctx.fillStyle = (i % 2) ? '#a9302e' : '#e8d9b0'; ctx.beginPath(); ctx.moveTo(-30 + i * 10, -34); ctx.lineTo(-30 + (i + 1) * 10, -34); ctx.lineTo(-30 + i * 10 + 5, -26); ctx.closePath(); ctx.fill(); }
      ctx.strokeStyle = '#20160b'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-30, -34); ctx.lineTo(30, -34); ctx.stroke();
      const lg = ctx.createRadialGradient(24, -20 + bob, 1, 24, -20 + bob, 14); lg.addColorStop(0, 'rgba(255,200,90,.9)'); lg.addColorStop(1, 'rgba(255,160,40,0)'); ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(24, -20 + bob, 14, 0, 7); ctx.fill();
      ctx.fillStyle = '#2a2018'; this._rr(ctx, 21, -26 + bob, 6, 10, 2); ctx.fill(); ctx.fillStyle = '#ffd66a'; this._rr(ctx, 22.5, -24 + bob, 3, 6, 1); ctx.fill();
      ctx.translate(0, bob);
      ctx.fillStyle = '#5a3a7a'; ctx.strokeStyle = '#2a1740'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-13, 0); ctx.quadraticCurveTo(-10, -22, 0, -26); ctx.quadraticCurveTo(10, -22, 13, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#3a2450'; ctx.beginPath(); ctx.arc(0, -22, 8, Math.PI, 0); ctx.fill();
      ctx.fillStyle = '#0a0810'; ctx.beginPath(); ctx.arc(0, -19, 6, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffd24a'; ctx.beginPath(); ctx.arc(-2.2, -19, 1.4, 0, 7); ctx.arc(2.2, -19, 1.4, 0, 7); ctx.fill();
      ctx.restore();
      ctx.fillStyle = 'rgba(255,207,74,' + (0.7 + 0.3 * Math.sin(t * 4)) + ')'; ctx.font = 'bold 17px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('🪙', x, y - 44 + bob); ctx.textAlign = 'left';
      ctx.fillStyle = '#ffe9b0'; ctx.font = 'bold 13px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('\uD83E\uDE99 Mercante', x, y - 60 + bob); ctx.textAlign = 'left';
    },
    // v2.19 — QUI C'ERA il fabbro disegnato a mano della v1.52 (forgia, incudine, martello che
    // batte). Era gia' morto da tempo — la v1.57 aveva ridefinito `_drawGearMerchant` piu' in
    // basso e in un oggetto letterale vince l'ultima — e con tre botteghe non torna: il banco
    // lo fanno i mobili della stanza (fucina, archeria, bottega arcana) e il mercante e' un
    // mercante come gli altri. Tolto: 45 righe che nessuno chiamava piu'.
    // v1.57 — MERCANTE. Taglia DOPPIA rispetto alla v1.56 e piu' dettagliato, ma stesso stile:
    // figura incappucciata, volto in ombra, occhi accesi. Ognuno tiene in mano l'oggetto del suo mestiere.
    // Il fuoco della piazza li illumina da un lato (rimlight caldo) cosi' non sembrano incollati sul fondo.
    // v1.75 — I MERCANTI RIUSANO LA SILHOUETTE DEGLI EROI, ricolorata e DISARMATA (`civile`), con
    // l'attrezzo del mestiere in mano. Il primo tentativo era una sagoma nuova disegnata da zero: vista
    // grande erano uova, perche' testa, torso e mantello avevano la stessa taglia e si fondevano. Quella
    // degli eroi invece e' gia' tarata per la lettura a picco — ed e' l'unico disegno del gioco che sia
    // stato limato fino a convincere. Riusarlo costa niente e tiene insieme lo stile: se un domani un
    // eroe cambia, i mercanti cambiano con lui.
    // v2.6 — `oracolo` ha preso il posto di `seer`. La cartomante era un mago viola col ventaglio di
    // carte; l’oracolo e' un'altra cosa — verderame, ossa, pelli — e si vede da lontano che non e' lei.
    // v2.18 — i mercanti non sono eroi: hanno solo bisogno di un'IMPALCATURA su cui essere disegnati.
    // Qui si nomina la classe che rappresenta quel corpo (barbaro = pesante, arciere = agile, mago =
    // arcana), e resta vero anche se domani le classi diventassero dieci.
    // v2.19 — e i due mercanti nuovi. L'ARCIERA sta sull'impalcatura agile, com'e' giusto per chi
    // vende archi; l'ARCANISTA su quella arcana. E' lo stesso criterio di prima — il corpo dice il
    // mestiere prima ancora dei colori — ed e' il motivo per cui si leggono da lontano anche di spalle:
    // tre sagome diverse per tre botteghe diverse.
    _vendorBase: { smith: 'barbaro', crier: 'barbaro', innkeeper: 'arciere', herbalist: 'mago', oracolo: 'mago',
                   fletcher: 'arciere', arcanist: 'mago', patron: 'arciere' },
    _vendorPal: {
      smith:     { cloth: '#8a5a2c', clothDk: '#4a2f14', steelDk: '#4a4038', pelo: '#5a4026', skin: '#e0b183', trim: '#ffb14a' },
      // verde cuoio e corda: l'arciera e' l'unica del paese vestita come chi sta fuori
      fletcher:  { cloth: '#4e6b34', clothDk: '#28381a', steelDk: '#5a5a48', pelo: '#4a4a2e', skin: '#e3c396', wood: '#8a6534', trim: '#8fd96a' },
      // viola e argento: l'arcanista e' l'unica veste del villaggio che non sia terra o cuoio
      arcanist:  { body: '#4a3f7a', bodyDk: '#241c46', accent: '#a98cff', orlo: 'rgba(169,140,255,.8)', skin: '#e0c4a8', trim: '#a98cff' },
      crier:     { cloth: '#6b5a72', clothDk: '#33303f', steelDk: '#5a6070', pelo: '#4a4050', skin: '#e0b48f', trim: '#ff9a8a' },
      innkeeper: { cloth: '#b8863c', clothDk: '#6b4a1c', skin: '#f0c795', wood: '#8a6534', trim: '#ffd97a' },
      herbalist: { body: '#3f6b34', bodyDk: '#1f3a1b', accent: '#9fe06a', orlo: 'rgba(159,224,106,.8)', skin: '#e3c396', trim: '#9fe06a' },
      oracolo:  { body: '#3f6b60', bodyDk: '#1c332e', accent: '#7fd6c0', orlo: 'rgba(127,214,192,.8)', skin: '#d6b48f', trim: '#7fd6c0' },
      patron:    { cloth: '#a08a68', clothDk: '#6b5940', body: '#a08a68', bodyDk: '#6b5940', pelo: '#63513a', skin: '#e6c79c', wood: '#7a5a34', trim: '#e8d9b0' },
    },
    _vendorTool(ctx, kind, r) {
      ctx.save(); ctx.translate(r * 1.15, r * 0.25);
      if (kind === 'smith') {                       // martello da fucina
        ctx.strokeStyle = '#4a3520'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-6, 4); ctx.lineTo(6, -6); ctx.stroke();
        ctx.fillStyle = '#7b828e'; ctx.strokeStyle = '#22262d'; ctx.lineWidth = 1.4; this._rr(ctx, 4, -11, 9, 7, 1.5); ctx.fill(); ctx.stroke();
      } else if (kind === 'innkeeper') {            // vassoio con i boccali
        ctx.fillStyle = '#5a4326'; ctx.strokeStyle = '#241a10'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(2, 0, 10, 7.5, 0, 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#c9a35a'; for (const d of [[-3, -2], [4, 1], [0, 3]]) { ctx.beginPath(); ctx.arc(2 + d[0], d[1], 2.6, 0, 7); ctx.fill(); }
      } else if (kind === 'herbalist') {            // mazzo d'erbe
        ctx.strokeStyle = '#4e7a3c'; ctx.lineWidth = 1.6;
        for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(-4, 2); ctx.quadraticCurveTo(2, -2 + k, 7, -6 + k * 3); ctx.stroke(); }
        ctx.fillStyle = '#9fe06a'; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.ellipse(7, -6 + k * 3, 2.2, 3.2, k * 0.4, 0, 7); ctx.fill(); }
      } else if (kind === 'oracolo') {             // v2.6 — il bastone con le ossa e le piume appese
        ctx.strokeStyle = '#6b5436'; ctx.lineWidth = 3.2; ctx.beginPath(); ctx.moveTo(-3, 8); ctx.lineTo(3, -12); ctx.stroke();
        ctx.fillStyle = '#e8e0cc'; ctx.strokeStyle = '#3a3428'; ctx.lineWidth = 1.1;
        ctx.beginPath(); ctx.arc(4, -14, 4.2, 0, 7); ctx.fill(); ctx.stroke();       // il teschietto in cima
        ctx.fillStyle = '#2a2620'; ctx.beginPath(); ctx.arc(5.4, -14.8, 1.1, 0, 7); ctx.fill();
        ctx.strokeStyle = '#7fd6c0'; ctx.lineWidth = 1.4;
        for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(1, -6); ctx.quadraticCurveTo(-3 + k, -2, -5 + k * 2, 3); ctx.stroke(); }
      } else if (kind === 'fletcher') {             // v2.19 — l'arco incordato e la freccia sulla corda
        ctx.strokeStyle = '#8a6534'; ctx.lineWidth = 2.6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(-1, -1, 11, -1.15, 1.15); ctx.stroke();            // il legno
        ctx.strokeStyle = 'rgba(235,230,210,.9)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(3.4, -11); ctx.lineTo(3.4, 9); ctx.stroke();    // la corda
        ctx.strokeStyle = '#6b5432'; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.moveTo(3.4, -1); ctx.lineTo(-9, -1); ctx.stroke();     // l'asta incoccata
        ctx.fillStyle = '#d8d2c0'; ctx.beginPath(); ctx.moveTo(-9, -1); ctx.lineTo(-6.6, -3.2); ctx.lineTo(-6.6, 1.2); ctx.closePath(); ctx.fill();
        ctx.lineCap = 'butt';
      } else if (kind === 'arcanist') {             // v2.19 — il bastone con la gemma accesa in cima
        ctx.strokeStyle = '#5a4a7a'; ctx.lineWidth = 3; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(-3, 9); ctx.lineTo(3, -12); ctx.stroke(); ctx.lineCap = 'butt';
        const gg = ctx.createRadialGradient(3.6, -14, 0.5, 3.6, -14, 8);
        gg.addColorStop(0, 'rgba(235,225,255,.95)'); gg.addColorStop(0.45, 'rgba(169,140,255,.7)'); gg.addColorStop(1, 'rgba(120,90,220,0)');
        ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(3.6, -14, 8, 0, 7); ctx.fill();
        ctx.fillStyle = '#c8b4ff'; ctx.strokeStyle = '#3b2f66'; ctx.lineWidth = 1.1;
        ctx.beginPath(); ctx.moveTo(3.6, -18.5); ctx.lineTo(6.4, -14); ctx.lineTo(3.6, -9.5); ctx.lineTo(0.8, -14); ctx.closePath(); ctx.fill(); ctx.stroke();
      } else if (kind === 'crier') {                // registro delle taglie
        ctx.fillStyle = '#e8dcc0'; ctx.strokeStyle = '#6b5024'; ctx.lineWidth = 1.4; this._rr(ctx, -4, -7, 12, 14, 1.5); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1;
        for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(-2, -4 + k * 4); ctx.lineTo(6, -4 + k * 4); ctx.stroke(); }
      } else {                                      // boccale
        ctx.fillStyle = '#8a6a30'; ctx.strokeStyle = '#4a3512'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.arc(2, 2, 3.6, 0, 7); ctx.fill(); ctx.stroke();
      }
      ctx.restore();
    },
    // SEDUTO: niente mantello che svolazza (chi e' seduto non ce l'ha dietro), veste allargata a terra
    // tutt'attorno e le spalle piu' strette. La differenza si legge anche di sfuggita.
    _vendorSeduto(ctx, kind, r, t) {
      const P = this._vendorPal[kind] || this._vendorPal.patron;
      const cor = P.body || P.cloth, corDk = P.bodyDk || P.clothDk;
      ctx.fillStyle = corDk; ctx.strokeStyle = '#07080c'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(-r * 0.14, 0, r * 1.05, r * 0.88, 0, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = cor; ctx.strokeStyle = '#07080c'; ctx.lineWidth = 2;
      this._rr(ctx, -r * 0.42, -r * 0.55, r * 0.86, r * 1.1, r * 0.28); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(-r * 0.3, -r * 0.34); ctx.lineTo(r * 0.28, -r * 0.34); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.beginPath(); ctx.arc(r * 0.36, 0, r * 0.38, 0, 7); ctx.fill();
      ctx.fillStyle = P.pelo || corDk; ctx.strokeStyle = '#07080c'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(r * 0.4, 0, r * 0.34, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = P.skin || '#e0be93';
      ctx.beginPath(); ctx.arc(r * 0.47, 0, r * 0.24, -1.3, 1.3); ctx.closePath(); ctx.fill();
      this._vendorTool(ctx, kind, r * 0.62);
    },
    // ===== v1.84 — IL RECINTO, LA CHIAVE, LA FAGLIA =========================================
    // Tre oggetti disegnati a codice come tutto il resto. Il recinto e' una palizzata tonda: pali
    // irregolari e due corrent i— e' basso, non blocca il passaggio, ma si legge subito come "qui non si
    // entra". Dentro ci sta della gente, disegnata con la stessa figura dei mercanti del villaggio
    // (_hero civile) e una palette per ciascuno, cosi' non sono cinque copie.
    // ===== v1.85 — quello che le abilita' lasciano sul campo ==================================
    // Tre oggetti, tre linguaggi diversi: il muro BRUCIA (caldo, mobile, luminoso), la tagliola e'
    // METALLO (freddo, immobile, piccolo), la nube e' ASSENZA (scura, morbida, senza contorno).
    // ============================================================================================
    // v2.17 — IL MURO DI FUOCO SI VEDE
    // ============================================================================================
    // Prima: una striscia sbiadita e sei fiammelle ogni 34px su una linea lunga 220. In mezzo a
    // un'ondata non si notava — Paolo: «non ha nessun effetto grafico». Adesso il muro e' fatto di
    // quattro strati, dal basso verso l'alto, e cambia mentre muore:
    //   1. l'ALONE, largo, che tinge il pavimento intorno;
    //   2. la COLATA, una linea spessa arancione che pulsa;
    //   3. il CUORE bianco-giallo, sottile, che e' la cosa che si vede da lontano;
    //   4. le FIAMME, una ogni 18px invece che ogni 34, piu' braci che salgono.
    // Nell'ultimo secondo tutto cala e il cuore lampeggia: si capisce che sta per cadere, e in un gioco
    // dove il muro DECIDE da dove ti arrivano addosso, sapere quando finisce e' informazione, non ornamento.
    _drawMuri(ctx, world, dt) {
      for (const w of (world.muri || [])) {
        const dx = w.x2 - w.x1, dy = w.y2 - w.y1, L = Math.hypot(dx, dy) || 1;
        const vita = Math.max(0, Math.min(1, w.p));
        const morente = vita < 0.2 ? (0.55 + 0.45 * Math.sin(this.time * 18)) : 1;   // lampeggia sul finale
        const puls = 0.86 + Math.sin(this.time * 7 + w.x * 0.05) * 0.14;
        ctx.save();
        ctx.lineCap = 'round';
        // 1) l'alone sul pavimento
        ctx.globalCompositeOperation = 'lighter';
        ctx.strokeStyle = 'rgba(255,90,20,' + (0.10 + vita * 0.14) * morente + ')';
        ctx.lineWidth = 64 * puls;
        ctx.beginPath(); ctx.moveTo(w.x1, w.y1); ctx.lineTo(w.x2, w.y2); ctx.stroke();
        // 2) la colata
        ctx.strokeStyle = 'rgba(255,130,30,' + (0.34 + vita * 0.30) * morente + ')';
        ctx.lineWidth = 30 * puls;
        ctx.beginPath(); ctx.moveTo(w.x1, w.y1); ctx.lineTo(w.x2, w.y2); ctx.stroke();
        // 3) il cuore
        ctx.strokeStyle = 'rgba(255,236,170,' + (0.55 + vita * 0.40) * morente + ')';
        ctx.lineWidth = 8 * puls;
        ctx.beginPath(); ctx.moveTo(w.x1, w.y1); ctx.lineTo(w.x2, w.y2); ctx.stroke();
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
        // 4) le fiamme, fitte, e le braci che salgono
        const n = Math.max(6, Math.round(L / 18));
        for (let i = 0; i <= n; i++) {
          const t = i / n, x = w.x1 + dx * t, y = w.y1 + dy * t;
          this._flame(ctx, x, y, (0.72 + Math.sin(this.time * 6 + i * 1.7) * 0.12 + vita * 0.3) * morente);
        }
        if (Math.random() < 0.9) {
          const t = Math.random(), x = w.x1 + dx * t, y = w.y1 + dy * t;
          this.particles.push({ x, y, vx: MU.rand(-14, 14), vy: -MU.rand(30, 85), life: MU.rand(0.5, 1.1), t: 0, fire: true, r: MU.rand(1.4, 3.2), over: true });
        }
      }
    },
    _drawTrappole(ctx, world) {
      for (const tr of (world.trap || [])) {
        ctx.save(); ctx.translate(tr.x, tr.y);
        // due ganasce aperte: mezzelune contrapposte, metallo freddo su un piatto scuro
        ctx.fillStyle = 'rgba(8,10,16,.55)'; ctx.beginPath(); ctx.ellipse(0, 3, tr.r * 0.62, tr.r * 0.4, 0, 0, 7); ctx.fill();
        for (const s of [-1, 1]) {
          ctx.strokeStyle = '#b9c4cc'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.arc(0, 0, tr.r * 0.5, s > 0 ? -0.9 : Math.PI - 0.9, s > 0 ? 0.9 : Math.PI + 0.9); ctx.stroke();
          ctx.strokeStyle = '#78848d'; ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.arc(0, 0, tr.r * 0.5, s > 0 ? -0.9 : Math.PI - 0.9, s > 0 ? 0.9 : Math.PI + 0.9); ctx.stroke();
        }
        ctx.fillStyle = '#5d666d'; ctx.beginPath(); ctx.arc(0, 0, 3.4, 0, 7); ctx.fill();
        ctx.restore();
      }
    },
    _drawNebbie(ctx, world) {
      for (const nb of (world.nebb || [])) {
        const vita = Math.max(0, Math.min(1, nb.p));
        ctx.save(); ctx.globalAlpha = 0.30 + vita * 0.42;
        for (let k = 0; k < 5; k++) {
          const an = this.time * 0.25 + k * 1.3;
          const ox = Math.cos(an) * nb.r * 0.22, oy = Math.sin(an * 1.2) * nb.r * 0.16;
          const rr = nb.r * (0.52 + 0.13 * k) * (0.7 + vita * 0.3);
          const g = ctx.createRadialGradient(nb.x + ox, nb.y + oy, 0, nb.x + ox, nb.y + oy, rr);
          g.addColorStop(0, 'rgba(18,26,22,.55)'); g.addColorStop(0.6, 'rgba(24,34,28,.32)'); g.addColorStop(1, 'rgba(20,28,24,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(nb.x + ox, nb.y + oy, rr, 0, 7); ctx.fill();
        }
        ctx.restore(); ctx.globalAlpha = 1;
      }
    },
    // L'onda del Grido: tre anelli sfasati, non uno. Uno solo si legge come un'esplosione; tre come una VOCE.
    grido(x, y, r) { for (let k = 0; k < 3; k++) setTimeout(() => this.ring(x, y, '#ffb45a', 10 + k * 14, r, 0.5), k * 90); },
    _drawRecinto(ctx, rec, chiaveInTasca) {
      const t = this.time, R2 = rec.r;
      ctx.save(); ctx.translate(rec.x, rec.y);
      // terra battuta dentro al recinto
      ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(0, R2 * 0.16, R2 * 0.98, R2 * 0.62, 0, 0, 7); ctx.fill();
      // v1.87 — DUE BRACIERI ai lati. Sulla minimappa il recinto non c'e' (e non deve tornarci): se lo si
      // deve trovare guardandosi intorno, allora deve essere una cosa che SI VEDE — un fuoco acceso nel
      // buio si legge da mezzo schermo, e resta una scoperta invece che una commissione.
      if (!rec.lib) for (const sx of [-1, 1]) {
        const bx = sx * R2 * 0.92, by = -R2 * 0.10;
        ctx.fillStyle = '#2a2418'; ctx.beginPath(); ctx.moveTo(bx - 5, by + 10); ctx.lineTo(bx + 5, by + 10); ctx.lineTo(bx + 3, by - 6); ctx.lineTo(bx - 3, by - 6); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#3a3222'; ctx.beginPath(); ctx.ellipse(bx, by - 6, 7, 3.4, 0, 0, 7); ctx.fill();
        this._flame(ctx, bx, by - 8, 0.5);
      }
      if (!rec.lib) {   // l alone: giallo se hai la chiave (puoi aprire), spento se non ce l hai
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const c = chiaveInTasca === 2 ? '#ffd24a' : '#7f8ba0';
        const a = (chiaveInTasca === 2 ? 0.13 : 0.06) + 0.04 * Math.sin(t * 2.2);
        const gr = this._grad('rec|' + c + '|' + Math.round(R2), () => { const q = ctx.createRadialGradient(0, 0, R2 * 0.2, 0, 0, R2 * 1.7); q.addColorStop(0, this._rgba(c, 0.5)); q.addColorStop(1, 'rgba(0,0,0,0)'); return q; });
        ctx.globalAlpha = a; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, R2 * 1.7, 0, 7); ctx.fill(); ctx.restore();
      }
      // i pali: quelli DIETRO prima, cosi' la gente dentro sta in mezzo
      const NP = 18;
      const palo = (i, dietro) => {
        const an = (i / NP) * Math.PI * 2;
        const sy = Math.sin(an);
        if ((sy < 0) !== !!dietro) return;
        const px = Math.cos(an) * R2, py = sy * R2 * 0.62;
        const h = R2 * (0.42 + ((i * 37) % 11) / 44);
        const sp = rec.lib && (i % 3 === 0);                       // aperto: qualche palo e' caduto
        ctx.save(); ctx.translate(px, py); if (sp) ctx.rotate(0.9 + (i % 5) * 0.1);
        ctx.fillStyle = '#2a2018'; ctx.beginPath(); ctx.ellipse(0, 0, 4.6, 2.6, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#4a3a26'; ctx.lineWidth = 5.2; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -h); ctx.stroke();
        ctx.strokeStyle = '#6a5436'; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(-1.1, -1); ctx.lineTo(-1.1, -h + 2); ctx.stroke();
        ctx.restore();
      };
      const correnti = (dietro) => {
        ctx.strokeStyle = 'rgba(74,58,38,.9)'; ctx.lineWidth = 3; ctx.lineCap = 'round';
        for (const q of [0.42, 0.72]) {
          ctx.beginPath();
          for (let i = 0; i <= NP; i++) {
            const an = (i / NP) * Math.PI * 2, sy = Math.sin(an);
            if ((sy < 0) !== !!dietro) { ctx.stroke(); ctx.beginPath(); continue; }
            const px = Math.cos(an) * R2, py = sy * R2 * 0.62 - R2 * q;
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.stroke();
        }
      };
      for (let i = 0; i < NP; i++) palo(i, true);
      if (!rec.lib) correnti(true);
      ctx.restore();
      // la gente dentro (in coordinate mondo, cosi' entra nell ordine di profondita' del resto)
      if (!rec.lib) for (const pr of rec.pr) {
        const px = rec.x + pr.dx, py = rec.y + pr.dy;
        const bob = Math.sin(t * 1.3 + pr.dx * 0.05) * 1.1;
        ctx.save(); ctx.translate(px, py + bob);
        this._shadow(ctx, 0, 0, C.PLAYER_RADIUS * (C.VIS_SCALE || 1));
        ctx.rotate(pr.f || 0);
        this._hero(ctx, pr.h || 'arciere', C.PLAYER_RADIUS * (C.VIS_SCALE || 1), t + px * 0.01, false, 0,
          { civile: 1, pal: { cloth: pr.c, clothDk: this._shade(pr.c, -40), body: pr.c, bodyDk: this._shade(pr.c, -40), accent: '#d8cfc4', skin: '#c99a6a' } });
        ctx.restore();
      }
      ctx.save(); ctx.translate(rec.x, rec.y);
      for (let i = 0; i < NP; i++) palo(i, false);
      if (!rec.lib) correnti(false);
      ctx.restore();
      // la scritta sopra
      ctx.save(); ctx.textAlign = 'center'; ctx.font = 'bold 13px Segoe UI';
      const testo = rec.lib ? 'liberi' : (chiaveInTasca === 2 ? 'entra per liberarli' : 'prigionieri \u00b7 serve una chiave');
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.85)'; ctx.strokeText(testo, rec.x, rec.y - R2 - 22);
      ctx.fillStyle = rec.lib ? '#9ef0b0' : (chiaveInTasca === 2 ? '#ffd24a' : '#c9d2e6'); ctx.fillText(testo, rec.x, rec.y - R2 - 22);
      ctx.textAlign = 'left'; ctx.restore();
    },
    _drawChiave(ctx, k, vis) {
      const t = this.time, b = 0.6 + 0.4 * Math.sin(t * 3), V = vis == null ? 1 : vis;
      ctx.save(); ctx.globalAlpha = V; ctx.translate(k.x, k.y + Math.sin(t * 2) * 2.5);
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = (0.18 + b * 0.22) * V;
      const gr = this._grad('chv', () => { const q = ctx.createRadialGradient(0, 0, 1, 0, 0, 34); q.addColorStop(0, 'rgba(255,210,74,.9)'); q.addColorStop(1, 'rgba(255,210,74,0)'); return q; });
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, 34, 0, 7); ctx.fill(); ctx.restore();
      ctx.rotate(-0.5);
      ctx.strokeStyle = '#2a1e08'; ctx.lineWidth = 4.4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(-5, 0, 4.6, 0, 7); ctx.moveTo(-0.6, 0); ctx.lineTo(9, 0); ctx.moveTo(9, 0); ctx.lineTo(9, 4.4); ctx.moveTo(5.4, 0); ctx.lineTo(5.4, 3.4); ctx.stroke();
      ctx.strokeStyle = '#ffd24a'; ctx.lineWidth = 2.6;
      ctx.beginPath(); ctx.arc(-5, 0, 4.6, 0, 7); ctx.moveTo(-0.6, 0); ctx.lineTo(9, 0); ctx.moveTo(9, 0); ctx.lineTo(9, 4.4); ctx.moveTo(5.4, 0); ctx.lineTo(5.4, 3.4); ctx.stroke();
      ctx.restore(); ctx.globalAlpha = 1;
    },
    // LA FAGLIA D'USCITA. Uno squarcio verticale che pulsa: si attraversa per finire l'ondata. Disegnata
    // a macchie come tutto il resto, con l'orlo piu' chiaro del dentro — il dentro e' un buco, e i buchi
    // non hanno colore.
    // v1.87.1 — IL PORTALE. Fino alla 1.87 la faglia era uno SQUARCIO: un'ellisse verticale di macchie
    // morbide, alta e stretta, come una crepa nell'aria. Sul campo si leggeva male — sembrava un'ombra o
    // un effetto, non una cosa in cui si entra. Adesso e' un PORTALE TONDO E FRONTALE, quello che chiunque
    // abbia giocato a un gioco riconosce senza spiegazioni: anello di energia, vortice dentro, rune che
    // girano, luce a terra.
    _drawFaglia(ctx, f) {
      const t = this.time, R = (C.FAGLIA_RAGGIO || 46) * 1.55;
      const puls = 0.97 + 0.03 * Math.sin(t * 2.2);
      const RR = R * puls;
      ctx.save(); ctx.translate(f.x, f.y);

      // 1) la luce a terra: il portale POGGIA nel mondo, non ci galleggia sopra
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const terra = this._grad('fg_terra|' + Math.round(R), () => {
        const q = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 1.9);
        q.addColorStop(0, 'rgba(150,90,255,.30)'); q.addColorStop(0.55, 'rgba(120,70,230,.12)'); q.addColorStop(1, 'rgba(0,0,0,0)');
        return q;
      });
      ctx.fillStyle = terra; ctx.beginPath(); ctx.ellipse(0, R * 0.42, R * 1.9, R * 0.72, 0, 0, 7); ctx.fill();
      ctx.restore();

      // 2) l'alone dietro all'anello
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const alone = this._grad('fg_alone|' + Math.round(R), () => {
        const q = ctx.createRadialGradient(0, 0, RR * 0.55, 0, 0, RR * 1.75);
        q.addColorStop(0, 'rgba(190,130,255,.32)'); q.addColorStop(0.45, 'rgba(140,80,255,.16)'); q.addColorStop(1, 'rgba(0,0,0,0)');
        return q;
      });
      ctx.fillStyle = alone; ctx.beginPath(); ctx.arc(0, 0, RR * 1.75, 0, 7); ctx.fill();
      ctx.restore();

      // 3) LA BOCCA: scura al centro, viva verso il bordo. E' la profondita' — un portale e' un buco,
      //    e un buco e' piu' scuro al centro, non piu' chiaro.
      const bocca = this._grad('fg_bocca|' + Math.round(R), () => {
        const q = ctx.createRadialGradient(0, 0, 0, 0, 0, RR);
        q.addColorStop(0, '#05020a'); q.addColorStop(0.30, '#0d0520');
        q.addColorStop(0.62, '#2d1070'); q.addColorStop(0.86, '#6d2ee0'); q.addColorStop(1, '#b382ff');
        return q;
      });
      ctx.fillStyle = bocca; ctx.beginPath(); ctx.ellipse(0, 0, RR, RR * 0.94, 0, 0, 7); ctx.fill();

      // 4) IL VORTICE: quattro braccia di spirale che girano dentro la bocca. Girano tutte insieme e
      //    ognuna e' sfalsata di un quarto di giro: e' il movimento che dice "ci si entra".
      ctx.save(); ctx.beginPath(); ctx.ellipse(0, 0, RR * 0.97, RR * 0.91, 0, 0, 7); ctx.clip();
      ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round';
      for (let b = 0; b < 4; b++) {
        const off = b * Math.PI / 2 + t * 0.85;
        // ogni braccio si disegna a segmenti: trasparente al centro, acceso al bordo. Un tratto solo
        // avrebbe la stessa forza dappertutto e riempirebbe di luce proprio il buco.
        for (let i = 0; i < 26; i++) {
          const k0 = i / 26, k1 = (i + 1) / 26;
          const a0 = off + k0 * 3.1, a1 = off + k1 * 3.1;
          const r0 = RR * (0.10 + 0.86 * k0), r1 = RR * (0.10 + 0.86 * k1);
          ctx.strokeStyle = 'rgba(196,140,255,' + (0.03 + 0.26 * k0 * k0) * (0.85 + 0.15 * Math.sin(t * 2 + b)) + ')';
          ctx.lineWidth = 1.6 + 2.4 * k0;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a0) * r0, Math.sin(a0) * r0 * 0.94);
          ctx.lineTo(Math.cos(a1) * r1, Math.sin(a1) * r1 * 0.94);
          ctx.stroke();
        }
      }
      // pulviscolo che gira e viene risucchiato verso il centro
      for (let i = 0; i < 14; i++) {
        const sp = ((t * 0.42 + i * 0.137) % 1);        // 1 = bordo, 0 = centro
        const k = 1 - sp;
        const ang = i * 2.39 + t * 1.6 + sp * 2.2;
        const rad = RR * (0.06 + 0.92 * sp);
        ctx.globalAlpha = 0.75 * Math.min(1, sp * 2.4);
        ctx.fillStyle = i % 3 === 0 ? '#ffd9ff' : '#c9a8ff';
        ctx.beginPath(); ctx.arc(Math.cos(ang) * rad, Math.sin(ang) * rad * 0.94, 1.1 + k * 1.4, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.restore();

      // 5) L'ANELLO: due tratti: uno largo e morbido (l'energia), uno sottile e acceso (il bordo netto).
      // il filo scuro fuori dall'anello: senza, su un pavimento chiaro il portale non ha un bordo e
      // sembra una macchia luminosa appoggiata sopra.
      ctx.strokeStyle = 'rgba(6,3,14,.8)'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.ellipse(0, 0, RR * 1.10, RR * 1.04, 0, 0, 7); ctx.stroke();
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = 'rgba(150,90,255,.50)'; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.ellipse(0, 0, RR * 1.02, RR * 0.96, 0, 0, 7); ctx.stroke();
      ctx.strokeStyle = 'rgba(245,228,255,' + (0.85 + 0.15 * Math.sin(t * 3.1)) + ')'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(0, 0, RR * 1.02, RR * 0.96, 0, 0, 7); ctx.stroke();
      // 6) le RUNE: sei rombi incastonati NELL'anello (non sparsi fuori: li' sembravano graffi),
      //    che girano lenti e si accendono a turno.
      for (let i = 0; i < 6; i++) {
        const a = t * 0.30 + i * Math.PI / 3;
        const x = Math.cos(a) * RR * 1.02, y = Math.sin(a) * RR * 0.96;
        ctx.save(); ctx.translate(x, y); ctx.rotate(a);
        const on = 0.35 + 0.55 * Math.max(0, Math.sin(t * 1.6 + i * 1.05));
        ctx.globalAlpha = on;
        ctx.fillStyle = '#fff0ff';
        ctx.beginPath(); ctx.moveTo(0, -5); ctx.lineTo(3.4, 0); ctx.lineTo(0, 5); ctx.lineTo(-3.4, 0); ctx.closePath(); ctx.fill();
        ctx.globalAlpha = on * 0.55; ctx.fillStyle = '#c9a8ff';
        ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(5.5, 0); ctx.lineTo(0, 9); ctx.lineTo(-5.5, 0); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
      // 7) scintille che risalgono lungo il bordo
      for (let i = 0; i < 6; i++) {
        const a = -Math.PI / 2 + Math.sin(t * 0.8 + i * 1.7) * 2.6;
        const rr = RR * (1.02 + 0.06 * Math.sin(t * 3 + i));
        ctx.globalAlpha = 0.35 + 0.4 * Math.abs(Math.sin(t * 2.2 + i));
        ctx.fillStyle = '#fff0ff';
        ctx.beginPath(); ctx.arc(Math.cos(a) * rr, Math.sin(a) * rr * 0.94, 1.6, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      ctx.restore();

      ctx.save(); ctx.textAlign = 'center'; ctx.font = 'bold 13px Segoe UI';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.85)'; ctx.strokeText('attraversa la faglia', f.x, f.y - R * 1.35 - 10);
      ctx.fillStyle = '#e2d0ff'; ctx.fillText('attraversa la faglia', f.x, f.y - R * 1.35 - 10);
      ctx.textAlign = 'left'; ctx.restore();
    },
    // ===================== v2.3 — I GIROVAGHI DEL VILLAGGIO =====================
    // Camminano per le strade, e la loro posizione non e' uno stato che qualcuno aggiorna: e' una
    // FUNZIONE del tempo della partita (`world.tick`, che arriva da server ed e' uguale per tutti).
    // Quindi niente banda, niente codice di movimento sul server, e tutti li vedono nello stesso punto.
    //
    // Le rotte sono polilinee che seguono le strade (le fa la pianta, vedi mapgen): chi le cambia deve
    // restare sulle strade, perche' qui non c'e' nessun controllo sui muri — non serve, se la rotta e'
    // fatta bene, e costerebbe a ogni fotogramma.
    _ROTTA_PAUSA: 1.6,   // secondi fermi a ogni capolinea, prima di tornare indietro
    _rottaMisura(g) {
      if (g._seg) return;
      const p = g.pts, n = p.length, chiusa = !!g.anello;
      const seg = [], fin = chiusa ? n : n - 1;
      let tot = 0;
      for (let i = 0; i < fin; i++) {
        const a = p[i], b = p[(i + 1) % n];
        const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
        seg.push({ a, b, L, da: tot }); tot += L;
      }
      g._seg = seg; g._tot = tot || 1;
    },
    // dove sta il girovago `g` al tempo `t`, e verso dove guarda
    _rottaPunto(g, t, out) {
      this._rottaMisura(g);
      const L = g._tot, v = g.vel || 60;
      let d;
      if (g.anello) {
        d = (((t * v) / L + (g.fase || 0)) % 1) * L;              // anello: gira e basta
      } else {
        const T1 = L / v, P = this._ROTTA_PAUSA, ciclo = 2 * T1 + 2 * P;
        let u = ((t / ciclo) + (g.fase || 0)) % 1; if (u < 0) u += 1;
        const s = u * ciclo;
        if (s < T1) d = s * v;                                     // andata
        else if (s < T1 + P) d = L;                                // fermo al capolinea
        else if (s < 2 * T1 + P) d = L - (s - T1 - P) * v;         // ritorno
        else d = 0;                                                // fermo all'altro capo
      }
      if (d < 0) d = 0; else if (d > L) d = L;
      const seg = g._seg;
      let i = 0; while (i < seg.length - 1 && d > seg[i].da + seg[i].L) i++;
      const S = seg[i], k = S.L > 0 ? (d - S.da) / S.L : 0;
      out.x = S.a[0] + (S.b[0] - S.a[0]) * k;
      out.y = S.a[1] + (S.b[1] - S.a[1]) * k;
      out.face = Math.atan2(S.b[1] - S.a[1], S.b[0] - S.a[0]);
      // fermo al capolinea: si guarda attorno invece di restare impalato verso il muro
      out.fermo = !g.anello && (d <= 0.5 || d >= L - 0.5);
      if (out.fermo) out.face += Math.sin(t * 0.7 + (g.fase || 0) * 9) * 0.8;
      return out;
    },
    // ===================== v2.5 — I PAESANI =====================
    // Fino alla v2.4 ogni abitante del villaggio era il LADRO ricolorato: stessa sagoma, stessa posa,
    // stesso cappuccio, solo tinte diverse. In una strada con dieci persone si vedeva subito — dieci
    // gemelli travestiti. I mercanti possono permetterselo (sono cinque, distanti, e ognuno ha il suo
    // banco e il suo alone); i passanti no.
    //
    // Questi hanno una sagoma LORO, che non ha niente a che vedere con quella degli eroi: non e' un
    // eroe ricolorato, e' disegnato da zero — corpo tondo, spalle basse, testa grossa, e per ognuno una
    // cosa sola che lo distingue da lontano (il cesto, il grembiule, il cappuccio, la gobba, la statura).
    // La regola e' quella di sempre: dal cielo si legge la SILHOUETTE, non i dettagli.
    _paesaniPal: {
      paesano:   { veste: '#6b5a3c', vesteDk: '#3a3020', pelle: '#e0b183', capelli: '#4a3a24', extra: '#8a7048' },
      paesana:   { veste: '#7a4a52', vesteDk: '#42262c', pelle: '#eec49a', capelli: '#5a3a28', extra: '#c8a27a' },
      vecchio:   { veste: '#57565f', vesteDk: '#2e2d34', pelle: '#d9b48f', capelli: '#d8d4cc', extra: '#6b5a3c' },
      bimbo:     { veste: '#4f6b52', vesteDk: '#2a3a2c', pelle: '#f0c795', capelli: '#7a5a30', extra: '#9fb07a' },
      bottegaio: { veste: '#8a5f34', vesteDk: '#4a321a', pelle: '#e3b98c', capelli: '#3a2a18', extra: '#d8cbae' },
      monaco:    { veste: '#4a4258', vesteDk: '#26222f', pelle: '#d6b48f', capelli: '#2a2530', extra: '#9a8fb5' },
      minatore:  { veste: '#4a4f5a', vesteDk: '#262a31', pelle: '#d8ac80', capelli: '#3a2f22', extra: '#ffd27a' },
      // v2.6 — LA GUARDIA della casa del portale. E' l'unica che non fa niente per mestiere: sta ferma
      // sulla soglia, e il fatto che stia ferma e' il suo mestiere. Grigio ferro, cotta scura, lancia.
      guardia:   { veste: '#3f4653', vesteDk: '#1e242e', pelle: '#dcb289', capelli: '#2c2a2e', extra: '#9aa6b5' },
    },
    _PAESANI: ['paesano', 'paesana', 'vecchio', 'bimbo', 'bottegaio', 'monaco', 'minatore', 'guardia'],
    _ePaesano(k) { return this._paesaniPal[k] != null; },
    // disegnato con lo stesso mestiere di tutto il resto: ombra, base scura, sfumatura, contorno nero
    // sottile, e un filo di luce sul bordo alto. Il contorno e' quello che lo stacca dal pavimento.
    _paesano(g, tipo, r, t) {
      const P = this._paesaniPal[tipo] || this._paesaniPal.paesano;
      const S = tipo === 'bimbo' ? 0.66 : (tipo === 'vecchio' ? 0.90 : 1);
      const rr = r * S;
      const resp = 1 + Math.sin(t * 1.6) * 0.02;
      const pas = Math.sin(t * 3.1) * 0.5;            // il passo: le braccia vanno in controtempo
      g.save(); g.scale(resp, resp);

      // COME SI LEGGE UNA PERSONA DALL'ALTO. Non da un ovale: dalla LINEA DELLE SPALLE, larga di traverso
      // rispetto a dove guardi, con la testa che ci sta sopra e due braccia che escono davanti. Al primo
      // tentativo avevo fatto un ovale con un pallino di fianco e sembravano sassi con la faccia.
      // Nel sistema locale si guarda verso +x, quindi le spalle sono lunghe lungo y.

      // Il secondo tentativo era un CERCHIO con due moncherini dietro: leggeva Topolino, corpo tondo e
      // due orecchie. La differenza fra un sasso e una persona vista dall'alto sta tutta in una cosa:
      // il corpo e' BASSO e LARGO (spalle di traverso), la testa SPORGE DAVANTI, e le braccia le stanno
      // ai lati — non dietro. Quindi ellisse schiacciata lungo x, larga lungo y, e testa fuori sagoma.

      // 1) LE SPALLE: schiacciate davanti-dietro, larghe di traverso. E' questa proporzione che fa la persona.
      const bg = g.createLinearGradient(rr * 0.30, 0, -rr * 0.40, 0);
      bg.addColorStop(0, P.veste); bg.addColorStop(1, P.vesteDk);
      g.fillStyle = P.vesteDk; g.strokeStyle = '#07080c'; g.lineWidth = 2.2;
      g.beginPath(); g.ellipse(-rr * 0.08, 0, rr * 0.46, rr * 0.84, 0, 0, 7); g.fill(); g.stroke();
      g.fillStyle = bg;
      g.beginPath(); g.ellipse(-rr * 0.06, 0, rr * 0.36, rr * 0.70, 0, 0, 7); g.fill();
      // la piega della schiena: una riga sola, ed e' quella che dice "c'e' una stoffa addosso"
      g.strokeStyle = 'rgba(0,0,0,.30)'; g.lineWidth = 1.3;
      g.beginPath(); g.moveTo(-rr * 0.30, -rr * 0.40); g.lineTo(-rr * 0.26, rr * 0.40); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.16)'; g.lineWidth = 1.5;
      g.beginPath(); g.ellipse(-rr * 0.06, 0, rr * 0.30, rr * 0.62, 0, -1.30, 0.60); g.stroke();

      // 2) LE BRACCIA, SOPRA il corpo (dall'alto le vedi, non stanno sotto) e piu' chiare della veste, se no
      // si fondono col busto e tornano a leggere come due orecchie. In punta la MANO: due macchie di pelle
      // grosse come niente, ma sono loro a dire "questa cosa ha le braccia".
      for (const lato of [-1, 1]) {
        g.save(); g.translate(-rr * 0.04, lato * rr * 0.56); g.rotate(lato * (0.34 + pas * 0.34));
        g.fillStyle = P.veste; g.strokeStyle = '#07080c'; g.lineWidth = 1.6;
        this._rr(g, -rr * 0.10, -rr * 0.16, rr * 0.62, rr * 0.32, rr * 0.15); g.fill(); g.stroke();
        g.fillStyle = P.pelle;
        g.beginPath(); g.arc(rr * 0.44, 0, rr * 0.13, 0, 7); g.fill(); g.stroke();
        g.restore();
      }

      // 3) LA TESTA: sporge DAVANTI alle spalle, non ci sta dentro. Capelli calotta, faccia spicchio.
      const hx = rr * 0.50, hr = rr * 0.40;
      if (tipo !== 'monaco') {
        g.fillStyle = P.capelli; g.strokeStyle = '#07080c'; g.lineWidth = 1.9;
        g.beginPath(); g.arc(hx, 0, hr, 0, 7); g.fill(); g.stroke();
        g.fillStyle = P.pelle;
        g.beginPath(); g.arc(hx, 0, hr * 0.84, -1.15, 1.15); g.closePath(); g.fill();
        g.fillStyle = 'rgba(0,0,0,.35)';                        // il naso: tre pixel, ma guarda avanti
        g.beginPath(); g.ellipse(hx + hr * 0.62, 0, hr * 0.16, hr * 0.12, 0, 0, 7); g.fill();
      } else {
        g.fillStyle = P.veste; g.strokeStyle = '#07080c'; g.lineWidth = 2;
        g.beginPath(); g.arc(hx - hr * 0.08, 0, hr * 1.12, 0, 7); g.fill(); g.stroke();
        // dentro il cappuccio non c'e' un buco nero tondo (leggeva ciambella): c'e' un'ombra a spicchio
        // e dentro l'ombra un filo di faccia. E' quel filo che fa capire che sotto c'e' qualcuno.
        g.fillStyle = '#0b0a10';
        g.beginPath(); g.arc(hx + hr * 0.14, 0, hr * 0.74, -1.30, 1.30); g.closePath(); g.fill();
        g.fillStyle = P.pelle;
        g.beginPath(); g.ellipse(hx + hr * 0.52, 0, hr * 0.22, hr * 0.30, 0, 0, 7); g.fill();
      }

      // 4) LA COSA CHE LO DISTINGUE. Una sola per tipo: due non si leggono.
      g.lineCap = 'round';
      if (tipo === 'paesana') {
        g.fillStyle = P.extra; g.strokeStyle = '#07080c'; g.lineWidth = 1.6;   // il fazzoletto
        g.beginPath(); g.arc(hx, 0, hr * 1.04, 1.05, -1.05); g.closePath(); g.fill(); g.stroke();
        g.fillStyle = '#8a6a38'; g.strokeStyle = '#3a2a12'; g.lineWidth = 1.6; // e il cesto al fianco
        g.beginPath(); g.ellipse(-rr * 0.10, rr * 0.92, rr * 0.28, rr * 0.21, 0.25, 0, 7); g.fill(); g.stroke();
      } else if (tipo === 'vecchio') {
        g.fillStyle = P.capelli; g.strokeStyle = '#07080c'; g.lineWidth = 1.4; // la barba lunga in avanti
        g.beginPath(); g.ellipse(hx + hr * 0.74, 0, hr * 0.30, hr * 0.50, 0, 0, 7); g.fill(); g.stroke();
        g.strokeStyle = P.extra; g.lineWidth = 2.8;                            // il bastone
        g.beginPath(); g.moveTo(rr * 0.34, rr * 0.86); g.lineTo(rr * 0.58, -rr * 0.30); g.stroke();
      } else if (tipo === 'bottegaio') {
        g.fillStyle = P.extra; g.strokeStyle = '#07080c'; g.lineWidth = 1.5;   // il grembiule bianco
        this._rr(g, -rr * 0.30, -rr * 0.40, rr * 0.52, rr * 0.80, rr * 0.14); g.fill(); g.stroke();
        g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 1.1;
        g.beginPath(); g.moveTo(rr * 0.06, -rr * 0.30); g.lineTo(rr * 0.06, rr * 0.30); g.stroke();
      } else if (tipo === 'minatore') {
        g.fillStyle = '#3a3f49'; g.strokeStyle = '#07080c'; g.lineWidth = 1.8; // l'elmetto
        g.beginPath(); g.arc(hx, 0, hr * 1.02, 0, 7); g.fill(); g.stroke();
        g.fillStyle = P.extra;                                                 // e la lampada davanti
        g.beginPath(); g.arc(hx + hr * 0.80, 0, hr * 0.28, 0, 7); g.fill();
        g.strokeStyle = '#5a4a2e'; g.lineWidth = 2.4;                          // il piccone in spalla
        g.beginPath(); g.moveTo(-rr * 0.52, -rr * 0.20); g.lineTo(rr * 0.10, -rr * 0.78); g.stroke();
        g.strokeStyle = '#8d97a5'; g.lineWidth = 2.8;
        g.beginPath(); g.moveTo(-rr * 0.06, -rr * 0.60); g.lineTo(rr * 0.26, -rr * 0.88); g.stroke();
      } else if (tipo === 'guardia') {
        g.fillStyle = '#4a515e'; g.strokeStyle = '#07080c'; g.lineWidth = 1.8;  // l'elmo, con la cresta
        g.beginPath(); g.arc(hx, 0, hr * 1.06, 0, 7); g.fill(); g.stroke();
        g.fillStyle = '#8e2f3a';
        g.beginPath(); g.ellipse(hx - hr * 0.15, 0, hr * 0.34, hr * 1.05, 0, 0, 7); g.fill();
        g.fillStyle = '#1a1d24';                                               // la fessura per gli occhi
        g.beginPath(); g.ellipse(hx + hr * 0.66, 0, hr * 0.20, hr * 0.46, 0, 0, 7); g.fill();
        g.strokeStyle = '#5a4630'; g.lineWidth = 2.6;                          // la lancia, piantata a terra
        g.beginPath(); g.moveTo(-rr * 0.14, rr * 1.02); g.lineTo(rr * 0.30, -rr * 1.18); g.stroke();
        g.fillStyle = P.extra; g.strokeStyle = '#07080c'; g.lineWidth = 1.2;
        g.beginPath(); g.moveTo(rr * 0.30, -rr * 1.52); g.lineTo(rr * 0.48, -rr * 1.10);
        g.lineTo(rr * 0.16, -rr * 1.10); g.closePath(); g.fill(); g.stroke();
      } else if (tipo === 'bimbo') {
        g.fillStyle = P.extra; g.strokeStyle = '#07080c'; g.lineWidth = 1.3;   // una palla in mano
        g.beginPath(); g.arc(rr * 0.46, rr * 0.66, rr * 0.22, 0, 7); g.fill(); g.stroke();
      } else if (tipo === 'paesano') {
        g.strokeStyle = '#3a2a16'; g.lineWidth = 2.6;                          // la cintura
        g.beginPath(); g.moveTo(-rr * 0.26, -rr * 0.52); g.lineTo(-rr * 0.22, rr * 0.52); g.stroke();
        g.fillStyle = P.extra; g.strokeStyle = '#07080c'; g.lineWidth = 1.5;   // il sacco in spalla
        g.beginPath(); g.ellipse(-rr * 0.44, -rr * 0.52, rr * 0.30, rr * 0.24, -0.4, 0, 7); g.fill(); g.stroke();
      }
      g.lineCap = 'butt';
      g.restore();
    },
    // v2.19.5 — LA LAMA GENERICA del guerriero. `lato`: +1 mano destra, -1 sinistra, 0 davanti al corpo
    // (un'arma a due mani, tenuta con entrambe). Il carattere ne decide le proporzioni: e' l'unica
    // informazione che la sagoma deve dare, perche' e' quella che cambia il colpo.
    _lamaGenerica(ctx, r, atk, carattere, lato, P, DK) {
      const F = carattere === 'pesante' ? { L: 1.22, W: 0.105, G: 0.34, M: 0.30 }
              : carattere === 'leggera' ? { L: 0.80, W: 0.055, G: 0.20, M: 0.20 }
              :                           { L: 0.98, W: 0.075, G: 0.26, M: 0.24 };
      const y = lato === 0 ? r * 0.06 : lato * r * 0.44;
      const rot = lato === 0 ? (-0.10 + atk * 0.20) : lato * (0.30 - atk * 0.28);
      ctx.save(); ctx.translate(r * (0.42 + 0.26 * atk), y); ctx.rotate(rot);
      // l'impugnatura: piu' lunga se la tengono due mani
      ctx.strokeStyle = '#3a2a18'; ctx.lineWidth = r * 0.09; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-r * F.M, 0); ctx.lineTo(r * 0.02, 0); ctx.stroke(); ctx.lineCap = 'butt';
      // la guardia
      ctx.fillStyle = (P && P.orlo) || '#c8a23a'; ctx.strokeStyle = DK; ctx.lineWidth = 1.4;
      ctx.fillRect(r * 0.00, -r * F.G / 2, r * 0.055, r * F.G); ctx.strokeRect(r * 0.00, -r * F.G / 2, r * 0.055, r * F.G);
      // la lama, con la punta
      ctx.fillStyle = '#dfe5ee'; ctx.strokeStyle = DK; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(r * 0.06, -r * F.W); ctx.lineTo(r * (F.L - 0.10), -r * F.W * 0.55); ctx.lineTo(r * F.L, 0);
      ctx.lineTo(r * (F.L - 0.10), r * F.W * 0.55); ctx.lineTo(r * 0.06, r * F.W); ctx.closePath(); ctx.fill(); ctx.stroke();
      // la sguscia: una riga scura lungo il mezzo, che la fa leggere come lama anche piccola
      ctx.strokeStyle = 'rgba(40,48,60,.45)'; ctx.lineWidth = Math.max(1, r * 0.022);
      ctx.beginPath(); ctx.moveTo(r * 0.10, 0); ctx.lineTo(r * (F.L - 0.16), 0); ctx.stroke();
      ctx.restore();
    },
    _drawVendor(ctx, n, opts) {
      const o = opts || {}, t = this.time, x = n.x, y = n.y;
      const r = C.PLAYER_RADIUS * (C.VIS_SCALE || 1);
      const base = this._vendorBase[n.kind] || 'arciere';
      const pal = this._vendorPal[n.kind] || this._vendorPal.patron;
      const bob = Math.sin(t * 1.1 + x * 0.03) * 0.9;
      ctx.save(); ctx.translate(x, y + bob);
      this._shadow(ctx, 0, 0, r * (n.seated ? 0.8 : 1));
      // v2.0 — GLI ABITANTI FANNO QUALCOSA. Un villaggio di statue non e' abitato: e' un presepe. Ognuno
      // ha un mestiere in corso (`act`) e lo esegue sul posto, senza spostarsi davvero — il suo CORPO
      // resta dov'e', se no ci si passerebbe attraverso mentre ondeggia. Il movimento e' piccolo apposta:
      // deve leggersi con la coda dell'occhio mentre compri, non rubare la scena.
      let faccia = n.face != null ? n.face : 0;
      if (n.act === 'guarda') faccia += Math.sin(t * 0.5 + x * 0.01) * 0.55;          // si guarda attorno
      if (n.act === 'cammina') ctx.translate(Math.sin(t * 0.55 + x * 0.02) * 13, 0);  // va e viene per la strada
      if (n.act === 'rimesta') ctx.translate(Math.cos(t * 1.9 + x * 0.02) * 2.2, Math.sin(t * 1.9 + x * 0.02) * 1.6);
      ctx.rotate(faccia);
      if (n.act === 'martella') ctx.rotate(Math.sin(t * 4.4 + x * 0.02) * 0.17);      // il colpo di martello
      if (n.act === 'fuoco') ctx.rotate(Math.sin(t * 0.9 + x * 0.01) * 0.08);         // si scalda, e dondola
      // v2.5 — i PAESANI hanno una sagoma loro; i cinque mercanti restano gli eroi ricolorati, che li'
      // funziona: sono pochi, distanti, ognuno col suo banco e il suo alone.
      if (this._ePaesano(n.kind)) this._paesano(ctx, n.kind, r, t + x * 0.013);
      else if (n.seated) this._vendorSeduto(ctx, n.kind, r, t);
      else { this._hero(ctx, base, r, t + (x * 0.013), false, 0, { pal, civile: 1 }); this._vendorTool(ctx, n.kind, r); }
      ctx.restore();

      if (!o.noLabel) {
        const ny = y - r * 1.5 - 26;
        ctx.save(); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = 'bold 14px Segoe UI';
        const label = (o.label || n.name || '');
        const tw = ctx.measureText(label).width;
        ctx.fillStyle = 'rgba(12,9,6,.85)'; ctx.strokeStyle = pal.trim || '#c8a23a'; ctx.lineWidth = 2;
        this._rr(ctx, x - tw / 2 - 10, ny - 11, tw + 20, 22, 6); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#f4e3b8'; ctx.fillText(label, x, ny + 1);
        const sub = n.soon ? '— chiuso —' : (n.sub ? '— ' + n.sub + ' —' : '');
        if (sub) { ctx.font = 'bold 11px Segoe UI'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.85)';
          ctx.strokeText(sub, x, ny + 20); ctx.fillStyle = n.soon ? 'rgba(205,195,175,.8)' : 'rgba(255,205,130,.9)'; ctx.fillText(sub, x, ny + 20); }
        ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.restore();
      }
    },
    // v1.57 — l'anello-beacon che segnala «qui si compra»: la colonna di luce che si vede dalla via e
    // l'ellisse che pulsa ai piedi del mercante.
    // v2.19 — SI COLORA COL COLORE DELLA BOTTEGA, e non disegna piu' il mercante. Prima era arancione
    // fisso perche' il negozio era uno solo ed era il fabbro; adesso l'arancione e' del fabbro, il verde
    // dell'arciera e il viola dell'arcanista — e dalla piazza si capisce dove si sta andando senza
    // leggere le insegne. Il colore arriva dal manifesto del villaggio (`n.col`), che e' lo stesso che
    // tinge l'alone a terra: una fonte sola, se no in due versioni si scollano.
    _beaconBottega(ctx, n) {
      const t = this.time, x = n.x, y = n.y, bt = 0.5 + 0.5 * Math.sin(t * 2.4);
      const rgb = this._hex2rgb ? this._hex2rgb(n.col || '#ffb14a') : null;
      const c = rgb ? rgb.join(',') : '255,170,60';
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const bmg = ctx.createLinearGradient(x, y - 110, x, y - 8);
      bmg.addColorStop(0, 'rgba(' + c + ',0)'); bmg.addColorStop(1, 'rgba(' + c + ',' + (0.10 + bt * 0.12).toFixed(3) + ')');
      ctx.fillStyle = bmg; ctx.fillRect(x - 10, y - 110, 20, 96); ctx.restore();
      ctx.strokeStyle = 'rgba(' + c + ',' + (0.30 + bt * 0.45).toFixed(3) + ')'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.ellipse(x, y + 30, 46 + bt * 6, 18 + bt * 3, 0, 0, 7); ctx.stroke();
    },
    // '#rrggbb' -> [r,g,b]. Serve perche' gli aloni si compongono in `rgba(...)` con un'opacita' che
    // cambia ogni frame, e un colore esadecimale li' dentro non ci sta.
    _hex2rgb(h) {
      const s = String(h || '').replace('#', '');
      if (s.length !== 6) return [255, 170, 60];
      return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
    },
    // v1.58 — FUNGO SPORIFERO. Immobile per design: tutto il movimento sta nel respiro del cappello e
    // nell'urto di quando sputa le spore. Vettoriale puro, nessun asset.
    _fungusF(ctx, m, r, def, atk) {
      const t = this.time, eye = def.eye || '#c8ff6a';
      const a = atk || 0;
      const puff = a > 0 ? Math.sin(Math.min(1, a) * Math.PI) : 0;         // gonfia -> sgonfia
      const breathe = 1 + Math.sin(t * 1.6 + m.x * 0.02) * 0.035 + puff * 0.30;
      ctx.save();
      // micelio a terra
      ctx.strokeStyle = 'rgba(120,160,80,.22)'; ctx.lineWidth = 2; ctx.lineCap = 'round';
      for (let i = 0; i < 7; i++) { const an = (i / 7) * 6.283 + m.x * 0.01;
        ctx.beginPath(); ctx.moveTo(0, r * 0.55); ctx.lineTo(Math.cos(an) * r * 1.35, r * 0.55 + Math.sin(an) * r * 0.34); ctx.stroke(); }
      ctx.lineCap = 'butt';
      ctx.fillStyle = 'rgba(0,0,0,.42)'; ctx.beginPath(); ctx.ellipse(0, r * 0.62, r * 0.95, r * 0.34, 0, 0, 7); ctx.fill();
      // gambo
      const st = ctx.createLinearGradient(0, -r * 0.2, 0, r * 0.6); st.addColorStop(0, '#d8d0b4'); st.addColorStop(1, '#7d745c');
      ctx.fillStyle = st; ctx.strokeStyle = '#2a2a1e'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-r * 0.28, r * 0.6); ctx.quadraticCurveTo(-r * 0.20, 0, -r * 0.22, -r * 0.25);
      ctx.lineTo(r * 0.22, -r * 0.25); ctx.quadraticCurveTo(r * 0.20, 0, r * 0.28, r * 0.6); ctx.closePath(); ctx.fill(); ctx.stroke();
      // lamelle luminose sotto il cappello
      ctx.save(); ctx.scale(breathe, breathe);
      const gl = ctx.createRadialGradient(0, -r * 0.18, 1, 0, -r * 0.18, r * 1.05);
      gl.addColorStop(0, this._rgba ? this._rgba(eye, 0.55 + puff * 0.4) : eye); gl.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gl; ctx.beginPath(); ctx.ellipse(0, -r * 0.14, r * 1.0, r * 0.42, 0, 0, 7); ctx.fill();
      // cappello
      const cg = ctx.createLinearGradient(0, -r * 1.15, 0, -r * 0.1);
      cg.addColorStop(0, '#4a5a34'); cg.addColorStop(1, '#202a16');
      ctx.fillStyle = cg; ctx.strokeStyle = '#12180c'; ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.ellipse(0, -r * 0.28, r * 1.02, r * 0.78, 0, Math.PI, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
      // macchie
      ctx.fillStyle = 'rgba(200,255,120,.55)';
      for (const d of [[-0.44, -0.62, 0.15], [0.30, -0.72, 0.13], [0.62, -0.44, 0.10], [-0.10, -0.86, 0.11]])
        { ctx.beginPath(); ctx.ellipse(d[0] * r, d[1] * r, d[2] * r, d[2] * r * 0.72, 0, 0, 7); ctx.fill(); }
      // occhietti sotto la cuffia
      ctx.fillStyle = eye; ctx.globalAlpha = 0.65 + 0.35 * Math.sin(t * 3);
      ctx.beginPath(); ctx.arc(-r * 0.18, -r * 0.12, r * 0.09, 0, 7); ctx.arc(r * 0.18, -r * 0.12, r * 0.09, 0, 7); ctx.fill();
      ctx.globalAlpha = 1; ctx.restore();
      // spore che salgono quando spara
      if (puff > 0.02) { ctx.save(); ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 9; i++) { const an = (i / 9) * 6.283 + t, rr2 = r * (0.5 + puff * 1.5);
          ctx.fillStyle = this._rgba ? this._rgba(eye, 0.5 * puff) : eye;
          ctx.beginPath(); ctx.arc(Math.cos(an) * rr2, -r * 0.5 + Math.sin(an) * rr2 * 0.5 - puff * r, r * 0.10, 0, 7); ctx.fill(); }
        ctx.restore(); }
      ctx.restore();
    },
    // v1.58 — SFERA D'OSSA. La rotazione e ricavata dallo SPOSTAMENTO REALE (niente frame): rotola davvero,
    // e quando e ferma resta ferma. In carica si schiaccia e vibra.
    // ===== v2.22 — LAMA ERRANTE ==============================================================
    // Nessun frame: una rotazione e uno scatto. L'OMBRA STA STACCATA E PIU' IN BASSO — e' l'unica
    // cosa che dice "questa cosa galleggia" invece di "questa cosa striscia". Il bagliore e il
    // rinculo della carica arrivano dagli eventi `lama_wind`/`lama_go`, come per la Sfera d'Ossa.
    _lamaF(ctx, m, rr, def, atk) {
      const t = this.time, sc = rr / 16;   // v2.23.1 — Paolo: *«la spada mi sembra troppo grossa»*.
      // Il raggio e' sceso da 14 a 11 e il disegno da rr/14 a rr/16: in tutto un terzo in meno.
      const car = atk;                                        // il cronometro dei telegrafi: lo stesso della Sfera d'Ossa
      const bob = Math.sin(t * 3.1 + (m.e || 0)) * 3 * sc;
      ctx.save();
      // l'ombra: staccata di 26, piu' piccola della lama, e NON segue il bob in pieno
      ctx.save(); ctx.translate(0, 26 * sc + bob * 0.5);
      ctx.fillStyle = 'rgba(0,0,0,.34)'; ctx.beginPath(); ctx.ellipse(0, 0, 15 * sc, 6 * sc, m.f, 0, 7); ctx.fill(); ctx.restore();
      ctx.translate(0, bob); ctx.rotate(m.f); ctx.scale(sc, sc);
      if (car > 0) {                                           // il mezzo secondo che si deve vedere
        const q = ctx.createRadialGradient(0, 0, 2, 0, 0, 44 + car * 18);
        q.addColorStop(0, 'rgba(180,220,255,' + (0.34 * car) + ')'); q.addColorStop(1, 'rgba(120,180,255,0)');
        ctx.fillStyle = q; ctx.beginPath(); ctx.arc(0, 0, 44 + car * 18, 0, 7); ctx.fill();
      }
      const sctt = this._lamaSc && this._lamaSc[m.e] > t;      // sta scattando: il filo dietro (evento lama_go)
      if (sctt) { ctx.strokeStyle = 'rgba(190,225,255,.35)'; ctx.lineWidth = 7; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(-52, 0); ctx.stroke(); ctx.lineCap = 'butt'; }
      ctx.fillStyle = '#4a3a26'; ctx.strokeStyle = '#15100a'; ctx.lineWidth = 2; this._rr(ctx, -24, -3, 12, 6, 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#c9a24a'; ctx.strokeStyle = '#5a4514'; ctx.beginPath(); ctx.arc(-26, 0, 4.4, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#8f96a4'; ctx.strokeStyle = '#15181f'; ctx.lineWidth = 2; this._rr(ctx, -13, -11, 5, 22, 2); ctx.fill(); ctx.stroke();
      const bg = ctx.createLinearGradient(0, -7, 0, 7);
      bg.addColorStop(0, '#eaf1f8'); bg.addColorStop(.45, '#aab6c6'); bg.addColorStop(1, '#5e6878');
      ctx.fillStyle = bg; ctx.strokeStyle = '#13161d'; ctx.lineWidth = 2; ctx.lineJoin = 'round';
      ctx.beginPath(); ctx.moveTo(-8, -7); ctx.lineTo(26, -5); ctx.lineTo(38, 0); ctx.lineTo(26, 5); ctx.lineTo(-8, 7); ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.65)'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(-6, -2.4); ctx.lineTo(28, -1.4); ctx.stroke();
      ctx.strokeStyle = 'rgba(10,14,20,.45)'; ctx.beginPath(); ctx.moveTo(-6, 2.6); ctx.lineTo(27, 1.8); ctx.stroke();
      // la runa sulla guardia: e' una spada STREGATA, non una spada caduta per terra
      ctx.fillStyle = 'rgba(139,233,255,' + (.55 + Math.sin(t * 4) * .2 + car * .4) + ')';
      ctx.beginPath(); ctx.arc(-10.5, 0, 2.2 + car * 1.4, 0, 7); ctx.fill();
      if (m.fl) { ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.beginPath();
        ctx.moveTo(-8, -7); ctx.lineTo(38, 0); ctx.lineTo(-8, 7); ctx.closePath(); ctx.fill(); }
      ctx.restore();
    },
    // ===== v2.22 — CUBO GELATINOSO ===========================================================
    // Il problema era farlo leggere come un CUBO e non come un quadrato. Quattro cose, e la terza e'
    // quella che fa il lavoro:
    //  1. due facce sfalsate in verticale (a terra e in alto) che ondeggiano in modo DIVERSO fra loro
    //     — se ondeggiassero uguali sembrerebbero due copie della stessa figura;
    //  2. il fianco vicino in UN PEZZO SOLO: a segmenti si vedevano le cuciture e pareva una staccionata;
    //  3. lo spigolo di fondo visto ATTRAVERSO il vetro — il bordo lontano della faccia a terra si
    //     intravede dentro la faccia in alto, spostato in basso. E' il segnale che l'occhio usa per
    //     capire che sta guardando dentro una scatola trasparente, e sono due righe;
    //  4. la parallasse della roba dentro: chi sta in superficie e' disegnato piu' in alto e piu'
    //     grande, chi e' affondato piu' piccolo e piu' smorto. Due monete alla stessa quota sono un
    //     adesivo; due monete a quote diverse sono un volume.
    _cuboF(ctx, m, rr, def, atk) {
      const t = this.time, R = rr, ALT = rr * 0.36;
      const mem = (this._cuboMem || (this._cuboMem = {}));
      let me2 = mem[m.e]; if (!me2) me2 = mem[m.e] = { x: m.x, y: m.y, dx: 0, dy: 0, sq: 0 };
      { const vx = m.x - me2.x, vy = m.y - me2.y, len = Math.hypot(vx, vy);
        if (len > 0.05) { const nx = vx / len, ny = vy / len;
          const cos = nx * me2.dx + ny * me2.dy;
          if (me2.dx || me2.dy) { if (cos < 0.55) me2.sq = Math.min(1, me2.sq + (0.55 - cos)); }
          me2.dx = nx; me2.dy = ny; }
        me2.x = m.x; me2.y = m.y; me2.sq *= 0.90; }
      const sq = me2.sq;
      const pul = 1 + Math.sin(t * 1.8 + (m.e || 0)) * .035;
      const sx = (1 + sq * .30) * pul, sy = (1 - sq * .22) * pul;
      const yB = ALT * .5, yT = -ALT * .5;
      const sem = ((m.e || 1) * 2654435761) % 1000 / 1000;
      const sagoma = (rad, fase) => { const p = [];
        for (let k = 0; k < 64; k++) { const a = k / 64 * 6.283, ca = Math.cos(a), sa = Math.sin(a);
          const box = rad / Math.max(Math.abs(ca), Math.abs(sa));
          let r2 = Math.min(box, rad * 1.31);
          r2 *= 1 + Math.sin(a * 3 + t * 1.7 + fase) * .030 + Math.sin(a * 5 - t * 1.2 + fase) * .020;
          p.push({ x: ca * r2, y: sa * r2 }); }
        return p; };
      const via = (p, dy) => { ctx.beginPath(); p.forEach((q, i) => i ? ctx.lineTo(q.x, q.y + dy) : ctx.moveTo(q.x, q.y + dy)); ctx.closePath(); };
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,.40)'; ctx.beginPath(); ctx.ellipse(R * .08, yB + R * .78, R * .92, R * .26, 0, 0, 7); ctx.fill();
      ctx.scale(sx, sy);
      const base = sagoma(R * 0.94, 0.0), alto = sagoma(R, 1.6);
      ctx.fillStyle = 'rgba(26,54,24,.60)'; via(base, yB); ctx.fill();
      { const da = -5, a2 = 37;                       // il fianco vicino, una fascia sola
        ctx.beginPath();
        for (let k = da; k <= a2; k++) { const q = alto[(k + 64) % 64]; k === da ? ctx.moveTo(q.x, q.y + yT) : ctx.lineTo(q.x, q.y + yT); }
        for (let k = a2; k >= da; k--) { const q = base[(k + 64) % 64]; ctx.lineTo(q.x, q.y + yB); }
        ctx.closePath();
        const fg = ctx.createLinearGradient(0, yT, 0, yB + R);
        fg.addColorStop(0, 'rgba(96,152,68,.58)'); fg.addColorStop(.55, 'rgba(62,112,48,.60)'); fg.addColorStop(1, 'rgba(26,56,24,.66)');
        ctx.fillStyle = fg; ctx.fill(); }
      // la roba dentro, a quote diverse. Le posizioni vengono dall'eid: ogni cubo ha il suo bottino
      ctx.save(); ctx.beginPath();
      alto.forEach((q, i) => i ? ctx.lineTo(q.x, q.y + yT) : ctx.moveTo(q.x, q.y + yT)); ctx.closePath();
      base.forEach((q, i) => i ? ctx.lineTo(q.x, q.y + yB) : ctx.moveTo(q.x, q.y + yB)); ctx.closePath(); ctx.clip();
      const N = 8;
      for (let i = 0; i < N; i++) {
        const f = (sem * 97 + i * 0.3723) % 1, f2 = (sem * 53 + i * 0.7191) % 1, f3 = (sem * 29 + i * 0.1367) % 1;
        const z = 0.08 + f3 * 0.84, dy = yB + (yT - yB) * z, s2 = (0.82 + z * 0.30) * (R / 40);
        const ox = (f - .5) * R * 1.05, oy = (f2 - .5) * R * 0.78 + dy;
        ctx.save(); ctx.translate(ox + Math.sin(t * .8 + f * 6) * 3.5, oy + Math.cos(t * .7 + f2 * 6) * 3.5);
        ctx.scale(s2, s2); ctx.rotate(f * 6.28 + Math.sin(t * .5 + f) * .12);
        ctx.globalAlpha = 0.58 + z * 0.40;
        const k = i % 4;
        if (k === 0) { ctx.fillStyle = '#e8b93a'; ctx.strokeStyle = '#7a5c12'; ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.ellipse(0, 0, 6, 5, 0, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#fff0b0'; ctx.beginPath(); ctx.arc(-1.6, -1.6, 1.8, 0, 7); ctx.fill(); }
        else if (k === 1) { ctx.strokeStyle = '#cfc7b0'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(-8, 0); ctx.lineTo(8, 1); ctx.stroke(); ctx.lineCap = 'butt'; }
        else if (k === 2) { ctx.fillStyle = '#d8d2c0'; ctx.strokeStyle = '#8f8874'; ctx.lineWidth = 1.3;
          ctx.beginPath(); ctx.arc(0, -1, 7, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillRect(-5, 4, 10, 4);
          ctx.fillStyle = '#1a1a22'; ctx.beginPath(); ctx.arc(-2.6, -1, 2, 0, 7); ctx.arc(2.6, -1, 2, 0, 7); ctx.fill(); }
        else { ctx.fillStyle = '#98a2b0'; ctx.strokeStyle = '#1b1f27'; ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.moveTo(-14, -2.6); ctx.lineTo(12, -2); ctx.lineTo(18, 0); ctx.lineTo(12, 2); ctx.lineTo(-14, 2.6); ctx.closePath();
          ctx.fill(); ctx.stroke(); ctx.fillStyle = '#5a4326'; ctx.fillRect(-19, -2, 6, 4); }
        ctx.globalAlpha = 1; ctx.restore();
      }
      // I DARDI ANCORA CONFICCATI: il server dice quanti sono (m.ab), qui si disegnano. E' la
      // meccanica messa in figura — senza, "ferma i proiettili" resterebbe una cosa da leggere
      // nelle note invece che una cosa da vedere in partita.
      const nd = Math.min(6, m.ab || 0);
      for (let i = 0; i < nd; i++) {
        const f = (sem * 131 + i * 0.5309) % 1, f2 = (sem * 17 + i * 0.8887) % 1;
        const z = 0.55 + ((sem * 7 + i * 0.3061) % 1) * 0.40, dy = yB + (yT - yB) * z;
        ctx.save(); ctx.translate((f - .5) * R * 1.3, (f2 - .5) * R * 0.9 + dy); ctx.rotate(f * 6.28);
        const sd = R / 40;
        ctx.scale(sd, sd);
        ctx.globalAlpha = 1; ctx.strokeStyle = '#ffd88a'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(-10, 0); ctx.lineTo(6, 0); ctx.stroke();
        ctx.fillStyle = '#fff2c0'; ctx.beginPath(); ctx.arc(7, 0, 3.4, 0, 7); ctx.fill();
        ctx.globalAlpha = .40; const q = ctx.createRadialGradient(7, 0, 1, 7, 0, 14);
        q.addColorStop(0, '#ffe9a8'); q.addColorStop(1, 'rgba(255,200,80,0)');
        ctx.fillStyle = q; ctx.beginPath(); ctx.arc(7, 0, 14, 0, 7); ctx.fill();
        ctx.globalAlpha = 1; ctx.lineCap = 'butt'; ctx.restore();
      }
      ctx.restore();
      // la faccia in alto: e' la piu' piena, perche' e' quella rivolta alla telecamera
      const gg = ctx.createLinearGradient(-R, yT - R, R, yT + R);
      gg.addColorStop(0, 'rgba(176,220,128,.30)'); gg.addColorStop(.5, 'rgba(104,160,72,.25)'); gg.addColorStop(1, 'rgba(58,106,48,.29)');
      ctx.fillStyle = gg; via(alto, yT); ctx.fill();
      ctx.save(); via(alto, yT); ctx.clip();
      const cuore = ctx.createRadialGradient(-R * .2, yT - R * .2, R * .1, 0, yT, R * 1.15);
      cuore.addColorStop(0, 'rgba(40,80,34,0)'); cuore.addColorStop(1, 'rgba(28,58,26,.34)');
      ctx.fillStyle = cuore; ctx.fillRect(-R * 1.4, yT - R * 1.4, R * 2.8, R * 2.8);
      ctx.strokeStyle = 'rgba(206,240,160,.26)'; ctx.lineWidth = 2;   // lo spigolo di fondo, nel vetro
      ctx.beginPath();
      for (let k = 36; k <= 60; k++) { const q = base[(k + 64) % 64]; k === 36 ? ctx.moveTo(q.x, q.y + yB) : ctx.lineTo(q.x, q.y + yB); }
      ctx.stroke(); ctx.restore();
      if (m.fl) { ctx.fillStyle = 'rgba(255,255,255,.28)'; via(alto, yT); ctx.fill(); }
      ctx.strokeStyle = 'rgba(212,246,166,.62)'; ctx.lineWidth = 2.8; via(alto, yT); ctx.stroke();
      ctx.strokeStyle = 'rgba(16,32,14,.45)'; ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let k = -5; k <= 37; k++) { const q = base[(k + 64) % 64]; k === -5 ? ctx.moveTo(q.x, q.y + yB) : ctx.lineTo(q.x, q.y + yB); }
      ctx.stroke();
      ctx.strokeStyle = 'rgba(214,246,170,.26)'; ctx.lineWidth = 2;   // i due spigoli vicini
      for (const k of [8, 24]) { ctx.beginPath(); ctx.moveTo(base[k].x, base[k].y + yB); ctx.lineTo(alto[k].x, alto[k].y + yT); ctx.stroke(); }
      ctx.fillStyle = 'rgba(232,255,200,.26)';
      ctx.beginPath(); ctx.ellipse(-R * .40, yT - R * .40, R * .30, R * .16, -.5, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.34)';
      ctx.beginPath(); ctx.ellipse(-R * .46, yT - R * .46, R * .12, R * .065, -.5, 0, 7); ctx.fill();
      ctx.restore();
    },
    // v2.23 — LE ALI E L'ALONE DEL PADRONE (vettoriale sopra la marionetta raster).
    // Il battito e' UNA rotazione piu' una compressione orizzontale: da sopra non si vede lo
    // spessore, quindi la sola cosa che racconta il colpo d'ala e' quanto l'ala si accorcia.
    _aliPadrone(ctx, s, st, t) {
      const A = st.ali || {}, wind = A.wind || 0, strike = A.strike || 0, mov = A.moving ? 1 : 0;
      // in marcia batte piano, in carica si spalanca, nell'affondo si chiude di scatto
      const bat = Math.sin(t * (2.1 + mov * 1.5)) * (0.30 + mov * 0.16) + wind * 0.46 - strike * 0.52;
      const apri = 1 + wind * 0.22 - strike * 0.30;
      const RX = 132 * s, RY = -690 * s;              // la spalla, in coordinate della tela
      for (const lato of [-1, 1]) {
        ctx.save(); ctx.translate(lato * RX, RY); ctx.scale(lato, 1);
        ctx.rotate(-0.24 + bat * 0.34);
        ctx.scale((0.70 + Math.abs(Math.cos(bat)) * 0.34) * apri, 1.04 * apri);
        const L = 660 * s;                            // apertura dell'ala, in unita' della tela
        const wg = ctx.createLinearGradient(0, -L * 0.30, L, L * 0.18);
        wg.addColorStop(0, '#7a1f22'); wg.addColorStop(.45, '#4a1116'); wg.addColorStop(1, '#22070c');
        ctx.fillStyle = wg; ctx.strokeStyle = '#150508'; ctx.lineWidth = Math.max(1.4, 3 * s * 18);
        ctx.lineJoin = 'round';
        const P = (x, y) => [x * L, y * L];
        // la membrana: curve, non spezzate. Al primo giro era tutta a spigoli e sembrava un
        // aquilone di carta piegata.
        ctx.beginPath();
        let q = P(0.03, -0.07); ctx.moveTo(q[0], q[1]);
        let c1 = P(0.30, -0.44), c2 = P(0.68, -0.52), e = P(0.99, -0.40);
        ctx.bezierCurveTo(c1[0], c1[1], c2[0], c2[1], e[0], e[1]);          // il dito lungo
        c1 = P(0.78, -0.24); e = P(0.90, -0.09); ctx.quadraticCurveTo(c1[0], c1[1], e[0], e[1]);
        c1 = P(0.70, -0.02); e = P(0.77, 0.16); ctx.quadraticCurveTo(c1[0], c1[1], e[0], e[1]);
        c1 = P(0.55, 0.09); e = P(0.46, 0.30); ctx.quadraticCurveTo(c1[0], c1[1], e[0], e[1]);
        c1 = P(0.28, 0.14); e = P(0.03, 0.15); ctx.quadraticCurveTo(c1[0], c1[1], e[0], e[1]);
        ctx.closePath(); ctx.fill(); ctx.stroke();
        // le nervature: appena accennate. Marcate, la membrana sembra un ombrello.
        ctx.strokeStyle = 'rgba(184,92,104,.18)'; ctx.lineWidth = Math.max(0.8, 1.6 * s * 18);
        for (const d of [[-0.40, 0.92], [-0.06, 0.84], [0.14, 0.70], [0.28, 0.42]]) {
          const a0 = P(0.05, -0.02), a1 = P(d[1], d[0]);
          ctx.beginPath(); ctx.moveTo(a0[0], a0[1]);
          ctx.quadraticCurveTo((a0[0] + a1[0]) * 0.5, (a0[1] + a1[1]) * 0.5 - L * 0.05, a1[0], a1[1]); ctx.stroke(); }
        // il bordo esterno piu' scuro: da' spessore alla membrana
        ctx.strokeStyle = 'rgba(12,4,7,.5)'; ctx.lineWidth = Math.max(1.2, 2.4 * s * 18);
        ctx.beginPath(); const b0 = P(0.99, -0.40), b1 = P(0.90, -0.09), b2 = P(0.77, 0.16), b3 = P(0.46, 0.30);
        ctx.moveTo(b0[0], b0[1]); ctx.lineTo(b1[0], b1[1]); ctx.lineTo(b2[0], b2[1]); ctx.lineTo(b3[0], b3[1]); ctx.stroke();
        // gli strappi
        ctx.fillStyle = 'rgba(8,3,6,.45)';
        for (const d of [[0.58, -0.22, 0.09], [0.42, 0.06, 0.065]]) {
          const k0 = P(d[0], d[1]), k1 = P(d[0] + d[2], d[1] + d[2] * 0.4), k2 = P(d[0] + d[2] * 0.4, d[1] + d[2]);
          ctx.beginPath(); ctx.moveTo(k0[0], k0[1]); ctx.lineTo(k1[0], k1[1]); ctx.lineTo(k2[0], k2[1]); ctx.closePath(); ctx.fill(); }
        // gli artigli: piccoli. Prima erano palle nere grosse come la testa.
        ctx.fillStyle = '#3a1016'; ctx.strokeStyle = '#150508'; ctx.lineWidth = Math.max(0.8, 1.4 * s * 18);
        for (const d of [[0.99, -0.40, 1.0], [0.90, -0.09, 0.8], [0.77, 0.16, 0.7], [0.46, 0.30, 0.6]]) {
          const cc = P(d[0], d[1]); ctx.beginPath();
          ctx.arc(cc[0], cc[1], Math.max(1.1, 2.2 * s * 18 * d[2]), 0, 7); ctx.fill(); ctx.stroke(); }
        ctx.restore();
      }
    },
    _rollerF(ctx, m, r, def, atk) {
      const t = this.time, eye = def.eye || '#ff7a3b';
      this._roll = this._roll || {}; this._rollP = this._rollP || {};
      const prev = this._rollP[m.e]; let step = 0;
      if (prev) step = Math.hypot(m.x - prev.x, m.y - prev.y);
      this._rollP[m.e] = { x: m.x, y: m.y };
      const dir = step > 0.4 ? Math.atan2(m.y - (prev ? prev.y : m.y), m.x - (prev ? prev.x : m.x)) : (m.f || 0);
      this._roll[m.e] = (this._roll[m.e] || 0) + (step / Math.max(6, r)) * (Math.cos(dir) >= 0 ? 1 : -1);
      const spin = this._roll[m.e];
      const a = atk || 0;
      const wind = a > 0 ? Math.sin(Math.min(1, a) * Math.PI) : 0;      // carica: schiaccia e trema
      const sx = 1 + wind * 0.22, sy = 1 - wind * 0.18;
      const shake = wind * 2.4;
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.beginPath(); ctx.ellipse(0, r * 0.72, r * 0.86, r * 0.3, 0, 0, 7); ctx.fill();
      ctx.translate(Math.sin(t * 40) * shake, Math.cos(t * 37) * shake * 0.6);
      ctx.scale(sx, sy); ctx.rotate(spin);
      // sfera di ossa
      const bg = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.15, 0, 0, r);
      bg.addColorStop(0, '#efe8d2'); bg.addColorStop(0.6, '#cfc7b0'); bg.addColorStop(1, '#6f6857');
      ctx.fillStyle = bg; ctx.strokeStyle = '#3a3527'; ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill(); ctx.stroke();
      // suture / placche
      ctx.strokeStyle = 'rgba(60,54,40,.75)'; ctx.lineWidth = 2;
      for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.ellipse(0, 0, r * (0.92 - k * 0.06), r * (0.34 + k * 0.2), k * 1.05, 0, 7); ctx.stroke(); }
      // spuntoni d'osso
      ctx.fillStyle = '#e6dfc8'; ctx.strokeStyle = '#3a3527'; ctx.lineWidth = 1.6;
      for (let k = 0; k < 6; k++) { const an = (k / 6) * 6.283; ctx.save(); ctx.rotate(an);
        ctx.beginPath(); ctx.moveTo(-r * 0.16, -r * 0.94); ctx.lineTo(0, -r * 1.24); ctx.lineTo(r * 0.16, -r * 0.94); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore(); }
      // orbite accese
      ctx.fillStyle = '#171410'; ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.1, r * 0.19, r * 0.24, -0.2, 0, 7); ctx.ellipse(r * 0.3, -r * 0.1, r * 0.19, r * 0.24, 0.2, 0, 7); ctx.fill();
      const gp = 0.6 + 0.4 * Math.sin(t * 5) + wind * 0.5;
      ctx.fillStyle = this._rgba ? this._rgba(eye, Math.min(1, gp)) : eye;
      ctx.beginPath(); ctx.arc(-r * 0.3, -r * 0.1, r * 0.10, 0, 7); ctx.arc(r * 0.3, -r * 0.1, r * 0.10, 0, 7); ctx.fill();
      ctx.restore();
      // scia di polvere mentre rotola
      if (step > 1.2) { ctx.save(); ctx.globalAlpha = 0.28;
        for (let i = 1; i <= 3; i++) { ctx.fillStyle = '#8a8270';
          ctx.beginPath(); ctx.arc(-Math.cos(dir) * r * i * 0.7, -Math.sin(dir) * r * i * 0.7 + r * 0.4, r * (0.3 - i * 0.06), 0, 7); ctx.fill(); }
        ctx.restore(); }
    },
    // v1.61 — NUGOLO DI PIPISTRELLI. Una sola entita', 9 sagome che ORBITANO attorno al centro con fasi
    // diverse (angolo aureo: mai allineate). Ogni pipistrello e' corpo + due ali, e le ali sono UNA SOLA
    // sinusoide di battito: zero cicli di camminata, zero asset. In attacco il nugolo si STRINGE e scatta.
    // NOTA CONTRASTO: su pavimento quasi nero un pipistrello nero sparisce. Il corpo e' quindi GRIGIO-VIOLA
    // con bordo piu' chiaro, e sotto il nugolo c'e' un alone viola tenue che lo fa leggere a colpo d'occhio.
    _batsF(ctx, m, r, def, atk) {
      const t = this.time, eye = def.eye || '#c9a0ff', N = def.swarmN || 9;
      const a = atk || 0;
      const agg = a > 0 ? Math.sin(Math.min(1, a) * Math.PI) : 0;
      ctx.save();
      // ombra: una macchia sola, non 9 — il nugolo legge come UN nemico
      ctx.fillStyle = 'rgba(0,0,0,.30)';
      ctx.beginPath(); ctx.ellipse(0, r * 0.98, r * 0.66 * (1 - agg * 0.25), r * 0.22, 0, 0, 7); ctx.fill();
      // alone di massa: senza, su roccia nera lo sciame e' invisibile
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const hg = ctx.createRadialGradient(0, -r * 0.15, r * 0.2, 0, -r * 0.15, r * 1.45);
      hg.addColorStop(0, this._rgba(eye, 0.13 + agg * 0.10)); hg.addColorStop(1, this._rgba(eye, 0));
      ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(0, -r * 0.15, r * 1.45, 0, 7); ctx.fill();
      ctx.restore();
      // ordinamento per profondita': i pipistrelli "dietro" prima, cosi' si sovrappongono giusti
      const list = [];
      for (let i = 0; i < N; i++) {
        const ph = i * 2.399963;
        const rad = r * (0.34 + 0.60 * ((i * 0.37) % 1)) * (1 - agg * 0.38);
        const sp = 1.5 + ((i * 0.53) % 1) * 1.6;
        const an = t * sp + ph;
        list.push({
          x: Math.cos(an) * rad * 1.42,
          y: Math.sin(an * 0.9 + ph) * rad * 0.54 - r * 0.26 + Math.sin(t * 3.1 + i) * r * 0.12,
          s: r * 0.225 * (0.80 + 0.40 * ((i * 0.71) % 1)),
          ph: t * (11 + (i % 4) * 2.3) + i * 1.7,
          fp: Math.cos(an) < 0 ? -1 : 1,
        });
      }
      list.sort((p, q) => p.y - q.y);
      // v1.64 — niente piu' disegno vettoriale per pipistrello: si sceglie la posa dal battito (che e' una
      // sinusoide, quindi periodica) e si copia il fotogramma gia' cotto.
      const FR = this._batFrames(eye);
      for (const b of list) {
        const idx = ((((b.ph / 6.283185) % 1) + 1) % 1 * FR.n) | 0;
        const k = b.s / FR.S;
        ctx.save(); ctx.translate(b.x, b.y); ctx.scale(b.fp * k, k);
        ctx.drawImage(FR.frames[idx], -FR.ox, -FR.oy);
        ctx.restore();
      }
      ctx.restore();
    },
    // v1.64 — PIPISTRELLO COTTO. Misurato: il Nugolo costava 116 microsecondi per nemico per frame, TRE volte
    // lo scheletro e quindici volte la melma — di gran lunga il nemico piu' caro del gioco. Il motivo: 9 sagome
    // x (2 gradienti lineari + una ventina di operazioni di path) = 18 gradienti e ~180 operazioni per singolo
    // nugolo, sessanta volte al secondo. Il battito d'ali pero' e' una sinusoide: ha solo N pose distinte.
    // Le disegniamo UNA volta su canvas piccole e poi si fa drawImage, che e' una copia di pixel.
    _batFrames(eye) {
      const key = 'bat|' + eye;
      this._batC = this._batC || {};
      if (this._batC[key]) return this._batC[key];
      const S = 26, N = 12;
      const W = Math.ceil(S * 4.6 + 10), H = Math.ceil(S * 2.5 + 10);
      const ox = W / 2, oy = S * 1.7 + 5;
      const frames = [];
      for (let i = 0; i < N; i++) {
        const up = 0.30 + 0.70 * Math.sin((i / N) * 6.283185);
        const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
        const g = cv.getContext('2d'); g.translate(ox, oy);
        this._bat1(g, 0, 0, S, up, eye, 1);
        frames.push(cv);
      }
      const o = { frames, n: N, S, ox, oy };
      this._batC[key] = o; return o;
    },
    // singolo pipistrello: ali = due archi che si aprono/chiudono con `up`, corpo = ellisse, orecchie, occhietti
    _bat1(ctx, x, y, s, up, eye, flip) {
      ctx.save(); ctx.translate(x, y); if (flip < 0) ctx.scale(-1, 1);
      // membrana alare: grigio-viola con bordo chiaro (leggibile su nero) + venature
      const wg = ctx.createLinearGradient(0, -s * 1.1, 0, s * 0.5);
      wg.addColorStop(0, '#6a5c86'); wg.addColorStop(0.55, '#453a5c'); wg.addColorStop(1, '#2b2340');
      ctx.fillStyle = wg; ctx.strokeStyle = '#8e7fb0'; ctx.lineWidth = Math.max(0.7, s * 0.09); ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(0, -s * 0.1);
      ctx.quadraticCurveTo(-s * 1.35, -s * 1.45 * up, -s * 2.15, -s * 0.22 * up - s * 0.06);
      ctx.quadraticCurveTo(-s * 1.45, s * 0.26, 0, s * 0.34);
      ctx.quadraticCurveTo(s * 1.45, s * 0.26, s * 2.15, -s * 0.22 * up - s * 0.06);
      ctx.quadraticCurveTo(s * 1.35, -s * 1.45 * up, 0, -s * 0.1);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      // venature delle ali: due segmenti per lato, danno la lettura di "ala" e non di "macchia"
      ctx.strokeStyle = 'rgba(155,138,190,.55)'; ctx.lineWidth = Math.max(0.5, s * 0.06);
      ctx.beginPath();
      ctx.moveTo(-s * 0.15, -s * 0.02); ctx.lineTo(-s * 1.55, -s * 0.62 * up);
      ctx.moveTo(-s * 0.15, s * 0.06); ctx.lineTo(-s * 1.45, s * 0.12);
      ctx.moveTo(s * 0.15, -s * 0.02); ctx.lineTo(s * 1.55, -s * 0.62 * up);
      ctx.moveTo(s * 0.15, s * 0.06); ctx.lineTo(s * 1.45, s * 0.12);
      ctx.stroke();
      // corpo
      const bg = ctx.createLinearGradient(0, -s * 0.7, 0, s * 0.7);
      bg.addColorStop(0, '#5b4f74'); bg.addColorStop(1, '#241d33');
      ctx.fillStyle = bg; ctx.strokeStyle = '#0f0b18'; ctx.lineWidth = Math.max(0.6, s * 0.07);
      ctx.beginPath(); ctx.ellipse(0, s * 0.06, s * 0.42, s * 0.64, 0, 0, 7); ctx.fill(); ctx.stroke();
      // orecchie
      ctx.fillStyle = '#3d3355';
      ctx.beginPath();
      ctx.moveTo(-s * 0.32, -s * 0.34); ctx.lineTo(-s * 0.20, -s * 0.98); ctx.lineTo(-s * 0.02, -s * 0.40); ctx.closePath();
      ctx.moveTo(s * 0.32, -s * 0.34); ctx.lineTo(s * 0.20, -s * 0.98); ctx.lineTo(s * 0.02, -s * 0.40); ctx.closePath();
      ctx.fill();
      // occhietti accesi
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = eye;
      ctx.beginPath(); ctx.arc(-s * 0.18, -s * 0.14, s * 0.13, 0, 7); ctx.arc(s * 0.18, -s * 0.14, s * 0.13, 0, 7); ctx.fill();
      ctx.restore();
      ctx.restore();
    },
    // v1.61 — FUOCO FATUO. Fiamma fredda sospesa: nucleo additivo, lingua di fuoco che sfarfalla (nessun
    // frame: 3 sinusoidi sfasate), 3 scintille in orbita e ondeggio verticale lento. In drenaggio avvampa.
    _wispF(ctx, m, r, def, atk) {
      const t = this.time, eye = def.eye || '#7dffea';
      const a = atk || 0;
      const fl = a > 0 ? Math.sin(Math.min(1, a) * Math.PI) : 0;             // avvampata del drenaggio
      const bob = Math.sin(t * 1.5 + (m.e || 0)) * (def.bobAmp || 6);
      const flick = 0.82 + 0.18 * Math.sin(t * 9.3 + (m.e || 0)) + 0.10 * Math.sin(t * 21.7);
      ctx.save();
      // riflesso a terra: non e' un'ombra, e' luce proiettata (fluttua, non poggia)
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const fg = ctx.createRadialGradient(0, r * 1.5, 1, 0, r * 1.5, r * 1.9);
      fg.addColorStop(0, this._rgba(eye, 0.14 + fl * 0.10)); fg.addColorStop(1, this._rgba(eye, 0));
      ctx.fillStyle = fg; ctx.beginPath(); ctx.ellipse(0, r * 1.5, r * 1.9, r * 0.6, 0, 0, 7); ctx.fill();
      ctx.restore();
      ctx.translate(0, bob);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      // alone
      const hg = ctx.createRadialGradient(0, 0, r * 0.15, 0, 0, r * (2.5 + fl * 0.7));
      hg.addColorStop(0, this._rgba(eye, (0.34 + fl * 0.30) * flick)); hg.addColorStop(0.45, this._rgba(eye, 0.10 * flick)); hg.addColorStop(1, this._rgba(eye, 0));
      ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(0, 0, r * (2.5 + fl * 0.7), 0, 7); ctx.fill();
      // lingua di fiamma: larghezza e punta modulate da tre sinusoidi sfasate
      const hgt = r * (1.55 + 0.22 * Math.sin(t * 6.1) + fl * 0.5);
      const wid = r * (0.62 + 0.08 * Math.sin(t * 7.7 + 1.1));
      const sway = r * 0.16 * Math.sin(t * 4.3 + 0.7);
      ctx.fillStyle = this._rgba(eye, 0.55 * flick);
      ctx.beginPath();
      ctx.moveTo(0, r * 0.55);
      ctx.quadraticCurveTo(-wid, r * 0.1, -wid * 0.55 + sway * 0.5, -hgt * 0.45);
      ctx.quadraticCurveTo(-wid * 0.18 + sway, -hgt * 0.82, sway, -hgt);
      ctx.quadraticCurveTo(wid * 0.18 + sway, -hgt * 0.82, wid * 0.55 + sway * 0.5, -hgt * 0.45);
      ctx.quadraticCurveTo(wid, r * 0.1, 0, r * 0.55);
      ctx.closePath(); ctx.fill();
      // nucleo bianco
      const cg = ctx.createRadialGradient(0, -r * 0.12, 1, 0, -r * 0.12, r * 0.72);
      cg.addColorStop(0, 'rgba(255,255,255,' + (0.92 * flick) + ')'); cg.addColorStop(0.5, this._rgba(eye, 0.7 * flick)); cg.addColorStop(1, this._rgba(eye, 0));
      ctx.fillStyle = cg; ctx.beginPath(); ctx.ellipse(0, -r * 0.12, r * 0.6, r * 0.74, 0, 0, 7); ctx.fill();
      // due occhietti vuoti dentro il nucleo: da lontano e' una fiamma, da vicino ti guarda
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = 'rgba(4,18,20,' + (0.55 + 0.25 * Math.sin(t * 2.6)) + ')';
      ctx.beginPath(); ctx.ellipse(-r * 0.22, -r * 0.2, r * 0.11, r * 0.16, -0.15, 0, 7);
      ctx.ellipse(r * 0.22, -r * 0.2, r * 0.11, r * 0.16, 0.15, 0, 7); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      // scintille in orbita
      for (let i = 0; i < 3; i++) {
        const an = t * (1.9 + i * 0.6) + i * 2.1, rr2 = r * (1.0 + 0.25 * Math.sin(t * 2 + i));
        ctx.fillStyle = this._rgba(eye, 0.55 + 0.35 * Math.sin(t * 5 + i * 2));
        ctx.beginPath(); ctx.arc(Math.cos(an) * rr2, Math.sin(an) * rr2 * 0.55 - r * 0.1, r * 0.12, 0, 7); ctx.fill();
      }
      ctx.restore();
      ctx.restore();
      // brace che sale, rada (una ogni ~5 frame): la scia che lo rende "vivo" senza costare
      if (Math.random() < 0.22) this.particles.push({ x: m.x + MU.rand(-r * 0.5, r * 0.5), y: m.y + bob - r * 0.3,
        vx: MU.rand(-8, 8), vy: -MU.rand(14, 34), life: 0.6, t: 0.6, color: eye, r: MU.rand(1, 2.2), over: true });
    },
    _drawDarkMerchant(ctx, mrc, me) {
      const t = this.time; const x = mrc.x, y = mrc.y; const bob = Math.sin(t * 1.6) * 1.4; const flick = 0.6 + 0.4 * Math.sin(t * 9 + x);
      // v1.32 — beacon SEMPRE visibile (parità col Mercante Errante): colonna di luce viola/cremisi + anello pulsante
      const bt = 0.5 + 0.5 * Math.sin(t * 3);
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; const bmg = ctx.createLinearGradient(x, y - 80, x, y - 8); bmg.addColorStop(0, 'rgba(180,80,255,0)'); bmg.addColorStop(1, 'rgba(180,80,255,' + (0.10 + bt * 0.13) + ')'); ctx.fillStyle = bmg; ctx.fillRect(x - 7, y - 80, 14, 68); const bmg2 = ctx.createLinearGradient(x, y - 80, x, y - 8); bmg2.addColorStop(0, 'rgba(255,45,107,0)'); bmg2.addColorStop(1, 'rgba(255,45,107,' + (0.05 + bt * 0.06) + ')'); ctx.fillStyle = bmg2; ctx.fillRect(x - 4, y - 80, 8, 68); ctx.restore();
      ctx.strokeStyle = 'rgba(199,125,255,' + (0.35 + bt * 0.45) + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y + 4, 30 + bt * 5, 0, 7); ctx.stroke();
      // ombra viola
      ctx.fillStyle = 'rgba(40,0,50,.5)'; ctx.beginPath(); ctx.ellipse(x, y + 18, 24, 8, 0, 0, 7); ctx.fill();
      ctx.save(); ctx.translate(x, y);
      // altare di pietra scura
      ctx.fillStyle = '#241026'; ctx.strokeStyle = '#0a040c'; ctx.lineWidth = 2; this._rr(ctx, -22, -2, 44, 20, 3); ctx.fill(); ctx.stroke();
      // rune incise che pulsano
      ctx.strokeStyle = 'rgba(180,80,255,' + flick + ')'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-14, 8); ctx.lineTo(-8, 2); ctx.lineTo(-14, 2); ctx.moveTo(0, 8); ctx.lineTo(4, 2); ctx.lineTo(0, 2); ctx.lineTo(4, 8); ctx.moveTo(12, 8); ctx.lineTo(16, 2); ctx.stroke();
      // teschi ai lati dell'altare
      ctx.fillStyle = '#d8d2c0'; ctx.beginPath(); ctx.arc(-18, 2, 3.4, 0, 7); ctx.arc(18, 2, 3.4, 0, 7); ctx.fill(); ctx.fillStyle = '#0a040c'; ctx.beginPath(); ctx.arc(-19, 1.6, 1, 0, 7); ctx.arc(-17, 1.6, 1, 0, 7); ctx.arc(17, 1.6, 1, 0, 7); ctx.arc(19, 1.6, 1, 0, 7); ctx.fill();
      // pali ricurvi + lanterna viola sospesa
      ctx.strokeStyle = '#1a0a1e'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(24, -2); ctx.lineTo(28, -30); ctx.quadraticCurveTo(20, -34, 14, -32); ctx.stroke();
      const lg = ctx.createRadialGradient(14, -30 + bob, 1, 14, -30 + bob, 16); lg.addColorStop(0, 'rgba(190,90,255,' + (0.7 + 0.3 * flick) + ')'); lg.addColorStop(1, 'rgba(120,20,160,0)'); ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(14, -30 + bob, 16, 0, 7); ctx.fill();
      ctx.fillStyle = '#160820'; this._rr(ctx, 11, -35 + bob, 6, 10, 2); ctx.fill(); ctx.fillStyle = '#c77dff'; this._rr(ctx, 12.5, -33 + bob, 3, 6, 1); ctx.fill();
      // relique fluttuanti attorno
      for (let i = 0; i < 3; i++) { const a = t * 1.2 + i * 2.1; const rx = Math.cos(a) * 20, ry = -14 + Math.sin(a) * 6 + bob; ctx.fillStyle = ['#ff2d6b', '#b061ff', '#7dffea'][i]; ctx.globalAlpha = 0.85; ctx.beginPath(); ctx.arc(rx, ry, 2.4, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      // v1.32 — figura incappucciata scura dietro l'altare (restyle)
      ctx.translate(-2, bob);
      const cg = ctx.createLinearGradient(0, -34, 0, 4); cg.addColorStop(0, '#3a1550'); cg.addColorStop(0.6, '#20102e'); cg.addColorStop(1, '#0a040c'); ctx.fillStyle = cg; ctx.strokeStyle = '#1a0820'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-15, 4); ctx.quadraticCurveTo(-13, -28, 0, -33); ctx.quadraticCurveTo(13, -28, 15, 4); ctx.quadraticCurveTo(0, 10, -15, 4); ctx.closePath(); ctx.fill(); ctx.stroke();
      // bordo runico sulla veste
      ctx.strokeStyle = 'rgba(199,125,255,' + (0.3 + 0.3 * flick) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-11, 2); ctx.lineTo(11, 2); ctx.stroke();
      // spalle a punta bordate
      ctx.fillStyle = '#20102e'; ctx.strokeStyle = '#1a0820'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-14, -8); ctx.lineTo(-20, -16); ctx.lineTo(-9, -11); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(14, -8); ctx.lineTo(20, -16); ctx.lineTo(9, -11); ctx.closePath(); ctx.fill(); ctx.stroke();
      // cappuccio
      ctx.fillStyle = '#20102a'; ctx.strokeStyle = '#0a040c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-9, -24); ctx.quadraticCurveTo(0, -40, 9, -24); ctx.quadraticCurveTo(0, -20, -9, -24); ctx.closePath(); ctx.fill(); ctx.stroke();
      // volto: TESCHIO
      ctx.fillStyle = '#e8e0d0'; ctx.beginPath(); ctx.arc(0, -25, 5.6, 0, 7); ctx.fill(); ctx.fillRect(-3.6, -22, 7.2, 4);
      ctx.fillStyle = '#0a040c'; ctx.beginPath(); ctx.arc(-2.3, -26, 1.8, 0, 7); ctx.arc(2.3, -26, 1.8, 0, 7); ctx.fill();
      // occhi ardenti viola dentro le orbite
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = '#d9a6ff'; ctx.shadowColor = '#c77dff'; ctx.shadowBlur = 9; ctx.beginPath(); ctx.arc(-2.3, -26, 1.0, 0, 7); ctx.arc(2.3, -26, 1.0, 0, 7); ctx.fill(); ctx.restore();
      // mani ossute che presentano la merce
      ctx.strokeStyle = '#e8e0d0'; ctx.lineCap = 'round'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-8, -6); ctx.lineTo(-12, -2); ctx.moveTo(8, -6); ctx.lineTo(12, -2); ctx.stroke();
      ctx.restore();
      // simbolo teschio fluttuante + etichetta se vicino
      ctx.fillStyle = 'rgba(199,125,255,' + (0.7 + 0.3 * Math.sin(t * 4)) + ')'; ctx.font = 'bold 17px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('\uD83D\uDC80', x, y - 46 + bob); ctx.textAlign = 'left';
      // v1.32 — etichetta SEMPRE visibile (come il Mercante Errante), non solo da vicino
      ctx.fillStyle = '#e0b0ff'; ctx.font = 'bold 13px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('\uD83D\uDC80 Mercante Nero', x, y - 62 + bob); ctx.textAlign = 'left';
    },
    _drawXp(ctx, o) { const t = this.time; const y = o.y + Math.sin(t * 6 + o.e) * 1.2; ctx.fillStyle = 'rgba(120,255,180,' + (0.5 + 0.3 * Math.sin(t * 8 + o.e)) + ')'; ctx.beginPath(); ctx.arc(o.x, y, 5, 0, 7); ctx.fill(); ctx.fillStyle = '#eaffe6'; ctx.beginPath(); ctx.arc(o.x, y, 2, 0, 7); ctx.fill(); },
    _drawCoin(ctx, o) { const cc = COIN_COL[o.c] || { color: '#ffcf4a', r: 5 }; const t = this.time; const ph = o.e || 0; const y = o.y + Math.sin(t * 5 + ph) * 1.4; const sq = Math.abs(Math.cos(t * 3 + ph)); const rw = cc.r * (0.4 + 0.6 * sq); ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(o.x, o.y + 6, cc.r * 0.9, cc.r * 0.4, 0, 0, 7); ctx.fill(); ctx.fillStyle = cc.color; ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(o.x, y, rw, cc.r, 0, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,' + (0.35 + 0.35 * sq) + ')'; ctx.beginPath(); ctx.ellipse(o.x - rw * 0.3, y - cc.r * 0.3, rw * 0.3, cc.r * 0.35, 0, 0, 7); ctx.fill(); },
    _drawItem(ctx, it) { const def = ITEM_BY_ID[it.id] || {}; const col = def.color || '#ffd24a'; const t = this.time; const y = it.y + Math.sin(t * 2.5 + it.e) * 1.8;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(it.x, it.y + 12, 12, 5, 0, 0, 7); ctx.fill();
      const gr = ctx.createRadialGradient(it.x, y, 2, it.x, y, 26); gr.addColorStop(0, col + 'cc'); gr.addColorStop(1, 'rgba(0,0,0,0)'); ctx.globalAlpha = 0.35 + 0.2 * Math.sin(t * 5 + it.e); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(it.x, y, 26, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
      ctx.fillStyle = col; ctx.strokeStyle = '#0a0c12'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(it.x, y, 8, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#0a0c12'; ctx.font = 'bold 12px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText(def.glyph || '?', it.x, y + 4); ctx.textAlign = 'left'; },
    _drawCrate(ctx, c) { const t = this.time; const x = c.x, y = c.y + Math.sin(t * 2 + c.e) * 1.2; ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(c.x, c.y + 14, 15, 6, 0, 0, 7); ctx.fill(); const gr = ctx.createRadialGradient(x, y, 2, x, y, 30); gr.addColorStop(0, 'rgba(255,200,80,' + (0.28 + 0.12 * Math.sin(t * 4 + c.e)) + ')'); gr.addColorStop(1, 'rgba(255,180,40,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, 30, 0, 7); ctx.fill(); ctx.fillStyle = '#6b4a28'; ctx.strokeStyle = '#2c1c0e'; ctx.lineWidth = 2; this._rr(ctx, x - 14, y - 11, 28, 22, 3); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#5a3d20'; this._rr(ctx, x - 14, y - 3, 28, 6, 2); ctx.fill(); ctx.strokeStyle = '#b98b4a'; ctx.beginPath(); ctx.moveTo(x - 14, y - 3); ctx.lineTo(x + 14, y - 3); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x, y - 11); ctx.lineTo(x, y + 11); ctx.stroke(); ctx.fillStyle = '#ffd24a'; ctx.beginPath(); ctx.arc(x, y - 1, 3.2, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,235,150,.9)'; ctx.font = 'bold 14px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('?', x, y - 16 + Math.sin(t * 3 + c.e) * 2); ctx.textAlign = 'left'; },
    _drawWeapon(ctx, wd) { const W = window.GAME.Loot.WEAPONS[wd.wt] || {}; const col = W.color || '#ffd24a'; const t = this.time; const x = wd.x, y = wd.y + Math.sin(t * 2.5 + wd.e) * 1.6; ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(wd.x, wd.y + 14, 13, 5, 0, 0, 7); ctx.fill(); const gr = ctx.createRadialGradient(x, y, 2, x, y, 30); gr.addColorStop(0, col + 'cc'); gr.addColorStop(1, 'rgba(0,0,0,0)'); ctx.globalAlpha = 0.35 + 0.2 * Math.sin(t * 5 + wd.e); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, 30, 0, 7); ctx.fill(); ctx.globalAlpha = 1; ctx.save(); ctx.translate(x, y); ctx.strokeStyle = '#0a0c12'; ctx.lineWidth = 2; if (wd.wt === 'scatter') { ctx.fillStyle = col; this._rr(ctx, -10, -4, 20, 8, 2); ctx.fill(); ctx.stroke(); } else if (wd.wt === 'burst') { ctx.fillStyle = col; this._rr(ctx, -9, -3, 16, 6, 2); ctx.fill(); ctx.stroke(); } else { ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(0, -7); ctx.lineTo(11, 0); ctx.lineTo(0, 7); ctx.closePath(); ctx.fill(); ctx.stroke(); } ctx.restore(); for (let i = 0; i < 3; i++) { ctx.fillStyle = i < (wd.lv || 1) ? col : 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.arc(x - 8 + i * 8, y - 15, 2.4, 0, 7); ctx.fill(); } },
    _drawChains(ctx) { for (const c of this.chains) { const a = c.t / 0.18; ctx.strokeStyle = 'rgba(140,220,255,' + a + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); const seg = 4; ctx.moveTo(c.x1, c.y1); for (let i = 1; i < seg; i++) { const t = i / seg; ctx.lineTo(MU.lerp(c.x1, c.x2, t) + MU.rand(-6, 6), MU.lerp(c.y1, c.y2, t) + MU.rand(-6, 6)); } ctx.lineTo(c.x2, c.y2); ctx.stroke(); } },
    // v1.63 — LA FAGLIA AI MARGINI. L'alone si chiude dai bordi dello schermo mentre la carica sale, e
    // la carica comincia a salire APPENA entri nella fascia — cioe' 2.5 secondi PRIMA che il danno inizi.
    // E' un avviso, non un castigo: quando i filamenti compaiono hai gia' perso vita, quando l'alone e'
    // appena accennato sei ancora in tempo. Il valore arriva dallo snapshot (me.eg, 0..1).
    // v1.65 — IL FASCIO DELLA FAGLIA. La prima versione (tentacoli sottili) era troppo timida: si vedeva
    // appena, e un avviso che non si vede non e' un avviso. Rifatta con lo stesso linguaggio visivo del
    // FASCIO DELLO SGUARDO del Beholder, che nel gioco funziona: ventaglio pieno che si allarga dalla
    // sorgente + nucleo pulsante ad alta frequenza + bagliore alla radice.
    // Differenza chiave rispetto ai tentacoli: i filamenti ARRIVANO al giocatore invece di allungarsi a
    // caso. E' la linea che collega causa ed effetto — si capisce a colpo d'occhio che e' QUEL muro a farti
    // male, non "l'aria". In un angolo partono due fasci, uno per lato.
    // le RADICI del fascio: il punto sulla roccia del bordo piu' vicino, per ogni lato entro portata.
    // Serve sia al fascio sia al buio (che deve aprire un buco li', altrimenti l'effetto resta al buio).
    _edgeRoots(me) {
      const m = this.map; if (!m || !me) return [];
      const T = m.tile;
      const x0 = 2 * T, y0 = 2 * T, x1 = (m.w - 2) * T, y1 = (m.h - 2) * T;
      const REACH = (C.EDGE_MARGIN || 3) * T + 150;
      const r = [];
      if (me.x - x0 < REACH) r.push({ x: x0 - T * 0.5, y: me.y });
      if (x1 - me.x < REACH) r.push({ x: x1 + T * 0.5, y: me.y });
      if (me.y - y0 < REACH) r.push({ x: me.x, y: y0 - T * 0.5 });
      if (y1 - me.y < REACH) r.push({ x: me.x, y: y1 + T * 0.5 });
      return r;
    },
    _drawEdgeTendrils(ctx, world) {
      const me = world.me; if (!me) return;
      const lv = me.eg || 0; if (lv <= 0.02) return;
      const m = this.map; if (!m) return;
      const T = m.tile, t = this.time, col = '#b25cff';
      const x0 = 2 * T, y0 = 2 * T, x1 = (m.w - 2) * T, y1 = (m.h - 2) * T;
      const roots = this._edgeRoots(me);
      if (!roots.length) return;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (const r of roots) {
        const dx = me.x - r.x, dy = me.y - r.y;
        const len = Math.max(30, Math.hypot(dx, dy));
        const ang = Math.atan2(dy, dx);
        ctx.save(); ctx.translate(r.x, r.y); ctx.rotate(ang);

        // 1) VENTAGLIO — gradiente in cache su lunghezze arrotondate (niente allocazioni per frame)
        const L = Math.max(40, Math.round(len / 40) * 40);
        const spread = Math.tan(0.40) * len;
        const gr = this._grad('ef|' + L, () => {
          const q = ctx.createLinearGradient(0, 0, L, 0);
          q.addColorStop(0, this._rgba(col, 0.46)); q.addColorStop(0.6, this._rgba(col, 0.12)); q.addColorStop(1, this._rgba(col, 0.02));
          return q;
        });
        ctx.globalAlpha = 0.28 + 0.72 * lv;
        ctx.fillStyle = gr;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(len, -spread * 0.55); ctx.lineTo(len, spread * 0.55); ctx.closePath(); ctx.fill();

        // 2) FILAMENTI che arrivano ADDOSSO al giocatore
        ctx.globalAlpha = 1;
        ctx.lineCap = 'round';
        for (let i = 0; i < 5; i++) {
          const w1 = Math.sin(t * (2.1 + i * 0.6) + i * 1.9) * len * 0.16;
          const w2 = Math.sin(t * (1.5 + i * 0.5) + i * 2.7) * len * 0.11;
          ctx.strokeStyle = this._rgba(col, (0.30 + 0.50 * lv) * (0.55 + 0.45 * Math.sin(t * 8 + i * 2.1)));
          ctx.lineWidth = 1.8 + 3.2 * lv * (0.5 + 0.5 * ((i * 0.37) % 1));
          ctx.beginPath();
          ctx.moveTo(0, (i - 2) * 9);
          ctx.bezierCurveTo(len * 0.34, w1, len * 0.68, w2, len, 0);
          ctx.stroke();
        }

        // 3) NUCLEO pulsante ad alta frequenza, come la linea centrale dello sguardo del Beholder
        ctx.strokeStyle = this._rgba('#eccfff', (0.30 + 0.55 * lv) * (0.5 + 0.5 * Math.sin(t * 14)));
        ctx.lineWidth = 1.4 + 2.2 * lv;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(len, 0); ctx.stroke();
        ctx.lineCap = 'butt';

        // 4) BAGLIORE alla radice: la ferita nella roccia da cui esce tutto
        const fg = this._grad('efr', () => {
          const q = ctx.createRadialGradient(0, 0, 2, 0, 0, 110);
          q.addColorStop(0, this._rgba('#e0b3ff', 0.85)); q.addColorStop(0.35, this._rgba(col, 0.35)); q.addColorStop(1, this._rgba(col, 0));
          return q;
        });
        ctx.globalAlpha = (0.35 + 0.65 * lv) * (0.75 + 0.25 * Math.sin(t * 6));
        ctx.fillStyle = fg; ctx.beginPath(); ctx.arc(0, 0, 110, 0, 7); ctx.fill();
        ctx.globalAlpha = 1;
        ctx.restore();
      }
      ctx.restore();
    },
    // v2.17 — TEMPO RUBATO: come si vede che il mondo sta andando al rallentatore.
    // Tre cose insieme, perche' una sola si legge come un difetto dello schermo e non come un'abilita':
    //   · una TINTA fredda su tutto il mondo (non sull'HUD: l'interfaccia resta leggibile);
    //   · una VIGNETTATURA blu che stringe i bordi, come quando il tempo ti si chiude addosso;
    //   · due ANELLI che si allargano dal personaggio a ritmo lento, l'orologio che batte piano.
    // Si accende e si spegne con una rampa di 0,25s: un taglio netto sembrerebbe un lampo, non un'entrata.
    _drawTempo(ctx, world, dt) {
      const acceso = !!world.bt;
      this._btA = Math.max(0, Math.min(1, (this._btA || 0) + (acceso ? 1 : -1) * (dt || 0.016) / 0.25));
      const a = this._btA; if (a <= 0.001) return;
      const W = this.w, H = this.h, cx = W / 2, cy = H / 2;
      // 1) la tinta fredda su tutto (lo schermo, non il mondo: e' un effetto di camera)
      ctx.fillStyle = 'rgba(120,180,255,' + (0.13 * a) + ')';
      ctx.fillRect(0, 0, W, H);
      // 2) la vignettatura blu che stringe i bordi
      const gr = ctx.createRadialGradient(cx, cy, Math.min(W, H) * 0.26, cx, cy, Math.max(W, H) * 0.62);
      gr.addColorStop(0, 'rgba(10,26,60,0)'); gr.addColorStop(1, 'rgba(10,26,60,' + (0.62 * a) + ')');
      ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
      // 3) due anelli lenti dal centro: l'orologio che batte piano
      for (let k = 0; k < 2; k++) {
        const f = ((this.time * 0.5 + k * 0.5) % 1);
        ctx.strokeStyle = 'rgba(143,216,255,' + ((1 - f) * 0.4 * a) + ')';
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(cx, cy, 30 + f * Math.max(W, H) * 0.5, 0, 7); ctx.stroke();
      }
    },
    _drawEdgeVignette(ctx, world) {
      const me = world.me; if (!me) return;
      const lv = me.eg || 0; if (lv <= 0.01) return;
      const t = this.time, W = this.w, H = this.h;
      const pulse = 0.72 + 0.28 * Math.sin(t * (4 + lv * 10));
      // soglia bassa ALZATA: a lv 0.15 (dentro la finestra di grazia, nessun danno ancora) prima non si
      // vedeva niente, e un avviso invisibile non e' un avviso. Ora l'alone si accende subito e poi si chiude.
      const a = Math.min(0.82, 0.14 + lv * 0.72) * pulse;
      ctx.save();
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * (0.55 - lv * 0.26), W / 2, H / 2, Math.max(W, H) * 0.74);
      g.addColorStop(0, 'rgba(120,30,180,0)');
      g.addColorStop(0.6, 'rgba(108,26,168,' + (a * 0.30).toFixed(3) + ')');
      g.addColorStop(1, 'rgba(52,6,96,' + a.toFixed(3) + ')');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      // filamenti che strisciano verso l'interno: compaiono solo quando il drenaggio morde davvero
      if (lv > 0.34) {
        const k = (lv - 0.34) / 0.66;
        ctx.globalCompositeOperation = 'lighter';
        ctx.strokeStyle = 'rgba(190,110,255,' + (0.16 + 0.22 * k).toFixed(3) + ')';
        ctx.lineCap = 'round';
        for (let i = 0; i < 22; i++) {
          const s = (i * 0.61803) % 1, side = i % 4;
          const len = (26 + 74 * k) * (0.5 + ((i * 0.37) % 1)) * (0.8 + 0.2 * Math.sin(t * 3 + i));
          ctx.lineWidth = 1 + 1.6 * ((i * 0.53) % 1);
          ctx.beginPath();
          if (side === 0) { ctx.moveTo(s * W, 0); ctx.quadraticCurveTo(s * W + len * 0.3, len * 0.5, s * W - len * 0.2, len); }
          else if (side === 1) { ctx.moveTo(s * W, H); ctx.quadraticCurveTo(s * W - len * 0.3, H - len * 0.5, s * W + len * 0.2, H - len); }
          else if (side === 2) { ctx.moveTo(0, s * H); ctx.quadraticCurveTo(len * 0.5, s * H + len * 0.3, len, s * H - len * 0.2); }
          else { ctx.moveTo(W, s * H); ctx.quadraticCurveTo(W - len * 0.5, s * H - len * 0.3, W - len, s * H + len * 0.2); }
          ctx.stroke();
        }
        ctx.lineCap = 'butt';
      }
      ctx.restore();
    },
    // v1.64 — la funzione light() prende il gradiente dalla CACHE: prima ne allocava uno per OGNI sorgente
    // a ogni frame (torce, proiettili, monete, oggetti, giocatori, boss...). ATTENZIONE: questo metodo e' una
    // sola istruzione lunghissima, i commenti vanno sopra la riga, mai in coda.
    // ===================== v2.1 — IL CAMPO VISIVO =====================
    // Prima il buio era un velo TONDO attorno al giocatore: vedevi un cerchio, e una stanza dietro una
    // roccia si vedeva uguale a una stanza aperta. Adesso si vede quello che si PUO' vedere, e si vede
    // come lo vedrebbe uno con una TORCIA IN MANO.
    //
    // UNA SOLA FORMA. Al primo tentativo avevo fatto un cono davanti piu' un cerchietto attorno ai piedi:
    // due forme diverse cucite insieme, e la cucitura si vedeva — un cerchio netto con un triangolo
    // attaccato. Adesso e' una goccia sola: si tirano raggi su TUTTO il giro, e a cambiare non e' quali
    // raggi esistono ma QUANTO LONTANO arrivano (`_fovPortata`). Davanti lontano, di fianco meno, dietro
    // pochissimo. Nessun bordo, perche' non c'e' nessun bordo da disegnare.
    //
    // Ogni raggio cammina a passetti finche' non sbatte in un muro. Dietro il muro il raggio non arriva,
    // quindi la luce non ci arriva: l'occlusione non e' un calcolo a parte, e' la stessa cosa.
    _fovBuf: null,
    // dc = coseno dell'angolo fra "dove guardo" e il raggio. Due luci, stessa formula:
    //   l'ALONE — largo, corto, ti illumina attorno
    //   il FASCIO — stretto, lungo, va dove punti
    // Sono due curve continue: sommandole non nasce nessuna giuntura, ed e' tutto il trucco.
    _fovPortata(dc) {
      const A = C.FOV_AVANTI || 540, D = C.FOV_DIETRO || 118;
      return D + (A - D) * Math.pow((1 + dc) * 0.5, C.FOV_FORMA || 1.5);
    },
    _fovPortataCono(dc) {
      return (C.FOV_CONO || 1150) * Math.pow((1 + dc) * 0.5, C.FOV_CONO_FORMA || 5.5);
    },
    // per ogni raggio salva quattro numeri: la direzione (nx, ny), dove ha sbattuto (d) e quanto lontano
    // sarebbe potuto arrivare (rt). Servono tutti e quattro: gli strati della sfumatura si accorciano
    // sulla PORTATA, ma restano fermi al MURO — se no accanto a una parete si aprirebbe un anello scuro.
    // v2.1.1 — L'OMBRA LA FANNO SOLO I MURI. La griglia e' binaria: per lei una LAPIDE del cimitero e un
    // masso sono la stessa cosa, e infatti ogni lapide proiettava il suo cono d'ombra — un campo di lapidi
    // diventava una grattugia di ombre. Il tipo vero della tessera sta in `m.muri` (lo stesso array che
    // dice al renderer cosa disegnare, v1.97).
    //
    // Passa la luce SOLO la lapide (1): e' roba che arriva al ginocchio, ci si vede sopra. Tutto il resto
    // ferma lo sguardo — roccia (0), pietra squadrata delle cappelle (2), cinta (3) e ALBERI SECCHI (4),
    // che sono alti e per giunta fanno da bordo alla mappa: se lasciassero passare la luce si vedrebbe
    // fuori dal cimitero. (Se un giorno servisse far passare anche i muretti bassi, si aggiunge il 2 qui
    // e basta: e' l'unico punto in cui questa distinzione esiste.)
    //
    // Attenzione: qui si parla solo di LUCE. Per le collisioni e per l'IA una lapide resta un muro — e
    // dev'essere cosi', se no i mostri ci passerebbero attraverso.
    _fovBlocca(m, i) {
      if (m.grid[i] !== C.T_WALL) return false;
      const mu = m.muri; if (!mu) return true;
      return mu[i] !== 1;
    },
    // Un raggio solo per entrambe le luci: si marcia fino alla PIU' LUNGA delle due portate e si segna
    // dove si e' sbattuto. Poi ogni luce si ferma alla sua portata o al muro, quello che viene prima.
    // Cinque numeri per raggio: direzione (nx, ny), dove ha sbattuto (d), e le due portate (alone, fascio).
    _fovPunte(px, py, aim, out, off, n) {
      const m = this.map, T = m.tile, W = m.w, H = m.h;
      const passo = T * 0.34;                       // un terzo di tessera: piu' fine non si nota
      const ca = Math.cos(aim), sa = Math.sin(aim);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * 6.283185307;
        const nx = Math.cos(a), ny = Math.sin(a);
        const dc = nx * ca + ny * sa;
        const Ra = this._fovPortata(dc), Rc = this._fovPortataCono(dc);
        const R = Ra > Rc ? Ra : Rc;
        let d = passo;
        while (d < R) {
          const tx = ((px + nx * d) / T) | 0, ty = ((py + ny * d) / T) | 0;
          if (tx < 0 || ty < 0 || tx >= W || ty >= H || this._fovBlocca(m, ty * W + tx)) break;
          d += passo;
        }
        if (d > R) d = R;
        const o = off + i * 5;
        out[o] = nx; out[o + 1] = ny; out[o + 2] = d; out[o + 3] = Ra; out[o + 4] = Rc;
      }
    },
    // il contorno della macchia a una certa FRAZIONE della portata (1 = il bordo esterno)
    // `q` sceglie la luce: 3 = l'alone, 4 = il fascio
    _fovContorno(g, buf, off, n, ox, oy, fr, q) {
      const k = q || 3;
      for (let i = 0; i < n; i++) {
        const o = off + i * 5;
        let r = buf[o + k] * fr; const d = buf[o + 2]; if (r > d) r = d;
        const x = ox + buf[o] * r, y = oy + buf[o + 1] * r;
        if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
      }
      g.closePath();
    },
    // LA SFUMATURA. Non un gradiente radiale — un gradiente e' un cerchio, e questa forma non lo e'.
    // Sono contorni annidati, dal piu' largo al piu' stretto, ognuno cancella un altro po' di velo: la
    // luce cala seguendo la goccia invece che un cerchio, e vicino ai muri si ferma dove si ferma la vista.
    // La tabella si calcola una volta: per ogni strato, quale frazione della portata e quanto cancella.
    // La tabella si costruisce da una CURVA DI LUCE: `v(t)` dice quanta luce vogliamo a quel raggio, e da
    // li' si ricava quanto deve cancellare ogni strato perche' il risultato cumulato sia proprio quello.
    // Due curve, una per luce, ed e' qui che si regola l'integrazione fra le due:
    //   l'ALONE cala presto e dolce — e' luce diffusa, non deve avere un bordo;
    //   il FASCIO tiene piu' a lungo e sfuma lunghissimo — e' un fascio, la punta deve arrivare.
    // `piena` = fino a che frazione della portata la luce resta PIENA prima di cominciare a calare.
    // E' il numero che decide se una luce si LEGGE o se sfuma via subito: su un pavimento di grotta, gia'
    // scuro di suo, sotto il 60% di luce non si distingue piu' niente. Un fascio che cala da subito e'
    // un fascio che sembra corto, per quanto lontano arrivi la sua portata.
    _fovTabella: function (L, piena, esp) {
      const out = []; let prec = 0;
      for (let i = 0; i < L; i++) {
        const fr = 1 - i / L;
        const t = 1 - (i + 1) / L;
        const v = t <= piena ? 1 : Math.min(1, Math.pow(Math.max(0, (1 - t) / (1 - piena)), esp));
        const a = prec >= 1 ? 1 : (v - prec) / (1 - prec);
        out.push([fr, Math.max(0, Math.min(1, a))]);
        prec = v;
      }
      return out;
    },
    // Calcola le macchie di TUTTI i giocatori vivi una volta per fotogramma. In cooperativa la visuale e'
    // condivisa: quello che vede un compagno lo vedi anche tu, se no in due si gioca peggio che da soli.
    _fovSagome(world) {
      if (!this._fovStratiAlone) {
        this._fovStratiAlone = this._fovTabella(14, 0.22, 1.00);   // alone: pieno vicino, poi sfuma tutto
        this._fovStratiCono  = this._fovTabella(20, 0.34, 0.70);   // fascio: pieno per un terzo, poi cala piano
      }
      const N = C.FOV_RAGGI || 256, per = N * 5;
      const vivi = [];
      for (const p of world.players) if (!p.d) vivi.push(p);
      if (!vivi.length) return null;
      if (!this._fovBuf || this._fovBuf.length < vivi.length * per) this._fovBuf = new Float32Array(Math.max(6, vivi.length) * per);
      const out = this._fovOut || (this._fovOut = []);
      out.length = 0;
      for (let k = 0; k < vivi.length; k++) {
        const p = vivi[k], base = k * per;
        this._fovPunte(p.x, p.y, p.a || 0, this._fovBuf, base, N);
        out.push({ x: p.x, y: p.y, a: p.a || 0, off: base, n: N });
      }
      return out;
    },
    // v2.0.2 — IL VELO SI TOGLIE SOLO DOVE LA MAPPA LO DICE. `map.lit` lo dichiara UNA mappa sola, il
    // villaggio: la' vuoi vedere dove sono le botteghe, non scoprirle. Ovunque altro il velo resta quello
    // di sempre — nelle ondate non sapere cosa c'e' dietro l'angolo e' meta' del gioco, e questa riga non
    // va allargata ad altre mappe senza rendersene conto.
    // v2.1 — IL VELO E' UNA TELA A PARTE, e non poteva essere altrimenti. Al primo tentativo ritagliavo
    // il campo visivo direttamente sulla tela del gioco con 'destination-out': quello non cancella il
    // velo, cancella i PIXEL — mondo compreso — e il cono diventava un buco trasparente sul nero della
    // pagina. Il velo si costruisce quindi su una sua tela (a meta' risoluzione: il bordo sfumato non
    // chiede di piu', e costa un quarto), ci si ritaglia dentro la sagoma, e poi la si appoggia sopra.
    // v2.1.3 — la tela del velo e' piu' GRANDE dello schermo di un margine. Serve alla sfocatura: sfocando
    // un rettangolo, il suo bordo diventa semitrasparente, e se quel bordo coincidesse col bordo dello
    // schermo si vedrebbe una cornice chiara tutt'attorno. Col margine il bordo sfumato cade fuori.
    _veloM: 26,
    _veloTela() {
      if (!this._veloCv) { this._veloCv = document.createElement('canvas'); this._veloCtx = this._veloCv.getContext('2d'); }
      const s = 0.5, M = this._veloM;
      const w = Math.max(1, Math.round((this.w + M * 2) * s)), h = Math.max(1, Math.round((this.h + M * 2) * s));
      if (this._veloCv.width !== w || this._veloCv.height !== h) { this._veloCv.width = w; this._veloCv.height = h; }
      return s;
    },
    _drawLighting(ctx, world, camX, camY) {
      ctx.save(); const g = ctx;
      const _lit = !!(this.map && this.map.lit);
      const _fov = _lit ? null : this._fovSagome(world);
      if (_fov) {
        // --- IL BUIO, e dentro il buio la sagoma di cio' che si vede ---
        const s = this._veloTela(), vg = this._veloCtx, B = C.FOV_BUIO || 0.93, M = this._veloM;
        vg.setTransform(s, 0, 0, s, M * s, M * s);
        vg.globalCompositeOperation = 'source-over';
        vg.clearRect(-M, -M, this.w + M * 2, this.h + M * 2);
        vg.fillStyle = 'rgba(2,3,9,' + B.toFixed(3) + ')'; vg.fillRect(-M, -M, this.w + M * 2, this.h + M * 2);
        vg.globalCompositeOperation = 'destination-out';
        vg.fillStyle = '#000';
        for (const f of _fov) {
          const sx = f.x - camX, sy = f.y - camY;
          // v2.1.2 — DUE PASSATE, non due forme incollate. Cancellare e' moltiplicativo: dove l'alone ha
          // gia' tolto meta' velo, il fascio toglie meta' di quel che resta. Il risultato e' che nel cuore
          // (davanti e vicino) le due luci si SOMMANO senza gradino, e ai lati il fascio si spegne da solo
          // perche' la sua portata li' e' quasi zero. Nessun bordo, nessuna giuntura: la fusione la fanno
          // le sfumature, non un ritaglio.
          for (let i = 0; i < this._fovStratiAlone.length; i++) {
            const st = this._fovStratiAlone[i];
            vg.globalAlpha = st[1];
            vg.beginPath(); this._fovContorno(vg, this._fovBuf, f.off, f.n, sx, sy, st[0], 3); vg.fill();
          }
          for (let i = 0; i < this._fovStratiCono.length; i++) {
            const st = this._fovStratiCono[i];
            vg.globalAlpha = st[1];
            vg.beginPath(); this._fovContorno(vg, this._fovBuf, f.off, f.n, sx, sy, st[0], 4); vg.fill();
          }
        }
        vg.globalAlpha = 1;
        vg.setTransform(1, 0, 0, 1, 0, 0);
        g.globalCompositeOperation = 'source-over';
        // LA PENOMBRA. Il bordo dell'ombra di un muro era un taglio netto — giusto in geometria (il raggio
        // o passa o non passa), sbagliato all'occhio: nessuna luce vera fa un bordo cosi'. Si sfoca il velo
        // INTERO, una volta sola, quando lo si appoggia: costa un'operazione per fotogramma invece di una
        // per ogni contorno, e ammorbidisce insieme i bordi delle ombre e la coda delle due luci.
        const _sf = C.FOV_SFUMA || 0;
        if (_sf > 0) g.filter = 'blur(' + _sf + 'px)';
        g.drawImage(this._veloCv, -M, -M, this.w + M * 2, this.h + M * 2);
        if (_sf > 0) g.filter = 'none';
      } else if (this.map.lit) {
        // ===== IL VILLAGGIO: buio vero, bucato dalle sorgenti =====
        // v2.4 — dalla v2.2 qui c'era una VELATURA: un rettangolo semitrasparente steso su tutto. Piu' la
        // si caricava e piu' si vedeva per quello che era — una PATINA. Un velo uniforme non scurisce:
        // SBIANCA, perche' schiarisce i neri tanto quanto spegne i chiari, e il risultato e' una nebbia
        // grigia appoggiata sopra il disegno.
        // Adesso il villaggio e' quasi nero e la luce la fanno SOLO le sorgenti, che ci scavano dentro i
        // loro buchi. E' lo stesso meccanismo del campo visivo delle grotte — una tela a parte, si
        // cancella, si sfoca, si appoggia — applicato alle sorgenti invece che alla vista. La differenza
        // con la velatura e' tutta qui: la' si aggiungeva grigio, qui si TOGLIE buio.
        const s = this._veloTela(), vg = this._veloCtx, M = this._veloM;
        const B = C.VILL_BUIO == null ? 0.90 : C.VILL_BUIO, K = C.VILL_LUCE || 2;
        vg.setTransform(s, 0, 0, s, M * s, M * s);
        vg.globalCompositeOperation = 'source-over';
        vg.clearRect(-M, -M, this.w + M * 2, this.h + M * 2);
        vg.fillStyle = 'rgba(3,4,9,' + B.toFixed(3) + ')'; vg.fillRect(-M, -M, this.w + M * 2, this.h + M * 2);
        vg.globalCompositeOperation = 'destination-out';
        // v2.6 — LA PIAZZA E' CHIARA. Non con una luce in piu' appoggiata sopra — quella tornerebbe a
        // essere una patina — ma togliendo buio: dentro il rettangolo della piazza il velo vale
        // VILL_PIAZZA invece di VILL_BUIO, e fra i due si passa sfumando per qualche tessera, cosi' il
        // bordo non e' un taglio. E' un ovale e non un rettangolo apposta: un alone quadrato con gli
        // spigoli si legge come una finestra, non come uno spiazzo illuminato.
        {
          const pz = this.map.piazza, T2 = this.map.tile || 48;
          const PB = C.VILL_PIAZZA == null ? 0.34 : C.VILL_PIAZZA;
          if (pz && PB < B) {
            const ORLO = (C.VILL_PZ_ORLO || 3) * T2;
            const cx2 = ((pz.x0 + pz.x1 + 1) / 2) * T2 - camX, cy2 = ((pz.y0 + pz.y1 + 1) / 2) * T2 - camY;
            const rx = ((pz.x1 - pz.x0 + 1) / 2) * T2, ry = ((pz.y1 - pz.y0 + 1) / 2) * T2;
            const RX = rx + ORLO, RY = ry + ORLO, A = 1 - PB / B;
            const gp = this._grad('vpz|' + Math.round(RX) + '|' + Math.round(rx) + '|' + A.toFixed(2), () => {
              const q = vg.createRadialGradient(0, 0, 0, 0, 0, RX);
              q.addColorStop(0, 'rgba(0,0,0,' + A.toFixed(3) + ')');
              q.addColorStop(Math.max(0.05, Math.min(0.95, rx / RX)), 'rgba(0,0,0,' + A.toFixed(3) + ')');
              q.addColorStop(1, 'rgba(0,0,0,0)'); return q;
            });
            vg.save(); vg.translate(cx2, cy2); vg.scale(1, RY / RX);
            vg.fillStyle = gp; vg.beginPath(); vg.arc(0, 0, RX, 0, 7); vg.fill(); vg.restore();
          }
        }
        // ogni sorgente scava il suo buco. La sfumatura si costruisce una volta per raggio e si riusa
        // (regola della v1.64): i raggi in gioco sono cinque o sei, quindi la cache basta e avanza.
        const buco = (wx, wy, rad, forza) => {
          const x = wx - camX, y = wy - camY, R = Math.round(rad * K);
          if (x < -R || y < -R || x > this.w + R || y > this.h + R) return;
          const F = Math.round(forza * 20) / 20;
          const gr = this._grad('vb|' + R + '|' + F, () => {
            const q = vg.createRadialGradient(0, 0, 0, 0, 0, R);
            q.addColorStop(0, 'rgba(0,0,0,' + F + ')');
            q.addColorStop(0.45, 'rgba(0,0,0,' + (F * 0.90).toFixed(3) + ')');
            q.addColorStop(0.78, 'rgba(0,0,0,' + (F * 0.46).toFixed(3) + ')');
            q.addColorStop(1, 'rgba(0,0,0,0)'); return q;
          });
          vg.fillStyle = gr; vg.translate(x, y); vg.beginPath(); vg.arc(0, 0, R, 0, 7); vg.fill(); vg.translate(-x, -y);
        };
        // v2.6 — LA PATINA CHE RESTAVA. Dopo la v2.5 il villaggio era ancora velato, e stavolta non era
        // uno strato in piu': era uno SFASAMENTO. Il buio si buca qui con un raggio, e il bagliore caldo
        // si disegnava piu' sotto con un altro — l'alone dell'eroe usciva a 190x1,45 = 275 px dentro un
        // buco di 130. Quei 145 px di differenza sono luce appoggiata sul buio invece che dentro un buco:
        // esattamente una patina, e ti seguiva perche' l'eroe sei tu.
        //
        // Il rimedio non e' limare un numero: e' che i due passaggi leggano LA STESSA LISTA. Le sorgenti
        // del villaggio si dichiarano una volta sola qui sotto — [x, y, raggio, colore, alfa, forza] — si
        // bucano con quel raggio e piu' avanti si accendono con lo stesso. Nessun bagliore senza il suo
        // buco, nessun buco piu' piccolo del suo bagliore. Il test verifica proprio questo.
        const VS = this._villSrc || (this._villSrc = []); VS.length = 0;
        const HR = C.VILL_EROE || 130;
        if (this.bigLight) VS.push([this.bigLight.x, this.bigLight.y, this.bigLight.r, '#ff8a2b', 0.58, 0.94]);
        for (const cf of this.campfires) VS.push([cf.fx || cf.x, cf.fy || cf.y, 200, '#ff8a2b', 0.55, 1]);
        for (const tc of this.torches) VS.push([tc.x, tc.y, 120, '#ff9a3b', 0.5, 0.96]);
        for (const gl of (this.glows || [])) VS.push([gl.x, gl.y, gl.rad || 100, gl.col, gl.a, 0.92]);
        { const gl2 = this._giroLuci; if (gl2) for (let i = 0; i < gl2.length; i += 2) VS.push([gl2[i], gl2[i + 1] - 6, 104, '#ffc071', 0.46, 0.88]); }
        if (world.fg) VS.push([world.fg.x, world.fg.y, 220, '#9a5cff', 0.55, 1]);
        // il cerchietto che ci si porta dietro: senza, fra una luce e l'altra si cammina alla cieca
        for (const p of world.players) if (!p.d) VS.push([p.x, p.y, HR / K, (HERO[p.h] || HERO.guerriero).accent || '#8bd6ff', 0.26, 0.98]);
        for (const s of VS) buco(s[0], s[1], s[2], s[5]);
        vg.setTransform(1, 0, 0, 1, 0, 0);
        g.globalCompositeOperation = 'source-over';
        const _sfv = C.FOV_SFUMA || 0;
        if (_sfv > 0) g.filter = 'blur(' + _sfv + 'px)';
        g.drawImage(this._veloCv, -M, -M, this.w + M * 2, this.h + M * 2);
        if (_sfv > 0) g.filter = 'none';
      } else {
        // nessuna mappa arriva qui oggi (o c'e' il campo visivo, o e' il villaggio): resta la vignettatura
        // leggera di sempre, come rete di sicurezza se un domani nascesse una terza specie di mappa.
        const grA = g.createRadialGradient(this.w / 2, this.h / 2, 80, this.w / 2, this.h / 2, Math.max(this.w, this.h) * 0.68);
        grA.addColorStop(0, 'rgba(6,8,14,0.0)'); grA.addColorStop(0.7, 'rgba(5,7,12,0.06)'); grA.addColorStop(1, 'rgba(3,5,10,0.20)');
        g.fillStyle = grA; g.fillRect(0, 0, this.w, this.h);
      }
      g.globalCompositeOperation = 'lighter';
      // LE LUCI VIVONO SOLO DENTRO LA VISUALE: una torcia dietro una roccia non deve illuminare la roccia
      if (_fov) { g.save(); g.beginPath(); for (const f of _fov) { const sx = f.x - camX, sy = f.y - camY; this._fovContorno(g, this._fovBuf, f.off, f.n, sx, sy, 1, 3); this._fovContorno(g, this._fovBuf, f.off, f.n, sx, sy, 1, 4); } g.clip(); }
      /* v2.4 — nel villaggio ogni sorgente illumina un'area DOPPIA (VILL_LUCE). Il moltiplicatore sta qui, in
         un posto solo, cosi' il colore caldo cresce insieme al buco scavato nel buio: se crescesse solo il
         buco, resterebbe un alone grigio con un puntino caldo in mezzo. Fuori dal villaggio vale 1. */
      const KL = this.map.lit ? (C.VILL_LUCE || 2) : 1;
      const light = (wx, wy, rad0, color, a) => { const rad = rad0 * KL; const x = wx - camX, y = wy - camY; if (x < -rad || y < -rad || x > this.w + rad || y > this.h + rad) return; const R = Math.round(rad); const gr = this._grad('li|' + color + '|' + R, () => { const q = g.createRadialGradient(0, 0, 0, 0, 0, R); q.addColorStop(0, color); q.addColorStop(1, 'rgba(0,0,0,0)'); return q; }); g.globalAlpha = a; g.fillStyle = gr; g.translate(x, y); g.beginPath(); g.arc(0, 0, R, 0, 7); g.fill(); g.translate(-x, -y); };
      // v2.6 — nel villaggio si accende ESATTAMENTE quello che si e' bucato, con gli stessi raggi. La
      // lista lunga qui sotto e' quella delle grotte, dove il velo e' il campo visivo e il ritaglio tiene
      // ogni bagliore dentro la visuale; li' non c'e' niente da tenere in riga.
      if (_lit) { for (const s of this._villSrc) light(s[0], s[1], s[2], s[3], s[4]); } else {
      if (_fov) { /* v2.1.2 — LA LUCE DEL FASCIO. Togliere il velo non basta: senza velo il pavimento di una grotta e' comunque scuro, e il fascio si leggeva come 'meno buio' invece che come luce. Queste tre lampade calde in fila lungo la direzione in cui guardi sono cio' che lo rende una TORCIA. Sono dentro il ritaglio come tutte le altre, quindi un muro le ferma. */ const RC = C.FOV_CONO || 1150; for (const f of _fov) { const cx2 = Math.cos(f.a), cy2 = Math.sin(f.a); light(f.x + cx2 * RC * 0.14, f.y + cy2 * RC * 0.14, 250, '#ffb066', 0.30); light(f.x + cx2 * RC * 0.36, f.y + cy2 * RC * 0.36, 300, '#ffa557', 0.21); light(f.x + cx2 * RC * 0.60, f.y + cy2 * RC * 0.60, 350, '#ff9c4e', 0.13); } }; /* v2.3 — la lanterna di chi cammina: le posizioni le ha segnate la passata dei girovaghi, qui diventano luce */ { const gl2 = this._giroLuci; if (gl2) for (let i = 0; i < gl2.length; i += 2) light(gl2[i], gl2[i + 1] - 6, 104, '#ffc071', 0.46); } for (const tc of this.torches) light(tc.x, tc.y, 120, '#ff9a3b', 0.5); for (const cf of this.campfires) light(cf.fx || cf.x, cf.fy || cf.y, 200, '#ff8a2b', 0.55); if (this.bigLight) light(this.bigLight.x, this.bigLight.y, this.bigLight.r, '#ff9a3b', 0.42); for (const hz of (this.hazards || [])) light(hz.x, hz.y, hz.r || 42, hz.col, 0.2); for (const gl of (this.glows || [])) light(gl.x, gl.y, gl.rad, gl.col, gl.a); for (const c of (world.crates || [])) light(c.x, c.y, 60, '#ffcf5a', 0.3); for (const o of (world.ogg || [])) if (o.k) light(o.x, o.y - 12, 34, '#ff8a3a', 0.34); for (const l of ((this.map || {}).leve || [])) light(l.x, l.y - 10, 44, this.grateAperte.has(l.gid) ? '#7de08a' : '#e0b23a', 0.32); if (world.fg) light(world.fg.x, world.fg.y, 220, '#9a5cff', 0.55); if (world.rec && !world.rec.lib) { light(world.rec.x - world.rec.r * 0.92, world.rec.y, 150, '#ff9a3b', 0.55); light(world.rec.x + world.rec.r * 0.92, world.rec.y, 150, '#ff9a3b', 0.55); } for (const o of (world.coins || [])) light(o.x, o.y, 22, '#ffcf4a', 0.28); if (world.merch) light(world.merch.x, world.merch.y - 6, 150, '#ffcf7a', 0.5); if (world.merchD) { light(world.merchD.x, world.merchD.y - 6, 120, '#9b2cff', 0.45); light(world.merchD.x, world.merchD.y - 6, 60, '#ff2d6b', 0.35); } for (const o of (world.orbs || [])) { if (o.k === 'turret') light(o.x, o.y, 90, '#9fe0ff', 0.3); } for (const it of (world.items || [])) { const d = ITEM_BY_ID[it.id] || {}; light(it.x, it.y, 55, d.color || '#ffd24a', 0.3); } for (const p of world.players) if (!p.d) { const h = HERO[p.h] || HERO.barbaro; light(p.x, p.y, 190, h.accent || '#8bd6ff', 0.30); } for (const b of world.bul) light(b.x, b.y, 26, b.c || '#fff', 0.5); for (const m of world.mon) { if (m.tr) light(m.x, m.y, 90, '#ffd24a', 0.4); else if (m.b) light(m.x, m.y, m.mg ? 170 : 120, m.mg ? '#ff2d55' : '#ff6a3b', 0.2); }
      }
      if (_fov) g.restore();
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; ctx.restore();
    },
    // v1.16 — MODALITÀ TORCIA: mappa quasi nera "bucata" da un cono di luce + aloni (tasto L)
    _drawDarkness(world, camX, camY) {
      if (!this.torch || !this.darkCv || !this.map) return;
      if (this.map.lit) return;   // v2.0.2 — nel villaggio no: e' l'unica mappa illuminata, e il tasto L non la rimette al buio
      // v1.57 — la sala del mercato resta BUIA: la luce la fa il FALO' (vedi this.bigLight piu' sotto).
      const s = this.darkScale, dg = this.darkCtx, W = this.darkCv.width, H = this.darkCv.height;
      dg.setTransform(1, 0, 0, 1, 0, 0); dg.globalCompositeOperation = 'source-over'; dg.clearRect(0, 0, W, H);
      dg.fillStyle = 'rgba(2,3,8,' + this.darkness + ')'; dg.fillRect(0, 0, W, H);
      dg.globalCompositeOperation = 'destination-out';
      // v1.64 — stessa cura degli aloni di luce: gradiente costruito UNA volta attorno all'origine e riusato.
      const halo = (wx, wy, rad, a0) => { const x = (wx - camX) * s, y = (wy - camY) * s, r = Math.round(rad * s); if (x < -r || y < -r || x > W + r || y > H + r) return; const A = Math.round(a0 * 20) / 20; const gr = this._grad('ha|' + r + '|' + A, () => { const q = dg.createRadialGradient(0, 0, 0, 0, 0, r); q.addColorStop(0, 'rgba(0,0,0,' + A + ')'); q.addColorStop(0.6, 'rgba(0,0,0,' + (A * 0.82) + ')'); q.addColorStop(1, 'rgba(0,0,0,0)'); return q; }); dg.fillStyle = gr; dg.translate(x, y); dg.beginPath(); dg.arc(0, 0, r, 0, 7); dg.fill(); dg.translate(-x, -y); };
      // v1.17 — grande alone TONDO attorno a ogni eroe (niente più cono direzionale)
      for (const p of world.players) { if (p.d) continue; halo(p.x, p.y, this.haloR, 0.98); }
      // sorgenti che restano visibili nel buio
      for (const tc of this.torches) halo(tc.x, tc.y, 82, 0.9);
      for (const cf of this.campfires) halo(cf.fx || cf.x, cf.fy || cf.y, 135, 0.92);
      // v1.57 — il FALO' della sala mercato: un unico grande alone circolare che scopre i mercanti
      // e si spegne contro le pareti nere. E' l'unica sorgente della stanza.
      if (this.bigLight) halo(this.bigLight.x, this.bigLight.y, this.bigLight.r, 0.99);
      for (const hz of (this.hazards || [])) halo(hz.x, hz.y, (hz.r || 40) * 0.75, 0.5); // v1.18 — le pozze si intravedono nel buio
      // v1.65 — il fascio della faglia esce dal bordo, cioe' dalla parte piu' buia della mappa: senza un
      // buco nel buio proprio li' l'effetto resterebbe invisibile esattamente dove serve vederlo.
      if (world.me && (world.me.eg || 0) > 0.04) { const lv = world.me.eg; for (const r of this._edgeRoots(world.me)) halo(r.x, r.y, 150, 0.35 + 0.55 * lv); }
      for (const gl of (this.glows || [])) halo(gl.x, gl.y, (gl.rad || 40) * 0.7, 0.55); // v1.20 — funghi bioluminescenti
      if (this.map.exit) { const ex = this.map.exit.x * this.map.tile + this.map.tile / 2, ey = this.map.exit.y * this.map.tile + this.map.tile / 2; halo(ex, ey, 74, 0.85); }
      if (world.merch) halo(world.merch.x, world.merch.y, 140, 0.92);
      if (world.merchD) halo(world.merchD.x, world.merchD.y, 92, 0.85);
      for (const o of (world.orbs || [])) halo(o.x, o.y, 58, 0.7);
      for (const b of (world.bul || [])) halo(b.x, b.y, 20, 0.5); // i proiettili illuminano volando
      for (const m of world.mon) { if (m.b) halo(m.x, m.y, m.mg ? 92 : 72, 0.6); else if (m.el || m.tr) halo(m.x, m.y, 48, 0.5); }
      dg.globalCompositeOperation = 'source-over';
      const ctx = this.ctx; ctx.save(); ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); ctx.imageSmoothingEnabled = true; ctx.drawImage(this.darkCv, 0, 0, W, H, 0, 0, this.w, this.h); ctx.restore();
    },
    // v1.16 — pulviscolo ambientale (dust motes) che fluttua nel fascio di luce
    _drawDust(ctx, camX, camY, dt) {
      const N = 70; const d = this.dust; const margin = 40;
      while (d.length < N) d.push({ x: camX - margin + Math.random() * (this.w + margin * 2), y: camY - margin + Math.random() * (this.h + margin * 2), vx: MU.rand(-6, 6), vy: MU.rand(-4, 10), r: MU.rand(0.5, 1.8), a: MU.rand(0.05, 0.22), ph: Math.random() * 7 });
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      for (const p of d) {
        p.x += p.vx * dt; p.y += p.vy * dt; p.ph += dt;
        // wrap attorno alla camera
        if (p.x < camX - margin) p.x = camX + this.w + margin; else if (p.x > camX + this.w + margin) p.x = camX - margin;
        if (p.y < camY - margin) p.y = camY + this.h + margin; else if (p.y > camY + this.h + margin) p.y = camY - margin;
        const tw = 0.6 + 0.4 * Math.sin(p.ph * 2);
        ctx.globalAlpha = p.a * tw; ctx.fillStyle = '#dfe8ff';
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; ctx.restore();
    },
    // v1.21 — NEBBIA VOLUMETRICA: strati di foschia che derivano lentamente (world-space, si dirada nel buio)
    _drawFog(ctx, camX, camY, dt) {
      const N = 14; const f = this.fog; const M = 240;
      while (f.length < N) f.push({ x: camX - M + Math.random() * (this.w + M * 2), y: camY - M + Math.random() * (this.h + M * 2), r: MU.rand(130, 260), vx: MU.rand(-9, 9), vy: MU.rand(-5, 5), a: MU.rand(0.05, 0.11), ph: Math.random() * 7 });
      ctx.save();
      for (const p of f) {
        p.x += p.vx * dt; p.y += p.vy * dt; p.ph += dt * 0.3;
        if (p.x < camX - M) p.x = camX + this.w + M; else if (p.x > camX + this.w + M) p.x = camX - M;
        if (p.y < camY - M) p.y = camY + this.h + M; else if (p.y > camY + this.h + M) p.y = camY - M;
        const a = p.a * (0.7 + 0.3 * Math.sin(p.ph));
        const gr = ctx.createRadialGradient(p.x, p.y, 1, p.x, p.y, p.r);
        gr.addColorStop(0, 'rgba(150,160,185,' + a + ')'); gr.addColorStop(1, 'rgba(150,160,185,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      }
      ctx.restore();
    },
    _isWallW(wx, wy) { const m = this.map; if (!m) return false; const gx = (wx / m.tile) | 0, gy = (wy / m.tile) | 0; if (gx < 0 || gy < 0 || gx >= m.w || gy >= m.h) return true; return m.grid[gy * m.w + gx] === C.T_WALL; },
    // v1.22 — ANIMALETTI: ratti/ragni/scarafaggi che sfrecciano a scatti sul pavimento (cosmetici, evitano i muri)
    _drawCritters(ctx, camX, camY, dt) {
      if (!this.map) return; const N = 5, cr = this.critters, m = this.map, M = 60;
      // v1.99 — IL CICLO CHE NON FINIVA. Qui c'era un `while (cr.length < N)`: cercava a caso un punto
      // non-muro dentro l'inquadratura, e riprovava all'infinito. Se la telecamera guarda un'area TUTTA
      // roccia il punto non esiste, e il gioco si pianta — non rallenta: si pianta, dentro il primo
      // fotogramma. Con la caverna non capitava quasi mai (riempie il rettangolo della mappa); con la
      // caldera, che e' un ovale con gli angoli pieni, bastava guardare un angolo. Adesso i tentativi
      // sono contati: se non c'e' posto per gli animaletti, semplicemente non ci sono animaletti.
      for (let _t = 0; cr.length < N && _t < 24; _t++) { const wx = camX + Math.random() * this.w, wy = camY + Math.random() * this.h; if (this._isWallW(wx, wy)) continue; cr.push({ x: wx, y: wy, a: Math.random() * 6.28, vx: 0, vy: 0, type: (Math.random() * 3) | 0, st: 0, t: MU.rand(0.2, 1.0), sp: MU.rand(56, 118), ph: Math.random() * 7 }); }
      ctx.save();
      for (let i = cr.length - 1; i >= 0; i--) { const p = cr[i]; p.t -= dt; p.ph += dt;
        if (p.t <= 0) { if (p.st === 0) { p.st = 1; p.t = MU.rand(0.25, 0.7); p.a += MU.rand(-1.4, 1.4); p.vx = Math.cos(p.a) * p.sp; p.vy = Math.sin(p.a) * p.sp; } else { p.st = 0; p.t = MU.rand(0.4, 1.6); p.vx = 0; p.vy = 0; } }
        if (p.st === 1) { const nx = p.x + p.vx * dt, ny = p.y + p.vy * dt; if (this._isWallW(nx, p.y)) { p.vx = -p.vx; p.a = Math.PI - p.a; } else p.x = nx; if (this._isWallW(p.x, ny)) { p.vy = -p.vy; p.a = -p.a; } else p.y = ny; }
        // ricicla se troppo fuori dalla vista
        if (p.x < camX - M || p.x > camX + this.w + M || p.y < camY - M || p.y > camY + this.h + M) { let ok = false; for (let k = 0; k < 8 && !ok; k++) { const wx = camX + Math.random() * this.w, wy = camY + Math.random() * this.h; if (!this._isWallW(wx, wy)) { p.x = wx; p.y = wy; ok = true; } } if (!ok) { cr.splice(i, 1); continue; } }
        const sx = p.x - camX, sy = p.y - camY; const moving = p.st === 1; const bob = moving ? Math.sin(p.ph * 22) * 0.6 : 0;
        ctx.save(); ctx.translate(sx, sy + bob); ctx.rotate(p.a); ctx.scale(1.9, 1.9); // v1.23 animaletti piu grandi
        if (p.type === 0) { // ratto
          ctx.fillStyle = '#2a2530'; ctx.strokeStyle = '#141018'; ctx.lineWidth = 0.8;
          ctx.strokeStyle = '#3a3540'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-4, 0); ctx.quadraticCurveTo(-9, Math.sin(p.ph * 18) * 2, -12, 0); ctx.stroke(); // coda
          ctx.fillStyle = '#33303a'; ctx.beginPath(); ctx.ellipse(0, 0, 5, 3, 0, 0, 7); ctx.fill(); // corpo
          ctx.beginPath(); ctx.arc(5, 0, 2.2, 0, 7); ctx.fill(); // testa
          ctx.fillStyle = '#22202a'; ctx.beginPath(); ctx.arc(4.5, -1.6, 1, 0, 7); ctx.arc(4.5, 1.6, 1, 0, 7); ctx.fill(); // orecchie
          ctx.fillStyle = '#ff5a5a'; ctx.beginPath(); ctx.arc(6, -0.7, 0.5, 0, 7); ctx.fill(); // occhio
        } else if (p.type === 1) { // ragno
          ctx.strokeStyle = '#15121a'; ctx.lineWidth = 1; const lg = Math.sin(p.ph * 26) * 1.2;
          for (const s of [-1, 1]) for (let l = 0; l < 4; l++) { const ang = (l - 1.5) * 0.5; const bx = Math.cos(ang) * 5, by = s * (2 + Math.abs(Math.sin(ang)) * 2); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(bx, by); ctx.lineTo(bx + Math.cos(ang) * 3, by + s * (2 + lg)); ctx.stroke(); }
          ctx.fillStyle = '#1a1620'; ctx.beginPath(); ctx.arc(-1, 0, 2.4, 0, 7); ctx.fill(); ctx.beginPath(); ctx.arc(2.4, 0, 1.6, 0, 7); ctx.fill();
          ctx.fillStyle = '#c02a2a'; ctx.beginPath(); ctx.arc(3, -0.6, 0.5, 0, 7); ctx.arc(3, 0.6, 0.5, 0, 7); ctx.fill();
        } else { // scarafaggio
          ctx.strokeStyle = '#12100a'; ctx.lineWidth = 1; for (const s of [-1, 1]) for (let l = 0; l < 3; l++) { ctx.beginPath(); ctx.moveTo(-1 + l * 2, s * 2); ctx.lineTo(-2 + l * 2, s * (3.6 + Math.sin(p.ph * 24 + l) * 0.8)); ctx.stroke(); }
          const bg = ctx.createLinearGradient(0, -3, 0, 3); bg.addColorStop(0, '#3b2f16'); bg.addColorStop(1, '#17120a'); ctx.fillStyle = bg; ctx.beginPath(); ctx.ellipse(0, 0, 4.4, 3, 0, 0, 7); ctx.fill();
          ctx.strokeStyle = '#0a0806'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(-3.5, 0); ctx.lineTo(3.5, 0); ctx.stroke();
          ctx.strokeStyle = '#2a2210'; ctx.beginPath(); ctx.moveTo(4, -1); ctx.lineTo(6.5, -2); ctx.moveTo(4, 1); ctx.lineTo(6.5, 2); ctx.stroke();
        }
        ctx.restore();
      }
      ctx.restore();
    },
    _drawParticles(ctx, over) { for (const p of this.particles) { if (!!p.over !== over) continue; if (p.fire) { const life = 1 - (p.t / p.life); let col; if (life < 0.35) col = 'rgba(255,240,160,'; else if (life < 0.7) col = 'rgba(255,140,40,'; else col = 'rgba(90,80,80,'; ctx.fillStyle = col + (0.85 * (1 - life)) + ')'; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(0.5, p.r * (1.1 - life * 0.6)), 0, 7); ctx.fill(); } else { const a = p.t / p.life; ctx.globalAlpha = a; ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.4 + a * 0.6), 0, 7); ctx.fill(); } } ctx.globalAlpha = 1; },
    _drawSwings(ctx) {
      if (!this.swings.length) return;
      for (const sw of this.swings) {
        const u = sw.t / sw.dur, a = 1 - u;
        // il settore si "apre" nel primo terzo dell'animazione: e' quello che da' il senso del movimento
        const grow = Math.min(1, u / 0.34), half = sw.half * (0.35 + 0.65 * grow), rad = sw.rad * (0.72 + 0.28 * grow);
        const R = Math.round(sw.rad);
        const g = this._grad('sw|' + R + '|' + (sw.crit ? 1 : 0), () => {
          const q = ctx.createRadialGradient(0, 0, R * 0.25, 0, 0, R);
          q.addColorStop(0, 'rgba(255,255,255,0)');
          q.addColorStop(0.62, sw.crit ? 'rgba(255,243,107,.30)' : 'rgba(224,165,44,.26)');
          q.addColorStop(1, sw.crit ? 'rgba(255,243,107,.62)' : 'rgba(255,226,160,.55)');
          return q;
        });
        ctx.save(); ctx.translate(sw.x, sw.y); ctx.rotate(sw.a); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a;
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, rad, -half, half); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = sw.crit ? 'rgba(255,255,255,.95)' : 'rgba(255,236,190,.9)'; ctx.lineWidth = 3 * a + 1;
        ctx.beginPath(); ctx.arc(0, 0, rad, -half, half); ctx.stroke();
        ctx.restore(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      }
    },
    _drawFlashes(ctx) { for (const f of this.flashes) { const a = f.t / f.life; ctx.globalAlpha = a; ctx.strokeStyle = f.color; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, f.y, MU.lerp(f.r0, f.r1, 1 - a), 0, 7); ctx.stroke(); } ctx.globalAlpha = 1; },
    _drawFloaters(ctx) { ctx.textAlign = 'center'; for (const f of this.floaters) { const a = Math.min(1, f.t / f.life * 1.5); ctx.globalAlpha = a; ctx.fillStyle = f.color; ctx.font = (f.big ? 'bold 22px ' : 'bold 15px ') + 'Segoe UI, sans-serif'; ctx.fillText(f.text, f.x, f.y); } ctx.globalAlpha = 1; ctx.textAlign = 'left'; },
    updateFx(dt) { for (const p of this.particles) { p.t += (p.fire ? dt : 0); if (!p.fire) p.t -= dt * 2; p.x += p.vx * dt; p.y += p.vy * dt; if (p.fire) { p.vy += 8 * dt; p.vx *= 0.96; } else { p.vx *= 0.92; p.vy *= 0.92; } } this.particles = this.particles.filter(p => p.fire ? p.t < p.life : p.t > 0); for (const f of this.flashes) f.t -= dt; this.flashes = this.flashes.filter(f => f.t > 0); for (const f of this.floaters) { f.t -= dt; f.y -= 26 * dt; } this.floaters = this.floaters.filter(f => f.t > 0); for (const c of this.chains) c.t -= dt; this.chains = this.chains.filter(c => c.t > 0); for (const pp of this.pare) pp.t -= dt; this.pare = this.pare.filter(pp => pp.t > 0); for (const sw of this.swings) sw.t += dt; this.swings = this.swings.filter(sw => sw.t < sw.dur); for (const L of this.levelUps) L.t += dt; this.levelUps = this.levelUps.filter(L => L.t < L.dur); for (const k in this.atk) { this.atk[k] -= dt; if (this.atk[k] <= 0) delete this.atk[k]; } for (const k in this.mAtk) { const a = this.mAtk[k]; a.t += dt; if (a.t >= a.dur) delete this.mAtk[k]; } for (const d of this.deaths) d.t += dt; this.deaths = this.deaths.filter(d => d.t < d.dur); },
    _drawOrb(ctx, o) {
      if (o.k === 'turret') { const x = o.x, y = o.y; ctx.save(); ctx.translate(x, y); ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(0, 8, 13, 5, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#2a3550'; ctx.strokeStyle = '#0a0c12'; ctx.lineWidth = 2; this._rr(ctx, -10, -2, 20, 12, 3); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#3a4a6a'; this._rr(ctx, -7, -5, 14, 6, 2); ctx.fill(); ctx.stroke();
        ctx.save(); ctx.rotate(o.f || 0); ctx.fillStyle = '#4a5a80'; ctx.strokeStyle = '#0a0c12'; ctx.beginPath(); ctx.arc(0, -4, 6, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#1a2233'; this._rr(ctx, 0, -6, 16, 4, 1.5); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#9fe0ff'; ctx.beginPath(); ctx.arc(0, -4, 2.2, 0, 7); ctx.fill(); ctx.restore();
        if (o.tt) { const a = Math.min(1, o.tt / 8); ctx.strokeStyle = 'rgba(159,224,255,' + (0.35 + 0.3 * a) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, -2, 15, -Math.PI / 2, -Math.PI / 2 + a * Math.PI * 2); ctx.stroke(); }
        ctx.restore(); return; }
      if (o.k === 'rift') { ctx.save(); ctx.translate(o.x, o.y); const rot = this.time * 3; for (let i = 0; i < 3; i++) { ctx.rotate(rot + i * 2.1); ctx.strokeStyle = 'rgba(0,240,200,' + (0.3 + 0.2 * Math.sin(this.time * 6)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, o.r * (0.5 + i * 0.22), 0.5, 5); ctx.stroke(); } ctx.fillStyle = 'rgba(0,240,200,0.10)'; ctx.beginPath(); ctx.arc(0, 0, o.r, 0, 7); ctx.fill(); ctx.restore(); } },
    _drawBullet(ctx, b) { b = Object.assign({}, b, { r: b.r * 1.35 }); if (b.pf) return this._drawPalla(ctx, b); if (b.sk) return this._drawScarica(ctx, b); if (b.ar) return this._drawArrow(ctx, b); if (b.g) { ctx.fillStyle = '#c7f06a'; ctx.beginPath(); ctx.arc(b.x, b.y, 5, 0, 7); ctx.fill(); ctx.strokeStyle = '#7a9a2b'; ctx.stroke(); return; }
      // v1.19 — proiettile luminoso: scia + alone saturo + nucleo bianco
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = b.c; ctx.globalAlpha = 0.55; ctx.lineWidth = b.r * 1.5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x - (b.vx || 0) * 0.016, b.y - (b.vy || 0) * 0.016); ctx.stroke(); ctx.lineCap = 'butt';
      ctx.globalAlpha = 0.85; ctx.fillStyle = b.c; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 1.15, 0, 7); ctx.fill();
      ctx.globalAlpha = 1; ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.62, 0, 7); ctx.fill();
      ctx.restore();
      if (b.h) { ctx.strokeStyle = '#ff3b5b'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 1.6, 0, 7); ctx.stroke(); } },
    _shadow(ctx, x, y, r) { ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.75, r * 0.9, r * 0.45, 0, 0, 7); ctx.fill(); },
    // ============================================================================================
    // v2.19.11 — LA SCARICA: un lampo di energia, non una bolla
    // ============================================================================================
    // Paolo: *«l'effetto dello sparo (la bolla) non mi piace per niente, sembra che spara bolle di
    // sapone. Quello che vorrei e' una scarica di energia (non elettrica) azzurra per il mago e
    // viola per il warlock. Magari un effetto tipo un lampo»*.
    //
    // Qui c'era una sfera translucida con tanto di riflesso in alto a sinistra — cioe' esattamente
    // il disegno di una bolla di sapone. Adesso e' una SAETTA: una spezzata che corre lungo la
    // traiettoria, con la testa incandescente davanti e la coda che si sfilaccia dietro.
    //
    // Non e' elettricita': non ci sono rami azzurri che schizzano a caso e non c'e' il bianco-blu del
    // fulmine. E' energia che si scarica — il nucleo e' bianco, l'alone e' il colore della classe
    // (azzurro il mago, viola il warlock, e il colore arriva dal server, vedi Room.effWeapon) e la
    // spezzata si rimescola dodici volte al secondo, cosi' vibra invece di lampeggiare.
    //
    // La spezzata e' DETERMINISTICA: dipende dall'id del proiettile e dal tempo a scatti, non da
    // Math.random(). Con il random ogni fotogramma la saetta sfarfallerebbe come una scintilla rotta,
    // e per giunta ogni giocatore ne vedrebbe una diversa.
    // ============================================================================================
    // v2.19.11 — LA PALLA DI FUOCO: una sfera, non un pallino arancione
    // ============================================================================================
    // Paolo: *«deve essere una sfera di fuoco convincente, muoversi (tipo la bolla molto piu' veloce)
    // e generare danno ad area»*. Prima non si disegnava affatto — l'abilita' faceva danno e basta, e
    // l'evento che mandava non lo raccoglieva nessuno.
    //
    // Cosa la rende una sfera invece di un cerchio colorato: tre strati che non hanno lo stesso
    // centro. Il nucleo bianco-giallo sta un po' AVANTI (verso la direzione di volo), la palla
    // arancione gli sta attorno, e l'alone rosso cupo resta INDIETRO e si allunga in scia. E' lo
    // stesso trucco della fiamma di una candela: il caldo davanti, il fumo dietro.
    // Il bordo frastagliato vibra con lo stesso rumore deterministico della scarica — sei punte che
    // si rimescolano quindici volte al secondo — cosi' la palla sembra BRUCIARE invece di scorrere.
    _drawPalla(ctx, b) {
      const a = b.a != null ? b.a / 100 : 0, R = b.r, seme = (b.e || 0) * 11 + Math.floor(this.time * 15) * 17;
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a);
      ctx.globalCompositeOperation = 'lighter';
      // la scia: tre sbuffi che si allungano all'indietro e si spengono
      for (let i = 1; i <= 3; i++) {
        const q = this._scNoise(seme + i * 2.7);
        ctx.globalAlpha = 0.26 / i;
        ctx.fillStyle = i < 3 ? '#ff7a2b' : '#8a1f08';
        ctx.beginPath(); ctx.arc(-R * (0.75 * i), (q - 0.5) * R * 0.45, R * (1.05 - i * 0.2), 0, 7); ctx.fill();
      }
      // l'alone
      ctx.globalAlpha = 1;
      const g = this._grad('pf|' + Math.round(R * 10), () => {
        const q = ctx.createRadialGradient(R * 0.18, 0, R * 0.12, 0, 0, R * 2.1);
        q.addColorStop(0, 'rgba(255,255,235,.98)'); q.addColorStop(0.24, 'rgba(255,214,92,.92)');
        q.addColorStop(0.5, 'rgba(255,122,43,.72)'); q.addColorStop(0.78, 'rgba(198,48,12,.30)');
        q.addColorStop(1, 'rgba(120,20,0,0)'); return q;
      });
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 2.1, 0, 7); ctx.fill();
      // il bordo che brucia: sei punte che si rimescolano
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const ang = i / 6 * Math.PI * 2, rr = R * (0.92 + this._scNoise(seme + i * 4.1) * 0.45);
        const x = Math.cos(ang) * rr, y = Math.sin(ang) * rr;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.closePath(); ctx.fillStyle = 'rgba(255,150,50,.55)'; ctx.fill();
      // il nucleo, spostato in avanti
      ctx.fillStyle = '#fff6d8'; ctx.beginPath(); ctx.arc(R * 0.22, 0, R * 0.46, 0, 7); ctx.fill();
      ctx.restore();
    },
    _scNoise(n) { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); },
    _drawScarica(ctx, b) {
      const a = b.a != null ? b.a / 100 : 0, R = b.r, L = Math.max(20, R * 4.2);
      const seme = (b.e || 0) * 7 + Math.floor(this.time * 12) * 31;
      const N = 5, pts = [];
      for (let i = 0; i <= N; i++) {
        const t = i / N;                                  // 0 = coda, 1 = testa
        const off = (this._scNoise(seme + i * 3.3) - 0.5) * R * 1.9 * (1 - t) * (t > 0.05 ? 1 : 0.2);
        pts.push([-L * (1 - t), off]);
      }
      pts[N][1] = 0;                                      // la testa sta sulla traiettoria, sempre
      const traccia = () => { ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i <= N; i++) ctx.lineTo(pts[i][0], pts[i][1]); ctx.stroke(); };
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a);
      ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      // l'alone: largo, tenue, del colore della classe
      ctx.strokeStyle = b.c || '#5aa8ff'; ctx.globalAlpha = 0.30; ctx.lineWidth = R * 2.4; traccia();
      // il corpo della scarica
      ctx.globalAlpha = 0.85; ctx.lineWidth = R * 1.05; traccia();
      // due rametti corti che partono dalla spezzata: e' cio' che la fa leggere come una saetta
      for (let k = 0; k < 2; k++) {
        const i = 2 + k, q = this._scNoise(seme + 40 + k * 5.7);
        ctx.globalAlpha = 0.55; ctx.lineWidth = R * 0.42;
        ctx.beginPath(); ctx.moveTo(pts[i][0], pts[i][1]);
        ctx.lineTo(pts[i][0] + R * (0.5 + q), pts[i][1] + (q < 0.5 ? -1 : 1) * R * (1.0 + q * 1.2));
        ctx.stroke();
      }
      // il nucleo bianco e la testa incandescente
      ctx.globalAlpha = 1; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = R * 0.42; traccia();
      const g = this._grad('sk|' + Math.round(R * 10) + '|' + (b.c || ''), () => {
        const q = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 2.2);
        q.addColorStop(0, 'rgba(255,255,255,.95)'); q.addColorStop(0.35, this._rgba(b.c || '#5aa8ff', 0.55)); q.addColorStop(1, this._rgba(b.c || '#5aa8ff', 0)); return q;
      });
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 2.2, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(0, 0, R * 0.52, 0, 7); ctx.fill();
      ctx.restore();
      if (b.h) { ctx.strokeStyle = '#ff3b5b'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(b.x, b.y, R + 1.6, 0, 7); ctx.stroke(); }
    },
    // v1.66 — FRECCIA del ladro: asta, punta e impennaggio orientati sulla traiettoria.
    _drawArrow(ctx, b) {
      const L = Math.max(13, b.r * 3.4), a = b.a != null ? b.a / 100 : 0;
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a);
      ctx.strokeStyle = '#d9c9a3'; ctx.lineWidth = 2; ctx.lineCap = 'butt';
      ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(L * 0.55, 0); ctx.stroke();
      ctx.fillStyle = b.c || '#9ef0b0';
      ctx.beginPath(); ctx.moveTo(L, 0); ctx.lineTo(L * 0.42, -b.r * 0.85); ctx.lineTo(L * 0.42, b.r * 0.85); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = this._rgba(b.c || '#9ef0b0', 0.85); ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(-L, -b.r * 0.7); ctx.lineTo(-L * 0.55, 0); ctx.lineTo(-L, b.r * 0.7); ctx.stroke();
      ctx.restore();
    },
    _drawPlayer(ctx, p, isMe) {
      const h = HERO[p.h] || HERO.barbaro; const r = C.PLAYER_RADIUS * (C.VIS_SCALE || 1); const x = p.x, y = p.y; this._shadow(ctx, x, y, r);
      if (p.d) { ctx.globalAlpha = 0.5; ctx.fillStyle = '#555'; ctx.fillRect(x - 8, y - 12, 16, 20); ctx.globalAlpha = 1; return; }
      ctx.save(); ctx.translate(x, y);
      if (p.iv) { ctx.strokeStyle = 'rgba(255,235,120,' + (0.5 + 0.4 * Math.sin(this.time * 10)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, r + 9, 0, 7); ctx.stroke(); }
      if (p.bar) { ctx.save(); ctx.rotate(p.a); ctx.strokeStyle = 'rgba(120,200,255,.9)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, r + 12, -0.9, 0.9); ctx.stroke(); ctx.restore(); }
      // v1.85 — SCUDO DI MANA: una bolla che si increspa. GIURAMENTO: una lastra dorata bassa, a terra,
      // che sta addosso a tutti quelli protetti — anche ai compagni, che e' cio' che lo rende un giuramento.
      if (p.sc) {
        const rr = r + 13 + Math.sin(this.time * 7) * 1.6;
        const g = ctx.createRadialGradient(0, 0, r * 0.4, 0, 0, rr);
        g.addColorStop(0, 'rgba(125,255,234,0)'); g.addColorStop(0.75, 'rgba(125,255,234,.10)'); g.addColorStop(1, 'rgba(125,255,234,.34)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, rr, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(160,255,240,.75)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(0, 0, rr, 0, 7); ctx.stroke();
      }
      if (p.gi) {
        ctx.save(); ctx.strokeStyle = 'rgba(255,233,168,' + (0.55 + 0.3 * Math.sin(this.time * 4)) + ')'; ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.ellipse(0, 6, r + 15, (r + 15) * 0.55, 0, 0, 7); ctx.stroke();
        ctx.fillStyle = 'rgba(255,220,130,.10)'; ctx.beginPath(); ctx.ellipse(0, 6, r + 15, (r + 15) * 0.55, 0, 0, 7); ctx.fill();
        ctx.restore();
      }
      if (p.tb && p.tb.length) { ctx.strokeStyle = 'rgba(255,210,90,' + (0.4 + 0.3 * Math.sin(this.time * 8)) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, r + 7, 0, 7); ctx.stroke(); }
      if (p.cu) { // v1.28 — aura viola di maledizione + volute
        ctx.strokeStyle = 'rgba(156,107,255,' + (0.45 + 0.35 * Math.sin(this.time * 6)) + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0, 0, r + 6, 0, 7); ctx.stroke();
        if (Math.random() < 0.3) this.particles.push({ x: x + MU.rand(-r, r), y: y - r, vx: MU.rand(-8, 8), vy: -MU.rand(14, 30), life: 0.6, t: 0.6, color: '#b98bff', r: 2, over: true });
      }
      if (p.gz) { // v1.34 — debuff dello Sguardo dell'Occhio (colore per tipo)
        const gc = p.gz === 'slow' ? '#5ad0ff' : p.gz === 'sunder' ? '#c48cff' : '#ff7a5a';
        ctx.strokeStyle = this._rgba(gc, 0.4 + 0.35 * Math.sin(this.time * 7)); ctx.lineWidth = 2.5; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.arc(0, 0, r + 5, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      // v2.19.5 — UN PERSONAGGIO CHE NON SI DISEGNA NON DEVE FERMARE IL GIOCO. Un'eccezione qui dentro
      // usciva da `render`, il ciclo non arrivava mai al fotogramma successivo e restava l'ultima
      // immagine: il «villaggio congelato» segnalato da Paolo. Adesso quel personaggio salta un
      // fotogramma e il resto va avanti. L'errore si scrive UNA volta in console, perche' va visto e
      // corretto, non nascosto.
      // v2.19.7 — LO ZOMBIE DEL WARLOCK. Si disegna col pupazzo degli zombie nemici (Paolo: *«simile a
      // quelli nemici»*), ma con gli occhi e un cerchio a terra del viola del warlock: nella mischia deve
      // leggersi a colpo d'occhio come «mio», altrimenti non si capisce chi colpire.
      if (p.zb) {
        const pul = 0.5 + 0.5 * Math.sin(this.time * 3 + x * 0.01);
        ctx.save();
        ctx.strokeStyle = 'rgba(192,107,255,' + (0.55 + 0.3 * pul).toFixed(3) + ')'; ctx.lineWidth = 2.6;
        ctx.beginPath(); ctx.ellipse(0, r * 0.55, r * 1.15, r * 0.5, 0, 0, 7); ctx.stroke();
        ctx.globalCompositeOperation = 'lighter';
        const al = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 1.6);
        al.addColorStop(0, 'rgba(192,107,255,' + (0.18 + 0.10 * pul).toFixed(3) + ')'); al.addColorStop(1, 'rgba(192,107,255,0)');
        ctx.fillStyle = al; ctx.beginPath(); ctx.arc(0, 0, r * 1.6, 0, 7); ctx.fill();
        ctx.restore();
        const zm = this._zmv || (this._zmv = {}); const pv = zm[p.i] || (zm[p.i] = { x, y, on: 0 });
        const mv = Math.hypot(x - pv.x, y - pv.y); pv.on = mv > 0.4 ? 1 : Math.max(0, pv.on - 0.1); pv.x = x; pv.y = y;
        const flip = Math.cos(p.a) < 0 ? -1 : 1, back = Math.sin(p.a) < -0.35;
        const atkZ = Math.max(0, (this.atk[p.i] || 0)) / 0.20;
        const pronto = PUPPETS.ghoul && PUPPETS.ghoul.ready;
        try { this._front(ctx, pronto ? 'ghoul' : 'zombie', r * 1.05, '#3f4a3a', '#1a1f18', '#d59cff', this.time, atkZ, back, flip, pv.on > 0, p.bf > 0, false); }
        catch (e) { if (!this._erroreEroe) { this._erroreEroe = 1; console.error('[renderer] disegno dello zombie fallito:', e); } }
        ctx.restore(); ctx.globalAlpha = 1;
      } else {
      if (p.ph) ctx.globalAlpha = 0.55; ctx.save(); ctx.rotate(p.a);
      try { this._hero(ctx, p.h, r, this.time, !!p.dash, Math.max(0, (this.atk[p.i] || 0)) / 0.20, p); }
      catch (e) { if (!this._erroreEroe) { this._erroreEroe = 1; console.error('[renderer] disegno del personaggio fallito:', e); } }
      ctx.restore(); ctx.restore(); ctx.globalAlpha = 1;
      }   // v1.82 — `p` porta anche p.pal: e' la tinta del mercenario, letta da _heroGuerriero/_heroMago/_heroLadro
      if (p.dash) this.particles.push({ x, y, vx: 0, vy: 0, life: 0.25, t: 0.25, color: h.accent, r: 5, over: false });
      const bw = r * 2.6; ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(x - bw / 2, y - r - 22, bw, 5); const hf = Math.max(0, p.hp / p.mhp); ctx.fillStyle = hf > 0.4 ? '#4bd66b' : '#ff4b6b'; ctx.fillRect(x - bw / 2, y - r - 22, bw * hf, 5);
      for (let i = 0; i < (p.lv || 0); i++) { ctx.fillStyle = '#ff5a7a'; ctx.beginPath(); ctx.arc(x - bw / 2 + 4 + i * 9, y - r - 28, 2.6, 0, 7); ctx.fill(); }
      // v1.73 — SOPRA LA TUA TESTA NON C'E' PIU' NULLA. Nome, livello, rango e barra dell'XP sono passati
      // nel box dell'HUD (#heroBox): erano scritte fisse in mezzo all'azione, proprio dove serve vedere.
      // Sopra i COMPAGNI restano: senza, in co-op tre sagome uguali diventano indistinguibili e non si
      // capisce piu' a che punto sono della loro progressione.
      const LV = window.GAME && window.GAME.Levels;
      if (!isMe || p.dn) {
        ctx.textAlign = 'center';
        ctx.fillStyle = isMe ? '#fff' : '#c9d2e6'; ctx.font = 'bold 12px Segoe UI';
        ctx.fillText(p.n + (p.dn ? ' (a terra ' + p.dt + 's)' : ''), x, y - r - 32);
        if (LV && p.lvl && !isMe) {
          const rk = LV.rankName(p.h, p.lvl, p.sp || null), spec = LV.rankForLevel(p.lvl) >= 5;
          ctx.font = '11px Segoe UI'; ctx.fillStyle = spec ? '#ffd27a' : '#8d97ab';
          ctx.fillText('Lv.' + p.lvl + ' · ' + rk, x, y - r - 44);
          if ((p.prg || 0) < 1) { const bw2 = r * 2.6; ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(x - bw2 / 2, y - r - 15, bw2, 2.5); ctx.fillStyle = '#8bd6ff'; ctx.fillRect(x - bw2 / 2, y - r - 15, bw2 * (p.prg || 0), 2.5); }
        }
        ctx.textAlign = 'left';
      }
      if (p.dn) { ctx.strokeStyle = '#ffcf3a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r + 8 + Math.sin(this.time * 6) * 3, 0, 7); ctx.stroke(); }
      if (p.bf) { ctx.fillStyle = 'rgba(255,60,80,.35)'; ctx.beginPath(); ctx.arc(x, y, r + 3, 0, 7); ctx.fill(); }
    },
    _boot(ctx, x, y, r) { this._rr(ctx, x - r * 0.17, y - r * 0.17, r * 0.34, r * 0.34, 3); ctx.fill(); ctx.stroke(); },
    // ===== v1.66 — I TRE EROI, VISTI DALL'ALTO =====================================================
    // Il giocatore e' l'unica cosa del gioco disegnata dall'alto (i nemici sono cartelloni frontali), e
    // il contesto arriva qui gia' ruotato sulla mira: avanti e' +x, i fianchi sono ±y. Le tre classi
    // riusano la stessa impalcatura del vecchio _hero (stivali, braccia come tratti, torso arrotondato,
    // testa a r*0.5) perche' e' quella che si legge alla scala di gioco: cambiano stoffa, sagoma e arma.
    // Le sfumature passano dalla cache _grad: r e' costante, quindi si costruiscono una volta sola e
    // non ogni fotogramma (v1.64 — mai creare gradienti dentro un ciclo per entita').
    // v1.67 — `eq` porta l'equipaggiamento visibile (`wp` arma, `sh` scudo). Si disegna cio' che cambia
    // la SAGOMA — scudo a torre, arco lungo, orbe della bacchetta — perche' e' l'unica differenza che si
    // legge dall'alto a questa scala; il resto (armature, vesti, calzature) si legge nelle statistiche.
    // La firma di una palette: entra nelle chiavi della cache dei gradienti. Chiavi diverse per tinte
    // diverse, chiave vuota per chi non ha tinta — cosi' i personaggi senza palette continuano a
    // condividere il gradiente di sempre e non si paga niente per una funzione che non si usa.
    _palKey(pal) {
      if (!pal) return '';
      let k = '';
      for (const c of ['cloth', 'clothDk', 'body', 'bodyDk', 'steelDk', 'skin', 'wood', 'accent', 'pelo', 'orlo', 'mant', 'capp', 'metallo', 'scudo']) if (pal[c]) k += pal[c];
      return k;
    },
    // v1.88 — L'EQUIPAGGIAMENTO SI VEDE ADDOSSO. Ogni oggetto porta una `tinta` (gear.js) e un rango:
    // la tinta ridipinge i pezzi grossi del personaggio (metallo, veste, mantellina), il rango cambia
    // le FORME — quanto e' largo lo scudo, quanto e' lungo l'arco, che orbe ha il bastone. Cosi' due
    // maghi con equipaggiamento diverso si distinguono da lontano, senza leggere niente.
    _palGear(eq) {
      const G = window.GAME && window.GAME.Gear; if (!G) return eq.pal || null;
      const out = {};
      for (const gid of [eq.arm, eq.stv, eq.sh]) { const it = gid && G.BY_ID[gid]; if (it && it.tinta) Object.assign(out, it.tinta); }
      if (eq.pal) Object.assign(out, eq.pal);   // la tinta del mercenario resta sopra: e' la sua identita'
      return Object.keys(out).length ? out : (eq.pal || null);
    },
    _gearRanks(eq) {
      const G = window.GAME && window.GAME.Gear;
      const rk = (gid) => { const it = G && gid && G.BY_ID[gid]; return it ? (it.rank || 1) : 1; };
      return { w: rk(eq.wp), a: rk(eq.arm), s: rk(eq.sh), b: rk(eq.stv) };
    },
    _gearCol(gid, fallback) {
      const G = window.GAME && window.GAME.Gear; const it = G && gid && G.BY_ID[gid];
      return (it && it.color) || fallback;
    },
    // ============================================================================================
    // v2.18 — LO STILE DI OGNI CLASSE
    // ============================================================================================
    // Quattro voci per classe e nient'altro: `testa` (elmo chiuso, elmo aperto, testa nuda, cappuccio,
    // cappello a tesa), `spalle` (acciaio o pelliccia), `arma` (ascia, spada+scudo, due spade, due
    // pugnali, arco, bastone, sigillo) e la TINTA. E' il patto della bozza approvata: le sagome si
    // distinguono senza che nasca una quarta impalcatura, e l'equipaggiamento continua a ridipingere
    // gli stessi pezzi di sempre (la tinta di un oggetto arriva dopo, in `_palGear`, e vince su questa).
    _hero(ctx, id, r, t, dashing, atk, eq) {
      const a = Math.max(0, Math.min(1, atk || 0));
      eq = eq || {};
      if (!eq.civile) { eq.pal = this._palGear(eq); eq._rk = this._gearRanks(eq); }
      eq._hid = id;   // v2.19.5 — chi e': il corpo del guerriero ne ha bisogno per la regola delle due mani
      // v1.82 FIX — LA CACHE DEI GRADIENTI ERA CIECA ALLA PALETTE. Le chiavi erano 'h_torso|lad|<raggio>':
      // due ladri con lo stesso raggio si spartivano lo STESSO gradiente, cioe' i colori di chi veniva
      // disegnato per primo. Finche' le tinte non esistevano non si vedeva; con i mercenari il giocatore
      // si e' ritrovato addosso i colori del compagno. La firma della palette entra nella chiave, e ogni
      // combinazione ha il suo gradiente. (Il mago era gia' a posto per meta': la chiave conteneva body.)
      eq._pk = this._palKey(eq.pal);
      // v1.69 — il rango V si vede addosso: e' l'unico che cambia una scelta, quindi e' l'unico che
      // merita di essere riconoscibile a colpo d'occhio anche dai compagni.
      if (eq.sp) this._specSotto(ctx, r, t, eq.sp);
      // v2.18 — SETTE CLASSI, TRE IMPALCATURE. Il disegno si sceglie sul CORPO (pesante/agile/arcana),
      // non sulla classe: barbaro, paladino e maestro d'armi condividono lo scheletro del guerriero e
      // si distinguono per testa, spalle, arma e tinta — quattro cose, non quattro funzioni nuove.
      // `eq._st` e' lo stile della classe, letto una volta e passato giu'.
      eq._st = STILE[id] || STILE.barbaro;
      const corpo = (eq._st && eq._st.corpo) || 'guerriero';
      if (corpo === 'mago') this._heroMago(ctx, r, t, a, eq);
      else if (corpo === 'ladro') this._heroLadro(ctx, r, t, a, eq);
      else this._heroGuerriero(ctx, r, t, a, eq);
      if (eq.sp) this._specSopra(ctx, r, t, eq.sp);
      // v1.88 — IL RANGO DIVINO SI VEDE ANCHE AL BUIO: un alone che respira, del colore del pezzo.
      // Solo il rango 4, e solo un pezzo (il piu' alto che hai): tre aloni sovrapposti sarebbero una lampadina.
      const rk = eq._rk;
      // v2.12 — BRILLA SOLO IL DIVINO. La soglia era 4 quando i gradi erano quattro e il 4 era l'ultimo;
      // con cinque gradi avrebbe preso anche il leggendario, e un alone che si accende a meta' catalogo
      // smette di voler dire "questo e' il meglio che c'e'".
      const ALONE = 5;
      if (rk && Math.max(rk.w, rk.a, rk.s, rk.b) >= ALONE) {
        const src = rk.a >= ALONE ? eq.arm : rk.w >= ALONE ? eq.wp : rk.s >= ALONE ? eq.sh : eq.stv;
        const col = this._gearCol(src, '#ffe9a8');
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = 0.16 + 0.07 * Math.sin(t * 2.4);
        const g = this._grad('gear_div|' + col + '|' + r, () => { const q = ctx.createRadialGradient(0, 0, r * 0.6, 0, 0, r * 1.7); q.addColorStop(0, this._rgba(col, 0.55)); q.addColorStop(1, 'rgba(0,0,0,0)'); return q; });
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 1.7, 0, 7); ctx.fill();
        ctx.restore(); ctx.globalAlpha = 1;
      }
      if (dashing) { const h = HERO[id] || HERO.guerriero; ctx.strokeStyle = h.accent || '#9fe0ff'; ctx.globalAlpha = 0.5; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, r * 1.1, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
    },
    // v1.69 — i due strati della specializzazione: cio' che sta SOTTO il personaggio (aure, mantelli
    // che strisciano a terra) e cio' che sta SOPRA (elmi, bagliori). Disegnarli come strati separati
    // evita di dover riscrivere i tre eroi per sei varianti.
    _specSotto(ctx, r, t, sp) {
      if (sp === 'paladino') {                      // l'aura e' un'informazione di gioco: e' il raggio vero
        const R = 220 * ((C.VIS_SCALE || 1.45) / 1.45), pu = 0.5 + 0.5 * Math.sin(t * 2);
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        // alone tenue SOLO attorno ai piedi: l'informazione utile e' il bordo, non la superficie
        ctx.globalAlpha = 0.16 + 0.06 * pu;
        const g = this._grad('sp_pal|' + Math.round(R), () => { const q = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.42); q.addColorStop(0, 'rgba(255,233,168,.5)'); q.addColorStop(1, 'rgba(255,233,168,0)'); return q; });
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R * 0.42, 0, 7); ctx.fill();
        // il cerchio del raggio: tratteggiato e sottile, si legge senza coprire il campo di battaglia
        ctx.globalAlpha = 0.30 + 0.18 * pu; ctx.strokeStyle = 'rgba(255,233,168,.85)'; ctx.lineWidth = 1.6;
        ctx.setLineDash([10, 9]); ctx.lineDashOffset = -t * 14;
        ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        ctx.restore();
      } else if (sp === 'stregone') {               // ombra che si allarga sotto i piedi
        ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = '#1a0a14';
        ctx.beginPath(); ctx.ellipse(-r * 0.2, 0, r * 1.5, r * 1.1, 0, 0, 7); ctx.fill(); ctx.restore();
      }
    },
    _specSopra(ctx, r, t, sp) {
      ctx.save();
      if (sp === 'paladino') {                      // aureola dorata sopra l'elmo
        ctx.strokeStyle = 'rgba(255,220,120,.9)'; ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.ellipse(r * 0.05, 0, r * 0.62, r * 0.30, 0, 0, 7); ctx.stroke();
      } else if (sp === 'maestro') {                // cresta rossa e lama di luce sull arco
        ctx.fillStyle = '#c0332b'; ctx.strokeStyle = '#0a0c12'; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.moveTo(-r * 0.1, -r * 0.06); ctx.lineTo(-r * 0.95, -r * 0.02); ctx.lineTo(-r * 0.95, r * 0.02); ctx.lineTo(-r * 0.1, r * 0.06); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = 'rgba(255,210,122,.55)'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(0, 0, r * 1.25, -0.95, 0.95); ctx.stroke();
      } else if (sp === 'arcimago') {               // rune dorate in orbita larga
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 5; i++) { const a = t * 0.9 + i * 1.257; ctx.fillStyle = 'rgba(255,214,120,.75)';
          ctx.beginPath(); ctx.arc(Math.cos(a) * r * 1.5, Math.sin(a) * r * 1.35, r * 0.09, 0, 7); ctx.fill(); }
      } else if (sp === 'stregone') {               // nucleo rosso al posto dell orbe
        ctx.globalCompositeOperation = 'lighter';
        const g = this._grad('sp_str|' + r, () => { const q = ctx.createRadialGradient(r * 1.62, 0, 1, r * 1.62, 0, r * 0.62); q.addColorStop(0, 'rgba(255,255,255,.9)'); q.addColorStop(0.3, 'rgba(255,90,122,.85)'); q.addColorStop(1, 'rgba(255,45,107,0)'); return q; });
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(r * 1.62, 0, r * 0.62, 0, 7); ctx.fill();
      } else if (sp === 'assassino') {              // scia scura e lama alla cintura
        ctx.globalAlpha = 0.55; ctx.fillStyle = '#120a1e';
        ctx.beginPath(); ctx.moveTo(-r * 0.2, -r * 0.5); ctx.quadraticCurveTo(-r * 1.7, 0, -r * 0.2, r * 0.5); ctx.closePath(); ctx.fill();
        ctx.globalAlpha = 1; ctx.lineCap = 'round';
        ctx.strokeStyle = '#0a0c12'; ctx.lineWidth = r * 0.16; ctx.beginPath(); ctx.moveTo(-r * 0.02, r * 0.6); ctx.lineTo(r * 0.36, r * 0.72); ctx.stroke();
        ctx.strokeStyle = '#d8d2c8'; ctx.lineWidth = r * 0.08; ctx.beginPath(); ctx.moveTo(-r * 0.02, r * 0.6); ctx.lineTo(r * 0.36, r * 0.72); ctx.stroke();
        ctx.lineCap = 'butt';
      } else if (sp === 'cacciatore') {             // seconda faretra e punte accese
        ctx.strokeStyle = '#9ef0b0'; ctx.lineWidth = 1.8;
        for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(-r * 0.75, r * (0.1 + k * 0.22)); ctx.lineTo(-r * 1.15, r * (0.02 + k * 0.3)); ctx.stroke(); }
        ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(158,240,176,.5)';
        ctx.beginPath(); ctx.arc(-r * 1.18, 0, r * 0.16, 0, 7); ctx.fill();
      }
      ctx.restore();
    },
    // ---- MAGO: il mantello e' la sagoma. La massa della stoffa la fa il VALORE, non il contorno: il
    // primo tentativo aveva panno quasi nero e filo ciano tutt'intorno e da sopra leggeva come un anello.
    _heroMago(ctx, r, t, atk, eq) {
      const st = (eq && eq._st) || {};
      const _P = Object.assign({}, st, (eq && eq.pal) || {});
      const DK = '#0a0c12', body = _P.body || '#16181f', bodyDk = _P.bodyDk || '#05060a', accent = _P.accent || '#00f0c8', skin = _P.skin || '#d8d2c8';
      const sway = Math.sin(t * 5) * 0.12, sw2 = Math.sin(t * 5 + 0.8) * 0.10;
      ctx.lineJoin = 'round';
      const mg = this._grad('h_mag|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 1.6, -r * 0.6, r * 0.4, r * 0.6); q.addColorStop(0, _P.body || '#20252f'); q.addColorStop(0.55, _P.bodyDk || '#161a22'); q.addColorStop(1, '#0d1016'); return q; });
      ctx.fillStyle = mg; ctx.strokeStyle = DK; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(r * 0.30, -r * 0.34);
      ctx.quadraticCurveTo(r * 0.02, -r * 1.02, -r * 0.72, -r * 1.16);
      if (st.stracciato) {
        // WARLOCK: l'orlo a brandelli. Punte alterne lungo il dietro del mantello, con un respiro
        // lento: e' la sola differenza di SAGOMA fra lui e il mago, ed e' quella che si legge da sopra.
        const N = 11, A0 = -1.92, A1 = -2 * Math.PI + 1.92;
        for (let i = 0; i <= N; i++) {
          const u = i / N, an = A0 + (A1 - A0) * u;
          const f = (i % 2) ? 0.76 : 1.0 + 0.05 * Math.sin(t * 2.2 + i);
          ctx.lineTo(-r * 0.30 + Math.cos(an) * r * 1.50 * f, Math.sin(an) * r * 1.22 * f);
        }
      } else {
        ctx.quadraticCurveTo(-r * 1.62, -r * 1.08, -r * 1.78, -r * (0.30 + sway));
        ctx.quadraticCurveTo(-r * 1.86, 0, -r * 1.78, r * (0.30 + sw2));
        ctx.quadraticCurveTo(-r * 1.62, r * 1.08, -r * 0.72, r * 1.16);
      }
      ctx.quadraticCurveTo(r * 0.02, r * 1.02, r * 0.30, r * 0.34);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = _P.orlo || 'rgba(0,240,200,.75)'; ctx.lineWidth = 2.2;   // l'accento resta SOLO sull'orlo
      ctx.beginPath(); ctx.moveTo(-r * 0.72, -r * 1.16);
      ctx.quadraticCurveTo(-r * 1.62, -r * 1.08, -r * 1.78, -r * (0.30 + sway));
      ctx.quadraticCurveTo(-r * 1.86, 0, -r * 1.78, r * (0.30 + sw2));
      ctx.quadraticCurveTo(-r * 1.62, r * 1.08, -r * 0.72, r * 1.16); ctx.stroke();
      ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 2;         // due pieghe verso l'orlo
      ctx.beginPath(); ctx.moveTo(-r * 0.30, -r * 0.70); ctx.quadraticCurveTo(-r * 1.00, -r * 0.80, -r * 1.42, -r * 0.46); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-r * 0.30, r * 0.70); ctx.quadraticCurveTo(-r * 1.00, r * 0.80, -r * 1.42, r * 0.46); ctx.stroke();
      ctx.fillStyle = '#0a0b10'; ctx.strokeStyle = DK; ctx.lineWidth = 2; this._boot(ctx, -r * 0.5, -r * 0.34, r); this._boot(ctx, -r * 0.5, r * 0.34, r);
      ctx.strokeStyle = body; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.34;
      ctx.beginPath(); ctx.moveTo(0, -r * 0.45); ctx.lineTo(r * 0.7, -r * 0.14); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, r * 0.45); ctx.lineTo(r * 0.7, r * 0.14); ctx.stroke();
      ctx.lineCap = 'butt'; ctx.lineWidth = 2; ctx.strokeStyle = DK;
      const gr = this._grad('h_torso|mag|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 0.6, 0, r * 0.4, 0); q.addColorStop(0, bodyDk); q.addColorStop(1, body); return q; });
      ctx.fillStyle = gr; this._rr(ctx, -r * 0.65, -r * 0.55, r * 1.15, r * 1.1, r * 0.4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = accent; ctx.globalAlpha = 0.75; ctx.fillRect(-r * 0.5, -r * 0.06, r * 0.9, r * 0.12); ctx.globalAlpha = 1;
      ctx.fillStyle = '#0a0b10'; ctx.strokeStyle = accent; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(-r * 0.30, 0, r * 0.16, 0, 7); ctx.fill(); ctx.stroke();
      const _civM = !!(eq && eq.civile);   // v1.75 — il civile non impugna nulla
      if (!_civM && st.arma === 'sigillo') {
        // WARLOCK: niente bastone. Un sigillo che ruota sospeso davanti al palmo, e divampa quando
        // lancia. Riusa gli stessi due strati dell'orbe (cerchio piu' alone), quindi non costa nulla.
        ctx.save(); ctx.translate(r * 1.35, 0); ctx.rotate(t * 0.8);
        ctx.globalCompositeOperation = 'lighter';
        const acc = _P.accent || '#c06bff';
        ctx.strokeStyle = this._rgba(acc.charAt(0) === '#' ? acc : '#c06bff', 0.55 + 0.35 * atk); ctx.lineWidth = 2.2;
        const R2 = r * (0.46 + 0.10 * atk);
        ctx.beginPath(); ctx.arc(0, 0, R2, 0, 7); ctx.stroke();
        ctx.beginPath();
        for (let i = 0; i < 5; i++) { const a1 = i * 2.513, b1 = ((i + 2) % 5) * 2.513;
          ctx.moveTo(Math.cos(a1) * R2, Math.sin(a1) * R2); ctx.lineTo(Math.cos(b1) * R2, Math.sin(b1) * R2); }
        ctx.stroke();
        const sg = this._grad('h_sig|' + r + '|' + acc, () => { const q = ctx.createRadialGradient(0, 0, 1, 0, 0, r * 0.55); q.addColorStop(0, 'rgba(255,255,255,.85)'); q.addColorStop(0.35, this._rgba(acc.charAt(0) === '#' ? acc : '#c06bff', 0.7)); q.addColorStop(1, this._rgba(acc.charAt(0) === '#' ? acc : '#c06bff', 0)); return q; });
        ctx.globalAlpha = 0.7 + 0.3 * atk; ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(0, 0, r * 0.55, 0, 7); ctx.fill();
        ctx.restore();
      } else if (!_civM) {
      ctx.fillStyle = '#2a1d10'; ctx.strokeStyle = DK; ctx.lineWidth = 1.5;   // bastone
      this._rr(ctx, r * 0.45, -r * 0.06, r * 1.05, r * 0.12, 2); ctx.fill(); ctx.stroke();
      ctx.save(); ctx.globalCompositeOperation = 'lighter';                   // orbe: divampa quando lancia
      // v1.88 — un orbe per bacchetta: colore e grandezza dicono che arma hai in mano.
      const orb = { mag_scettro: ['163,140,255', 0.62], mag_bastone: ['127,251,228', 0.76], mag_stelle: ['255,217,255', 0.92] }[eq && eq.wp] || ['0,240,200', 0.50];
      const og = this._grad('h_orb|' + r + '|' + orb[0], () => { const q = ctx.createRadialGradient(r * 1.62, 0, 1, r * 1.62, 0, r * orb[1]); q.addColorStop(0, 'rgba(255,255,255,.95)'); q.addColorStop(0.28, 'rgba(' + orb[0] + ',.85)'); q.addColorStop(1, 'rgba(' + orb[0] + ',0)'); return q; });
      ctx.globalAlpha = 0.75 + 0.25 * atk; ctx.fillStyle = og; ctx.beginPath(); ctx.arc(r * 1.62, 0, r * (orb[1] + 0.34 * atk), 0, 7); ctx.fill(); ctx.restore();
      }
      ctx.fillStyle = skin; ctx.strokeStyle = DK; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(r * 0.05, 0, r * 0.5, 0, 7); ctx.fill(); ctx.stroke();
      // v2.18 — IL CAPPELLO A TESA LARGA del mago: un disco sotto la punta. Dall'alto e' la sagoma che
      // lo rende riconoscibile a colpo d'occhio, ed e' l'unica cosa che lo distingue dal warlock, che
      // tiene il cappuccio a punta di sempre.
      if (st.cappello === 'tesa') {
        ctx.fillStyle = _P.capp || '#1b2445'; ctx.strokeStyle = DK; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(-r * 0.05, 0, r * 0.86, r * 0.74, 0, 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = this._shade(_P.capp || '#1b2445', 22);
      } else ctx.fillStyle = _P.capp || '#0c0d12';
      ctx.strokeStyle = DK; ctx.lineWidth = 2;     // cappuccio a punta
      ctx.beginPath(); ctx.moveTo(r * 0.16, -r * 0.46); ctx.quadraticCurveTo(-r * 0.55, -r * 0.52, -r * 1.06, -r * 0.10);
      ctx.quadraticCurveTo(-r * 1.12, 0, -r * 1.06, r * 0.10);
      ctx.quadraticCurveTo(-r * 0.55, r * 0.52, r * 0.16, r * 0.46); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = accent; ctx.globalAlpha = 0.5; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(r * 0.02, 0, r * 0.42, -2.0, 2.0); ctx.stroke(); ctx.globalAlpha = 1;
      ctx.fillStyle = '#05060a'; ctx.fillRect(r * 0.22, -r * 0.30, r * 0.16, r * 0.60);
      ctx.fillStyle = accent; ctx.globalAlpha = 0.55; ctx.fillRect(r * 0.30, -r * 0.24, r * 0.04, r * 0.48); ctx.globalAlpha = 1;
      if (st.rune !== 0) {
        ctx.save(); ctx.globalCompositeOperation = 'lighter';                   // rune orbitanti
        for (let i = 0; i < 3; i++) { const ang = t * (1.1 + i * 0.35) + i * 2.1; ctx.fillStyle = this._rgba((accent && accent.charAt(0) === '#') ? accent : '#00f0c8', 0.5); ctx.beginPath(); ctx.arc(Math.cos(ang) * r * 1.05, Math.sin(ang) * r * 0.95, r * 0.07, 0, 7); ctx.fill(); }
        ctx.restore();
      }
      // WARLOCK: tre filamenti che strisciano dietro. Non gli sono stati messi gli OCCHI accesi sotto
      // il cappuccio — c'erano nella prima bozza e Paolo li ha fatti togliere. Non vanno rimessi.
      if (st.tentacoli) {
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.55;
        const acc2 = (accent && accent.charAt(0) === '#') ? accent : '#c06bff';
        ctx.strokeStyle = this._rgba(acc2, 0.5); ctx.lineWidth = r * 0.09; ctx.lineCap = 'round';
        for (let i = -1; i <= 1; i++) {
          const an = Math.PI + i * 0.42 + Math.sin(t * 1.6 + i) * 0.10;
          ctx.beginPath(); ctx.moveTo(Math.cos(an) * r * 0.9, Math.sin(an) * r * 0.75);
          ctx.quadraticCurveTo(Math.cos(an) * r * 1.5, Math.sin(an) * r * 1.10 + r * 0.22 * Math.sin(t * 2 + i), Math.cos(an) * r * 2.0, Math.sin(an) * r * 1.30);
          ctx.stroke();
        }
        ctx.restore(); ctx.lineCap = 'butt';
      }
    },
    // ---- GUERRIERO: armatura abbozzata (pochi solchi, non dettagli) e scudo ad arco ")" davanti.
    // Gli spallacci sono volutamente PIU SCURI del pettorale: con lo stesso acciaio la figura diventava
    // un grumo di grigi. L'elmo, al contrario, e' PIU CHIARO, altrimenti la testa spariva nel torace.
    _heroGuerriero(ctx, r, t, atk, eq) {
      // v2.18 — tre classi su questa impalcatura. `ST` da' la base (tinta, testa, spalle, arma); la
      // tinta dell'EQUIPAGGIAMENTO resta sopra, com'e' sempre stato dalla v1.88: un barbaro con
      // un'armatura azzurra si vede azzurro, non marrone.
      const st = (eq && eq._st) || {};
      const _P = Object.assign({}, st, (eq && eq.pal) || {});
      const DK = '#0a0c12', clothDk = _P.clothDk || '#243516', cloth = _P.cloth || '#3f5a2c', steelDk = _P.steelDk || '#3a424e';
      // v1.82.2 — DALL'ALTO IL GUERRIERO E' QUASI TUTTO METALLO: elmo, piastra e spalline coprivano la
      // sagoma e avevano tre grigi scritti a mano, quindi la tinta del vestito non si vedeva. Adesso i tre
      // pezzi nascono da UN colore (`metallo`) e dalle sue schiariture: cambiarlo cambia l'armatura intera.
      const met = _P.metallo || '#7f8895';
      const metS = this._shade(met, -69), metM = this._shade(met, 46), metL = this._shade(met, 99);
      const sway = Math.sin(t * 5) * 0.12;
      ctx.lineJoin = 'round';
      ctx.fillStyle = steelDk; ctx.strokeStyle = DK; ctx.lineWidth = 2; this._boot(ctx, -r * 0.5, -r * 0.34, r); this._boot(ctx, -r * 0.5, r * 0.34, r);
      const armPlate = (y0, y1, x1) => {                                       // bracciali segmentati
        ctx.strokeStyle = '#2c333d'; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.32;
        ctx.beginPath(); ctx.moveTo(0, y0); ctx.lineTo(x1, y1); ctx.stroke();
        ctx.lineCap = 'butt'; ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 1.6;
        for (let k = 1; k <= 2; k++) { const u = k / 3; ctx.beginPath(); ctx.moveTo(x1 * u - r * 0.05, y0 + (y1 - y0) * u - r * 0.16); ctx.lineTo(x1 * u + r * 0.05, y0 + (y1 - y0) * u + r * 0.16); ctx.stroke(); }
      };
      armPlate(-r * 0.45, -r * 0.30, r * 0.62); armPlate(r * 0.45, r * 0.16, r * 0.70);
      ctx.strokeStyle = DK; ctx.lineWidth = 2;
      const gr = this._grad('h_torso|gue|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 0.6, 0, r * 0.4, 0); q.addColorStop(0, clothDk); q.addColorStop(1, cloth); return q; });
      ctx.fillStyle = gr; this._rr(ctx, -r * 0.65, -r * 0.55, r * 1.15, r * 1.1, r * 0.4); ctx.fill(); ctx.stroke();
      if (st.piastra === 0) {
        // BARBARO: petto nudo e una cinghia di cuoio al posto del pettorale. E' la sua difesa che
        // manca, e si deve vedere prima ancora di leggere i numeri.
        ctx.fillStyle = _P.pelle || '#c08050'; ctx.strokeStyle = DK; ctx.lineWidth = 2;
        this._rr(ctx, -r * 0.30, -r * 0.30, r * 0.62, r * 0.60, r * 0.24); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = '#4a3520'; ctx.lineWidth = r * 0.10;
        ctx.beginPath(); ctx.moveTo(-r * 0.34, r * 0.34); ctx.lineTo(r * 0.26, -r * 0.30); ctx.stroke();
      } else {
      const pg = this._grad('h_plate|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 0.5, -r * 0.4, r * 0.3, r * 0.4); q.addColorStop(0, metS); q.addColorStop(0.5, met); q.addColorStop(1, '#c2c9d4'); return q; });
      ctx.fillStyle = pg; this._rr(ctx, -r * 0.36, -r * 0.34, r * 0.74, r * 0.68, r * 0.26); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(0,0,0,.42)'; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(-r * 0.30, -r * 0.30); ctx.lineTo(r * 0.24, -r * 0.24); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-r * 0.32, 0); ctx.lineTo(r * 0.28, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-r * 0.30, r * 0.30); ctx.lineTo(r * 0.24, r * 0.24); ctx.stroke();
      // PALADINO: il tabarro chiaro col sole sul petto. E' l'unico segno che lo distingue a colpo
      // d'occhio dal maestro d'armi, che porta la stessa piastra.
      if (st.tabarro) {
        ctx.fillStyle = st.tabarro; ctx.globalAlpha = 0.9; ctx.fillRect(-r * 0.34, -r * 0.10, r * 0.70, r * 0.20); ctx.globalAlpha = 1;
        ctx.fillStyle = _P.orlo || '#e0b64a'; ctx.beginPath(); ctx.arc(r * 0.02, 0, r * 0.11, 0, 7); ctx.fill();
      }
      }
      const sp = this._grad('h_spall|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 0.3, 0, r * 0.3, 0); q.addColorStop(0, this._shade(met, -95)); q.addColorStop(1, this._shade(met, -45)); return q; });
      for (const sgy of [-1, 1]) {
        if (st.spalle === 'pelliccia') {
          // BARBARO: pelliccia invece degli spallacci. Il contorno e' volutamente frastagliato — un
          // ellisse pulito, a questa scala, si legge come acciaio qualunque colore abbia.
          ctx.fillStyle = _P.pelo || '#6a5a44'; ctx.strokeStyle = DK; ctx.lineWidth = 2;
          ctx.beginPath();
          for (let i = 0; i < 9; i++) { const an = i / 8 * Math.PI * 2, rad = r * (0.27 + (i % 2 ? 0.06 : 0));
            const X = -r * 0.14 + Math.cos(an) * rad * 1.05, Y = sgy * r * 0.62 + Math.sin(an) * rad * 0.78;
            i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }
          ctx.closePath(); ctx.fill(); ctx.stroke();
          continue;
        }
        ctx.fillStyle = sp; ctx.strokeStyle = DK; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.ellipse(-r * 0.14, sgy * r * 0.60, r * 0.30, r * 0.21, sgy * 0.3, 0, 7); ctx.fill(); ctx.stroke();
      }
      ctx.strokeStyle = DK; ctx.lineWidth = 2;
      // v1.75 — CIVILE: la stessa sagoma senza scudo e senza elmo. La usano i mercanti, che condividono
      // il linguaggio degli eroi (spalle, corazza, mantello) ma non vanno in battaglia.
      const _civ = !!(eq && eq.civile);
      // ============================================================================================
      // v2.19.5 — IL GUERRIERO IMPUGNA CIO' CHE HA IN MANO, non cio' che dice la sua classe
      // ============================================================================================
      // Fino alla v2.19.4 le armi di questa impalcatura venivano dallo STILE della classe: il barbaro
      // aveva sempre l'ascia, il maestro sempre due spade, il paladino sempre lo scudo. Paolo ha trovato
      // i due modi in cui questo si rompe:
      //  · *«hai disegnato il barbaro con un'ascia, ma se equipaggia una spada e' un'incongruenza»*;
      //  · il paladino che impugna un'arma a DUE MANI si toglie lo scudo — e il gioco si CONGELAVA.
      //    Lo stile diceva `scudo: 1` («questa classe si disegna con lo scudo»), e `scudo` e' anche il
      //    nome del COLORE che la tinta dello scudo impugnato ci scrive sopra. Senza scudo in mano, al
      //    posto del colore restava il numero 1, `_shade(1)` lanciava a ogni fotogramma, e il ciclo di
      //    disegno si fermava sull'ultima immagine buona: il villaggio fermo.
      // Stessa radice: il disegno guardava la classe invece dell'equipaggiamento. Adesso guarda cosa c'e'
      // nelle mani — `wp` (arma principale), `wx` (seconda arma), `sh` (scudo), mandati dal server —
      // e lo disegna con UNA LAMA GENERICA, come Paolo ha chiesto (*«fallo piu' generico»*): non
      // un'ascia, una spada o un maglio, ma «un'arma», che non contraddice nessun pezzo del listino.
      // Cio' che la lama dice e' il PESO, che e' l'unica cosa che conta al colpo: la leggera e' corta e
      // sottile, l'equilibrata e' la spada di mezzo, la pesante e' lunga e larga — e se e' a due mani
      // la tengono tutte e due, davanti al corpo invece che di lato.
      const _G = window.GAME && window.GAME.Gear, _H = window.GAME && window.GAME.Heroes;
      const _pz = (id) => (_G && id && _G.BY_ID[id]) || null;
      const arma1 = _civ ? null : _pz(eq && eq.wp), arma2 = _civ ? null : _pz(eq && eq.wx);
      const scudoIt = _civ ? null : _pz(eq && eq.sh);
      const mani = (_H && _H.maniDi && eq && eq._hid) ? _H.maniDi(eq._hid) : null;
      const dueMani = !!(arma1 && _G && _G.aDueMani && _G.aDueMani(arma1, mani));
      if (arma1) this._lamaGenerica(ctx, r, atk, arma1.carattere, dueMani ? 0 : 1, _P, DK);
      if (arma2) this._lamaGenerica(ctx, r, atk, arma2.carattere, -1, _P, DK);
      // lo scudo si disegna SE C'E', e per chiunque lo impugni — non solo per il paladino: la tabella
      // lo concede anche al barbaro e al maestro d'armi, e finora loro lo portavano invisibile.
      if (scudoIt) {
      ctx.save(); ctx.translate(r * (0.30 + 0.22 * atk), -r * 0.14 + sway * 3);  // scudo: si protende nel colpo
      // scudo a torre: copre di piu' (arco piu' ampio) ed e' piu' spesso. E' l'unico pezzo d'armatura che
      // cambia la sagoma vista dall'alto, quindi vale la pena disegnarlo diverso.
      // v1.88 — QUATTRO SCUDI, non piu' due. Piu' alto e' il rango, piu' l'arco e' AMPIO e la lastra
      // spessa: e' l'unico pezzo d'armatura che cambia la sagoma vista dall'alto, ed e' anche il pezzo
      // che nel gioco para davvero — la forma dice quanto copre, e la dice senza numeri.
      const srk = (eq._rk && eq._rk.s) || 1;
      // v2.19.5 — il colore si usa solo se E' un colore. Non si fida del nome della chiave: e' proprio
      // un nome condiviso fra un'impostazione e un colore che ha congelato la partita.
      const scCol = (typeof _P.scudo === 'string') ? _P.scudo : '#8d97a5', orlo = (typeof _P.orlo === 'string') ? _P.orlo : '#c8a23a';
      const RS = r * (0.86 + 0.052 * (srk - 1)), TH = r * (0.26 + 0.052 * (srk - 1));
      const A0 = -(1.15 + 0.145 * (srk - 1)), A1 = -A0;
      const sgd = this._grad('h_scudo|' + r + '|' + srk + '|' + scCol, () => { const q = ctx.createLinearGradient(RS - TH, 0, RS + TH * 0.6, 0); q.addColorStop(0, this._shade(scCol, -78)); q.addColorStop(0.55, scCol); q.addColorStop(1, this._shade(scCol, 60)); return q; });
      ctx.fillStyle = sgd; ctx.strokeStyle = DK; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, RS + TH / 2, A0, A1); ctx.arc(0, 0, RS - TH / 2, A1, A0, true); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = orlo; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(0, 0, RS + TH / 2 - 2, A0 + 0.05, A1 - 0.05); ctx.stroke();
      ctx.fillStyle = orlo; ctx.strokeStyle = DK; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(RS, 0, r * (0.11 + 0.012 * (srk - 1)), 0, 7); ctx.fill(); ctx.stroke();
      // i rivetti: uno in piu' per rango, distribuiti sull'arco. Contarli non serve — si legge la densita'.
      ctx.fillStyle = '#e6ecf4';
      ctx.beginPath();
      for (let k = 0; k < srk + 1; k++) { const u = (k + 1) / (srk + 2), an = A0 + (A1 - A0) * u; ctx.arc(Math.cos(an) * RS, Math.sin(an) * RS, r * 0.05, 0, 7); }
      ctx.fill();
      if (srk >= 2) { ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(0, 0, RS, A0 + 0.12, A1 - 0.12); ctx.stroke(); }
      if (srk >= 4) {   // l'Aegis: una runa accesa lungo il bordo
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        ctx.strokeStyle = this._rgba(orlo, 0.55 + 0.3 * Math.sin(t * 3)); ctx.lineWidth = 2.6;
        ctx.beginPath(); ctx.arc(0, 0, RS - TH * 0.15, A0 + 0.2, A1 - 0.2); ctx.stroke();
        ctx.restore();
      }
      ctx.restore();
      }
      if (_civ) {   // testa scoperta: capelli e la fetta di viso davanti, al posto dell'elmo
        ctx.fillStyle = _P.pelo || '#4a3520'; ctx.strokeStyle = DK; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.arc(r * 0.05, 0, r * 0.44, 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = _P.skin || '#c79b6a';
        ctx.beginPath(); ctx.arc(r * 0.12, 0, r * 0.3, -1.25, 1.25); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.beginPath(); ctx.arc(r * 0.26, -r * 0.1, r * 0.045, 0, 7); ctx.arc(r * 0.26, r * 0.1, r * 0.045, 0, 7); ctx.fill();
        return;
      }
      // v2.18 — TRE TESTE. Il barbaro e' a capo scoperto (criniera, codino, barba), il maestro d'armi
      // ha l'elmo aperto col viso in vista e la sciarpa che svolazza, il paladino tiene l'elmo chiuso
      // della v1.66. Una classe si riconosce dalla testa prima che dall'arma: e' la parte che sta
      // sempre al centro della sagoma.
      if (st.testa === 'nuda') {
        const cri = _P.criniera || '#5a3a1e';
        ctx.strokeStyle = cri; ctx.lineWidth = r * 0.10; ctx.lineCap = 'round';
        for (let i = 0; i < 6; i++) { const an = 2.0 + i * 0.75;
          ctx.beginPath(); ctx.moveTo(Math.cos(an) * r * 0.34, Math.sin(an) * r * 0.34);
          ctx.lineTo(Math.cos(an) * r * (0.62 + 0.08 * Math.sin(t * 3 + i)), Math.sin(an) * r * (0.62 + 0.08 * Math.sin(t * 3 + i))); ctx.stroke(); }
        ctx.lineCap = 'butt';
        ctx.fillStyle = cri; ctx.strokeStyle = DK; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(-r * 0.44, 0, r * 0.15, 0, 7); ctx.fill(); ctx.stroke();      // codino
        ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(-r * 0.02, 0, r * 0.42, 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = this._shade(cri, -26);
        ctx.beginPath(); ctx.arc(r * 0.09, 0, r * 0.33, -1.30, 1.30); ctx.closePath(); ctx.fill();   // barba
        ctx.fillStyle = _P.pelle || '#c08050';
        ctx.beginPath(); ctx.arc(r * 0.14, 0, r * 0.25, -1.15, 1.15); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.beginPath(); ctx.arc(r * 0.26, -r * 0.09, r * 0.045, 0, 7); ctx.arc(r * 0.26, r * 0.09, r * 0.045, 0, 7); ctx.fill();
        return;
      }
      if (st.testa === 'elmoAperto') {
        ctx.fillStyle = _P.pelle || '#c79b6a'; ctx.strokeStyle = DK; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(r * 0.05, 0, r * 0.45, 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = this._shade(met, -30); ctx.strokeStyle = DK; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(r * 0.02, 0, r * 0.46, 1.05, -1.05); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.beginPath(); ctx.arc(r * 0.30, -r * 0.11, r * 0.05, 0, 7); ctx.arc(r * 0.30, r * 0.11, r * 0.05, 0, 7); ctx.fill();
        if (st.fascia) {
          ctx.fillStyle = st.fascia; ctx.strokeStyle = DK; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.moveTo(-r * 0.20, -r * 0.26); ctx.quadraticCurveTo(-r * 0.80, -r * (0.36 + sway), -r * 0.94, -r * 0.02);
          ctx.quadraticCurveTo(-r * 0.74, r * 0.16, -r * 0.20, r * 0.22); ctx.closePath(); ctx.fill(); ctx.stroke();
        }
        return;
      }
      const hg = this._grad('h_elmo|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 0.5, -r * 0.4, r * 0.4, r * 0.4); q.addColorStop(0, this._shade(met, -17)); q.addColorStop(0.5, metM); q.addColorStop(1, '#e2e7ee'); return q; });
      ctx.fillStyle = hg; ctx.strokeStyle = DK; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.arc(r * 0.05, 0, r * 0.46, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#0b0e13'; this._rr(ctx, r * 0.16, -r * 0.22, r * 0.30, r * 0.44, 3); ctx.fill();   // feritoia
      ctx.fillStyle = '#0b0e13'; this._rr(ctx, -r * 0.02, -r * 0.06, r * 0.34, r * 0.12, 2); ctx.fill();
      ctx.fillStyle = st.cresta || steelDk; ctx.strokeStyle = DK; ctx.lineWidth = 2;                       // cresta corta
      ctx.beginPath(); ctx.moveTo(-r * 0.16, -r * 0.10); ctx.quadraticCurveTo(-r * 0.62, -r * 0.06 + sway * r * 0.4, -r * 0.78, 0);
      ctx.quadraticCurveTo(-r * 0.62, r * 0.06 + sway * r * 0.4, -r * 0.16, r * 0.10); ctx.closePath(); ctx.fill(); ctx.stroke();
    },
    // ---- LADRO: cappuccio, mantellina corta, faretra, e l'arco disegnato di LATO — la curva ")" corre
    // lungo il fianco, non davanti: di fronte sarebbe uno scudo, non un arco.
    _heroLadro(ctx, r, t, atk, eq) {
      const st = (eq && eq._st) || {};
      const _P = Object.assign({}, st, (eq && eq.pal) || {});
      const DK = '#0a0c12', cloth = _P.cloth || '#3c5140', clothDk = _P.clothDk || '#1d2a22', skin = _P.skin || '#c99a6a', wood = _P.wood || '#8a6534';
      // v1.82.2 — dall'alto del ladro si vedono soprattutto MANTELLINA e CAPPUCCIO: erano due verdi
      // scritti a mano, quindi due ladri di tinta diversa restavano due macchie verdi uguali.
      const mant = _P.mant || '#25342b', capp = _P.capp || '#33443a';
      const sway = Math.sin(t * 5) * 0.12, draw = atk;
      ctx.lineJoin = 'round';
      // v2.18 — ASSASSINO: la scia d'ombra che lo segue. E' sotto tutto il resto, come le aure.
      if (st.scia) {
        ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = '#120a1e';
        ctx.beginPath(); ctx.moveTo(-r * 0.2, -r * 0.55); ctx.quadraticCurveTo(-r * 1.8, 0, -r * 0.2, r * 0.55); ctx.closePath(); ctx.fill(); ctx.restore();
      }
      ctx.fillStyle = mant; ctx.strokeStyle = DK; ctx.lineWidth = 2;           // mantellina dietro
      ctx.beginPath(); ctx.moveTo(-r * 0.10, -r * 0.58); ctx.quadraticCurveTo(-r * 1.20, -r * (0.62 + sway), -r * 1.10, 0);
      ctx.quadraticCurveTo(-r * 1.20, r * (0.62 - sway), -r * 0.10, r * 0.58); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = clothDk; ctx.strokeStyle = DK; ctx.lineWidth = 2; this._boot(ctx, -r * 0.5, -r * 0.34, r); this._boot(ctx, -r * 0.5, r * 0.34, r);
      // v2.19.6 — ANCHE QUI SI DISEGNA CIO' CHE SI IMPUGNA. Lo stile diceva «l'assassino ha i pugnali»,
      // e basta: l'assassino che impugnava un arco restava disegnato coi pugnali mentre tirava frecce —
      // il difetto che Paolo aveva trovato al contrario. Adesso decide l'arma in mano (`wp`): da mischia
      // = lame, altrimenti = arco. La seconda lama si vede solo se c'e' una seconda arma (`wx`). Se
      // l'equipaggiamento non e' noto (niente `wp`), si ricade sullo stile, come prima.
      const _GL = window.GAME && window.GAME.Gear;
      const _aL = _GL && eq && eq.wp ? _GL.BY_ID[eq.wp] : null;
      const lame = _aL ? !!(_aL.weapon && _aL.weapon.melee) : st.arma === 'pugnali';
      const dueLame = _aL ? !!(eq && eq.wx) : st.arma === 'pugnali';
      ctx.strokeStyle = skin; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.38;
      if (eq && eq.civile) {                                    // v1.75 — senza arco le braccia stanno gia' giu'
        ctx.beginPath(); ctx.moveTo(0, -r * 0.45); ctx.lineTo(r * 0.58, -r * 0.22); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, r * 0.45); ctx.lineTo(r * 0.58, r * 0.22); ctx.stroke();
      } else if (lame) {
        // ASSASSINO: le braccia stanno avanti e in fuori, una lama per mano. Non regge niente sopra la
        // testa, quindi la sagoma e' piu' bassa e larga di quella dell'arciere — si distinguono da li'.
        ctx.beginPath(); ctx.moveTo(0, -r * 0.45); ctx.lineTo(r * (0.52 + draw * 0.34), -r * 0.40); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, r * 0.45); ctx.lineTo(r * (0.52 + draw * 0.34), r * 0.40); ctx.stroke();
      } else {
      ctx.beginPath(); ctx.moveTo(0, -r * 0.45); ctx.lineTo(r * 0.22, -r * 0.92); ctx.stroke();           // regge l'arco
      ctx.beginPath(); ctx.moveTo(0, r * 0.42); ctx.lineTo(r * (0.30 - draw * 0.34), -r * (0.12 + draw * 0.30)); ctx.stroke();
      }
      ctx.lineCap = 'butt'; ctx.lineWidth = 2; ctx.strokeStyle = DK;
      const gr = this._grad('h_torso|lad|' + r + '|' + (eq._pk || ''), () => { const q = ctx.createLinearGradient(-r * 0.6, 0, r * 0.4, 0); q.addColorStop(0, clothDk); q.addColorStop(1, cloth); return q; });
      ctx.fillStyle = gr; this._rr(ctx, -r * 0.60, -r * 0.50, r * 1.05, r * 1.0, r * 0.38); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = '#5a3d1e'; ctx.lineWidth = r * 0.20; ctx.beginPath(); ctx.moveTo(-r * 0.45, r * 0.42); ctx.lineTo(r * 0.30, -r * 0.42); ctx.stroke();
      ctx.strokeStyle = DK; ctx.lineWidth = 2;
      const _civL = !!(eq && eq.civile);   // v1.75 — il civile non porta arco ne' faretra
      if (!_civL && lame) {
        for (const sg of (dueLame ? [-1, 1] : [1])) {
          ctx.save(); ctx.translate(r * (0.52 + draw * 0.34), sg * r * 0.40); ctx.rotate(sg * 0.18 - draw * 0.2 * sg);
          ctx.fillStyle = '#2a1d10'; ctx.strokeStyle = DK; ctx.lineWidth = 1.4; this._rr(ctx, -r * 0.16, -r * 0.05, r * 0.20, r * 0.10, 2); ctx.fill(); ctx.stroke();
          ctx.fillStyle = st.lama || '#cfd8dc'; ctx.strokeStyle = DK; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(r * 0.05, -r * 0.07); ctx.lineTo(r * 0.56, -r * 0.02); ctx.lineTo(r * 0.66, 0);
          ctx.lineTo(r * 0.56, r * 0.02); ctx.lineTo(r * 0.05, r * 0.07); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.restore();
        }
      }
      if (!_civL && !lame) {
      ctx.fillStyle = '#5a3d1e'; ctx.save(); ctx.translate(-r * 0.52, r * 0.40); ctx.rotate(-0.5);        // faretra
      this._rr(ctx, -r * 0.10, -r * 0.34, r * 0.20, r * 0.62, 3); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = '#ded4ab'; ctx.lineWidth = 1.8;
      for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(k * r * 0.06, -r * 0.34); ctx.lineTo(k * r * 0.09, -r * 0.60); ctx.stroke(); }
      ctx.restore(); ctx.strokeStyle = DK; ctx.lineWidth = 2;
      // l'arco lungo esce oltre la sagoma davanti e dietro, e la curva e' piu' profonda: da sopra e' la
      // sola cosa che distingue i due archi, e si vede subito.
      // v1.88 — l'arco cresce con il rango: quattro lunghezze e quattro legni. Il rango 1 e' quello di
      // partenza e resta il metro; dal terzo il legno si scurisce e il colore lo da' l'oggetto.
      const wrk = (eq._rk && eq._rk.w) || 1;
      // v2.12 — CINQUE VALORI, non quattro, e l'indice si stringe comunque. Con l'arrivo del grado
      // SCARSO i ranghi sono diventati 5: qui c'erano quattro numeri indicizzati per rango, quindi un'arma
      // di grado 5 leggeva `[4]` → `undefined` → tutta la matematica del disegno andava in NaN e l'arco del
      // ladro spariva. Il clamp non e' ridondante: e' la rete per il giorno che i gradi diventano sei.
      const _wi = Math.max(0, Math.min(4, wrk - 1));
      const BL = [1, 1.18, 1.34, 1.48, 1.60][_wi], BC = [0.46, 0.55, 0.62, 0.70, 0.76][_wi];
      const lungo = wrk >= 2;
      const arcoCol = wrk >= 2 ? this._gearCol(eq.wp, _P.wood || '#8a6534') : (_P.wood || '#8a6534');
      const bx0 = -r * 0.56 * BL, bx1 = r * 0.80 * BL, by = -r * 1.00;         // ARCO ")" di lato
      ctx.strokeStyle = arcoCol; ctx.lineCap = 'round'; ctx.lineWidth = r * (0.13 + 0.012 * (wrk - 1));
      ctx.beginPath(); ctx.moveTo(bx0, by + r * 0.10); ctx.quadraticCurveTo(r * 0.12, by - r * BC, bx1, by + r * 0.10); ctx.stroke();
      ctx.strokeStyle = '#5a4326'; ctx.lineWidth = r * 0.05;
      ctx.beginPath(); ctx.moveTo(bx0, by + r * 0.10); ctx.quadraticCurveTo(r * 0.12, by - r * BC, bx1, by + r * 0.10); ctx.stroke();
      ctx.strokeStyle = 'rgba(240,240,230,.9)'; ctx.lineWidth = 1.6; ctx.lineCap = 'butt';
      const pull = by + r * (0.10 + 0.60 * draw);                              // corda tirata mentre incocca
      ctx.beginPath(); ctx.moveTo(bx0, by + r * 0.10); ctx.lineTo(r * 0.12, pull); ctx.lineTo(bx1, by + r * 0.10); ctx.stroke();
      if (wrk >= 3) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = this._rgba(arcoCol, 0.5); ctx.lineWidth = r * 0.09; ctx.beginPath(); ctx.moveTo(bx0, by + r * 0.10); ctx.quadraticCurveTo(r * 0.12, by - r * BC, bx1, by + r * 0.10); ctx.stroke(); ctx.restore(); }
      if (lungo) { ctx.strokeStyle = 'rgba(230,220,190,.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(bx0, by + r * 0.10); ctx.quadraticCurveTo(r * 0.12, by - r * (BC - 0.10), bx1, by + r * 0.10); ctx.stroke(); ctx.strokeStyle = 'rgba(240,240,230,.9)'; ctx.lineWidth = 1.6; }
      if (draw > 0.05) {
        ctx.strokeStyle = '#efe7cf'; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(r * 0.12, pull); ctx.lineTo(r * 1.22, pull - r * 0.04); ctx.stroke();
        ctx.fillStyle = '#e2e9f2'; ctx.beginPath(); ctx.moveTo(r * 1.36, pull - r * 0.05); ctx.lineTo(r * 1.18, pull - r * 0.14); ctx.lineTo(r * 1.18, pull + r * 0.04); ctx.closePath(); ctx.fill();
      }
      }
      ctx.lineCap = 'butt';
      ctx.fillStyle = skin; ctx.strokeStyle = DK; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(r * 0.05, 0, r * 0.48, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = capp; ctx.strokeStyle = DK; ctx.lineWidth = 2;           // cappuccio a punta
      ctx.beginPath(); ctx.moveTo(r * 0.20, -r * 0.44); ctx.quadraticCurveTo(-r * 0.45, -r * 0.50, -r * 0.92, -r * 0.10);
      ctx.quadraticCurveTo(-r * 0.98, 0, -r * 0.92, r * 0.10);
      ctx.quadraticCurveTo(-r * 0.45, r * 0.50, r * 0.20, r * 0.44); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = st.buio || '#0d1512'; ctx.beginPath(); ctx.ellipse(r * 0.30, 0, r * 0.18, r * 0.24, 0, 0, 7); ctx.fill();
    },
    _drawMonster(ctx, m) {
      // v1.34 — fascio dello SGUARDO dell'Occhio Vagante (colore in base al tipo di debuff)
      if (m.t === 'occhio' && m.gz && m.gtx != null) {
        const gcol = { weaken: '#ff7a5a', slow: '#5ad0ff', sunder: '#c48cff' }[m.gk] || '#c48cff';
        const ga = Math.atan2(m.gty - m.y, m.gtx - m.x); const glen = Math.hypot(m.gtx - m.x, m.gty - m.y);
        const half = 0.55, spread = Math.tan(half) * glen;
        ctx.save(); ctx.translate(m.x, m.y); ctx.rotate(ga); ctx.globalCompositeOperation = 'lighter';
        const gg = ctx.createLinearGradient(0, 0, glen, 0); gg.addColorStop(0, this._rgba(gcol, 0.30)); gg.addColorStop(1, this._rgba(gcol, 0.02));
        ctx.fillStyle = gg; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(glen, -spread); ctx.lineTo(glen, spread); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = this._rgba(gcol, 0.45 + 0.3 * Math.sin(this.time * 14)); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(glen, 0); ctx.stroke();
        ctx.restore();
      }
      const def = MON[m.t] || BOSSES[m.t] || MON.skeleton; const rr = def.radius * (window.GAME.Constants.VIS_SCALE || 1) * (m.el ? 1.28 : 1) * (m.tr ? 1.15 : 1); const x = m.x, y = m.y; if (!def.puppet && !def.sheet) this._shadow(ctx, x, y, rr); /* v1.48 — puppet e sprite-sheet disegnano la PROPRIA ombra ai piedi (l'ombra generica sarebbe troppo bassa → sembra fluttuare) */
      ctx.save(); ctx.translate(x, y);
      if (def.fov) { // v1.39 — CONO VISIVO del Negromante (telegrafo): fioco, si accende quando ti vede (m.al) → allora spara sfere debilitanti
        const fov = def.fov, range = (def.sightRange || def.atkRange || 320), on = m.al ? 1 : 0, col = def.eye || '#a06bff';
        ctx.save(); ctx.rotate(m.f); ctx.globalCompositeOperation = 'lighter';
        const gr = ctx.createRadialGradient(0, 0, 10, 0, 0, range); gr.addColorStop(0, this._rgba(col, 0.05 + on * 0.13)); gr.addColorStop(1, this._rgba(col, 0));
        ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, range, -fov, fov); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = this._rgba(col, 0.1 + on * 0.28); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(-fov) * range, Math.sin(-fov) * range); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(fov) * range, Math.sin(fov) * range); ctx.stroke();
        ctx.restore();
      }
      if (def.puppet || def.sheet) { // alone emissivo tenue (puppet e sprite-sheet): più marcato e pulsante per lo SLIME (def.aura)
        const gc = def.eye || '#8bff86'; const aur = def.aura || 1; const pulse = def.aura ? (0.8 + 0.2 * Math.sin(this.time * 3 + x * 0.05)) : 1; const R2 = rr * (1.02 + (def.aura ? 0.4 : 0));
        // v1.64 — gradiente preso dalla cache (il pulsare passa da globalAlpha): era 1 allocazione per mostro per frame
        const gr = this._grad('au|' + gc + '|' + aur + '|' + R2.toFixed(1) + '|' + rr.toFixed(1), () => { const q = ctx.createRadialGradient(0, 0, rr * 0.2, 0, 0, R2); q.addColorStop(0, this._rgba(gc, 0.12 * aur)); q.addColorStop(1, this._rgba(gc, 0)); return q; });
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = pulse; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, R2, 0, 7); ctx.fill(); ctx.restore();
        if (def.bubbles && Math.random() < 0.35) { const bl = MU.rand(0.5, 0.9); this.particles.push({ x: x + MU.rand(-rr * 0.7, rr * 0.7), y: y + rr * 0.4, vx: MU.rand(-6, 6), vy: -MU.rand(18, 42), life: bl, t: bl, color: gc, r: MU.rand(1.5, 3), over: true }); } // v1.44 — bolle acide che salgono
      } else { const gc = def.eye || def.color || '#ff6b6b'; ctx.save(); ctx.globalCompositeOperation = 'lighter'; const gr = this._grad('a2|' + gc + '|' + rr.toFixed(1), () => { const q = ctx.createRadialGradient(0, 0, rr * 0.25, 0, 0, rr * 1.75); q.addColorStop(0, gc); q.addColorStop(1, 'rgba(0,0,0,0)'); return q; }); ctx.globalAlpha = (m.mg ? 0.55 : m.b ? 0.5 : m.el ? 0.42 : 0.3) * (0.85 + 0.15 * Math.sin(this.time * 4 + x * 0.05)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, rr * 1.75, 0, 7); ctx.fill(); ctx.restore(); } // v1.15 alone emissivo
      // v2.23 — IL RAGGIO DEL COMANDO. Lo disegna il Padrone stesso, sotto di se': l'anello
      // tratteggiato che gira e' l'unico modo che ha il giocatore di sapere DOVE finisce il
      // potenziamento, e quindi dove conviene tirare i mostri.
      if (def.comandoR) {
        const R = def.comandoR * (window.GAME.Constants.VIS_SCALE || 1), pu = 0.5 + 0.5 * Math.sin(this.time * 1.6);
        ctx.save();
        const ag = ctx.createRadialGradient(0, 0, R * 0.72, 0, 0, R);
        ag.addColorStop(0, 'rgba(255,90,30,0)'); ag.addColorStop(1, 'rgba(255,90,30,' + (0.05 + pu * 0.035) + ')');
        ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,130,60,' + (0.30 + pu * 0.18) + ')'; ctx.lineWidth = 2.4;
        ctx.setLineDash([14, 11]); ctx.lineDashOffset = -this.time * 26;
        ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        ctx.restore();
      }
      // e chi e' dentro al raggio lo porta addosso: bordo acceso. Senza, il potenziamento
      // sarebbe un numero invisibile e il giocatore non saprebbe perche' sta prendendo di piu'.
      if (m.cm) {
        const pu2 = 0.5 + 0.5 * Math.sin(this.time * 5 + (m.e || 0));
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const q = ctx.createRadialGradient(0, 0, rr * 0.55, 0, 0, rr * 1.75);
        q.addColorStop(0, 'rgba(255,120,40,' + (0.16 + pu2 * 0.10) + ')'); q.addColorStop(1, 'rgba(255,90,20,0)');
        ctx.fillStyle = q; ctx.beginPath(); ctx.arc(0, 0, rr * 1.75, 0, 7); ctx.fill(); ctx.restore();
        ctx.strokeStyle = 'rgba(255,150,70,' + (0.45 + pu2 * 0.3) + ')'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, 0, rr + 4, 0, 7); ctx.stroke();
      }
      if (m.tr) { ctx.strokeStyle = 'rgba(255,210,80,' + (0.6 + 0.3 * Math.sin(this.time * 7)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, rr + 8, 0, 7); ctx.stroke(); }
      else if (m.mg) { ctx.strokeStyle = 'rgba(255,45,85,' + (0.5 + 0.3 * Math.sin(this.time * 6)) + ')'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, rr + 12 + Math.sin(this.time * 4) * 3, 0, 7); ctx.stroke(); }
      else if (m.b) { ctx.strokeStyle = 'rgba(255,60,60,.5)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, rr + 8 + Math.sin(this.time * 4) * 2, 0, 7); ctx.stroke(); }
      else if (m.el) { ctx.strokeStyle = 'rgba(255,180,40,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, rr + 5, 0, 7); ctx.stroke(); }
      if (m.sh) { ctx.strokeStyle = 'rgba(120,255,234,.8)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0, 0, rr + 6, 0, 7); ctx.stroke(); }
      // v1.85 — MARCHIO: un sigillo che gira sopra la testa. Lo vede tutta la squadra, ed e' il punto:
      // e' il ladro che dice dove picchiare. Il cuneo ambra invece dice che quello sta inseguendo TE.
      if (m.mk) {
        ctx.save(); ctx.translate(0, -rr - 16); ctx.rotate(this.time * 2.2);
        ctx.strokeStyle = 'rgba(255,90,122,.95)'; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.arc(0, 0, 8, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, 4, 0, 7); ctx.stroke();
        for (let k = 0; k < 4; k++) { const an = k * Math.PI / 2; ctx.beginPath(); ctx.moveTo(Math.cos(an) * 9, Math.sin(an) * 9); ctx.lineTo(Math.cos(an) * 13, Math.sin(an) * 13); ctx.stroke(); }
        ctx.restore();
      }
      if (m.tn) { ctx.fillStyle = 'rgba(255,180,90,.9)'; ctx.beginPath(); ctx.moveTo(0, -rr - 9); ctx.lineTo(-5, -rr - 17); ctx.lineTo(5, -rr - 17); ctx.closePath(); ctx.fill(); }
      if (m.ps) { /* v1.38 — rimosso il disco verde attorno al nemico: il veleno si vede solo dalle particelle che salgono */ if (Math.random() < 0.3) this.particles.push({ x: x + MU.rand(-rr, rr), y: y - rr, vx: 0, vy: -20, life: 0.5, t: 0.5, color: '#7ee07e', r: 2, over: true }); }
      const bodyc = m.fl ? '#ffffff' : def.color; const dk = m.fl ? '#ffd0d0' : def.color2; const aa = this.mAtk[m.e]; const atk = aa ? Math.max(0, Math.min(1, aa.t / aa.dur)) : 0;
      // v1.46 — rilevamento movimento con ISTERESI + smoothing forte (per non tremolare, tipico dei mostri LENTI
      // come il Bruto la cui velocità sfiorava la soglia e faceva sfarfallare idle↔camminata = "parkinson").
      // v1.48 — soglie ABBASSATE + isteresi: i mostri LENTI (Troll speed 60, ~1px/frame; in vagabondaggio anche 0.5px)
      // ora attivano davvero l'animazione di CAMMINATA invece di restare in idle mentre scivolano.
      const moveInfo = (e) => { const gm = this._gmv || (this._gmv = {}); let pv = gm[e]; if (!pv) { pv = gm[e] = { x: m.x, y: m.y, mv: 0, on: 0, dir: 0 }; return pv; } const dx = m.x - pv.x, dy = m.y - pv.y, sp = Math.hypot(dx, dy); pv.mv = pv.mv != null ? pv.mv * 0.8 + sp * 0.2 : sp; if (pv.on) { if (pv.mv < 0.10) pv.on = 0; } else { if (pv.mv > 0.28) pv.on = 1; } if (sp > 0.05) pv.dir = Math.atan2(dy, dx); pv.x = m.x; pv.y = m.y; return pv; };
      if (def.topdown) { const pv = moveInfo(m.e); this._slimePuddle(ctx, m, rr, def, atk, !!pv.on, pv.dir); } // v1.46 — MELMA top-down (pozza fluo)
      else if (def.fungus) { this._fungusF(ctx, m, rr, def, atk); }   // v1.58 — immobile: nessuna camminata da animare
      else if (def.roller) { this._rollerF(ctx, m, rr, def, atk); }   // v1.58 — rotola: l'animazione e una rotazione
      else if (def.lama) { this._lamaF(ctx, m, rr, def, atk); }       // v2.22 — galleggia e scatta: nessun passo
      else if (def.gelatina) { this._cuboF(ctx, m, rr, def, atk); }   // v2.22 — un blocco che pulsa: nessun passo
      else if (def.bats) { this._batsF(ctx, m, rr, def, atk); }       // v1.61 — sciame: 11 sagome in orbita, nessuna camminata
      else if (def.wisp) { this._wispF(ctx, m, rr, def, atk); }       // v1.61 — fiamma sospesa: sinusoidi, nessun frame
      else if (def.larva) { const pv = moveInfo(m.e); this._larvaF(ctx, m, rr, def, atk, !!pv.on, pv.dir); }   // v1.81 — sacco gonfio dipinto a macchie
      else if (def.ragno) { const pv = moveInfo(m.e); this._ragnoDip(ctx, m, rr, def, atk, !!pv.on, pv.dir); }   // v1.81 — otto zampe dipinte a macchie
      else if (def.beholder) { const pv = moveInfo(m.e); this._beholderPuppet(ctx, m, rr, def, atk, !!pv.on, pv.dir); } // v1.49 — BEHOLDER (raster puppet: corpo ritagliato + iris che segue + eyestalks che avvampano nel colore dello sguardo)
      else if (def.sheet) { const pv = moveInfo(m.e); const flip = Math.cos(m.f) < 0 ? -1 : 1; // v1.47 — SPRITE SHEET (troll animato)
        if (!this._drawSheet(def.sheet, ctx, m, rr, def, atk, !!pv.on, flip, m.fl > 0, pv)) { ctx.rotate(m.f); this._shape(ctx, def.shape || 'imp', rr, bodyc, dk, def.eye || '#fff', this.time, atk, m); } }
      else if (def.front) { const flip = Math.cos(m.f) < 0 ? -1 : 1; const back = Math.sin(m.f) < -0.35; let moving = false; if (def.puppet) { moving = !!moveInfo(m.e).on; } this._front(ctx, def.shape, rr, bodyc, dk, def.eye || '#fff', this.time, atk, back, flip, moving, m.fl > 0, m.el); } // v1.30 billboard · v1.36 movimento · v1.38 hit · v1.39 elite (tint)
      else { ctx.rotate(m.f); this._shape(ctx, def.shape || 'imp', rr, bodyc, dk, def.eye || '#fff', this.time, atk, m); }
      ctx.restore();
      if (m.tr) { ctx.fillStyle = '#ffd24a'; ctx.font = 'bold 15px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('👑', x, y - rr - 14); ctx.textAlign = 'left'; }
      if (m.hp < m.mhp) { const bw = Math.max(24, rr * 2.2); ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(x - bw / 2, y - rr - 12, bw, m.b ? 6 : 4); ctx.fillStyle = m.tr ? '#ffd24a' : (m.mg ? '#ff2d55' : (m.b ? '#ff3b5b' : (m.el ? '#ffb020' : '#ff6b6b'))); ctx.fillRect(x - bw / 2, y - rr - 12, bw * Math.max(0, m.hp / m.mhp), m.b ? 6 : 4); }
    },
    // v1.26 — segnala un attacco (swing) per il mostro eid
    hitAttack(eid, dur) { if (eid == null) return; this.mAtk[eid] = { t: 0, dur: dur || 0.34 }; },
    // v1.26 — genera uno sprite di morte effimero (crolla/svanisce; volute per il negromante)
    spawnDeath(ev) { const def = MON[ev.id] || BOSSES[ev.id]; if (!def) return; this.deaths.push({ x: ev.x, y: ev.y, f: ev.f || 0, eid: ev.eid, type: ev.id, el: !!ev.elite, boss: !!ev.boss, t: 0, dur: ev.boss ? 0.9 : (def.sheet ? 0.7 : (def.puppet ? 0.8 : 0.6)) }); }, // v1.39/1.47 — morte puppet/sheet un filo più lunga
    _drawDeaths(ctx) {
      for (const d of this.deaths) {
        const def = MON[d.type] || BOSSES[d.type]; if (!def) continue;
        const p = Math.min(1, d.t / d.dur); const rr = def.radius * (window.GAME.Constants.VIS_SCALE || 1) * (d.el ? 1.28 : 1);
        ctx.save(); ctx.translate(d.x, d.y);
        if (def.sheet && SHEETS[def.sheet] && SHEETS[def.sheet].ready) { // v1.47 — morte SPRITE-SHEET: il frame idle cade in avanti e svanisce
          ctx.globalAlpha = Math.max(0, 1 - p); const flip = Math.cos(d.f) < 0 ? -1 : 1;
          ctx.translate(0, rr * 0.5 * p); ctx.rotate(flip * p * 0.5); ctx.scale(1 + p * 0.06, 1 - p * 0.5);
          this._drawSheet(def.sheet, ctx, { e: d.eid || 0, f: d.f, fl: 0 }, rr, def, 0, false, flip, false);
          ctx.globalAlpha = 1;
        }
        else if (def.topdown && PUPPETS.slime && PUPPETS.slime.ready) { // v1.46 — morte MELMA top-down: la pozza si restringe e svanisce
          const img = PUPPETS.slime.imgs.body; const gc = def.eye || '#a6ff3a';
          if (img) { const base = (rr * 2.7) / Math.max(img.width, img.height) * (1 - p * 0.5); ctx.globalAlpha = Math.max(0, 1 - p); ctx.drawImage(img, -img.width * base / 2, -img.height * base / 2, img.width * base, img.height * base); ctx.globalAlpha = 1; }
          ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(0, 0, rr * 0.3, 0, 0, rr * 1.3); gr.addColorStop(0, this._rgba(gc, 0.4 * (1 - p))); gr.addColorStop(1, this._rgba(gc, 0)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, rr * 1.3, 0, 7); ctx.fill();
          if (Math.random() < 0.5) this.particles.push({ x: d.x + MU.rand(-rr, rr), y: d.y + MU.rand(-rr, rr), vx: MU.rand(-10, 10), vy: -MU.rand(6, 24), life: 0.5, t: 0.5, color: gc, r: MU.rand(1.5, 3), over: true });
        }
        else if (def.beholder && PUPPETS.beholder && PUPPETS.beholder.ready) { // v1.49 — morte BEHOLDER: l'occhio si chiude/implode e svanisce
          const img = PUPPETS.beholder.imgs.body; const gc = def.eye || '#ff5ad0';
          if (img) { const base = (2.6 * rr) / Math.max(img.width, img.height); const sx = base * (1 + p * 0.3), sy = base * Math.max(0.04, 1 - p * 0.92);
            ctx.globalAlpha = Math.max(0, 1 - p); ctx.drawImage(img, -img.width * sx / 2, -img.height * sy / 2, img.width * sx, img.height * sy); ctx.globalAlpha = 1; }
          ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(0, 0, rr * 0.2, 0, 0, rr * 1.3 * (1 - p * 0.4)); gr.addColorStop(0, this._rgba(gc, 0.5 * (1 - p))); gr.addColorStop(1, this._rgba(gc, 0)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, rr * 1.3, 0, 7); ctx.fill();
          if (Math.random() < 0.5) this.particles.push({ x: d.x + MU.rand(-rr, rr), y: d.y + MU.rand(-rr, rr), vx: MU.rand(-14, 14), vy: -MU.rand(8, 30), life: 0.5, t: 0.5, color: gc, r: MU.rand(1.5, 3), over: true });
        }
        else if (def.bats) {   // v1.61 — morte NUGOLO: si sparpaglia (le sagome fuggono verso l'esterno) e svanisce
          ctx.globalAlpha = Math.max(0, 1 - p);
          const N = def.swarmN || 9;
          for (let i = 0; i < N; i++) {
            const ph = i * 2.399963, an = this.time * (1.5 + ((i * 0.53) % 1) * 1.6) + ph;
            const rad = rr * (0.30 + 0.66 * ((i * 0.37) % 1)) * (1 + p * 2.6);
            this._bat1(ctx, Math.cos(an) * rad * 1.18, Math.sin(an * 0.9 + ph) * rad * 0.6 - rr * 0.22 - p * rr,
              rr * 0.155 * (0.78 + 0.44 * ((i * 0.71) % 1)), 0.9, def.eye || '#c9a0ff', Math.cos(an) < 0 ? -1 : 1);
          }
          ctx.globalAlpha = 1;
        }
        else if (def.wisp) {   // v1.61 — morte FUOCO FATUO: la fiamma implode nel nucleo e si spegne
          const gc = def.eye || '#7dffea';
          ctx.globalCompositeOperation = 'lighter';
          const gr = ctx.createRadialGradient(0, 0, 1, 0, 0, rr * (1.8 * (1 - p) + 0.2));
          gr.addColorStop(0, this._rgba(gc, 0.85 * (1 - p))); gr.addColorStop(1, this._rgba(gc, 0));
          ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, rr * (1.8 * (1 - p) + 0.2), 0, 7); ctx.fill();
          if (Math.random() < 0.6) this.particles.push({ x: d.x + MU.rand(-rr, rr), y: d.y + MU.rand(-rr, rr),
            vx: MU.rand(-30, 30), vy: -MU.rand(10, 50), life: 0.5, t: 0.5, color: gc, r: MU.rand(1.2, 2.6), over: true });
        }
        else if (def.puppet && PUPPETS[def.shape] && PUPPETS[def.shape].ready) { // v1.39 — morte PUPPET dedicata (crollo pezzi)
          const flip = Math.cos(d.f) < 0 ? -1 : 1; this._puppetDeath(def.shape, ctx, rr, def.eye || '#fff', this.time, flip, p);
        } else {
          ctx.globalAlpha = Math.max(0, 1 - p);
          if (def.front) { ctx.scale(1 - p * 0.1, 1 - p * 0.55); const flip = Math.cos(d.f) < 0 ? -1 : 1; this._front(ctx, def.shape, rr, def.color, def.color2, def.eye || '#fff', this.time, 0, false, flip); } // v1.30 — collasso frontale
          else { ctx.rotate(d.f + p * (d.boss ? 0.3 : 0.7)); ctx.scale(1 - p * 0.15, 1 - p * 0.5); this._shape(ctx, def.shape || 'imp', rr, def.color, def.color2, def.eye || '#fff', this.time, 0); }
        }
        ctx.restore();
        if ((def.shape === 'mage' || def.shape === 'lich') && Math.random() < 0.4) this.particles.push({ x: d.x + MU.rand(-rr, rr), y: d.y + MU.rand(-rr, rr), vx: MU.rand(-20, 20), vy: -MU.rand(10, 40), life: 0.6, t: 0.6, color: def.eye || '#b48cff', r: MU.rand(1.5, 3), over: true });
      }
    },
    // ============================ v1.30 — SPRITE FRONTALI (billboard) ============================
    _shade(hex, amt) { const n = parseInt(hex.slice(1), 16); let R = (n >> 16) + amt, G = ((n >> 8) & 255) + amt, B = (n & 255) + amt; R = Math.max(0, Math.min(255, R)); G = Math.max(0, Math.min(255, G)); B = Math.max(0, Math.min(255, B)); return 'rgb(' + R + ',' + G + ',' + B + ')'; },
    _rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; },
    _front(ctx, shape, r, col, dk, eye, t, atk, back, flip, moving, hit, elite) {
      ctx.save(); if (flip < 0) ctx.scale(-1, 1);
      if (shape === 'zombie') this._zombieF(ctx, r, col, dk, eye, t, atk, back);
      else if (shape === 'troll') this._trollF(ctx, r, col, dk, eye, t, atk, back);
      else if (shape === 'occhio') this._eyeF(ctx, r, col, dk, eye, t, atk, back);
      else if (shape === 'spettro') this._spettroF(ctx, r, col, dk, eye, t, atk, back);
      else if (shape === 'ghoul') this._puppet('ghoul', ctx, r, eye, t, atk, back, moving, hit, elite);
      else if (shape === 'mage') this._puppet('mage', ctx, r, eye, t, atk, back, moving, hit, elite);
      else if (shape === 'brute') this._puppet('brute', ctx, r, eye, t, atk, back, moving, hit, elite);
      else if (shape === 'padrone') this._puppet('padrone', ctx, r, eye, t, atk, back, moving, hit, elite);   // v2.23
      else if (shape === 'slime') this._puppet('slime', ctx, r, eye, t, atk, back, moving, hit, elite);
      ctx.restore();
    },
    // ===== v1.39 — MOTORE PUPPET GENERICO: compone i pezzi PNG ruotandoli attorno ai pivot secondo il
    // profilo (PROF[key]) + overlay vettoriale (occhi/orbe) + ombra a terra. Migliorie v1.39:
    //  • hit-reaction del corpo (squash + rinculo)  • inclinazione nel movimento  • ombra che si allunga
    //  • tint per gli elite (ctx.filter)  • morte dedicata con crollo dei pezzi (vedi _puppetDeath).
    _puppet(key, ctx, r, eye, t, atk, back, moving, hit, elite) {
      const reg = PUPPETS[key], prof = PROF[key]; reg.load();
      if (!reg.ready) { this._zombieF(ctx, r, '#3a3d3a', '#181a18', eye, t, atk, back); return; } // fallback finché carica
      const man = reg.man, SC = 0.5, OX = man.originX, OY0 = prof.OY0, CH = man.charH;
      const s = (prof.K * r) / CH, si = s / SC, D2R = Math.PI / 180, S = Math.sin;
      const st = prof.pose(t, moving, atk); const P = st.P, bob = st.bob, lungeX = st.lungeX, tilt = st.tilt || 0, swing = st.swing || 0;
      // ---- OMBRA A TERRA (si allunga/segue il movimento e l'affondo) ----
      { const fy = (man.feetY - OY0) * s; const lift = Math.max(0, -bob) / 22;
        const stretch = moving ? 1.22 : 1; const off = (moving ? 6 : 0) + lungeX * 0.6;
        const sw = r * 0.62 * stretch * (1 - lift * 0.3), sh = r * 0.20 * (1 - lift * 0.3);
        ctx.save(); ctx.filter = 'blur(' + Math.max(1, r * 0.11).toFixed(1) + 'px)';
        ctx.fillStyle = 'rgba(0,0,0,' + (0.5 - lift * 0.16).toFixed(2) + ')';
        ctx.beginPath(); ctx.ellipse(off * s, fy, sw, sh, 0, 0, 7); ctx.fill(); ctx.restore();
      }
      // ---- HIT-REACTION + SQUASH&STRETCH: scala l'intero puppet attorno alla riga dei piedi ----
      // Il profilo può restituire st.sx/st.sy (es. lo SLIME che si comprime/allunga saltando); l'hit aggiunge lo squash.
      const hb = hit ? 1 : 0;
      const sqx = (st.sx || 1) * (hb ? 1.06 : 1), sqy = (st.sy || 1) * (hb ? 0.9 : 1);
      ctx.save();
      { const fy = (man.feetY - OY0) * s; if (hb) ctx.translate(-5, 0); if (sqx !== 1 || sqy !== 1) { ctx.translate(0, fy); ctx.scale(sqx, sqy); ctx.translate(0, -fy); } }
      // tint elite (facoltativo): applicato ai soli pezzi raster
      const partFilter = elite ? prof.eliteFilter : (st.alpha != null ? '' : '');
      const byName = {}; for (const p of man.parts) byName[p.name] = p;
      // v2.23 — LE ALI DEL PADRONE, disegnate qui e non nel raster. Nel disegno di partenza c'erano
      // ma erano ferme: un'ala ferma e' un mantello. Tolte dal ritaglio e rifatte in vettoriale,
      // cosi' battono, si aprono sulla carica e si chiudono nell'affondo. Vanno DIETRO ai pezzi,
      // quindi si disegnano qui, prima del ciclo che mette giu' la marionetta.
      if (prof.ali) this._aliPadrone(ctx, s, st, t);
      for (const name of prof.order) {
        const p = byName[name], img = reg.imgs[name]; if (!p || !img) continue;
        const tr = P[name] || [0, 0, 0];
        const extraRot = (name === 'torso' || name === 'head' || name === 'robe') ? tilt : (tilt * 0.4);
        const wx = (p.ax + tr[1] + lungeX - OX) * s, wy = (p.ay + tr[2] + bob - OY0) * s;
        ctx.save(); ctx.translate(wx, wy); ctx.rotate((tr[0] + extraRot) * D2R);
        if (st.alpha != null) ctx.globalAlpha = st.alpha;
        if (partFilter) ctx.filter = partFilter;
        ctx.drawImage(img, -p.ox * si, -p.oy * si, p.w * si, p.h * si);
        ctx.restore();
      }
      // ---- OVERLAY VETTORIALE: orbe del bastone (mage) + occhi pulsanti (avvampano se colpito) ----
      // orbe/cast (solo mage)
      if (man.orb && byName.armStaff && reg.imgs.armStaff) { const asp = byName.armStaff, atr = P.armStaff || [0, 0, 0];
        ctx.save(); ctx.translate((asp.ax + atr[1] + lungeX - OX) * s, (asp.ay + atr[2] + bob - OY0) * s); ctx.rotate((atr[0] + tilt * 0.4) * D2R);
        ctx.globalCompositeOperation = 'lighter';
        const ox = (man.orb[0] - asp.ax) * s, oy = (man.orb[1] - asp.ay) * s, cast = st.cast || 0;
        const R0 = r * (0.34 + cast * 0.18) * (0.9 + 0.1 * S(t * 5));
        const gr = ctx.createRadialGradient(ox, oy, 0, ox, oy, R0);
        gr.addColorStop(0, this._rgba(eye, Math.min(1, 0.85 + cast * 0.15))); gr.addColorStop(0.5, this._rgba(eye, 0.4 + cast * 0.3)); gr.addColorStop(1, this._rgba(eye, 0));
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ox, oy, R0, 0, 7); ctx.fill();
        ctx.fillStyle = '#f3e9ff'; ctx.beginPath(); ctx.arc(ox, oy, R0 * 0.28, 0, 7); ctx.fill(); ctx.restore();
      }
      // ---- CORE emissivo (SLIME): nucleo verde acido pulsante che avvampa se colpito ----
      if (man.core && byName.body) { const bp = byName.body, btr = P.body || [0, 0, 0];
        ctx.save(); ctx.translate((bp.ax + btr[1] + lungeX - OX) * s, (bp.ay + btr[2] + bob - OY0) * s); ctx.globalCompositeOperation = 'lighter';
        const cx = (man.core[0] - bp.ax) * s, cy = (man.core[1] - bp.ay) * s;
        const pulse = 0.7 + 0.3 * S(t * 3) + hb * 0.6 + swing * 0.4;
        const R0 = r * 0.55 * (0.92 + 0.08 * S(t * 4));
        const gr = ctx.createRadialGradient(cx, cy, 0, cx, cy, R0);
        gr.addColorStop(0, this._rgba(eye, Math.min(1, 0.6 * pulse))); gr.addColorStop(0.5, this._rgba(eye, Math.min(1, 0.26 * pulse))); gr.addColorStop(1, this._rgba(eye, 0));
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, R0, 0, 7); ctx.fill();
        ctx.fillStyle = this._rgba('#eaffbf', Math.min(1, 0.6 * pulse)); ctx.beginPath(); ctx.arc(cx, cy, R0 * 0.16, 0, 7); ctx.fill(); ctx.restore();
      }
      const noBack = (key === 'slime'); // il blob non ha "dorso": mostra sempre gli occhi
      const hp = byName.head || byName.body, htr = (hp && P[hp.name]) || [0, 0, 0];
      if (hp) {
        ctx.save(); ctx.translate((hp.ax + htr[1] + lungeX - OX) * s, (hp.ay + htr[2] + bob - OY0) * s); ctx.rotate((htr[0] + (byName.head ? tilt : 0)) * D2R);
        if (!back || noBack) {
          ctx.globalCompositeOperation = 'lighter';
          // v1.45 — occhi che si ILLUMINANO nella DIREZIONE DI MOVIMENTO: più intensi mentre si muove, con
          // la pupilla luminosa spostata in avanti (il contesto è già specchiato verso il verso di marcia).
          const mv = st.moving ? 1 : 0;
          const pulse = Math.min(1.9, 0.6 + 0.3 * S(t * 4) + swing * 0.4 + hb * 0.95 + mv * 0.5);
          for (const e of (man.eyes || [])) {
            const ex = (e[0] - hp.ax) * s, ey = (e[1] - hp.ay) * s, R0 = r * (0.16 + swing * 0.05 + hb * 0.07 + mv * 0.03);
            const gr = ctx.createRadialGradient(ex, ey, 0, ex, ey, R0 * 3);
            gr.addColorStop(0, this._rgba(eye, Math.min(1, 0.9 * pulse))); gr.addColorStop(0.4, this._rgba(eye, Math.min(1, 0.5 * pulse))); gr.addColorStop(1, this._rgba(eye, 0));
            ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ex, ey, R0 * 3, 0, 7); ctx.fill();
            const fwd = mv * R0 * 0.5; // pupilla spostata in avanti (verso il movimento)
            ctx.fillStyle = '#f4fff0'; ctx.beginPath(); ctx.arc(ex + fwd, ey, R0 * (0.5 + hb * 0.25 + mv * 0.12), 0, 7); ctx.fill();
          }
        } else {
          ctx.fillStyle = 'rgba(8,10,14,0.5)'; ctx.beginPath(); ctx.ellipse(0, -r * 0.25, r * 0.72, r * 0.86, 0, 0, 7); ctx.fill();
          if (hb) { ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(0, -r * 0.25, 0, 0, -r * 0.25, r * 0.9); gr.addColorStop(0, this._rgba(eye, 0.75)); gr.addColorStop(1, this._rgba(eye, 0)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, -r * 0.25, r * 0.9, 0, 7); ctx.fill(); }
        }
        ctx.restore();
      }
      ctx.restore();
    },
    // v1.39 — MORTE PUPPET DEDICATA: i pezzi crollano (gambe cedono, testa rotola, veste si accascia) con dissolvenza.
    _puppetDeath(key, ctx, r, eye, t, flip, p) {
      const reg = PUPPETS[key], prof = PROF[key]; reg.load();
      if (!reg.ready || !prof.death) return false;
      const man = reg.man, SC = 0.5, OX = man.originX, OY0 = prof.OY0, CH = man.charH;
      const s = (prof.K * r) / CH, si = s / SC, D2R = Math.PI / 180;
      ctx.save(); if (flip < 0) ctx.scale(-1, 1);
      const st = prof.death(p); const P = st.P, bob = st.bob, alpha = st.alpha;
      // ombra che si dissolve e allarga
      { const fy = (man.feetY - OY0) * s; ctx.save(); ctx.filter = 'blur(' + Math.max(1, r * 0.12).toFixed(1) + 'px)';
        ctx.fillStyle = 'rgba(0,0,0,' + (0.42 * (1 - p)).toFixed(2) + ')'; ctx.beginPath(); ctx.ellipse(0, fy, r * 0.7 * (1 + p * 0.4), r * 0.22, 0, 0, 7); ctx.fill(); ctx.restore(); }
      // v1.44 — squash&stretch anche in morte (lo SLIME si scioglie appiattendosi)
      if (st.sx != null || st.sy != null) { const fy = (man.feetY - OY0) * s; ctx.translate(0, fy); ctx.scale(st.sx || 1, st.sy || 1); ctx.translate(0, -fy); }
      const byName = {}; for (const q of man.parts) byName[q.name] = q;
      for (const name of prof.order) {
        const q = byName[name], img = reg.imgs[name]; if (!q || !img) continue;
        const tr = P[name] || [0, 0, 0];
        const wx = (q.ax + tr[1] - OX) * s, wy = (q.ay + tr[2] + bob - OY0) * s;
        ctx.save(); ctx.globalAlpha = Math.max(0, alpha); ctx.translate(wx, wy); ctx.rotate(tr[0] * D2R);
        ctx.drawImage(img, -q.ox * si, -q.oy * si, q.w * si, q.h * si); ctx.restore();
      }
      // occhi che si spengono
      const hp = byName.head; if (hp && alpha > 0.05) { const htr = P.head || [0, 0, 0];
        ctx.save(); ctx.translate((hp.ax + htr[1] - OX) * s, (hp.ay + htr[2] + bob - OY0) * s); ctx.rotate(htr[0] * D2R); ctx.globalCompositeOperation = 'lighter';
        for (const e of (man.eyes || [])) { const ex = (e[0] - hp.ax) * s, ey = (e[1] - hp.ay) * s, R0 = r * 0.16 * alpha; const gr = ctx.createRadialGradient(ex, ey, 0, ex, ey, R0 * 3); gr.addColorStop(0, this._rgba(eye, 0.8 * alpha)); gr.addColorStop(1, this._rgba(eye, 0)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ex, ey, R0 * 3, 0, 7); ctx.fill(); }
        ctx.restore();
      }
      ctx.restore(); return true;
    },
    // v1.46 — MELMA CORROSIVA in vista TOP-DOWN: pozza fluo che striscia sul pavimento. Niente billboard/ombra:
    // il PNG (con edge-glow bakeato) è già "a terra". Animazione: WOBBLE gelatinoso (scala non uniforme lenta),
    // STIRAMENTO nella direzione di marcia, leggera rotazione ondeggiante, edge-glow additivo pulsante e
    // "spruzzo" in attacco. Il contesto è già traslato su (m.x, m.y).
    // v1.49 — BEHOLDER (raster puppet): disegna il corpo ritagliato (billboard fluttuante, leggero respiro),
    // poi sovrappone l'IRIDE centrale che SEGUE il bersaglio e si DILATA in attacco, gli occhi delle eyestalks
    // che AVVAMPANO nel colore dello sguardo ATTIVO (m.gk: weaken/slow/sunder) e un edge-glow magenta pulsante.
    // Il contesto e' gia' traslato su (m.x, m.y). Mirror non necessario (simmetrico).
    // ===== v1.79.2 — I BEHOLDER, DIPINTI ====================================================
    // Erano una marionetta: un ritaglio raster con l'iride incollata sopra. Adesso sono dipinti a codice
    // come la caverna — strati di macchie morbide dal buio al chiaro, bordo sporco, venature, iride
    // bagnata — e sono tre creature della stessa famiglia con tre palette. Un solo disegno, tre colori:
    // se un domani ne servisse un quarto basta aggiungere una riga a PAL_OCCHI.
    _macchia(ctx, x, y, rx, ry, col, a, rot) {
      ctx.save(); ctx.translate(x, y); if (rot) ctx.rotate(rot); ctx.globalAlpha = a;
      const g = this._grad('occ|' + col + '|' + Math.round(Math.max(rx, ry)), () => {
        const q = ctx.createRadialGradient(0, 0, 0, 0, 0, Math.max(rx, ry));
        q.addColorStop(0, col); q.addColorStop(0.62, col); q.addColorStop(1, 'rgba(0,0,0,0)'); return q;
      });
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, 0, 7); ctx.fill(); ctx.restore();
    },
    // un peduncolo: si assottiglia, ondeggia, e finisce in un occhietto acceso
    _peduncolo(ctx, cx, cy, ang, L, w, base, luce, t, i) {
      let px = cx, py = cy; const seg = 8;
      for (let k = 1; k <= seg; k++) {
        const p = k / seg;
        const a = ang + Math.sin(p * 2.2 + t * 1.8 + i * 1.3) * 0.40 * p;
        const x = cx + Math.cos(a) * L * p, y = cy + Math.sin(a) * L * p - Math.sin(p * Math.PI) * w * 0.6;
        const ww = w * (1 - p * 0.60);
        this._macchia(ctx, x, y, ww, ww * 0.92, base, 0.95);
        if (k > seg - 3) this._macchia(ctx, x, y, ww * 0.7, ww * 0.65, luce, 0.35);
        px = x; py = y;
      }
      this._macchia(ctx, px, py, w * 0.60, w * 0.58, '#fbe9f6', 0.9);
      this._macchia(ctx, px, py, w * 0.32, w * 0.31, luce, 1);
      this._macchia(ctx, px, py, w * 1.7, w * 1.6, luce, 0.20);
      ctx.fillStyle = '#12040f'; ctx.beginPath(); ctx.arc(px + Math.cos(ang) * w * 0.12, py + Math.sin(ang) * w * 0.12, Math.max(0.6, w * 0.16), 0, 7); ctx.fill();
    },
    // ===== v1.81 — LA LARVA FETIDA, DIPINTA ================================================
    // Stessa tecnica dei Beholder e della caverna: strati di macchie morbide dal buio al chiaro, bordo
    // sporco, niente contorno netto. E' un sacco basso e teso, segmentato, che striscia: il nucleo
    // dentro la pelle PULSA, e piu' e' vicino il momento in cui la uccidi piu' la luce si vede — e'
    // l'unico avviso che quando cade lascera' un buco nel pavimento. Nessun asset, solo codice.
    _larvaF(ctx, m, r, def, atk, moving, dir) {
      const t = this.time, e = (m.e || 0) * 0.7;
      const P = { buio: '#141b06', medio: '#3d4d15', chiaro: '#768c26', orlo: '#a8c23e', luce: '#e8ff6a', vena: '#232f0a' };
      const ang = (dir != null && moving) ? dir : (m.f || 0);
      const resp = 1 + Math.sin(t * 2.6 + e) * 0.045;
      const gonf = 0.5 + 0.5 * Math.sin(t * 3.1 + e);          // la sacca si gonfia e si sgonfia
      ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(0, r * 0.46, r * 0.92, r * 0.30, 0, 0, 7); ctx.fill(); ctx.restore();
      ctx.save(); ctx.rotate(ang); ctx.scale(1, resp);
      const seg = 6, len = 1.30, W = r * 0.92;
      const cx = i => (0.62 - (i / (seg - 1)) * len) * r;
      const wid = i => W * (1 - Math.pow(i / (seg - 1), 1.5) * 0.62);
      const off = i => Math.sin(t * 7.5 + e + (i / seg) * 2.4) * r * (moving ? 0.09 : 0.03) * (i / (seg - 1) + 0.25);
      // 1) massa scura: la sagoma, dalla coda alla testa
      for (let i = seg - 1; i >= 0; i--) { const w = wid(i); this._macchia(ctx, cx(i), off(i), w, w * 0.86, P.buio, 1); }
      // 2) il nucleo dentro la pelle: una luce sola, al centro del corpo, che pulsa
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      this._macchia(ctx, r * 0.02, 0, W * (0.62 + gonf * 0.14), W * 0.50, P.luce, 0.22 + gonf * 0.20);
      this._macchia(ctx, r * 0.02, 0, W * 0.34, W * 0.26, P.luce, 0.26 + gonf * 0.24);
      ctx.restore();
      // 3) volume: mezzitoni e luce in alto a sinistra (la luce della caverna viene dall alto)
      for (let i = seg - 1; i >= 0; i--) {
        const w = wid(i), o = off(i);
        this._macchia(ctx, cx(i) + w * 0.06, o - w * 0.18, w * 0.80, w * 0.56, P.medio, 0.85);
        this._macchia(ctx, cx(i) + w * 0.10, o - w * 0.34, w * 0.50, w * 0.28, P.chiaro, 0.60);
        this._macchia(ctx, cx(i) + w * 0.12, o - w * 0.44, w * 0.26, w * 0.13, P.orlo, 0.45);
      }
      // 4) solchi fra i segmenti: e quello che lo fa leggere come un verme e non come una macchia
      ctx.save(); ctx.globalAlpha = 0.55; ctx.strokeStyle = P.vena; ctx.lineCap = 'round';
      for (let i = 1; i < seg; i++) {
        const w = (wid(i) + wid(i - 1)) * 0.5, x = (cx(i) + cx(i - 1)) * 0.5, o = (off(i) + off(i - 1)) * 0.5;
        ctx.lineWidth = Math.max(1, w * 0.16);
        ctx.beginPath(); ctx.ellipse(x, o, w * 0.16, w * 0.72, 0, -1.15, 1.15); ctx.stroke();
      }
      ctx.restore();
      // 5) zampette: sei uncini che spingono quando striscia
      ctx.strokeStyle = P.vena; ctx.lineCap = 'round';
      for (let i = 0; i < 3; i++) for (const k of [-1, 1]) {
        const w = wid(i), px = cx(i) + r * 0.06, py = k * w * 0.62;
        const sw = Math.sin(t * 9 + e + i * 1.2 + (k > 0 ? 1.7 : 0)) * r * (moving ? 0.16 : 0.05);
        ctx.lineWidth = Math.max(1.3, r * 0.10);
        ctx.beginPath(); ctx.moveTo(px, py * 0.72); ctx.quadraticCurveTo(px + sw * 0.5, py, px + sw, py + k * r * 0.10); ctx.stroke();
      }
      // 6) testa: due occhietti accesi e le mandibole
      const hx = r * 0.70;
      ctx.strokeStyle = P.vena; ctx.lineWidth = Math.max(1.2, r * 0.10);
      for (const k of [-1, 1]) { ctx.beginPath(); ctx.moveTo(hx - r * 0.04, k * r * 0.20); ctx.quadraticCurveTo(hx + r * 0.20, k * r * 0.22, hx + r * 0.26, k * r * 0.06); ctx.stroke(); }
      for (const k of [-1, 1]) {
        ctx.fillStyle = '#0b1004'; ctx.beginPath(); ctx.ellipse(hx - r * 0.02, k * r * 0.20, r * 0.10, r * 0.075, 0, 0, 7); ctx.fill();
        this._macchia(ctx, hx + r * 0.01, k * r * 0.20, r * 0.055, r * 0.045, P.luce, 0.95);
        this._macchia(ctx, hx + r * 0.01, k * r * 0.20, r * 0.16, r * 0.13, P.luce, 0.22);
      }
      // 7) pelle bagnata
      this._macchia(ctx, r * 0.22, -r * 0.40, r * 0.34, r * 0.10, '#e8f7b0', 0.22);
      ctx.restore();
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; this._macchia(ctx, 0, 0, r * 1.7, r * 1.2, P.luce, 0.07 + gonf * 0.06); ctx.restore();
    },
    // ===== v1.81 — I TRE RAGNI DELLE VOLTE, DIPINTI =========================================
    // Stessa tecnica della caverna, dei Beholder e della Larva: solo macchie morbide sovrapposte, dal
    // buio al chiaro, nessun contorno chiuso. La lettura viene dalla SAGOMA — otto zampe che si piegano
    // sopra il corpo e ricadono a terra, addome ovale dietro, cefalotorace basso davanti col grappolo di
    // otto occhi. Un disegno solo, tre palette: se un domani ne servisse un quarto e' una riga in PAL_RAGNO.
    PAL_RAGNO: {
      vedova: { buio: '#08070c', chit: '#1e1a24', chiaro: '#4a3550', orlo: '#8f6f9c', segno: '#c8203a', occhio: '#ff3b52', alone: '#ff4d6a', pelo: '#160f1c' },
      cripta: { buio: '#0b0906', chit: '#261c12', chiaro: '#4a3720', orlo: '#8a6a3c', segno: '#d8a03a', occhio: '#ffc247', alone: '#ffb03a', pelo: '#1a1109' },
      veleno: { buio: '#070f0a', chit: '#152a1c', chiaro: '#2f5637', orlo: '#6ba268', segno: '#a6ff3a', occhio: '#c8ff5a', alone: '#9bff4d', pelo: '#0c1a10' },
    },
    // una zampa: femore che esce di lato e SALE (il ginocchio sta piu' in alto del corpo, come nei ragni
    // veri), tibia che ricade a terra e finisce a punta. `lato` e' +1 a destra, -1 a sinistra: e' quello
    // che tiene le otto zampe da tutt'e due le parti invece che ammucchiate su un fianco.
    _zampaRagno(ctx, x0, y0, lato, sp, L1, L2, gin, w, P, luce) {
      const kx = x0 + lato * Math.cos(sp) * L1, ky = y0 + Math.sin(sp) * L1 - gin;
      const fx = kx + lato * L2 * 1.15, fy = ky + L2 * 1.15;
      // le macchie vanno FITTE e larghe: a passo largo la zampa si legge come una collana di palline.
      const n1 = 26, n2 = 30;
      for (let i = 1; i <= n1; i++) {
        const p = i / n1;
        const x = x0 + (kx - x0) * p, y = y0 + (ky - y0) * p - Math.sin(p * Math.PI) * gin * 0.16;
        const ww = w * 1.45 * (1 - p * 0.22);
        this._macchia(ctx, x, y, ww, ww, P.chit, 0.55);
        if (luce) this._macchia(ctx, x - lato * ww * 0.28, y - ww * 0.34, ww * 0.46, ww * 0.30, P.chiaro, 0.16);
      }
      for (let i = 1; i <= n2; i++) {
        const p = i / n2;
        const x = kx + (fx - kx) * p, y = ky + (fy - ky) * p;
        const ww = w * 1.30 * (0.86 - p * 0.72);
        this._macchia(ctx, x, y, ww, ww, P.chit, 0.55);
        if (luce && p < 0.6) this._macchia(ctx, x - lato * ww * 0.28, y - ww * 0.32, ww * 0.40, ww * 0.28, P.chiaro, 0.14);
      }
      if (luce) this._macchia(ctx, fx, fy, w * 0.16, w * 0.13, P.orlo, 0.40);
    },
    // v1.90.2 — I RAGNI ERANO IL COLLO DI BOTTIGLIA. Misurato con un profilo vero all'ondata 16: UN
    // ragno costava 1313 macchie a frame (56 per zampa, sedici passaggi di zampa) — quasi cinque volte
    // TUTTO il resto della scena messo insieme, e con 7 ragni in campo il frame passava da 2,3 a 5,3 ms.
    // Il 23% del frame se ne andava nelle sole ctx.save().
    //
    // Soluzione: la stessa del Troll dalla v1.47 — si disegna la posa una volta in un riquadro fuori
    // schermo e poi si incolla. Il ciclo di camminata si quantizza in 12 fasi, l'attacco in 3, e le pose
    // si cuociono la prima volta che servono. Da 1313 fill a UN drawImage.
    _ragnoPose: null,
    _ragnoFrame(def, r, atk3, moving, fase) {
      const base = def.pal + '|' + Math.round(r) + '|' + atk3 + '|' + (moving ? 1 : 0) + '|';
      const cache = this._ragnoPose || (this._ragnoPose = new Map());
      let f = cache.get(base + fase);
      if (f) return f;
      // UNA COTTURA PER FRAME. Cuocerne tre di fila costa 11ms e si vede: quando la posa esatta non c'e'
      // ancora si usa la piu' vicina gia' pronta — a dodici fasi lo scarto e' mezzo passo, invisibile —
      // e la posa giusta arrivera' al frame dopo. Cosi' la spesa si spalma invece di fare uno scatto.
      if (this._cotturaN === this.frameN) {
        for (let d = 1; d <= 6; d++) {
          f = cache.get(base + ((fase + d) % 12)) || cache.get(base + ((fase + 12 - d) % 12));
          if (f) return f;
        }
      }
      this._cotturaN = this.frameN;
      const S = Math.ceil(r * 3.4);                     // le zampe arrivano a ~1,5r: il riquadro le contiene
      const dpr = this.dpr || 1;
      const cv = document.createElement('canvas');
      cv.width = Math.ceil(S * dpr); cv.height = Math.ceil(S * dpr);
      const g = cv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.translate(S / 2, S / 2);
      this._ragnoPosa(g, r, def, atk3 / 2, moving, (fase / 12) * Math.PI * 2);
      f = { cv, S };
      if (cache.size > 220) cache.clear();              // cambio di risoluzione o troppe varianti: si riparte
      cache.set(base + fase, f);
      return f;
    },
    _ragnoDip(ctx, m, r, def, atk, moving, dir) {
      const e = (m.e || 0) * 0.8;
      const ang = (this.time * 6.2 + e) % (Math.PI * 2);
      const fase = Math.round(ang / (Math.PI * 2) * 12) % 12;
      const atk3 = (atk || 0) > 0.66 ? 2 : (atk || 0) > 0.15 ? 1 : 0;
      const f = this._ragnoFrame(def, r, atk3, moving, fase);
      const flip = Math.cos(m.f || 0) < 0 ? -1 : 1;
      ctx.save(); ctx.scale(flip, 1);
      ctx.drawImage(f.cv, -f.S / 2, -f.S / 2, f.S, f.S);
      ctx.restore();
    },
    // v1.90.2 — LA POSA DEL RAGNO, disegnata UNA VOLTA per fase e poi riusata come immagine.
    // Il disegno e' identico a prima: cambia solo che al posto del tempo prende un ANGOLO di fase, cosi'
    // la stessa posa si puo' cuocere in un riquadro e ridisegnare con un drawImage invece di 1313 macchie.
    _ragnoPosa(ctx, r, def, atk, moving, ang) {
      const P = this.PAL_RAGNO[def.pal] || this.PAL_RAGNO.vedova;
      const sw = Math.sin((atk || 0) * Math.PI);
      const passo = moving ? 1 : 0.16;
      const bob = Math.sin(ang * 1.21) * r * (moving ? 0.05 : 0.02);
      const e = 0;
      ctx.save(); ctx.translate(0, bob);
      ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(0, r * 0.66, r * 1.25, r * 0.26, 0, 0, 7); ctx.fill(); ctx.restore();
      const SP = [-0.82, -0.34, 0.10, 0.52];          // apertura delle quattro zampe, dall'alto in basso
      const zampa = (i, lato, luce) => {
        const on = Math.sin(ang + i * 1.9 + (lato > 0 ? 2.8 : 0)) * passo;
        this._zampaRagno(ctx, lato * r * 0.16, -r * 0.02,
          lato, SP[i] + on * 0.13,
          r * (0.72 + i * 0.06), r * (0.58 + i * 0.06),
          r * (0.44 + on * 0.18) * (1 - i * 0.14),
          r * (0.105 - i * 0.008), P, luce);
      };
      for (let i = 3; i >= 0; i--) { zampa(i, -1, false); zampa(i, 1, false); }   // le zampe di la'
      // ADDOME: ovale, dietro e in alto
      const ax = -r * 0.52, ay = -r * 0.18, aw = r * 0.80;
      this._macchia(ctx, ax, ay + r * 0.06, aw * 1.16, aw * 0.92, P.buio, 0.95);
      this._macchia(ctx, ax, ay, aw * 1.02, aw * 0.78, P.chit, 0.95);
      this._macchia(ctx, ax - aw * 0.24, ay - aw * 0.24, aw * 0.52, aw * 0.34, P.chiaro, 0.38);
      this._macchia(ctx, ax - aw * 0.30, ay - aw * 0.34, aw * 0.26, aw * 0.14, P.orlo, 0.22);
      // il segno sull'addome: due gocce affusolate, non un faro
      this._macchia(ctx, ax + aw * 0.24, ay - aw * 0.10, aw * 0.20, aw * 0.11, P.segno, 0.60, -0.5);
      this._macchia(ctx, ax + aw * 0.24, ay + aw * 0.12, aw * 0.20, aw * 0.11, P.segno, 0.60, 0.5);
      this._macchia(ctx, ax + aw * 0.02, ay + aw * 0.02, aw * 0.16, aw * 0.24, P.segno, 0.35);
      for (let i = 0; i < 16; i++) {   // peluria sul bordo
        const a = (i / 16) * Math.PI * 2;
        this._macchia(ctx, ax + Math.cos(a) * aw * 0.94, ay + Math.sin(a) * aw * 0.68, aw * 0.075, aw * 0.045, P.pelo, 0.55, a);
      }
      this._macchia(ctx, -r * 0.05, r * 0.02, r * 0.16, r * 0.13, P.buio, 0.9);   // peduncolo
      // CEFALOTORACE: piu' piccolo, davanti e piu' basso
      const cx = r * 0.48, cy = r * 0.12, cw = r * 0.48;
      this._macchia(ctx, cx, cy + r * 0.03, cw * 1.16, cw * 0.84, P.buio, 0.95);
      this._macchia(ctx, cx, cy, cw * 1.00, cw * 0.68, P.chit, 0.95);
      this._macchia(ctx, cx - cw * 0.14, cy - cw * 0.24, cw * 0.56, cw * 0.30, P.chiaro, 0.40);
      // OTTO OCCHI: due grandi davanti e sei piccoli sopra
      const oc = (ox, oy, s2) => {
        this._macchia(ctx, cx + ox, cy + oy, cw * 0.24 * s2, cw * 0.20 * s2, P.alone, 0.13 + sw * 0.14);
        this._macchia(ctx, cx + ox, cy + oy, cw * 0.105 * s2, cw * 0.090 * s2, P.occhio, 0.95);
        this._macchia(ctx, cx + ox, cy + oy, cw * 0.048 * s2, cw * 0.040 * s2, '#fff4ee', 1);
      };
      oc(cw * 0.50, -cw * 0.04, 1.20); oc(cw * 0.46, cw * 0.26, 1.00);
      oc(cw * 0.16, -cw * 0.32, 0.60); oc(cw * 0.48, -cw * 0.34, 0.56);
      oc(cw * 0.70, -cw * 0.16, 0.50); oc(cw * 0.72, cw * 0.10, 0.48);
      oc(cw * 0.18, cw * 0.30, 0.52); oc(cw * 0.74, -cw * 0.02, 0.40);
      // CHELICERI: due zanne che si aprono quando morde
      for (const k of [-1, 1]) {
        const apre = 0.22 + sw * 0.40;
        for (let i = 1; i <= 6; i++) {
          const p = i / 6, a = 0.55 + k * apre;
          const x = cx + cw * 0.66 + Math.cos(a) * cw * 0.62 * p;
          const y = cy + cw * 0.36 + Math.sin(a) * cw * 0.62 * p + k * cw * 0.16;
          const w = cw * 0.14 * (1 - p * 0.76);
          this._macchia(ctx, x, y, w, w, i > 4 ? P.orlo : P.chit, 0.92);
        }
      }
      for (let i = 3; i >= 0; i--) { zampa(i, 1, true); zampa(i, -1, true); }     // le zampe di qua
      ctx.restore();
    },
    // v1.90.2 — IL BEHOLDER ERA IL SECONDO COLLO DI BOTTIGLIA: 936 chiamate di disegno ciascuno (sei
    // peduncoli da otto segmenti, il bordo sporco, le venature, i denti), cioe' piu' di tutti gli altri
    // mostri della scena messi insieme. Stessa cura dei ragni, con una differenza: l'OCCHIO segue il
    // bersaglio in continuazione e non si puo' cuocere. Quindi si cuoce il CORPO — massa, peduncoli,
    // bocca — e l'occhio, l'iride e l'alone si disegnano vivi sopra: sono una quindicina di chiamate.
    _behPose: null,
    _beholderCorpo(ctx, r, P, spettrale, gcolHex, ang2, apriQ, seme) {
      const cx = 0, cy = 0;          // il dondolio lo mette chi incolla l'immagine, non la posa
      // ---- peduncoli, dietro alla massa ----
      const NP = spettrale ? 8 : 6;
      for (let i = 0; i < NP; i++) {
        const a = -Math.PI + 0.35 + i * (Math.PI - 0.7) / (NP - 1) + Math.sin(ang2 + i) * 0.10;
        this._peduncolo(ctx, cx, cy - r * 0.30, a, r * (1.35 + 0.20 * Math.sin(ang2 * 1.45 + i * 2.1)), r * 0.145, P.ped, gcolHex, ang2 * 1.64, i);
      }
      // ---- la massa: strati di macchie, dal buio al chiaro ----
      if (spettrale) {
        for (let i = 0; i < 14; i++) { const a = ang2 * 0.27 + i * 0.45, rr = r * (0.7 + 0.3 * Math.sin(ang2 + i * 1.7));
          this._macchia(ctx, cx + Math.cos(a) * rr * 0.5, cy + Math.sin(a) * rr * 0.45, r * 0.32, r * 0.28, P.medio, 0.45); }
      }
      this._macchia(ctx, cx, cy, r * 1.08, r * 1.00, P.buio, spettrale ? 0.85 : 1);
      this._macchia(ctx, cx, cy + r * 0.10, r * 0.97, r * 0.90, P.medio, spettrale ? 0.8 : 1);
      this._macchia(ctx, cx - r * 0.10, cy - r * 0.08, r * 0.80, r * 0.72, P.chiaro, 0.40);
      this._macchia(ctx, cx - r * 0.24, cy - r * 0.28, r * 0.68, r * 0.56, P.chiaro, 0.75);
      this._macchia(ctx, cx - r * 0.34, cy - r * 0.40, r * 0.34, r * 0.26, P.luce, 0.30);
      if (!spettrale) {
        // bordo sporco: e' quello che toglie l'aria di plastica
        for (let i = 0; i < 14; i++) { const a = (i * 2.399 + seme) % 6.283; const rr = r * (0.93 + ((i * 37) % 11) / 90);
          this._macchia(ctx, cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.94, r * 0.10, r * 0.08, (i % 2) ? P.buio : P.medio, 0.45); }
        // venature
        ctx.save(); ctx.globalAlpha = 0.22; ctx.strokeStyle = P.vena; ctx.lineWidth = Math.max(1, r * 0.05); ctx.lineCap = 'round';
        for (let i = 0; i < 8; i++) { const a = i * 0.78 + 0.4; ctx.beginPath();
          ctx.moveTo(cx + Math.cos(a) * r * 0.34, cy + Math.sin(a) * r * 0.32);
          ctx.quadraticCurveTo(cx + Math.cos(a + 0.5) * r * 0.66, cy + Math.sin(a + 0.5) * r * 0.62, cx + Math.cos(a + 0.15) * r * 0.92, cy + Math.sin(a + 0.15) * r * 0.86);
          ctx.stroke(); }
        ctx.restore();
        // bocca dentata: si spalanca quando morde
        const apri = 1 + apriQ * 1.6;
        this._macchia(ctx, cx, cy + r * 0.66, r * 0.40, r * 0.15 * apri, '#170611', 0.92);
        ctx.save(); ctx.fillStyle = '#efe2cc';
        for (let i = 0; i < 8; i++) { const x = cx - r * 0.33 + i * r * 0.095; ctx.beginPath();
          ctx.moveTo(x, cy + r * 0.56); ctx.lineTo(x + r * 0.045, cy + r * 0.56); ctx.lineTo(x + r * 0.022, cy + r * (0.56 + 0.12 * apri)); ctx.closePath(); ctx.fill(); }
        ctx.restore();
      }
    },
    _beholderFrame(def, r, P, spettrale, gcolHex, fase, apriQ, seme) {
      const key = (def.dipinto || 'v') + '|' + Math.round(r) + '|' + gcolHex + '|' + fase + '|' + apriQ + '|' + seme;
      const cache = this._behPose || (this._behPose = new Map());
      let f = cache.get(key);
      if (f) return f;
      if (this._cotturaN === this.frameN) {          // una cottura per frame, come per i ragni
        for (let d = 1; d <= 5; d++) {
          f = cache.get((def.dipinto || 'v') + '|' + Math.round(r) + '|' + gcolHex + '|' + ((fase + d) % 10) + '|' + apriQ + '|' + seme)
           || cache.get((def.dipinto || 'v') + '|' + Math.round(r) + '|' + gcolHex + '|' + ((fase + 10 - d) % 10) + '|' + apriQ + '|' + seme);
          if (f) return f;
        }
      }
      this._cotturaN = this.frameN;
      const S = Math.ceil(r * 4.2);                  // i peduncoli arrivano lontano: il riquadro li contiene
      const dpr = this.dpr || 1;
      const cv = document.createElement('canvas');
      cv.width = Math.ceil(S * dpr); cv.height = Math.ceil(S * dpr);
      const g = cv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0); g.translate(S / 2, S / 2);
      this._beholderCorpo(g, r, P, spettrale, gcolHex, (fase / 10) * Math.PI * 2, apriQ / 2, seme);
      f = { cv, S };
      if (cache.size > 160) cache.clear();
      cache.set(key, f);
      return f;
    },
    _beholderPuppet(ctx, m, r, def, atk, moving, dir) {
      const t = this.time;
      const PAL = {
        viola:   { buio: '#2a0f24', medio: '#5d2453', chiaro: '#8f3d7c', luce: '#ff6fd0', iride: '#8a0f5e', vena: '#3d1436', ped: '#4d1f43', sclera: '#f7ead9' },
        carne:   { buio: '#2b1410', medio: '#6b2e26', chiaro: '#a2503f', luce: '#ffb08a', iride: '#7a1f12', vena: '#3c1a14', ped: '#4a221b', sclera: '#f3e2cf' },
        spettro: { buio: '#071016', medio: '#12303f', chiaro: '#2a5876', luce: '#ffb347', iride: '#ff6a2b', vena: '#0d222e', ped: '#16303f', sclera: '#0a1a22' },
      };
      const P = PAL[def.dipinto] || PAL.viola;
      const spettrale = def.dipinto === 'spettro';
      const GAZE = { weaken: '#ff7a5a', slow: '#5ad0ff', sunder: '#c48cff' };
      const gcolHex = GAZE[m.gk] || def.eye || P.luce;
      const swing = Math.sin((atk || 0) * Math.PI);
      const bob = Math.sin(t * 1.8 + m.e) * r * 0.06;
      // dove guarda: l'occhio segue la direzione della creatura
      const ang = (m.f != null ? m.f : 0);
      const cx = 0, cy = bob;

      const fase = Math.round(((t * 1.1 + m.e) % (Math.PI * 2)) / (Math.PI * 2) * 10) % 10;
      const apriQ = swing > 0.66 ? 2 : swing > 0.2 ? 1 : 0;
      const seme = (m.e || 0) % 3;
      const f = this._beholderFrame(def, r, P, spettrale, gcolHex, fase, apriQ, seme);
      ctx.save(); ctx.translate(0, bob);
      ctx.drawImage(f.cv, -f.S / 2, -f.S / 2, f.S, f.S);
      ctx.restore();
      // ---- l'occhio ----
      const ex = cx + Math.cos(ang) * r * 0.09, ey = cy - r * 0.04 + Math.sin(ang) * r * 0.07;
      this._macchia(ctx, ex, ey, r * 0.56, r * 0.50, '#1b0a16', spettrale ? 0.9 : 1);
      this._macchia(ctx, ex, ey, r * 0.50, r * 0.45, P.sclera, 1);
      if (!spettrale) {
        ctx.save(); ctx.globalAlpha = 0.22; ctx.fillStyle = P.vena;
        for (let i = 0; i < 12; i++) { const a = i * 0.52; ctx.beginPath(); ctx.moveTo(ex, ey);
          ctx.lineTo(ex + Math.cos(a) * r * 0.49, ey + Math.sin(a) * r * 0.44);
          ctx.lineTo(ex + Math.cos(a + 0.16) * r * 0.49, ey + Math.sin(a + 0.16) * r * 0.44); ctx.fill(); }
        ctx.restore();
      }
      const ix = ex + Math.cos(ang) * r * 0.15, iy = ey + Math.sin(ang) * r * 0.13;
      this._macchia(ctx, ix, iy, r * 0.27, r * 0.27, gcolHex, 1);
      this._macchia(ctx, ix, iy, r * 0.20, r * 0.20, P.iride, 1);
      ctx.fillStyle = '#080106'; ctx.beginPath(); ctx.arc(ix, iy, r * 0.105, 0, 7); ctx.fill();
      this._macchia(ctx, ix - r * 0.085, iy - r * 0.095, r * 0.075, r * 0.055, '#ffffff', 0.9);
      this._macchia(ctx, ex, ey - r * 0.32, r * 0.24, r * 0.075, '#ffffff', 0.18);
      // ---- alone: avvampa quando il raggio e' attivo o quando incassa ----
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const pr = 0.08 + 0.05 * Math.sin(t * 3 + m.e) + (m.gz ? 0.20 : 0) + swing * 0.16 + (m.fl > 0 ? 0.30 : 0);
      const R2 = r * 1.34, eg = ctx.createRadialGradient(0, bob, r * 0.6, 0, bob, R2);
      eg.addColorStop(0, this._rgba(gcolHex, 0)); eg.addColorStop(0.84, this._rgba(gcolHex, Math.min(0.6, pr))); eg.addColorStop(1, this._rgba(gcolHex, 0));
      ctx.fillStyle = eg; ctx.beginPath(); ctx.arc(0, bob, R2, 0, 7); ctx.fill(); ctx.restore();
    },
    _hexToRgb(hex) { const n = parseInt(hex.slice(1), 16); return { r: n >> 16, g: (n >> 8) & 255, b: n & 255 }; },
    _slimePuddle(ctx, m, r, def, atk, moving, dir) {
      const reg = PUPPETS.slime; reg.load(); const img = reg.imgs.body; const gc = def.eye || '#a6ff3a'; const t = this.time;
      const swing = Math.sin((atk || 0) * Math.PI);
      if (!reg.ready || !img) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(0, 0, r * 0.2, 0, 0, r * 1.2); gr.addColorStop(0, this._rgba(gc, 0.5)); gr.addColorStop(1, this._rgba(gc, 0)); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, r * 1.2, 0, 7); ctx.fill(); ctx.restore(); return; }
      const base = (r * 2.7) / Math.max(img.width, img.height);   // la pozza copre ~2.7·raggio
      const w1 = 0.06 * Math.sin(t * 1.8 + m.e * 1.3);             // wobble gelatinoso lento
      let sx = base * (1 + w1), sy = base * (1 - w1 * 0.85);
      sx *= (1 + swing * 0.16); sy *= (1 + swing * 0.16);          // "gonfia" nello sputo
      ctx.save();
      const rot = 0.06 * Math.sin(t * 0.9 + m.e) + (moving && dir != null ? dir * 0.12 : 0); // leggero ondeggio + accenno alla marcia
      ctx.rotate(rot);
      if (moving) { sx *= 1.12; sy *= 0.94; }                       // si allunga strisciando
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(img, -img.width * sx / 2, -img.height * sy / 2, img.width * sx, img.height * sy);
      ctx.restore();
      // edge-glow additivo pulsante (rinforza il bordo fluo, avvampa se colpito/attacca)
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const pr = 0.10 + 0.06 * Math.sin(t * 3 + m.e) + swing * 0.18 + (m.fl > 0 ? 0.35 : 0);
      const R2 = r * 1.28; const gr = ctx.createRadialGradient(0, 0, r * 0.5, 0, 0, R2);
      gr.addColorStop(0, this._rgba(gc, 0)); gr.addColorStop(0.82, this._rgba(gc, Math.min(0.6, pr))); gr.addColorStop(1, this._rgba(gc, 0));
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, R2, 0, 7); ctx.fill(); ctx.restore();
    },
    // v1.47 — RENDER SPRITE-SHEET: sceglie l'animazione (idle/walk/attack), il frame (dal tempo o dalla fase
    // d'attacco), ritaglia la cella dalla griglia e la disegna ancorata ai PIEDI. Mirror orizzontale per direzione.
    // Il contesto è già traslato su (m.x, m.y). Ritorna false se gli asset non sono pronti (fallback al chiamante).
    _drawSheet(key, ctx, m, r, def, atk, moving, flip, hit, pv) {
      const reg = SHEETS[key]; reg.load(); if (!reg.ready) return false;
      const man = reg.man, cell = man.cell, cols = man.cols, t = this.time;
      // v1.60 — stato per-entita'. Serve per tre cose che una funzione pura del tempo non puo' fare:
      // la DISTANZA percorsa (per agganciare il passo al terreno), la DISSOLVENZA fra due animazioni
      // e il VERSO smorzato. Senza, i piedi slittano e ogni cambio di stato e' uno scatto.
      const ST = this._shS = this._shS || {};
      const S = ST[m.e] = ST[m.e] || { x: m.x, y: m.y, d: 0, anim: null, prev: null, prevFi: 0, fi: 0, fade: 1, flip: flip, lt: t };
      const dt = Math.max(0.001, Math.min(0.05, t - S.lt)); S.lt = t;
      S.d += Math.hypot(m.x - S.x, m.y - S.y); S.x = m.x; S.y = m.y;

      const animName = (atk && atk > 0.001) ? 'attack' : (moving ? 'walk' : 'idle');
      if (S.anim !== animName) { S.prev = S.anim; S.prevFi = S.fi; S.anim = animName; S.fade = 0; }
      S.fade = Math.min(1, S.fade + dt / (man.blend || 0.14));

      const frameOf = (A) => {
        if (A.oneShot) {
          // v1.60 — mappatura a DUE TRATTI ancorata al fotogramma d'impatto. Prima era lineare:
          // con 25 fotogrammi la martellata si vedeva al 15 (0.60) ma il danno arriva a slamHit (0.72),
          // cioe' tre fotogrammi dopo. Si vedeva colpire e si subiva un attimo dopo.
          // In piu' i primi 7 fotogrammi sono una posa ferma: la curva (^0.72) li brucia in fretta e
          // indugia sul caricamento, che e' dove serve l'anticipo.
          const hf = (A.hitFrame != null) ? A.hitFrame : Math.round(A.frames * 0.6);
          const hp = def.slamHit || 0.72;
          const a = Math.max(0, Math.min(1, atk || 0));
          const f = (a <= hp) ? Math.pow(a / (hp || 1), 0.72) * hf
                              : hf + ((a - hp) / (1 - hp)) * (A.frames - 1 - hf);
          return Math.max(0, Math.min(A.frames - 1, Math.round(f)));
        }
        if (A.cyclePx) {
          // v1.60 — PASSO AGGANCIATO AL TERRENO: la fase viene dalla distanza percorsa, non dall'orologio.
          // Cosi' i piedi non slittano mai, e se la velocita' cambia (elite, rallentamenti, scaling)
          // la cadenza si adegua da sola invece di restare a fps fisso.
          return Math.floor((S.d / A.cyclePx) * A.frames + (m.e || 0) * 0.7) % A.frames;
        }
        return Math.floor(t * A.fps + (m.e || 0) * 0.7) % A.frames;
      };

      // v1.60 — il verso non si ribalta di scatto: passa per lo zero, quindi il troll si "gira" schiacciandosi
      S.flip += (flip - S.flip) * Math.min(1, dt * 13);
      const fx = Math.abs(S.flip) < 0.05 ? (S.flip < 0 ? -0.05 : 0.05) : S.flip;

      // ombra propria ai piedi (l'anchor cade sull'origine): non ruota col verso
      ctx.save(); ctx.filter = 'blur(' + Math.max(1, r * 0.10).toFixed(1) + 'px)'; ctx.fillStyle = 'rgba(0,0,0,0.42)';
      ctx.beginPath(); ctx.ellipse(0, -r * 0.04, r * 0.72, r * 0.24, 0, 0, 7); ctx.fill(); ctx.restore();

      const s = (2.9 * r) / man.charH, dw = cell * s, dh = cell * s;
      const drawOne = (nm, fi, alpha) => {
        const A = man.anims[nm]; const img = reg.imgs[nm]; if (!A || !img) return;
        const c0 = fi % cols, r0 = (fi / cols) | 0;
        ctx.save(); ctx.globalAlpha = ctx.globalAlpha * alpha; ctx.scale(fx, 1);
        if (hit) ctx.filter = 'brightness(1.7) saturate(1.2)';
        ctx.imageSmoothingEnabled = true;
        ctx.drawImage(img, c0 * cell, r0 * cell, cell, cell, -A.ax * s, -A.ay * s, dw, dh);
        ctx.restore();
      };

      const A = man.anims[animName] || man.anims.idle;
      if (!reg.imgs[animName] && !reg.imgs.idle) return false;
      const fi = frameOf(A); S.fi = fi;
      // dissolvenza: l'animazione uscente sfuma mentre entra la nuova (prima era un taglio netto)
      if (S.prev && S.prev !== animName && S.fade < 1) drawOne(S.prev, S.prevFi, 1 - S.fade);
      drawOne(animName, fi, S.fade);
      return true;
    },

    _zombieF(ctx, r, col, dk, eye, t, atk, back) {
      const D = '#0a0c12'; const phase = t * 7; const walk = Math.sin(phase); const bob = Math.sin(phase * 2) * r * 0.05;
      const swing = Math.sin((atk || 0) * Math.PI); const lp = (a, b) => a + (b - a) * swing;
      ctx.save(); ctx.filter = 'blur(1.5px)'; ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(0, r * 1.12, r * 0.5, r * 0.16, 0, 0, 7); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(0, bob); ctx.lineJoin = 'round';
      const foot = (sgn, sw) => { ctx.strokeStyle = dk; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(3, r * 0.26); ctx.beginPath(); ctx.moveTo(sgn * r * 0.22, r * 0.42); ctx.lineTo(sgn * r * 0.26, r * 0.98 + sw * r * 0.12); ctx.stroke(); ctx.fillStyle = dk; ctx.strokeStyle = D; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(sgn * r * 0.28, r * 1.02 + sw * r * 0.12, r * 0.15, r * 0.09, 0, 0, 7); ctx.fill(); ctx.stroke(); };
      foot(-1, walk); foot(1, -walk);
      const bg = ctx.createLinearGradient(-r, 0, r, 0); bg.addColorStop(0, dk); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(0, r * 0.1, r * 0.62, r * 0.7, 0, 0, 7); ctx.fill(); ctx.stroke();
      if (!back) { ctx.fillStyle = 'rgba(74,20,24,.5)'; ctx.beginPath(); ctx.ellipse(r * 0.14, r * 0.26, r * 0.15, r * 0.19, 0.3, 0, 7); ctx.fill(); ctx.strokeStyle = this._rgba(dk, 0.8); ctx.lineWidth = 1.4; for (let i = 0; i < 3; i++) { const yy = -r * 0.12 + i * r * 0.18; ctx.beginPath(); ctx.moveTo(-r * 0.14, yy); ctx.lineTo(r * 0.14, yy + 2); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(0, -r * 0.28); ctx.lineTo(0, r * 0.4); ctx.stroke(); }
      for (const sgn of [-1, 1]) { const sway = Math.sin(phase + (sgn < 0 ? 0 : Math.PI)) * r * 0.06; const shx = sgn * r * 0.48, shy = -r * 0.26; const elx = sgn * lp(r * 0.58, r * 0.46), ely = lp(r * 0.34, -r * 0.12) + sway; const hnx = sgn * lp(r * 0.6, r * 0.3), hny = lp(r * 0.84, -r * 0.4) + sway; ctx.strokeStyle = dk; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.2; ctx.beginPath(); ctx.moveTo(shx, shy); ctx.lineTo(elx, ely); ctx.stroke(); ctx.strokeStyle = col; ctx.lineWidth = r * 0.17; ctx.beginPath(); ctx.moveTo(elx, ely); ctx.lineTo(hnx, hny); ctx.stroke(); ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(hnx, hny, r * 0.16, 0, 7); ctx.fill(); ctx.stroke(); ctx.strokeStyle = dk; ctx.lineWidth = r * 0.05; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(hnx, hny); ctx.lineTo(hnx + sgn * r * 0.02, hny + lp(r * 0.18, -r * 0.04) + k * r * 0.07); ctx.stroke(); } }
      ctx.save(); ctx.translate(0, -r * 0.52); ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, r * 0.42, 0, 7); ctx.fill(); ctx.stroke();
      if (!back) { ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(-r * 0.15, -r * 0.02, r * 0.11, r * 0.14, 0, 0, 7); ctx.ellipse(r * 0.15, -r * 0.02, r * 0.11, r * 0.14, 0, 0, 7); ctx.fill(); ctx.fillStyle = eye; ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 4); ctx.beginPath(); ctx.arc(-r * 0.15, -r * 0.02, r * 0.045, 0, 7); ctx.arc(r * 0.15, -r * 0.02, r * 0.045, 0, 7); ctx.fill(); ctx.globalAlpha = 1; const jaw = r * (0.05 + swing * 0.14); ctx.fillStyle = '#2a0d0d'; ctx.beginPath(); ctx.ellipse(0, r * 0.24, r * 0.12, jaw + r * 0.03, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#cfc7b0'; for (let k = -1; k <= 1; k++) ctx.fillRect(k * r * 0.08 - r * 0.02, r * 0.16, r * 0.035, r * 0.06); }
      else { ctx.strokeStyle = this._rgba(dk, 0.7); ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-r * 0.16, -r * 0.12); ctx.lineTo(r * 0.04, r * 0.1); ctx.moveTo(r * 0.16, -r * 0.12); ctx.lineTo(-r * 0.02, r * 0.12); ctx.stroke(); }
      ctx.restore(); ctx.restore();
    },
    _necroF(ctx, r, col, dk, eye, t, atk, back) {
      const D = '#0a0713'; const phase = t * 5; const bob = Math.sin(phase) * r * 0.04; const sway = Math.sin(phase) * 0.05; const swing = Math.sin((atk || 0) * Math.PI); const pulse = 0.6 + 0.4 * Math.sin(t * 5);
      ctx.save(); ctx.filter = 'blur(1.5px)'; ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(0, r * 1.05, r * 0.42, r * 0.14, 0, 0, 7); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(0, bob); ctx.lineJoin = 'round';
      const hemY = r * 1.02, hemW = r * 0.82, topW = r * 0.32, topY = -r * 0.26;
      const rg = ctx.createLinearGradient(0, topY, 0, hemY); rg.addColorStop(0, col); rg.addColorStop(1, dk); ctx.fillStyle = rg; ctx.strokeStyle = D; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-topW, topY); ctx.quadraticCurveTo(-hemW * 0.9, r * 0.4, -hemW * (1 + sway), hemY); const waves = 5; for (let i = 0; i <= waves; i++) { const xx = -hemW * (1 + sway) + 2 * hemW * (i / waves); const yy = hemY + Math.sin(i * 1.7 + phase) * r * 0.06; ctx.lineTo(xx, yy); } ctx.quadraticCurveTo(hemW * 0.9, r * 0.4, topW, topY); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(6,4,12,.5)'; ctx.lineWidth = 1.4; for (const fx of [-0.4, 0, 0.4]) { ctx.beginPath(); ctx.moveTo(fx * topW * 1.4, topY + r * 0.1); ctx.quadraticCurveTo(fx * hemW * 1.1, r * 0.5, fx * hemW * 1.05, hemY - r * 0.05); ctx.stroke(); }
      ctx.save(); ctx.globalAlpha = 0.5 * pulse + 0.25; ctx.fillStyle = eye; for (let i = 0; i < 7; i++) { const xx = -hemW * 0.8 + i * (hemW * 1.6 / 6); ctx.beginPath(); ctx.arc(xx, hemY - r * 0.16, r * 0.03, 0, 7); ctx.fill(); } ctx.restore();
      const castUp = swing; { const shx = -r * 0.32, shy = -r * 0.02; const hx = -r * 0.6, hy = (0.5 - castUp * 1.1) * r * 0.6 + r * 0.1; ctx.strokeStyle = dk; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.24; ctx.beginPath(); ctx.moveTo(shx, shy); ctx.quadraticCurveTo(-r * 0.58, r * 0.15, hx, hy); ctx.stroke(); ctx.strokeStyle = '#cfc8b4'; ctx.lineWidth = r * 0.05; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx - r * 0.1, hy - r * 0.12 + k * r * 0.09); ctx.stroke(); } if (!back) { ctx.save(); ctx.globalAlpha = 0.4 + 0.6 * castUp; ctx.fillStyle = eye; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(hx - r * 0.16 - k * r * 0.08, hy - r * 0.16 - k * r * 0.05, r * (0.05 + castUp * 0.05) * (1 - k * 0.2), 0, 7); ctx.fill(); } ctx.restore(); } }
      { const shx = r * 0.32, shy = -r * 0.02; const hx = r * 0.48, hy = r * 0.2 - swing * r * 0.25; ctx.strokeStyle = dk; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.24; ctx.beginPath(); ctx.moveTo(shx, shy); ctx.quadraticCurveTo(r * 0.58, r * 0.1, hx, hy); ctx.stroke(); const topx = hx + r * 0.04, topy = -r * 0.92 - swing * r * 0.2, botx = hx - r * 0.02, boty = r * 0.82; ctx.strokeStyle = '#2a2118'; ctx.lineWidth = r * 0.09; ctx.beginPath(); ctx.moveTo(botx, boty); ctx.lineTo(topx, topy); ctx.stroke(); const orbR = r * (0.2 + swing * 0.12); const og = ctx.createRadialGradient(topx, topy, 0, topx, topy, orbR * 2.4); og.addColorStop(0, 'rgba(235,220,255,.9)'); og.addColorStop(0.4, this._rgba(eye, 0.55 * pulse + 0.2)); og.addColorStop(1, this._rgba(eye, 0)); ctx.fillStyle = og; ctx.beginPath(); ctx.arc(topx, topy, orbR * 2.4, 0, 7); ctx.fill(); ctx.fillStyle = eye; ctx.strokeStyle = this._shade(eye, 40); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(topx, topy, orbR, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.beginPath(); ctx.arc(topx - orbR * 0.3, topy - orbR * 0.3, orbR * 0.35, 0, 7); ctx.fill(); }
      const cg = ctx.createLinearGradient(0, -r * 0.4, 0, 0); cg.addColorStop(0, dk); cg.addColorStop(1, col); ctx.fillStyle = cg; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-r * 0.48, -r * 0.02); ctx.quadraticCurveTo(-r * 0.52, -r * 0.4, -r * 0.16, -r * 0.48); ctx.quadraticCurveTo(0, -r * 0.4, r * 0.16, -r * 0.48); ctx.quadraticCurveTo(r * 0.52, -r * 0.4, r * 0.48, -r * 0.02); ctx.quadraticCurveTo(0, r * 0.12, -r * 0.48, -r * 0.02); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.save(); ctx.translate(0, -r * 0.6); ctx.fillStyle = dk; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.32, r * 0.38, 0, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#050308'; ctx.beginPath(); ctx.ellipse(0, r * 0.03, r * 0.22, r * 0.28, 0, 0, 7); ctx.fill(); if (!back) { ctx.save(); ctx.globalAlpha = 0.6 + 0.4 * Math.sin(t * 4); ctx.fillStyle = eye; ctx.shadowColor = eye; ctx.shadowBlur = 6; ctx.beginPath(); ctx.ellipse(-r * 0.1, 0, r * 0.05, r * 0.07, 0, 0, 7); ctx.ellipse(r * 0.1, 0, r * 0.05, r * 0.07, 0, 0, 7); ctx.fill(); ctx.shadowBlur = 0; ctx.restore(); } ctx.restore();
      ctx.save(); ctx.translate(0, -r * 0.84); ctx.fillStyle = dk; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.6, r * 0.2, 0, 0, 7); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(-r * 0.3, -r * 0.02); ctx.quadraticCurveTo(-r * 0.18, -r * 0.7, r * 0.16, -r * 0.92); ctx.quadraticCurveTo(r * 0.02, -r * 0.5, r * 0.3, -r * 0.02); ctx.closePath(); const hg = ctx.createLinearGradient(-r * 0.3, 0, r * 0.3, 0); hg.addColorStop(0, '#0d0d10'); hg.addColorStop(1, col); ctx.fillStyle = hg; ctx.fill(); ctx.stroke(); ctx.save(); ctx.globalAlpha = 0.7 * pulse + 0.3; ctx.fillStyle = eye; ctx.beginPath(); ctx.arc(0, -r * 0.02, r * 0.05, 0, 7); ctx.fill(); ctx.restore(); ctx.restore();
      ctx.restore();
    },
    _trollF(ctx, r, col, dk, eye, t, atk, back) {
      const D = '#0b1108', CLAW = '#cfc8b4'; const phase = t * 6; const walk = Math.sin(phase); const bob = Math.abs(Math.sin(phase)) * r * 0.05 - r * 0.02; const breathe = Math.sin(t * 3) * r * 0.02; const swing = Math.sin((atk || 0) * Math.PI); const lp = (a, b) => a + (b - a) * swing; const LT = this._shade(col, 18);
      ctx.save(); ctx.filter = 'blur(1.8px)'; ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(0, r * 1.2, r * 0.72, r * 0.18, 0, 0, 7); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(0, bob); ctx.lineJoin = 'round';
      const stub = (sgn, sw) => { ctx.strokeStyle = dk; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.4; ctx.beginPath(); ctx.moveTo(sgn * r * 0.32, r * 0.55); ctx.lineTo(sgn * r * 0.4, r * 1.0 + sw * r * 0.06); ctx.stroke(); ctx.fillStyle = dk; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(sgn * r * 0.44, r * 1.05 + sw * r * 0.06, r * 0.26, r * 0.14, 0, 0, 7); ctx.fill(); ctx.stroke(); ctx.strokeStyle = CLAW; ctx.lineWidth = r * 0.05; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(sgn * r * 0.56 + k * r * 0.1, r * 1.08 + sw * r * 0.06); ctx.lineTo(sgn * r * 0.6 + k * r * 0.1, r * 1.14 + sw * r * 0.06); ctx.stroke(); } };
      stub(-1, walk); stub(1, -walk);
      const drawArm = (sgn, isBack, lift) => { const shx = sgn * r * 0.58, shy = -r * 0.3; const elx = sgn * lp(r * 0.98, r * 0.58), ely = lp(r * 0.3, -r * 0.34) - lift * r * 0.55; const hnx = sgn * lp(r * 0.9, r * 0.32), hny = lp(r * 1.12, -r * 0.6) - lift * r * 0.18; ctx.strokeStyle = isBack ? dk : this._shade(col, -6); ctx.lineCap = 'round'; ctx.lineWidth = r * 0.3; ctx.beginPath(); ctx.moveTo(shx, shy); ctx.quadraticCurveTo(sgn * r * 1.02, lp(-r * 0.02, -r * 0.3), elx, ely); ctx.stroke(); ctx.strokeStyle = isBack ? dk : col; ctx.lineWidth = r * 0.28; ctx.beginPath(); ctx.moveTo(elx, ely); ctx.lineTo(hnx, hny); ctx.stroke(); }; // v1.32 — braccia SENZA mani (rimosso pugno + nocche + artigli)
      const armLift = (atk || 0) > 0 ? swing : Math.max(0, -Math.sin(phase)) * 0.35;
      drawArm(-1, true, 0);
      const bg = ctx.createLinearGradient(0, -r * 0.6, 0, r * 0.7); bg.addColorStop(0, LT); bg.addColorStop(0.55, col); bg.addColorStop(1, dk); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(-r * 0.6, -r * 0.32); ctx.quadraticCurveTo(-r * 0.9, -r * 0.1, -r * 0.7, r * 0.55); ctx.quadraticCurveTo(-r * 0.4, r * 0.84, 0, r * 0.8 + breathe); ctx.quadraticCurveTo(r * 0.4, r * 0.84, r * 0.7, r * 0.55); ctx.quadraticCurveTo(r * 0.9, -r * 0.1, r * 0.6, -r * 0.32); ctx.quadraticCurveTo(0, -r * 0.46, -r * 0.6, -r * 0.32); ctx.closePath(); ctx.fill(); ctx.stroke();
      if (!back) { ctx.fillStyle = this._rgba(LT, 0.5); ctx.beginPath(); ctx.ellipse(0, r * 0.42 + breathe, r * 0.32, r * 0.34, 0, 0, 7); ctx.fill(); ctx.fillStyle = this._rgba(dk, 0.85); for (const w of [[-0.3, -0.1], [0.24, 0.05], [-0.1, 0.3], [0.32, -0.15]]) { ctx.beginPath(); ctx.arc(w[0] * r, w[1] * r, r * 0.05, 0, 7); ctx.fill(); } }
      drawArm(1, false, armLift);
      ctx.save(); ctx.translate(0, -r * 0.42); ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.4, r * 0.34, 0, 0, 7); ctx.fill(); ctx.stroke();
      if (!back) { const EYE = '#ff2e2e'; ctx.fillStyle = EYE; ctx.shadowColor = EYE; ctx.shadowBlur = 7; ctx.beginPath(); ctx.arc(-r * 0.15, -r * 0.02, r * 0.06, 0, 7); ctx.arc(r * 0.15, -r * 0.02, r * 0.06, 0, 7); ctx.fill(); ctx.shadowBlur = 0; const mo = r * (0.04 + swing * 0.12); ctx.fillStyle = '#2a0f10'; ctx.beginPath(); ctx.ellipse(0, r * 0.16, r * 0.2, mo + r * 0.04, 0, 0, 7); ctx.fill(); } // v1.32 — occhi ROSSI, niente ellisse-fascia sugli occhi, niente zanne (non è un vampiro)
      ctx.restore(); ctx.restore();
    },
    // v1.32 — OCCHIO VAGANTE: bulbo oculare con eye-stalks superiori e tentacoli, aura emissiva, iride che segue e pupilla che dilata in attacco
    _eyeF(ctx, r, col, dk, eye, t, atk, back) {
      r = r * 0.8; // v1.34 — sprite ridotto del 20%
      const D = '#0a0810'; const bob = Math.sin(t * 2.2) * r * 0.08; const swing = Math.sin((atk || 0) * Math.PI); const look = Math.sin(t * 1.3) * r * 0.06;
      ctx.save(); ctx.filter = 'blur(2px)'; ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(0, r * 1.35, r * 0.5, r * 0.14, 0, 0, 7); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(0, bob);
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; const ag = ctx.createRadialGradient(0, 0, r * 0.3, 0, 0, r * 1.6); ag.addColorStop(0, this._rgba(eye, 0.35 + swing * 0.3)); ag.addColorStop(1, this._rgba(eye, 0)); ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(0, 0, r * 1.6, 0, 7); ctx.fill(); ctx.restore();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      // v1.34 — tentacoli disposti TUTT'INTORNO al bulbo (raggiera), che ondeggiano dietro l'occhio
      const NT = 11;
      for (let i = 0; i < NT; i++) {
        const a = (i / NT) * Math.PI * 2 + t * 0.12;
        const ca = Math.cos(a), sa = Math.sin(a);
        const baseR = r * 0.8, len = r * (0.62 + 0.16 * Math.sin(t * 2.3 + i * 1.7));
        const sway = Math.sin(t * 2.6 + i * 1.3) * r * 0.2;
        const px = -sa, py = ca; // perpendicolare radiale
        const bx = ca * baseR, by = sa * baseR;
        const mx = ca * (baseR + len * 0.55) + px * sway, my = sa * (baseR + len * 0.55) + py * sway;
        const tx = ca * (baseR + len) + px * sway * 0.5, ty = sa * (baseR + len) + py * sway * 0.5;
        ctx.strokeStyle = dk; ctx.lineWidth = r * (0.15 - (i % 2) * 0.03);
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.quadraticCurveTo(mx, my, tx, ty); ctx.stroke();
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(tx, ty, r * 0.06, 0, 7); ctx.fill();
        ctx.fillStyle = eye; ctx.beginPath(); ctx.arc(tx, ty, r * 0.028, 0, 7); ctx.fill();
      }
      const sg = ctx.createRadialGradient(-r * 0.2, -r * 0.25, r * 0.1, 0, 0, r * 1.05); sg.addColorStop(0, '#f0ead6'); sg.addColorStop(0.6, '#d9cdb0'); sg.addColorStop(1, '#9b8c70'); ctx.fillStyle = sg; ctx.strokeStyle = D; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0, 0, r * 0.9, 0, 7); ctx.fill(); ctx.stroke();
      if (!back) {
        ctx.strokeStyle = 'rgba(150,20,24,0.5)'; ctx.lineWidth = r * 0.03;
        for (let i = 0; i < 7; i++) { const a = i / 7 * Math.PI * 2 + 0.3; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r * 0.86, Math.sin(a) * r * 0.86); ctx.quadraticCurveTo(Math.cos(a) * r * 0.5, Math.sin(a) * r * 0.5, Math.cos(a + 0.4) * r * 0.34, Math.sin(a + 0.4) * r * 0.34); ctx.stroke(); }
        const irx = look, iry = look * 0.6; const irisR = r * 0.42 * (1 - swing * 0.18);
        const ig = ctx.createRadialGradient(irx, iry, r * 0.05, irx, iry, irisR); ig.addColorStop(0, this._shade(eye, 50)); ig.addColorStop(0.5, eye); ig.addColorStop(1, this._shade(eye, -60)); ctx.fillStyle = ig; ctx.beginPath(); ctx.arc(irx, iry, irisR, 0, 7); ctx.fill();
        ctx.strokeStyle = this._shade(eye, -40); ctx.lineWidth = r * 0.02; for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2; ctx.beginPath(); ctx.moveTo(irx + Math.cos(a) * irisR * 0.4, iry + Math.sin(a) * irisR * 0.4); ctx.lineTo(irx + Math.cos(a) * irisR * 0.92, iry + Math.sin(a) * irisR * 0.92); ctx.stroke(); }
        ctx.fillStyle = '#080308'; ctx.beginPath(); ctx.arc(irx, iry, irisR * (0.42 + swing * 0.3), 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.arc(irx - irisR * 0.35, iry - irisR * 0.4, r * 0.08, 0, 7); ctx.fill(); ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.arc(irx + irisR * 0.2, iry + irisR * 0.3, r * 0.04, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
      } else { ctx.fillStyle = 'rgba(120,20,24,0.35)'; ctx.beginPath(); ctx.arc(0, 0, r * 0.5, 0, 7); ctx.fill(); }
      ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 2;
      const lid = (top) => { const s = top ? 1 : -1; ctx.beginPath(); ctx.moveTo(-r * 0.92, 0); ctx.quadraticCurveTo(0, -s * r * 1.15, r * 0.92, 0); ctx.quadraticCurveTo(0, -s * r * 0.5, -r * 0.92, 0); ctx.closePath(); ctx.fill(); ctx.stroke(); };
      const openA = r * (0.0 - swing * 0.12);
      ctx.save(); ctx.translate(0, -r * 0.5 + openA); lid(true); ctx.restore();
      ctx.save(); ctx.translate(0, r * 0.5 - openA); lid(false); ctx.restore();
      ctx.restore();
    },
    // v1.32 — SPETTRO: cappa spettrale translucida che sfuma in code ondulate, scie/wisp emissive, artigli protesi e occhi ardenti
    _spettroF(ctx, r, col, dk, eye, t, atk, back) {
      const phase = t * 3; const bob = Math.sin(phase) * r * 0.08; const swing = Math.sin((atk || 0) * Math.PI); const drift = Math.sin(t * 1.6) * r * 0.06;
      ctx.save(); ctx.translate(drift, bob);
      const baseA = 0.62 + 0.12 * Math.sin(t * 2.2);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const glow = ctx.createRadialGradient(0, -r * 0.1, r * 0.2, 0, -r * 0.1, r * 1.5); glow.addColorStop(0, this._rgba(eye, 0.18)); glow.addColorStop(1, this._rgba(eye, 0)); ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 1.5, 0, 7); ctx.fill();
      ctx.restore();
      ctx.globalAlpha = baseA * 0.5;
      ctx.fillStyle = this._rgba(col, 0.5);
      for (let i = 0; i < 4; i++) { const a = t * 1.2 + i * 1.7; const wx = Math.cos(a) * r * 0.5, wy = -r * 0.2 + Math.sin(a) * r * 0.3; ctx.beginPath(); ctx.ellipse(wx, wy, r * 0.16, r * 0.1, a, 0, 7); ctx.fill(); }
      ctx.globalAlpha = baseA;
      const bg = ctx.createLinearGradient(0, -r * 0.9, 0, r * 1.3); bg.addColorStop(0, this._shade(col, 30)); bg.addColorStop(0.45, col); bg.addColorStop(1, this._rgba(dk, 0)); ctx.fillStyle = bg; ctx.strokeStyle = this._rgba(this._shade(col, 40), 0.5); ctx.lineWidth = 2; ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(-r * 0.62, -r * 0.2);
      ctx.quadraticCurveTo(-r * 0.72, -r * 0.85, 0, -r * 0.9);
      ctx.quadraticCurveTo(r * 0.72, -r * 0.85, r * 0.62, -r * 0.2);
      ctx.quadraticCurveTo(r * 0.7, r * 0.4, r * 0.5, r * 0.7);
      const tails = 5; for (let i = 0; i <= tails; i++) { const xx = r * 0.5 - (r * 1.0) * (i / tails); const yy = r * 1.15 + Math.sin(i * 1.6 + phase) * r * 0.18; ctx.lineTo(xx, yy); }
      ctx.quadraticCurveTo(-r * 0.7, r * 0.4, -r * 0.62, -r * 0.2);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = this._rgba(col, 0.7); ctx.lineCap = 'round'; ctx.lineWidth = r * 0.14;
      for (const sgn of [-1, 1]) { const reach = swing * r * 0.3; const sx = sgn * r * 0.45, sy = r * 0.05; const ex = sgn * (r * 0.75 + reach), ey = r * 0.2 - swing * r * 0.15; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.quadraticCurveTo(sgn * r * 0.8, -r * 0.1, ex, ey); ctx.stroke(); ctx.strokeStyle = this._rgba(this._shade(col, 50), 0.8); ctx.lineWidth = r * 0.04; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(ex + sgn * r * 0.12, ey + r * 0.14 + k * r * 0.06); ctx.stroke(); } ctx.strokeStyle = this._rgba(col, 0.7); ctx.lineWidth = r * 0.14; }
      const hg = ctx.createLinearGradient(0, -r * 0.9, 0, -r * 0.2); hg.addColorStop(0, this._shade(col, 40)); hg.addColorStop(1, col); ctx.fillStyle = hg; ctx.strokeStyle = this._rgba(this._shade(col, 50), 0.5); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-r * 0.34, -r * 0.28); ctx.quadraticCurveTo(-r * 0.4, -r * 0.82, 0, -r * 0.86); ctx.quadraticCurveTo(r * 0.4, -r * 0.82, r * 0.34, -r * 0.28); ctx.quadraticCurveTo(0, -r * 0.12, -r * 0.34, -r * 0.28); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.globalAlpha = baseA * 0.9; ctx.fillStyle = 'rgba(6,10,16,0.7)'; ctx.beginPath(); ctx.ellipse(0, -r * 0.46, r * 0.24, r * 0.3, 0, 0, 7); ctx.fill();
      if (!back) { const eb = 0.7 + 0.3 * Math.max(swing, Math.sin(t * 4) * 0.5 + 0.5); ctx.globalAlpha = eb; ctx.fillStyle = eye; ctx.shadowColor = eye; ctx.shadowBlur = 10; ctx.beginPath(); ctx.ellipse(-r * 0.11, -r * 0.46, r * 0.05, r * 0.08, 0, 0, 7); ctx.ellipse(r * 0.11, -r * 0.46, r * 0.05, r * 0.08, 0, 0, 7); ctx.fill(); ctx.shadowBlur = 0; }
      ctx.restore();
      ctx.globalAlpha = 1;
    },
    // v1.89 — l'ultimo argomento (`st`) porta lo stato del mostro a chi lo sa usare: al Colosso serve
    // la frazione di vita, perche' la sua forma CAMBIA con le fasi (perde un braccio, si apre).
    _shape(ctx, shape, r, col, dark, eye, t, atk, st) {
      atk = atk || 0; st = st || {}; // v1.26 — 0..1 fase di attacco (0 = idle/camminata)
      const swing = Math.sin(atk * Math.PI); // 0→1→0 arco d'attacco
      ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; const D = '#0a0c12';
      const walk = Math.sin(t * 9 + (r * 1.3));
      const eyes = (ex, ey, er, c) => { ctx.fillStyle = c || eye; ctx.beginPath(); ctx.arc(ex, ey, er, 0, 7); ctx.arc(ex, -ey, er, 0, 7); ctx.fill(); ctx.fillStyle = '#0a0c12'; ctx.beginPath(); ctx.arc(ex + er * .3, ey, er * .45, 0, 7); ctx.arc(ex + er * .3, -ey, er * .45, 0, 7); ctx.fill(); };
      const leg = (bx, by, sw, c2) => { ctx.strokeStyle = c2 || dark; ctx.lineWidth = Math.max(2.5, r * .22); ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx - r * .1, by + r * .55 + sw * r * .18); ctx.stroke(); };
      const limb = (x1, y1, x2, y2, w, c) => { ctx.strokeStyle = c || col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };
      ctx.strokeStyle = D; ctx.lineWidth = 2;
      switch (shape) {
        case 'zombie': { // v1.26 — zombie: braccia laterali con mani, occhi neri vuoti, morso in attacco
          leg(-r * .15, r * .42, walk, dark); leg(-r * .15, -r * .42, -walk, dark);
          // corpo PRIMA, così le braccia (disegnate dopo) risultano ben staccate dai fianchi
          const bg = ctx.createLinearGradient(-r, 0, r, 0); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.ellipse(-r * .05, 0, r * .8, r * .66, 0, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = 'rgba(74,20,24,.6)'; ctx.beginPath(); ctx.ellipse(r * .05, r * .2, r * .16, r * .2, .3, 0, 7); ctx.fill();
          ctx.strokeStyle = 'rgba(20,26,16,.6)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(-r * .4, 0); ctx.lineTo(-r * .02, 0); ctx.stroke();
          // v1.27.1 — BRACCIA ai lati con spalla, gomito e MANO (lungo i fianchi a riposo, in avanti in attacco)
          const lp = (a, b) => a + (b - a) * swing; // riposo → attacco
          for (const sgn of [-1, 1]) {
            const sx = -r * .04, sy = sgn * r * .5;                 // spalla (staccata dal centro)
            const ex = lp(r * .02, r * .58), ey = sgn * lp(r * .82, r * .42); // gomito
            const hnx = lp(r * .18, r * 1.12), hny = sgn * lp(r * 1.0, r * .3); // mano
            ctx.strokeStyle = dark; ctx.lineCap = 'round'; ctx.lineWidth = r * .2; // spalla scura = stacco
            ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke();
            ctx.strokeStyle = col; ctx.lineWidth = r * .17;                        // avambraccio
            ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(hnx, hny); ctx.stroke();
            ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 1.5;         // MANO
            ctx.beginPath(); ctx.arc(hnx, hny, r * .17, 0, 7); ctx.fill(); ctx.stroke();
            ctx.strokeStyle = dark; ctx.lineWidth = r * .05; ctx.lineCap = 'round'; // artigli
            const cdir = swing > .1 ? 1 : 0; // a riposo puntano fuori, in attacco in avanti
            for (let k = -1; k <= 1; k++) { const ax = hnx + lp(r * .02, r * .2), ay = hny + sgn * lp(r * .2, r * .04) + k * r * .07; ctx.beginPath(); ctx.moveTo(hnx, hny); ctx.lineTo(ax, ay); ctx.stroke(); }
          }
          ctx.save(); ctx.translate(-r * .3, 0); // v1.26.1 — testa centrata sul corpo (top-down, viso visibile)
          ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(r * .42, 0, r * .44, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(r * .5, r * .16, r * .12, r * .15, 0, 0, 7); ctx.ellipse(r * .5, -r * .16, r * .12, r * .15, 0, 0, 7); ctx.fill();
          ctx.fillStyle = eye; ctx.globalAlpha = .5 + .3 * Math.sin(t * 4); ctx.beginPath(); ctx.arc(r * .52, r * .16, r * .04, 0, 7); ctx.arc(r * .52, -r * .16, r * .04, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          const jaw = r * (.05 + swing * .22); ctx.fillStyle = '#2a0d0d'; ctx.beginPath(); ctx.ellipse(r * .7, 0, r * .1, jaw + r * .03, 0, 0, 7); ctx.fill();
          ctx.restore();
          break; }
        case 'imp': {
          leg(-r * .2, r * .5, walk, dark); leg(-r * .2, -r * .5, -walk, dark);
          limb(-r * .1, -r * .2, r * .7, -r * .1 + walk * r * .12, r * .18, col);
          const bg = ctx.createLinearGradient(-r, 0, r, 0); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.ellipse(-r * .05, 0, r * .82, r * .72, 0, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = dark; ctx.beginPath(); ctx.moveTo(-r * .2, -r * .5); ctx.lineTo(-r * .9, -r * 1.15); ctx.lineTo(-r * .05, -r * .55); ctx.fill();
          ctx.beginPath(); ctx.moveTo(-r * .2, r * .5); ctx.lineTo(-r * .9, r * 1.15); ctx.lineTo(-r * .05, r * .55); ctx.fill();
          ctx.fillStyle = col; ctx.strokeStyle = D; ctx.beginPath(); ctx.arc(r * .35, 0, r * .5, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(r * .55, r * .18); ctx.lineTo(r * .62, r * .42); ctx.lineTo(r * .7, r * .18); ctx.fill();
          eyes(r * .45, r * .2, r * .13); break; }
        case 'brute': { // v1.26 — orco berserker: ascia, zanne, occhi rossi, fendente in attacco
          leg(-r * .3, r * .55, walk, dark); leg(-r * .3, -r * .55, -walk, dark);
          const axA = -0.5 + swing * 1.6; // ascia: da alzata a fendente
          ctx.save(); ctx.translate(r * .2, -r * .6); ctx.rotate(axA);
          ctx.strokeStyle = '#3a2a18'; ctx.lineWidth = r * .14; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(0, r * .1); ctx.lineTo(r * .9, -r * .7); ctx.stroke();
          const hx = r * .9, hy = -r * .7; const mg = ctx.createLinearGradient(hx - r * .4, hy, hx + r * .4, hy); mg.addColorStop(0, '#6b6f77'); mg.addColorStop(.5, '#c2c6ce'); mg.addColorStop(1, '#5a5e66');
          ctx.fillStyle = mg; ctx.strokeStyle = D; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(hx, hy - r * .32); ctx.quadraticCurveTo(hx + r * .5, hy - r * .1, hx + r * .4, hy + r * .24); ctx.lineTo(hx, hy + r * .12); ctx.quadraticCurveTo(hx - r * .5, hy - r * .1, hx - r * .4, hy + r * .24); ctx.lineTo(hx, hy + r * .12); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
          const bg = ctx.createLinearGradient(-r, -r, r, r); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2.5;
          this._rr(ctx, -r * .75, -r * .95, r * 1.5, r * 1.9, r * .45); ctx.fill(); ctx.stroke();
          ctx.strokeStyle = 'rgba(20,30,14,.55)'; ctx.lineWidth = r * .06; ctx.beginPath(); ctx.moveTo(-r * .5, 0); ctx.lineTo(r * .3, 0); ctx.stroke();
          ctx.fillStyle = dark; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(-r * .1, -r * .9, r * .42, 0, 7); ctx.arc(-r * .1, r * .9, r * .42, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#8a8f97'; for (const sy of [-1, 1]) { ctx.beginPath(); ctx.moveTo(-r * .3, sy * r * .9); ctx.lineTo(-r * .55, sy * r * 1.05); ctx.lineTo(-r * .05, sy * r * 1.02); ctx.closePath(); ctx.fill(); }
          const lean = swing * r * .18;
          limb(0, r * .8, r * .8 + lean, r * .5 - walk * r * .1, r * .3, col); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(r * .85 + lean, r * .5 - walk * r * .1, r * .26, 0, 7); ctx.fill(); ctx.stroke();
          ctx.save(); ctx.translate(-r * .3, 0); // v1.26.1 — testa centrata sul corpo (top-down, viso visibile)
          ctx.fillStyle = col; ctx.beginPath(); ctx.arc(r * .45 + lean, 0, r * .42, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = 'rgba(25,38,16,.5)'; ctx.beginPath(); ctx.ellipse(r * .4 + lean, 0, r * .42, r * .16, 0, 0, 7); ctx.fill();
          ctx.fillStyle = '#e8e2cf'; ctx.beginPath(); ctx.moveTo(r * .6 + lean, r * .15); ctx.lineTo(r * .74 + lean, r * .04); ctx.lineTo(r * .64 + lean, r * .24); ctx.fill(); ctx.beginPath(); ctx.moveTo(r * .6 + lean, -r * .15); ctx.lineTo(r * .74 + lean, -r * .04); ctx.lineTo(r * .64 + lean, -r * .24); ctx.fill();
          if (swing > .3) { ctx.fillStyle = '#2a1510'; ctx.beginPath(); ctx.ellipse(r * .66 + lean, 0, r * .1, r * .14, 0, 0, 7); ctx.fill(); }
          eyes(r * .5 + lean, r * .18, r * .12, eye); ctx.restore(); break; }
        case 'skeleton': {
          ctx.fillStyle = '#6a6f7a'; ctx.strokeStyle = D; this._rr(ctx, r * .55, -r * .55, r * .3, r * 1.1, 3); ctx.fill(); ctx.stroke();
          leg(-r * .2, r * .35, walk, '#c9c4b0'); leg(-r * .2, -r * .35, -walk, '#c9c4b0');
          ctx.fillStyle = dark; ctx.beginPath(); ctx.ellipse(-r * .05, 0, r * .5, r * .62, 0, 0, 7); ctx.fill();
          ctx.strokeStyle = '#eae6d8'; ctx.lineWidth = 2; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.arc(-r * .05, r * .3 * i, r * .34, -0.7, 0.7); ctx.stroke(); }
          ctx.fillStyle = col; ctx.strokeStyle = D; ctx.beginPath(); ctx.arc(r * .3, 0, r * .46, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#1a1c24'; ctx.beginPath(); ctx.arc(r * .38, r * .18, r * .12, 0, 7); ctx.arc(r * .38, -r * .18, r * .12, 0, 7); ctx.fill();
          ctx.fillStyle = '#39d5ff'; ctx.beginPath(); ctx.arc(r * .4, r * .18, r * .06, 0, 7); ctx.arc(r * .4, -r * .18, r * .06, 0, 7); ctx.fill();
          ctx.strokeStyle = D; ctx.lineWidth = 1; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(r * .5 + i * r * .06, r * .12); ctx.lineTo(r * .5 + i * r * .06, -r * .12); ctx.stroke(); } break; }
        case 'mage': { // v1.26 — negromante: cappuccio, occhi viola, bastone con orbe che divampa in cast
          const fl = Math.sin(t * 2.4) * r * .06;
          const bg = ctx.createLinearGradient(-r, 0, r, 0); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-r * 1.05, r * .5); ctx.quadraticCurveTo(-r * .2, r * .1, r * .2, r * .28 + fl); ctx.quadraticCurveTo(r * .55, 0, r * .2, -r * .28 - fl); ctx.quadraticCurveTo(-r * .2, -r * .1, -r * 1.05, -r * .5); ctx.quadraticCurveTo(-r * .7, 0, -r * 1.05, r * .5); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.fillStyle = 'rgba(120,90,200,.5)'; for (let i = -4; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(-r * 1.05, i * r * .11); ctx.lineTo(-r * 1.22, i * r * .11 + r * .05); ctx.lineTo(-r * 1.05, i * r * .11 + r * .1); ctx.fill(); }
          const orbF = 0.5 + swing * 0.9;
          ctx.strokeStyle = '#3a2b1a'; ctx.lineWidth = r * .1; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(r * .2, r * .5); ctx.lineTo(r * .95, -r * .5); ctx.stroke();
          const ox = r * .95, oy = -r * .5, orbR = r * .5 * (0.7 + swing * 0.8); const og = ctx.createRadialGradient(ox, oy, 0, ox, oy, orbR); og.addColorStop(0, 'rgba(200,160,255,' + orbF + ')'); og.addColorStop(.5, 'rgba(120,70,210,.7)'); og.addColorStop(1, 'rgba(70,30,130,0)');
          ctx.fillStyle = og; ctx.beginPath(); ctx.arc(ox, oy, orbR, 0, 7); ctx.fill();
          ctx.fillStyle = 'rgba(230,210,255,' + (0.85 * orbF) + ')'; ctx.beginPath(); ctx.arc(ox, oy, r * .13, 0, 7); ctx.fill();
          ctx.save(); ctx.translate(-r * .26, 0); // v1.26.1 — cappuccio centrato sul corpo (top-down, viso visibile)
          const hg = ctx.createLinearGradient(0, -r * .5, 0, r * .5); hg.addColorStop(0, col); hg.addColorStop(1, dark); ctx.fillStyle = hg; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-r * .1, -r * .5); ctx.quadraticCurveTo(r * .7, -r * .3, r * .72, 0); ctx.quadraticCurveTo(r * .7, r * .3, -r * .1, r * .5); ctx.quadraticCurveTo(-r * .2, 0, -r * .1, -r * .5); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#05040a'; ctx.beginPath(); ctx.ellipse(r * .36, 0, r * .28, r * .3, 0, 0, 7); ctx.fill();
          const eb = 0.6 + 0.4 * Math.max(swing, Math.sin(t * 6) * 0.5 + 0.5); ctx.fillStyle = eye; ctx.shadowColor = eye; ctx.shadowBlur = 8; ctx.globalAlpha = eb;
          ctx.beginPath(); ctx.ellipse(r * .42, r * .1, r * .06, r * .09, 0, 0, 7); ctx.ellipse(r * .42, -r * .1, r * .06, r * .09, 0, 0, 7); ctx.fill(); ctx.globalAlpha = 1; ctx.shadowBlur = 0;
          ctx.restore();
          break; }
        case 'lich': {
          const fl = Math.sin(t * 3) * r * .08;
          const bg = ctx.createLinearGradient(0, -r, 0, r * 1.4); bg.addColorStop(0, col); bg.addColorStop(1, dark); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-r * .9, r * 1.2 + fl); ctx.quadraticCurveTo(-r * .2, -r * .2, 0, -r * 1.35 + fl); ctx.quadraticCurveTo(r * .2, -r * .2, r * .9, r * 1.2 + fl);
          ctx.quadraticCurveTo(0, r * .9 + fl, -r * .9, r * 1.2 + fl); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#05060a'; ctx.beginPath(); ctx.arc(0, -r * .35 + fl, r * .42, 0, 7); ctx.fill();
          ctx.fillStyle = eye; ctx.shadowColor = eye; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(r * .14, -r * .4 + fl, r * .1, 0, 7); ctx.arc(-r * .14, -r * .4 + fl, r * .1, 0, 7); ctx.fill(); ctx.shadowBlur = 0;
          ctx.fillStyle = eye; ctx.globalAlpha = 0.45 + 0.3 * Math.sin(t * 6); ctx.beginPath(); ctx.arc(r * .8, r * .25 + fl, r * .26, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          ctx.strokeStyle = eye; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(r * .8, r * .25 + fl, r * .26, 0, 7); ctx.stroke(); break; }
        case 'mimic': {
          leg(-r * .5, r * .5, walk, dark); leg(-r * .5, -r * .5, -walk, dark); leg(r * .3, r * .5, -walk, dark); leg(r * .3, -r * .5, walk, dark);
          const bg = ctx.createLinearGradient(0, -r, 0, r); bg.addColorStop(0, col); bg.addColorStop(1, dark); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2.5;
          this._rr(ctx, -r * .95, -r * .2, r * 1.9, r * .95, 4); ctx.fill(); ctx.stroke();
          ctx.save(); ctx.translate(-r * .95, -r * .2); ctx.rotate(-0.5); ctx.fillStyle = dark; this._rr(ctx, 0, -r * .5, r * 1.9, r * .55, 4); ctx.fill(); ctx.stroke(); ctx.restore();
          ctx.fillStyle = '#c9a94a'; ctx.fillRect(-r * .95, r * .05, r * 1.9, r * .16);
          ctx.fillStyle = '#3a0d12'; this._rr(ctx, -r * .8, -r * .12, r * 1.6, r * .34, 2); ctx.fill();
          ctx.fillStyle = '#fff'; for (let i = -3; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(i * r * .24, -r * .12); ctx.lineTo(i * r * .24 + r * .1, r * .1); ctx.lineTo(i * r * .24 + r * .2, -r * .12); ctx.fill(); ctx.beginPath(); ctx.moveTo(i * r * .24, r * .22); ctx.lineTo(i * r * .24 + r * .1, r * .02); ctx.lineTo(i * r * .24 + r * .2, r * .22); ctx.fill(); }
          ctx.fillStyle = '#e0506a'; ctx.beginPath(); ctx.ellipse(0, r * .16, r * .28, r * .12, 0, 0, 7); ctx.fill();
          eyes(-r * .3, r * .5, r * .12, '#ff3b3b'); break; }
        case 'troll': {
          leg(-r * .2, r * .55, walk, dark); leg(-r * .2, -r * .55, -walk, dark);
          const bg = ctx.createLinearGradient(-r, -r, r, r); bg.addColorStop(0, col); bg.addColorStop(1, dark); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.ellipse(0, 0, r * .95, r * 1.02, 0, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = dark; ctx.beginPath(); ctx.arc(-r * .35, -r * .45, r * .4, 0, 7); ctx.fill();
          limb(r * .1, r * .3, r * 1.0, r * .8 - walk * r * .12, r * .38, col); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(r * 1.05, r * .8 - walk * r * .12, r * .32, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = col; ctx.beginPath(); ctx.arc(r * .5, -r * .25, r * .32, 0, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(r * .58, -r * .05); ctx.lineTo(r * .6, r * .2); ctx.lineTo(r * .7, -r * .05); ctx.fill();
          eyes(r * .55, r * .12, r * .12, eye); break; }
        case 'assassin': { // v1.28.1 — assassino ombra: mantello a freccia, doppie lame, occhi magenta, scia di fumo
          // scia di fumo/ombra dietro
          ctx.fillStyle = 'rgba(40,30,60,.5)';
          for (let i = 0; i < 5; i++) { const a = Math.PI + (i - 2) * 0.18; const dd = r * (0.9 + i * 0.12); ctx.globalAlpha = 0.26 - i * 0.04; ctx.beginPath(); ctx.ellipse(Math.cos(a) * dd, Math.sin(a) * dd, r * .3, r * .2, a, 0, 7); ctx.fill(); }
          ctx.globalAlpha = 1;
          leg(-r * .1, r * .38, walk, dark); leg(-r * .1, -r * .38, -walk, dark);
          // mantello appuntito (freccia verso il fronte)
          const bg = ctx.createLinearGradient(-r, 0, r, 0); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(r * .85, 0); ctx.quadraticCurveTo(r * .1, -r * .7, -r * .7, -r * .55); ctx.quadraticCurveTo(-r * 1.0, 0, -r * .7, r * .55); ctx.quadraticCurveTo(r * .1, r * .7, r * .85, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
          // DUE LAME (ai lati a riposo, incrociate avanti in attacco)
          for (const sgn of [-1, 1]) { const bx = r * .2, by = sgn * r * .42; const tx = bx + (r * .5 + swing * r * .6), ty = sgn * (r * .5 - swing * r * .42); ctx.strokeStyle = '#c9ccd6'; ctx.lineCap = 'round'; ctx.lineWidth = r * .09; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(tx, ty); ctx.stroke(); ctx.fillStyle = '#e8ebf2'; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx - r * .1, ty - sgn * r * .05); ctx.lineTo(tx + r * .12, ty + sgn * r * .02); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#2a2030'; ctx.beginPath(); ctx.arc(bx, by, r * .06, 0, 7); ctx.fill(); }
          // cappuccio a punta
          ctx.fillStyle = col; ctx.strokeStyle = D; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-r * .35, 0); ctx.quadraticCurveTo(-r * .1, -r * .34, r * .5, -r * .24); ctx.quadraticCurveTo(r * .66, 0, r * .5, r * .24); ctx.quadraticCurveTo(-r * .1, r * .34, -r * .35, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
          // viso in ombra + occhi magenta affilati
          ctx.fillStyle = '#050308'; ctx.beginPath(); ctx.ellipse(r * .24, 0, r * .2, r * .22, 0, 0, 7); ctx.fill();
          const eba = 0.6 + 0.4 * Math.max(swing, Math.sin(t * 7) * .5 + .5); ctx.fillStyle = eye; ctx.shadowColor = eye; ctx.shadowBlur = 8; ctx.globalAlpha = eba;
          ctx.beginPath(); ctx.moveTo(r * .3, r * .02); ctx.lineTo(r * .4, r * .12); ctx.lineTo(r * .42, r * .06); ctx.closePath(); ctx.moveTo(r * .3, -r * .02); ctx.lineTo(r * .4, -r * .12); ctx.lineTo(r * .42, -r * .06); ctx.closePath(); ctx.fill();
          ctx.globalAlpha = 1; ctx.shadowBlur = 0; break; }
        case 'wyvern': {
          const wf = walk;
          ctx.fillStyle = dark; ctx.strokeStyle = D; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-r * .1, -r * .2); ctx.lineTo(-r * 1.2, -r * (1.0 + wf * .4)); ctx.lineTo(-r * .2, -r * .5); ctx.lineTo(-r * .9, -r * .3); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(-r * .1, r * .2); ctx.lineTo(-r * 1.2, r * (1.0 + wf * .4)); ctx.lineTo(-r * .2, r * .5); ctx.lineTo(-r * .9, r * .3); ctx.closePath(); ctx.fill(); ctx.stroke();
          const bg = ctx.createLinearGradient(-r, 0, r, 0); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg;
          ctx.beginPath(); ctx.moveTo(r * 1.05, 0); ctx.quadraticCurveTo(r * .2, -r * .62, -r * .5, -r * .28); ctx.quadraticCurveTo(-r * .9, 0, -r * .5, r * .28); ctx.quadraticCurveTo(r * .2, r * .62, r * 1.05, 0); ctx.fill(); ctx.stroke();
          ctx.strokeStyle = '#e8e0cf'; ctx.lineWidth = r * .1; ctx.beginPath(); ctx.moveTo(r * .8, -r * .12); ctx.lineTo(r * 1.05, -r * .5); ctx.stroke();
          eyes(r * .7, r * .14, r * .1, eye); break; }
        // v1.89.1 — IL COLOSSO, DIPINTO. La prima stesura era fatta di poligoni piatti col contorno nero:
        // esattamente il contrario di come sono fatte le creature che vengono bene in questo gioco. Qui la
        // massa nasce da MACCHIE MORBIDE sovrapposte (scure sotto, chiare in alto a sinistra), le lastre
        // sono poche e stanno SOPRA la massa, e le crepe si disegnano due volte — larghe e fioche per il
        // bagliore, sottili e accese per il taglio. Le stesse regole del Beholder e dei ragni.
        case 'colosso': {
          const q = st.mhp ? Math.max(0, Math.min(1, (st.hp || 0) / st.mhp)) : 1;
          const fase = q <= 0.33 ? 3 : q <= 0.66 ? 2 : 1;
          const puls = 0.5 + 0.5 * Math.sin(t * 2.0);
          const passo = Math.sin(t * 2.3) * r * 0.045;
          const L = (k) => this._shade(col, k);
          // le crepe: sempre due passate, la larga fioca fa il bagliore e la sottile fa il taglio
          // una crepa e' SOTTILE: il bagliore lo fa la passata larga e fioca sotto, non lo spessore del
          // tratto. Con la linea grossa sembravano frecce dipinte sopra la roccia invece di fessure.
          const crepe = (pts, w2, ram) => {
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
            const traccia = (pp) => { ctx.beginPath(); ctx.moveTo(pp[0][0], pp[0][1]); for (let k = 1; k < pp.length; k++) ctx.lineTo(pp[k][0], pp[k][1]); ctx.stroke(); };
            ctx.strokeStyle = this._rgba(eye, 0.10 + 0.07 * puls); ctx.lineWidth = w2 * 5; traccia(pts);
            ctx.strokeStyle = this._rgba(eye, 0.62 + 0.24 * puls); ctx.lineWidth = w2; traccia(pts);
            if (ram) {   // una diramazione corta: e' l'irregolarita' a far leggere "spaccata", non la lunghezza
              const i2 = Math.max(1, (pts.length / 2) | 0), a4 = pts[i2];
              const b4 = [a4[0] + ram[0], a4[1] + ram[1]];
              ctx.strokeStyle = this._rgba(eye, 0.45 + 0.2 * puls); ctx.lineWidth = w2 * 0.7; traccia([a4, b4]);
            }
            ctx.restore();
          };
          // una LASTRA: poligono irregolare con il fianco scuro e il filo di luce sullo spigolo alto
          const lastra = (pts, tono) => {
            ctx.fillStyle = L(tono); ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
            for (let k = 1; k < pts.length; k++) ctx.lineTo(pts[k][0], pts[k][1]);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(6,8,14,.55)'; ctx.lineWidth = 1.6; ctx.stroke();
            ctx.strokeStyle = this._rgba(L(tono + 85), 0.55); ctx.lineWidth = 1.8;
            ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
            for (let k = 1; k < Math.min(3, pts.length); k++) ctx.lineTo(pts[k][0], pts[k][1]);
            ctx.stroke();
          };

          ctx.fillStyle = 'rgba(0,0,0,.34)';
          ctx.beginPath(); ctx.ellipse(-r * 0.06, r * 0.06, r * 1.22, r * 1.04, 0, 0, 7); ctx.fill();

          // ---- detriti in orbita: sassi veri, con la faccia illuminata e la crepa accesa ----
          for (let k = 0; k < 5; k++) {
            const a2 = t * 0.42 + k * 1.257, rr2 = r * (1.44 + 0.10 * Math.sin(t * 0.8 + k));
            const dx = Math.cos(a2) * rr2, dy = Math.sin(a2) * rr2 * 0.76, sz = r * (0.12 + 0.055 * (k % 3));
            this._macchia(ctx, dx, dy, sz * 1.5, sz * 1.3, '#000', 0.28);
            lastra([[dx - sz, dy - sz * 0.2], [dx - sz * 0.25, dy - sz], [dx + sz * 0.9, dy - sz * 0.15],
                    [dx + sz * 0.35, dy + sz * 0.9], [dx - sz * 0.7, dy + sz * 0.55]], -18 + k * 12);
            if (k % 2 === 0) crepe([[dx - sz * 0.5, dy - sz * 0.1], [dx + sz * 0.4, dy + sz * 0.35]], 0.9);
          }

          // ---- BRACCIA: tre macchie a scalare + il pugno. Dietro alle spalle. ----
          const braccio = (sgn) => {
            const sw = Math.sin(t * 2.1 + (sgn > 0 ? 0 : 1.7)) * r * 0.07;
            const P3 = [[r * 0.04, sgn * r * 0.86], [r * 0.62, sgn * r * 1.16 + sw], [r * 1.12 + swing * r * 0.5, sgn * r * 1.00 + sw]];
            for (let k = 0; k < P3.length; k++) {
              const w3 = r * (0.34 - k * 0.04);
              this._macchia(ctx, P3[k][0], P3[k][1], w3 * 1.6, w3 * 1.5, L(-58), 0.95);
              this._macchia(ctx, P3[k][0] - w3 * 0.28, P3[k][1] - w3 * 0.30, w3 * 1.05, w3 * 0.95, L(6), 0.85);
            }
            ctx.strokeStyle = L(-46); ctx.lineCap = 'round'; ctx.lineWidth = r * 0.30;
            ctx.beginPath(); ctx.moveTo(P3[0][0], P3[0][1]); ctx.lineTo(P3[1][0], P3[1][1]); ctx.lineTo(P3[2][0], P3[2][1]); ctx.stroke();
            const hx = P3[2][0] + r * 0.22 + swing * r * 0.24, hy = P3[2][1] - sgn * r * 0.04;
            this._macchia(ctx, hx, hy, r * 0.52, r * 0.48, '#000', 0.30);
            lastra([[hx - r * 0.30, hy - r * 0.14], [hx - r * 0.12, hy - r * 0.32], [hx + r * 0.24, hy - r * 0.26],
                    [hx + r * 0.33, hy + r * 0.10], [hx + r * 0.08, hy + r * 0.32], [hx - r * 0.26, hy + r * 0.20]], 14);
            crepe([[hx - r * 0.20, hy - r * 0.08], [hx + r * 0.02, hy + r * 0.06], [hx + r * 0.22, hy - r * 0.02]], 1.3);
          };
          braccio(1);
          if (fase < 2) braccio(-1);

          // ---- LA MASSA: sette macchie che costruiscono il volume prima di qualunque contorno ----
          const massa = [
            [r * 0.10, r * 0.26, 1.08, 0.94, -96, 1],      // il fondo: quasi nero, sotto e a destra
            [-r * 0.30, 0, 1.02, 0.90, -70, 1],
            [-r * 0.16, -r * 0.62, 0.74, 0.62, -52, 1],
            [-r * 0.16, r * 0.62, 0.74, 0.62, -60, 1],
            [r * 0.16, 0, 0.76, 0.64, -34, 0.95],
            [-r * 0.38, -r * 0.34, 0.60, 0.50, 26, 0.8],   // la luce viene da in alto a sinistra
            [-r * 0.44, -r * 0.52, 0.36, 0.30, 62, 0.5],
            [-r * 0.28, r * 0.36, 0.54, 0.44, -12, 0.65],
          ];
          for (const b3 of massa) this._macchia(ctx, b3[0], b3[1] + passo * 0.4, r * b3[2], r * b3[3], L(b3[4]), b3[5]);

          // ---- LE SPALLE: due lastroni sopra la massa, quello sinistro sparisce in fase 2 ----
          for (const sgn of [-1, 1]) {
            if (fase >= 2 && sgn < 0) continue;
            const y0 = sgn * r * 0.34, y1 = sgn * r * 1.08 + passo * sgn;
            lastra([[-r * 0.96, y0 * 0.74], [-r * 0.70, y1 * 1.06], [-r * 0.22, y1 * 1.12], [r * 0.16, y1 * 0.92],
                    [r * 0.44, y1 * 0.52], [r * 0.52, y0 * 1.04], [r * 0.10, y0 * 0.70]], sgn > 0 ? -8 : -30);
            crepe([[-r * 0.60, sgn * r * 0.50], [-r * 0.26, sgn * r * 0.78], [r * 0.06, sgn * r * 0.66], [r * 0.32, sgn * r * 0.80]], 1.4, [r * 0.10, sgn * r * 0.22]);
          }
          if (fase >= 2) {   // la frattura: pietra spezzata, e da dentro esce la luce
            lastra([[-r * 0.66, -r * 0.34], [-r * 0.40, -r * 0.62], [-r * 0.04, -r * 0.54],
                    [-r * 0.12, -r * 0.28], [-r * 0.44, -r * 0.22]], -52);
            ctx.save(); ctx.globalCompositeOperation = 'lighter';
            this._macchia(ctx, -r * 0.30, -r * 0.44, r * 0.30, r * 0.22, eye, 0.30 + 0.25 * puls, -0.5);
            ctx.restore();
            crepe([[-r * 0.52, -r * 0.30], [-r * 0.30, -r * 0.46], [-r * 0.10, -r * 0.40]], 1.5, [-r * 0.06, -r * 0.16]);
          }

          // ---- IL PETTO: la lastra grande, con la venatura che lo attraversa ----
          lastra([[-r * 0.72, -r * 0.40], [-r * 0.46, -r * 0.60], [r * 0.20, -r * 0.58], [r * 0.58, -r * 0.16],
                  [r * 0.44, r * 0.40], [-r * 0.16, r * 0.60], [-r * 0.66, r * 0.34]], 4);
          crepe([[-r * 0.62, -r * 0.06], [-r * 0.30, -r * 0.20], [-r * 0.02, r * 0.02], [r * 0.30, -r * 0.14], [r * 0.50, -r * 0.02]], 1.5, [r * 0.06, r * 0.26]);
          crepe([[-r * 0.24, r * 0.44], [r * 0.02, r * 0.30], [r * 0.30, r * 0.34]], 1.2, [-r * 0.10, r * 0.16]);
          crepe([[r * 0.16, -r * 0.50], [r * 0.28, -r * 0.30]], 1.1);

          if (fase >= 3) {   // ---- IL NUCLEO: la lastra si spacca e sotto c'e' la faglia ----
            ctx.fillStyle = '#06030c';
            ctx.beginPath();
            ctx.moveTo(-r * 0.40, -r * 0.30); ctx.lineTo(r * 0.06, -r * 0.44); ctx.lineTo(r * 0.34, -r * 0.02);
            ctx.lineTo(r * 0.10, r * 0.42); ctx.lineTo(-r * 0.34, r * 0.24);
            ctx.closePath(); ctx.fill();
            ctx.save(); ctx.globalCompositeOperation = 'lighter';
            this._macchia(ctx, -r * 0.02, 0, r * 0.62, r * 0.58, eye, 0.5 + 0.3 * puls);
            this._macchia(ctx, -r * 0.02, 0, r * 0.26, r * 0.24, '#ffffff', 0.55 + 0.35 * puls);
            for (let k = 0; k < 4; k++) {   // schegge che orbitano dentro la spaccatura
              const a3 = t * 1.6 + k * 1.57;
              this._macchia(ctx, Math.cos(a3) * r * 0.30, Math.sin(a3) * r * 0.26, r * 0.07, r * 0.06, '#e9d5ff', 0.7);
            }
            ctx.restore();
          }

          // ---- LA TESTA: incassata, senza volto. Un incavo scuro e dentro la fessura accesa ----
          this._macchia(ctx, r * 0.66, 0, r * 0.34, r * 0.30, '#000', 0.55);
          lastra([[r * 0.42, -r * 0.28], [r * 0.72, -r * 0.34], [r * 0.94, -r * 0.16],
                  [r * 0.94, r * 0.16], [r * 0.72, r * 0.34], [r * 0.42, r * 0.28]], -34);
          ctx.fillStyle = '#07040e';
          this._rr(ctx, r * 0.62, -r * 0.15, r * 0.30, r * 0.30, r * 0.06); ctx.fill();
          ctx.save(); ctx.globalCompositeOperation = 'lighter';
          this._macchia(ctx, r * 0.80, 0, r * 0.15, r * 0.13, eye, 0.55 + 0.4 * puls);
          ctx.fillStyle = this._rgba('#ffffff', 0.4 + 0.4 * puls);
          this._rr(ctx, r * 0.74, -r * 0.09, r * 0.10, r * 0.18, r * 0.03); ctx.fill();
          ctx.restore();
          // pietrisco che cade di continuo: e' cio' che dice che questa cosa si sta sbriciolando
          if (Math.random() < (fase >= 2 ? 0.5 : 0.28)) this.particles.push({
            x: MU.rand(-r * 0.8, r * 0.8), y: MU.rand(-r * 0.9, r * 0.9),
            vx: MU.rand(-8, 8), vy: MU.rand(14, 40), life: 0.5, t: 0.5, color: L(-30), r: MU.rand(1, 2.4), over: true });
          break; }
        // v1.89 — AZ'GAROTH RIDIPINTO. La forma era giusta (visto dall'alto, ali aperte ai lati, testa in
        // avanti) ma era fatta di campiture piatte: un'ellisse bordeaux, due triangoli scuri per ali e una
        // testa piccola. A schermo si leggeva come una macchia. Adesso e' costruito come i nemici nuovi —
        // volume dato da gradienti, luce sul dorso, membrana delle ali con le dita, coda a SEGMENTI che
        // ondeggia, e la gola che si accende PRIMA del soffio (il telegrafo e' anche decorazione).
        case 'dragon': {
          const bat = Math.sin(t * 2.6);                       // battito: giu' veloce, su lento
          const apri = 0.55 + 0.45 * (bat > 0 ? bat * bat : -0.35 * bat);
          const q = st.mhp ? Math.max(0, Math.min(1, (st.hp || 0) / st.mhp)) : 1;
          const furia = q <= 0.4;                               // sotto il 40% le crepe si accendono
          const magma = this._rgba(furia ? '#ff9a2b' : eye, 0.5 + 0.4 * (0.5 + 0.5 * Math.sin(t * 3.4)));
          ctx.fillStyle = 'rgba(0,0,0,.30)';
          ctx.beginPath(); ctx.ellipse(-r * 0.1, 0, r * 1.25, r * 0.95, 0, 0, 7); ctx.fill();

          // ---- ALI: un ventaglio di quattro dita con la membrana a festoni fra una e l'altra. Il bordo
          // che rientra fra le dita e' cio' che fa leggere "ala di drago" invece di "pinna".
          for (const sgn of [-1, 1]) {
            const sp = r * (1.35 + 0.72 * apri);                // apertura
            const arr = -r * (0.10 + 0.34 * (1 - apri));         // quanto sono ripiegate all'indietro
            const P2 = [
              [r * 0.16, sgn * r * 0.42],                        // attacco davanti
              [-r * 0.10 + arr, sgn * sp * 0.86],                // dito 1
              [-r * 0.66 + arr, sgn * sp],                       // dito 2
              [-r * 1.22 + arr, sgn * sp * 0.80],                // dito 3
              [-r * 1.55 + arr, sgn * sp * 0.44],                // dito 4
              [-r * 0.72, sgn * r * 0.34],                       // attacco dietro
            ];
            const wg = this._grad('dr_ala|' + r + '|' + col + '|' + sgn, () => {
              const g2 = ctx.createLinearGradient(0, sgn * r * 0.3, 0, sgn * r * 1.9);
              g2.addColorStop(0, this._shade(dark, 26)); g2.addColorStop(0.5, dark); g2.addColorStop(1, this._rgba(this._shade(col, -20), 0.72)); return g2;
            });
            ctx.fillStyle = wg; ctx.strokeStyle = D; ctx.lineWidth = 2.2; ctx.lineJoin = 'round';
            ctx.beginPath(); ctx.moveTo(P2[0][0], P2[0][1]);
            ctx.lineTo(P2[1][0], P2[1][1]);
            for (let k = 2; k <= 4; k++) {                       // festone: il bordo rientra verso il corpo
              const a2 = P2[k - 1], b2 = P2[k];
              ctx.quadraticCurveTo((a2[0] + b2[0]) / 2 + r * 0.10, (a2[1] + b2[1]) / 2 - sgn * r * 0.34, b2[0], b2[1]);
            }
            ctx.lineTo(P2[5][0], P2[5][1]); ctx.closePath(); ctx.fill(); ctx.stroke();
            // le dita: ossa chiare che tengono su la membrana
            ctx.strokeStyle = this._rgba(this._shade(col, 55), 0.8); ctx.lineWidth = r * 0.055; ctx.lineCap = 'round';
            for (let k = 1; k <= 4; k++) { ctx.beginPath(); ctx.moveTo(P2[0][0], P2[0][1]); ctx.lineTo(P2[k][0], P2[k][1]); ctx.stroke(); }
            // l'omero, piu' spesso
            ctx.strokeStyle = this._shade(col, 20); ctx.lineWidth = r * 0.10;
            ctx.beginPath(); ctx.moveTo(P2[0][0], P2[0][1]); ctx.lineTo(P2[2][0], P2[2][1]); ctx.stroke();
          }

          // ---- CODA: sei segmenti che ondeggiano con ritardo, non una curva sola ----
          ctx.strokeStyle = dark; ctx.lineCap = 'round';
          let cx2 = -r * 0.55, cy2 = 0;
          for (let k = 0; k < 6; k++) {
            const u = k / 5;
            const nx = -r * (0.55 + 0.32 * (k + 1)), ny = Math.sin(t * 2.2 - k * 0.75) * r * (0.10 + 0.24 * u);
            ctx.lineWidth = r * (0.46 - 0.062 * k);
            ctx.strokeStyle = k % 2 ? this._shade(col, -30) : dark;
            ctx.beginPath(); ctx.moveTo(cx2, cy2); ctx.lineTo(nx, ny); ctx.stroke();
            cx2 = nx; cy2 = ny;
          }
          ctx.fillStyle = this._shade(col, 30); ctx.strokeStyle = D; ctx.lineWidth = 2;   // punta a lama
          ctx.beginPath(); ctx.moveTo(cx2, cy2); ctx.lineTo(cx2 - r * 0.34, cy2 - r * 0.20); ctx.lineTo(cx2 - r * 0.24, cy2 + r * 0.22); ctx.closePath(); ctx.fill(); ctx.stroke();

          // ---- CORPO ----
          const bg = this._grad('dr_corpo|' + r + '|' + col, () => {
            const g2 = ctx.createLinearGradient(0, -r * 0.9, 0, r * 0.9);
            g2.addColorStop(0, this._shade(col, 52)); g2.addColorStop(0.45, col); g2.addColorStop(1, this._shade(dark, -10)); return g2;
          });
          ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.lineWidth = 2.8;
          ctx.beginPath(); ctx.ellipse(-r * 0.14, 0, r * 1.00, r * 0.64, 0, 0, 7); ctx.fill(); ctx.stroke();
          // placche del dorso, dalla coda alla nuca
          // le crepe si accendono SOLO in furia. A vita piena erano tre righe rosa sul dorso: era quello a
          // far sembrare il drago un verme a strisce. Sotto il 40% invece devono urlare, ed e' il momento giusto.
          if (furia) {
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
            const vena = (pp, w4) => {
              ctx.strokeStyle = this._rgba('#ff9a2b', 0.13); ctx.lineWidth = w4 * 5;
              ctx.beginPath(); ctx.moveTo(pp[0][0], pp[0][1]); for (let k = 1; k < pp.length; k++) ctx.lineTo(pp[k][0], pp[k][1]); ctx.stroke();
              ctx.strokeStyle = magma; ctx.lineWidth = w4;
              ctx.beginPath(); ctx.moveTo(pp[0][0], pp[0][1]); for (let k = 1; k < pp.length; k++) ctx.lineTo(pp[k][0], pp[k][1]); ctx.stroke();
            };
            vena([[-r * 0.80, -r * 0.28], [-r * 0.46, -r * 0.40], [-r * 0.14, -r * 0.26], [r * 0.20, -r * 0.38]], 1.5);
            vena([[-r * 0.64, r * 0.32], [-r * 0.30, r * 0.44], [r * 0.02, r * 0.30]], 1.3);
            ctx.restore();
          } else {
            // a riposo restano solo due solchi SCURI, che danno pelle invece di luce
            ctx.save(); ctx.strokeStyle = 'rgba(10,4,10,.45)'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(-r * 0.76, -r * 0.26); ctx.lineTo(-r * 0.40, -r * 0.36); ctx.lineTo(-r * 0.08, -r * 0.24);
            ctx.moveTo(-r * 0.58, r * 0.30); ctx.lineTo(-r * 0.24, r * 0.40);
            ctx.stroke(); ctx.restore();
          }
          // la cresta del dorso: una striscia STRETTA lungo la spina, con quattro placche che puntano
          // all'indietro. Larga come nella stesura precedente diventava una fascia a zigzag su tutto il
          // corpo, e il drago sembrava un verme con una riga.
          ctx.fillStyle = this._shade(col, -34);
          ctx.beginPath(); ctx.moveTo(-r * 0.92, 0);
          ctx.lineTo(-r * 0.30, -r * 0.07); ctx.lineTo(r * 0.72, -r * 0.05);
          ctx.lineTo(r * 0.72, r * 0.05); ctx.lineTo(-r * 0.30, r * 0.07);
          ctx.closePath(); ctx.fill();
          for (let k = 0; k < 4; k++) {
            const px2 = -r * (0.62 - k * 0.34), h3 = r * (0.17 - k * 0.018);
            ctx.fillStyle = this._shade(col, 26 + k * 6); ctx.strokeStyle = 'rgba(6,8,14,.55)'; ctx.lineWidth = 1.4;
            ctx.beginPath(); ctx.moveTo(px2 - r * 0.16, 0); ctx.lineTo(px2 + r * 0.06, -h3); ctx.lineTo(px2 + r * 0.18, 0);
            ctx.lineTo(px2 + r * 0.06, h3); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = this._rgba(this._shade(col, 88), 0.5);
            ctx.beginPath(); ctx.moveTo(px2 - r * 0.10, -r * 0.01); ctx.lineTo(px2 + r * 0.05, -h3 * 0.85); ctx.lineTo(px2 + r * 0.09, -r * 0.02); ctx.closePath(); ctx.fill();
          }
          // ---- COLLO E TESTA ----
          // Niente trapezio del collo: a questa scala si leggeva come una scatola scura fra il corpo e il
          // muso. Il collo e' fatto di due macchie che raccordano, e il cranio e' un cuneo DIPINTO — massa
          // morbida sotto, piano chiaro sopra, e i dettagli (occhi, narici, zanne) solo alla fine.
          const jaw = swing;                                    // 0 chiusa, 1 spalancata
          this._macchia(ctx, r * 0.74, 0, r * 0.42, r * 0.34, this._shade(col, -20), 0.95);
          this._macchia(ctx, r * 1.00, 0, r * 0.38, r * 0.29, this._shade(col, -6), 0.95);
          this._macchia(ctx, r * 1.22, 0, r * 0.34, r * 0.26, this._shade(col, 8), 0.95);
          // corna: corte, scure, all'indietro, disegnate PRIMA del cranio — se ne vedono le punte e basta
          ctx.save(); ctx.lineCap = 'round';
          for (const sg2 of [-1, 1]) {   // corna: due punte corte all'indietro, appena fuori dal cranio
            ctx.strokeStyle = '#463f34'; ctx.lineWidth = r * 0.085;
            ctx.beginPath(); ctx.moveTo(r * 1.30, sg2 * r * 0.19);
            ctx.quadraticCurveTo(r * 1.14, sg2 * r * 0.32, r * 0.98, sg2 * r * 0.30); ctx.stroke();
          }
          ctx.restore();
          // il cranio: massa morbida, poi il piano del muso piu' chiaro sopra
          this._macchia(ctx, r * 1.44, 0, r * 0.50, r * 0.34, this._shade(col, 12), 1);
          this._macchia(ctx, r * 1.40, -r * 0.06, r * 0.36, r * 0.20, this._shade(col, 48), 0.8);
          ctx.fillStyle = this._shade(col, 30); ctx.strokeStyle = D; ctx.lineWidth = 2.2;
          ctx.beginPath();
          ctx.moveTo(r * 1.08, -r * 0.34); ctx.lineTo(r * 1.52, -r * 0.24);
          ctx.lineTo(r * 1.84, -r * 0.10 - r * 0.05 * jaw); ctx.lineTo(r * 1.90, 0);
          ctx.lineTo(r * 1.84, r * 0.10 + r * 0.05 * jaw); ctx.lineTo(r * 1.52, r * 0.24); ctx.lineTo(r * 1.08, r * 0.34);
          ctx.closePath(); ctx.fill(); ctx.stroke();
          // dorso del muso, il piano che prende luce
          ctx.fillStyle = this._shade(col, 62);
          ctx.beginPath(); ctx.moveTo(r * 1.26, -r * 0.13); ctx.lineTo(r * 1.78, -r * 0.05);
          ctx.lineTo(r * 1.78, r * 0.05); ctx.lineTo(r * 1.26, r * 0.13); ctx.closePath(); ctx.fill();
          // arcate sopraccigliari
          ctx.fillStyle = this._shade(col, -38);
          for (const sg3 of [-1, 1]) {
            ctx.beginPath(); ctx.moveTo(r * 1.18, sg3 * r * 0.30); ctx.lineTo(r * 1.56, sg3 * r * 0.17);
            ctx.lineTo(r * 1.52, sg3 * r * 0.03); ctx.lineTo(r * 1.16, sg3 * r * 0.14); ctx.closePath(); ctx.fill();
          }
          // mandibola spalancata
          if (jaw > 0.02) {
            ctx.fillStyle = '#2a0510';
            ctx.beginPath(); ctx.moveTo(r * 1.34, 0); ctx.lineTo(r * 1.88, -r * 0.05 - r * 0.20 * jaw); ctx.lineTo(r * 1.88, r * 0.05 + r * 0.20 * jaw); ctx.closePath(); ctx.fill();
            ctx.fillStyle = '#efe6d2';
            for (const sg2 of [-1, 1]) { ctx.beginPath(); ctx.moveTo(r * 1.56, sg2 * (r * 0.05 + r * 0.12 * jaw)); ctx.lineTo(r * 1.68, sg2 * (r * 0.02 + r * 0.06 * jaw)); ctx.lineTo(r * 1.70, sg2 * (r * 0.10 + r * 0.17 * jaw)); ctx.closePath(); ctx.fill(); }
          }
          ctx.fillStyle = '#1a0308';                             // narici
          for (const sg4 of [-1, 1]) { ctx.beginPath(); ctx.ellipse(r * 1.70, sg4 * r * 0.06, r * 0.035, r * 0.022, 0, 0, 7); ctx.fill(); }
          // la GOLA che si accende PRIMA del soffio: il telegrafo e' anche decorazione
          ctx.save(); ctx.globalCompositeOperation = 'lighter';
          this._macchia(ctx, r * 1.66, 0, r * 0.44, r * 0.34, eye, 0.20 + 0.6 * jaw + (furia ? 0.14 : 0));
          ctx.restore();
          // occhi: incastonati sotto le arcate
          ctx.fillStyle = eye; ctx.shadowColor = eye; ctx.shadowBlur = 10;
          for (const sg2 of [-1, 1]) { ctx.beginPath(); ctx.ellipse(r * 1.38, sg2 * r * 0.16, r * 0.085, r * 0.05, sg2 * 0.25, 0, 7); ctx.fill(); }
          ctx.shadowBlur = 0;
          if (Math.random() < (furia ? 0.5 : 0.25)) this.particles.push({ x: r * 1.7, y: MU.rand(-r * 0.1, r * 0.1), vx: 50, vy: 0, life: 0.6, t: 0, fire: true, r: 3, over: true });
          break; }
        default: { const bg = ctx.createLinearGradient(-r, -r, r, r); bg.addColorStop(0, dark); bg.addColorStop(1, col); ctx.fillStyle = bg; ctx.strokeStyle = D; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill(); ctx.stroke(); eyes(r * .3, r * .3, r * .15); }
      }
    },
    // ===================== v1.64 — CACHE DEI GRADIENTI =====================
    // Misurato con 80 mostri in campo: il renderer creava 558 gradienti OGNI frame (33.500 al secondo),
    // quasi tutti identici a quelli del frame prima. Il frame mediano stava benissimo (6,5ms) ma il peggiore
    // arrivava a 39,7ms: non lentezza, SINGHIOZZO — ed e' la firma del garbage collector, non del disegno.
    // Un CanvasGradient e' un oggetto riusabile e le sue coordinate stanno nello SPAZIO UTENTE: basta
    // costruirlo attorno all'ORIGINE e disegnarlo col contesto gia' traslato sull'entita'. Quello che
    // cambia a ogni frame (il pulsare) si ottiene con globalAlpha, che non alloca niente.
    _grad(key, make) {
      const c = this._gcache || (this._gcache = new Map());
      let g = c.get(key);
      if (g === undefined) { g = make(); if (c.size > 512) c.clear(); c.set(key, g); }
      return g;
    },
    _rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); },
  };
  window.Renderer = R;
})();
