/* client.js — smoke test dell'INTERFACCIA con un DOM finto (v1.51).
   simulate.js copre il server; questo copre hud.js, che finora non era testato da nulla.
   Non serve un browser: si stuba il minimo di document/window e si verifica che il codice giri
   e produca il DOM atteso (barra dei poteri attivi, 3 carte potere, tetto delle statistiche, Emporio nascosto). */
const fs = require('fs'), path = require('path'); const ROOT = path.join(__dirname, '..') + path.sep;
const nodes = {};
function mkEl(id) {
  const el = { id, className: '', _html: '', textContent: '', style: { setProperty() {}, }, dataset: {}, children: [],
    classList: { _s: new Set(['hidden']), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, v) { v === undefined ? (this._s.has(c) ? this._s.delete(c) : this._s.add(c)) : (v ? this._s.add(c) : this._s.delete(c)); }, contains(c) { return this._s.has(c); } },
    appendChild(c) { this.children.push(c); }, removeChild(c) { this.children = this.children.filter(x => x !== c); },
    // v2.20.1 — GLI ATTRIBUTI SI RICORDANO. `setAttribute` non faceva niente e `getAttribute` non
    // esisteva affatto: dalla v2.19.9 `HUD._mettiArtwork` chiede `img.getAttribute('src')` per non
    // riassegnare la stessa immagine a ogni ridisegno, e qui tirava «img.getAttribute is not a
    // function». Il test del client si fermava li', e non se ne e' accorto nessuno per due versioni
    // perche' veniva lanciato solo `simulate.js`. Adesso lo stub tiene una mappa, come il DOM vero.
    _attr: {}, setAttribute(k, v) { this._attr[k] = String(v); }, getAttribute(k) { return k in this._attr ? this._attr[k] : null; },
    querySelector() { return mkEl('q'); }, get firstChild() { return this.children[0]; } };
  // innerHTML fedele: assegnarlo azzera i figli, come nel DOM vero
  Object.defineProperty(el, 'innerHTML', { get() { return el._html; }, set(v) { el._html = v; el.children = []; } });
  return el;
}
global.document = { getElementById: id => (nodes[id] = nodes[id] || mkEl(id)), createElement: () => mkEl('new'), querySelector: () => mkEl('q') };
global.window = { GAME: {} };
global.setTimeout = () => {}; global.clearTimeout = () => {};
for (const f of ['constants', 'mathutils', 'monsters', 'heroes', 'loot', 'gear', 'levels', 'potions', 'bounties', 'abilities', 'mapgen', 'storia', 'salvataggio']) {
  const src = fs.readFileSync(ROOT + 'shared/' + f + '.js', 'utf8');
  new Function('self', 'window', 'module', src)(window, window, undefined);
}
new Function('window', 'document', 'setTimeout', 'clearTimeout', fs.readFileSync(ROOT + 'public/js/hud.js', 'utf8'))(window, document, () => {}, () => {});
const HUD = window.HUD, L = window.GAME.Loot, C = window.GAME.Constants;
let fails = 0; const ok = (c, m) => { console.log((c ? '  ✅ ' : '  ❌ FAIL ') + m); if (!c) fails++; };

// 1) le carte attive — v1.73: non piu' una barra di gettoni ma le caselle del box del personaggio
HUD.setActiveBoons([
  { id: 'execute', icon: '🗡️', name: 'Colpo di Grazia', rarity: 'epic', n: 2, desc: 'esegue', on: 1 },
  { id: 'aegis', icon: '🧿', name: 'Egida Ostinata', rarity: 'rare', n: 1, desc: 'para', on: 1 },
  { id: 'headhunter', icon: '🎯', name: 'Cacciatore di Teste', n: 1, syn: 1, desc: 'sinergia' },
]);
const bar = document.getElementById('heroCards');
ok((bar.innerHTML.match(/cchip/g) || []).length === window.GAME.Constants.MAX_CARDS, 'le caselle sono sempre ' + window.GAME.Constants.MAX_CARDS);
ok((bar.innerHTML.match(/cchip empty/g) || []).length === 2, 'tre carte accese lasciano due caselle vuote');
ok(bar.innerHTML.includes('×2'), 'il moltiplicatore ×2 compare');
ok(bar.innerHTML.includes('syn'), 'la sinergia e evidenziata');
HUD.setActiveBoons([]);
ok((bar.innerHTML.match(/cchip empty/g) || []).length === window.GAME.Constants.MAX_CARDS, 'senza carte le caselle restano, tutte vuote');

// 2) v2.20.0 — il menu: TRE abilita' dello scaglione, statistiche con tetto, emporio assente.
// v2.20.1 — e la classe e' 'arciere': 'ladro' non e' una classe dalla v2.18 (e' un CORPO), quindi
// l'offerta tornava vuota e il pannello disegnava zero carte. Il test lo diceva da due versioni e
// nessuno lo sentiva, perche' veniva lanciato solo `simulate.js`.
const boons = L.offerteScaglione('arciere', 'rare', {}).map(b => ({ id: b.id, name: b.name, icon: b.icon, rarity: b.rarity, hero: b.hero, via: b.via, desc: 'x', owned: 0, max: b.max }));
HUD.setBoons({ boons, picked: false, tier: 'rare', tierName: 'Raro', tierColor: '#3aa0ff', scaglione: 2, tot: 4, resta: 1, liv: 6 }, () => {});
HUD.setStats({ xp: 500, level: 6, rankName: 'Predone', points: 5, wave: 6, stats: L.XP_STATS.map((s, i) => { const lvl = i === 0 ? L.STAT_MAX_LEVEL : 2; const maxed = lvl >= L.STAT_MAX_LEVEL; return { id: s.id, name: s.name, icon: s.icon, color: s.color, desc: s.desc, cost: maxed ? 0 : L.statCost(s.base, lvl), lvl, max: L.STAT_MAX_LEVEL, maxed }; }) }, () => {}, () => {});
ok(document.getElementById('boonCards').children.length === 3, 'il menu disegna le tre abilita dello scaglione');
ok(String(document.getElementById('boonSub').innerHTML).indexOf('Raro') > 0, 'e dice di quale scaglione si tratta');
const cards = document.getElementById('upgradeCards').children;
ok(cards.length === L.XP_STATS.length, 'una carta per statistica');
ok(cards[0].className.includes('maxed') && cards[0].innerHTML.includes('MAX'), 'la statistica al tetto e marcata MAX');
ok(cards[1].innerHTML.includes('Lv.2/' + L.STAT_MAX_LEVEL), 'le altre mostrano Lv.x/12');
ok(document.getElementById('gearSection').classList.contains('hidden'), 'la sezione Emporio resta nascosta senza dati equipaggiamento');
// 3) v1.67 — pannello del FABBRO: catalogo per classe, una riga per slot
const G = window.GAME.Gear;
const gearPayload = (heroId, coins, indosso) => ({ coins, near: 1, slots: G.slotsFor(heroId).map(slot => ({
  slot, name: G.SLOT_NAME[slot], icon: G.SLOT_ICON[slot],
  items: G.itemsFor(heroId, slot).map(it => ({ id: it.id, name: it.name, desc: it.desc, color: it.color, rank: it.rank, cost: it.cost, rarity: G.rarityOf(it), owned: (indosso || {})[slot] === it.id ? 1 : 0 })) })) });
let comprato = null;
HUD.showGear(gearPayload('paladino', 300, G.startingGear('paladino')), (id) => { comprato = id; });   // v2.20.1 — 'guerriero' e' un corpo, non una classe
const gw = document.getElementById('gearNpcCards');
ok(gw.children.length === G.slotsFor('paladino').length, 'il paladino vede i suoi slot (' + gw.children.length + ')');
const righe = gw.children.map(b => b.children.filter(c => c.className === 'gslot-row')[0]).filter(Boolean);
ok(righe.length === gw.children.length, 'ogni slot ha la sua riga di oggetti');
ok(righe[0].children.length === G.itemsFor('paladino', 'weapon').length, 'lo slot arma mostra tutte le armi che il paladino puo comprare (' + righe[0].children.length + ')');
const carte = righe[0].children;
ok(carte[0].className.includes('maxed') && carte[0].innerHTML.includes('IN USO'), 'l oggetto indosso e marcato IN USO');
ok(carte[1].innerHTML.includes('Spadone') && carte[1].innerHTML.includes('230'), 'lo spadone mostra nome e prezzo');
ok(!carte[1].className.includes('disabled'), 'con 300 monete lo spadone e acquistabile');
ok(carte[2].className.includes('disabled'), 'l alabarda (470) non e acquistabile con 300 monete');
carte[1].onclick(); ok(comprato === 'gue_spadone', 'il clic manda l id dell oggetto, non lo slot');
carte[0].onclick(); ok(comprato === 'gue_spadone', 'cliccare l oggetto gia indosso non ricompra nulla');
HUD.hideGear();
HUD.showGear(gearPayload('mago', 1000, G.startingGear('mago')), () => {});
ok(document.getElementById('gearNpcCards').children.length === 2, 'il mago vede due soli slot: niente scudo, niente calzature');


// 4) v1.68 — SNAPSHOT MAGRO: il giro completo server → rete → client.
// E' il controllo che conta davvero su questa modifica: se la ricostruzione lato client perde un campo,
// in partita si vedrebbero mostri senza tipo o barre della vita sbagliate, e nessun test del server
// se ne accorgerebbe. Qui si prende una stanza VERA, le si chiede la sequenza di snapshot magri che
// manderebbe in rete, li si passa a Net._reidrata e si confronta record per record con lo snapshot PIENO
// dello stesso identico istante.
{
  const { Room } = require(ROOT + 'server/Room.js');
  const Waves = require(ROOT + 'shared/waves.js');
  new Function('window', 'performance', 'WebSocket', 'location', 'setInterval',
    fs.readFileSync(ROOT + 'public/js/net.js', 'utf8'))(window, { now: () => 0 }, function () {}, { protocol: 'http:', host: 'x' }, () => {});
  const Net = window.Net;
  const room = new Room('rete'); const p = room.addPlayer('a', { send() {} }, 'A', 'guerriero');
  room.startGame(); room.phase = C.MSG ? 'combat' : 'combat'; room.wave = 9;
  for (let i = 0; i < 12; i++) { const q = room.randomSpawnPos(); room.spawnMonster(i % 3 === 0 ? 'darkmage' : 'skeleton', q.x, q.y, { scaling: Waves.scaling(9, 1) }); }
  const confronta = (etichetta) => {
    const pieno = room.snapshot();                       // la verita'
    const magro = Net._reidrata(room.snapshot(true));    // cio' che il client ricostruisce
    let differenze = [];
    for (const atteso of pieno.mon) {
      const avuto = magro.mon.find(m => m.e === atteso.e);
      if (!avuto) { differenze.push('mostro ' + atteso.e + ' mancante'); continue; }
      for (const k of Object.keys(atteso)) if (JSON.stringify(atteso[k]) !== JSON.stringify(avuto[k])) differenze.push('mostro ' + atteso.e + '.' + k + ': ' + atteso[k] + ' != ' + avuto[k]);
    }
    for (const atteso of pieno.players) {
      const avuto = magro.players.find(x => x.i === atteso.i);
      if (!avuto) { differenze.push('giocatore ' + atteso.i + ' mancante'); continue; }
      for (const k of Object.keys(atteso)) if (JSON.stringify(atteso[k]) !== JSON.stringify(avuto[k])) differenze.push('giocatore ' + atteso.i + '.' + k + ': ' + atteso[k] + ' != ' + avuto[k]);
    }
    ok(differenze.length === 0, etichetta + (differenze.length ? ' → ' + differenze.slice(0, 3).join(' · ') : ''));
  };
  confronta('primo snapshot: il client ricostruisce tutto');
  for (let i = 0; i < 20; i++) room.update(1 / C.TICK_RATE);
  confronta('dopo 20 tick: la parte immutabile e ancora quella giusta');
  // un mostro nuovo entra in scena
  const q = room.randomSpawnPos(); room.spawnMonster('occhio', q.x, q.y, { scaling: Waves.scaling(9, 1) });
  confronta('un mostro comparso dopo viene ricostruito');
  // un mostro muore: la cache non deve trattenerlo
  const vittima = room.monsters[0]; room.killMonster(vittima, null); room.monsters = room.monsters.filter(m => !m.dead);
  Net._reidrata(room.snapshot(true));
  ok(!Net._statMon.has(vittima.eid), 'la cache lascia andare i mostri morti');
  // i flag transitori NON devono restare accesi da un frame all'altro
  const vivo = room.monsters[0]; vivo.hitFlash = 0.1;
  ok(Net._reidrata(room.snapshot(true)).mon.find(m => m.e === vivo.eid).fl === 1, 'un flag acceso arriva');
  vivo.hitFlash = 0;
  ok(Net._reidrata(room.snapshot(true)).mon.find(m => m.e === vivo.eid).fl === 0, 'e quando si spegne torna 0, non resta acceso');
}


// 5) v1.70 — pannello del RANGO: le carte generiche non ci sono piu', resta il bivio del rango V
{
  const LV = window.GAME.Levels;
  ok(Object.keys(LV.CARD_BY_ID).length === 0, 'non ci sono piu carte di rango da mostrare');
  let scelto = null;
  HUD.setRank({ spec: 1, rank: 5, title: 'SCEGLI LA TUA STRADA',
    cards: LV.specsFor('mago').map(s => ({ id: s.id, name: s.name, icon: s.icon, color: s.color, desc: s.desc, abilita: s.abilita })) }, (id) => { scelto = id; });
  const rsec = document.getElementById('rankSection'), rrow = document.getElementById('rankCards');
  ok(!rsec.classList.contains('hidden'), 'al rango V il pannello compare');
  ok(rrow.children.length === 2, 'le strade sono due');
  ok(rrow.className === 'spec', 'e usa la disposizione a due colonne');
  ok(rrow.children[0].innerHTML.includes('SPECIALIZZAZIONE'), 'sono marcate come specializzazione');
  ok(rrow.children[0].innerHTML.includes('Meteora') || rrow.children[1].innerHTML.includes('Meteora'), 'e mostrano l abilita che arrivera');
  rrow.children[0].onclick();
  ok(scelto === LV.specsFor('mago')[0].id, 'il clic manda l id della specializzazione');
  HUD.setRank({ spec: 0, rank: 2, title: 'x', cards: [] }, () => {});
  ok(document.getElementById('rankSection').classList.contains('hidden'), 'senza carte da offrire il pannello resta nascosto');
  // il negozio parla di PUNTI, non piu di XP
  HUD.setStats({ points: 3, level: 7, rankName: 'Veterano', xp: 2500,
    stats: L.XP_STATS.map((s, i) => ({ id: s.id, name: s.name, icon: s.icon, color: s.color, desc: s.desc, lvl: i, max: 12, maxed: false, cost: i < 4 ? 1 : 2 })) }, () => {}, () => {});
  ok(String(document.getElementById('shopXp').textContent) === '3', 'la cifra grande sono i punti, non la XP');
  ok(String(document.getElementById('shopLevel').textContent) === '7', 'accanto c e il livello');
  ok(document.getElementById('shopRank').textContent === 'Veterano', 'e il nome del rango');
  const uc = document.getElementById('upgradeCards').children;
  ok(uc[0].innerHTML.includes('1 punto') && !uc[0].innerHTML.includes('XP'), 'il prezzo e in punti e non nomina piu la XP');
}

// ============================================================================================
// v1.64 — GUARDIA DI PRESTAZIONE SUL RENDERER
// Il gioco singhiozzava con molti nemici. Profilato: il frame MEDIANO stava bene (6,5ms) ma il
// peggiore arrivava a 39,7ms, e la causa erano 558 gradienti creati a OGNI frame (33.500 al
// secondo) — allocazioni che il garbage collector deve poi ripulire, tutte insieme.
// Questo test conta le allocazioni con un contesto 2D finto: e' l'unico modo per accorgersi di
// una regressione senza aprire un browser. Se qualcuno rimette un createGradient dentro un ciclo
// per-nemico, qui salta fuori subito invece che tra sei mesi giocando.
// ============================================================================================
(function testRenderPerf() {
  console.log('\n[CLIENT 2] Renderer — allocazioni per frame (v1.64)');
  const counters = { rad: 0, lin: 0 };
  const grad = { addColorStop() {} };
  const mkCtx = () => {
    const base = {
      canvas: { width: 1280, height: 720 },
      createRadialGradient() { counters.rad++; return grad; },
      createLinearGradient() { counters.lin++; return grad; },
      createPattern() { return null; },
      measureText() { return { width: 10 }; },
      getImageData(x, y, w, h) { return { data: new Uint8ClampedArray(Math.max(4, (w | 0) * (h | 0) * 4)), width: w | 0, height: h | 0 }; },
      createImageData(w, h) { const ww = (w && w.width) ? w.width : (w | 0), hh = (w && w.height) ? w.height : (h | 0); return { data: new Uint8ClampedArray(Math.max(4, ww * hh * 4)), width: ww, height: hh }; },
    };
    return new Proxy(base, {
      get(t, k) { if (k in t) return t[k]; if (typeof k !== 'string') return undefined; return (t[k] = function () {}); },
      set(t, k, v) { t[k] = v; return true; },
    });
  };
  const mkCanvas = () => { const c = { width: 1, height: 1, style: {}, _ctx: null }; c.getContext = () => (c._ctx = c._ctx || mkCtx()); return c; };
  const prevCreate = document.createElement;
  document.createElement = (tag) => (tag === 'canvas' ? mkCanvas() : prevCreate(tag));
  global.Image = function () { this.onload = null; this.onerror = null; };
  window.innerWidth = 1280; window.innerHeight = 720; window.devicePixelRatio = 1;
  window.addEventListener = () => {};
  window.localStorage = { getItem() { return null; }, setItem() {} };
  window.performance = { now: () => Date.now() };
  // renderer.js usa innerWidth/innerHeight nudi (globali del browser): vanno passati come parametri
  new Function('window', 'document', 'Image', 'localStorage', 'performance', 'requestAnimationFrame', 'innerWidth', 'innerHeight',
    fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8'))(window, document, global.Image, window.localStorage, window.performance, () => {}, 1280, 720);
  const R = window.Renderer;
  ok(!!R, 'il renderer si carica con un contesto 2D finto');
  R.init(mkCanvas());
  const MG = window.GAME.MapGen || window.GAME.Mapgen;
  ok(!!MG, 'il generatore di mappe e disponibile al test');
  const map = MG.generate(4242, 10);
  R.setMap(map);

  const TYPES = ['skeleton', 'slime', 'darkmage', 'spore_fungus', 'bone_roller', 'bat_swarm', 'wisp', 'occhio'];
  const N = 60;
  const cx = map.spawn.x, cy = map.spawn.y;
  const mon = [];
  for (let i = 0; i < N; i++) {
    const a = (i / N) * 6.283, r = 60 + (i % 8) * 55;
    mon.push({ e: i, t: TYPES[i % TYPES.length], x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r, f: a, hp: 50, mhp: 80, el: 0, b: 0, mg: 0, tr: 0, fl: 0, sh: 0, ps: 0, eg: 0 });
  }
  const bul = []; for (let i = 0; i < 30; i++) { const a = (i / 30) * 6.283; bul.push({ e: i, x: cx + Math.cos(a) * 150, y: cy + Math.sin(a) * 150, r: 5, c: '#9fe0ff' }); }
  const me = { i: 'a', h: 'enforcer', x: cx, y: cy, a: 0.5, hp: 90, mhp: 130, d: 0, dn: 0, lv: 3, tb: [], eg: 0.5 };
  const world = { players: [me], me, mon, bul, orbs: [], met: [], crates: [], wdrops: [], xp: [], coins: [], items: [], zones: [] };

  for (let i = 0; i < 6; i++) R.render(1 / 60, world);   // riscaldamento: la cache si riempie
  counters.rad = 0; counters.lin = 0;
  const FRAMES = 10;
  for (let i = 0; i < FRAMES; i++) R.render(1 / 60, world);
  const perFrame = (counters.rad + counters.lin) / FRAMES;
  console.log('     ' + N + ' nemici in campo -> ' + perFrame.toFixed(0) + ' gradienti per frame (' + (perFrame * 60).toFixed(0) + '/s a 60fps)');
  ok(perFrame < 240, 'meno di 240 gradienti per frame con ' + N + ' nemici (misurato ' + perFrame.toFixed(0) + ' — prima della v1.64 erano oltre 400)');
  ok(perFrame / N < 3.2, 'meno di 3,2 gradienti per nemico per frame (misurato ' + (perFrame / N).toFixed(2) + ')');

  // il Nugolo dev'essere COTTO: i suoi fotogrammi esistono e non si ridisegnano a mano
  const FR = R._batFrames('#c9a0ff');
  ok(!!FR && FR.frames.length >= 8, 'i fotogrammi del Nugolo sono precotti (' + (FR ? FR.frames.length : 0) + ' pose)');
  const before = counters.rad + counters.lin;
  R._batFrames('#c9a0ff');
  ok((counters.rad + counters.lin) === before, 'richiederli di nuovo NON ricuoce niente (sono in cache)');

  // lo scarto fuori inquadratura: un mostro lontanissimo non deve costare nulla
  const far = { e: 999, t: 'skeleton', x: cx + 9000, y: cy + 9000, f: 0, hp: 50, mhp: 80, el: 0, b: 0, mg: 0, tr: 0, fl: 0, sh: 0, ps: 0 };
  world.mon = [far];
  counters.rad = 0; counters.lin = 0;
  const solo = { players: [me], me, mon: [], bul: [], orbs: [], met: [], crates: [], wdrops: [], xp: [], coins: [], items: [], zones: [] };
  R.render(1 / 60, world); const withFar = counters.rad + counters.lin;
  counters.rad = 0; counters.lin = 0;
  R.render(1 / 60, solo); const without = counters.rad + counters.lin;
  ok(withFar === without, 'un nemico fuori inquadratura non viene disegnato affatto (' + withFar + ' = ' + without + ')');
  document.createElement = prevCreate;
})();


// ===== v1.71 — LA CINTURA E IL BANCO DELL'ERBORISTA =====
// La cintura si disegna dallo STESSO oggetto `me` che arriva nello snapshot: se cambia il formato di
// `bt` lato server, questo test se ne accorge prima che se ne accorga Paolo guardando lo schermo.
(function () {
  const P = window.GAME.Potions;
  HUD.updateBelt({ bt: [[0, 3], [3, 2], [2, 1]], pcd: 0 });
  const belt = document.getElementById('beltBar');
  ok(!belt.classList.contains('hidden'), 'la cintura si mostra quando il giocatore esiste');
  ok((belt.innerHTML.match(/pot-slot/g) || []).length === P.SLOTS, 'tre slot, quanti ne dichiara il catalogo');
  const s0 = document.getElementById('pot0');
  ok(s0.classList.contains('has'), 'lo slot con dentro una pozione e acceso');
  ok(!s0.classList.contains('empty'), 'e non e marcato vuoto');
  ok(String(s0.title).indexOf('Cura') === 0, 'il suggerimento porta il nome della pozione');
  // slot esaurito: assegnato ma senza cariche
  HUD._beltSig = null; HUD.updateBelt({ bt: [[0, 0], 0, 0], pcd: 0 });
  ok(document.getElementById('pot0').classList.contains('empty'), 'lo slot esaurito si spegne pur restando assegnato');
  ok(document.getElementById('pot1').classList.contains('empty'), 'e lo slot mai assegnato pure');
  // senza giocatore la cintura sparisce (schermata di fine partita, lobby)
  HUD.updateBelt(null);
  ok(belt.classList.contains('hidden'), 'senza giocatore la cintura si nasconde');

  // --- il banco ---
  const bel = [{ id: 'p_cura', n: 2 }, { id: 'p_furia', n: 3 }, null];
  const offerta = { coins: 310, max: P.MAX_CHARGES, near: 1, belt: bel,
    list: P.POTIONS.map(it => ({ id: it.id, name: it.name, icon: it.icon, color: it.color, cost: it.cost, desc: it.desc, dur: it.durTxt,
      slot: bel.findIndex(x => x && x.id === it.id) })) };
  let scelto = null, comprato = null;
  HUD._potSel = 1;
  HUD.showPotions(offerta, { pick: (slot, id) => { scelto = [slot, id]; }, buy: (slot) => { comprato = slot; } });
  const panel = document.getElementById('potionPanel');
  ok(!panel.classList.contains('hidden'), 'il banco si apre');
  ok(String(document.getElementById('potionHead').innerHTML).indexOf('310') > 0, 'e dice quante monete hai');
  const row = document.getElementById('potionBelt');
  ok(row.children.length === P.SLOTS, 'tre slot nel banco');
  ok(String(row.children[2].innerHTML).indexOf('vuoto') > 0, 'lo slot senza tipo dice di essere vuoto');
  ok(String(row.children[1].innerHTML).indexOf('piena') > 0, 'lo slot con 3 cariche non offre di comprarne una quarta');
  ok(String(row.children[0].innerHTML).indexOf('+1 carica') > 0, 'quello a meta strada si');
  const cat = document.getElementById('potionCat');
  ok(cat.children.length === P.POTIONS.length, 'il catalogo mostra tutte le pozioni');
  const cura = cat.children[0];
  ok(String(cura.className).indexOf('in') >= 0, 'quella gia in cintura e spenta');
  ok(String(cura.innerHTML).indexOf('slot 1') > 0, 'e dice in quale slot sta');
  ok(!cura.onclick, 'e non si puo cliccare: un tipo per slot');
  const libera = cat.children[1];   // Pelle di Pietra: non e in cintura
  ok(!!libera.onclick, 'una pozione libera si puo scegliere');
  libera.onclick();
  ok(scelto && scelto[0] === 1 && scelto[1] === 'p_pelle', 'e finisce nello slot selezionato');
  ok(String(document.getElementById('potionCatSub').textContent).indexOf('slot 2') > 0, 'il sottotitolo dice a quale slot stai lavorando');
  HUD.hidePotions();
  ok(panel.classList.contains('hidden'), 'e il banco si chiude quando ti allontani');
})();


// ===== v1.72 — LA TAGLIA IN PARTITA E IL BANCO DEL BANDITORE =====
(function () {
  const B = window.GAME.Bounties, G = window.GAME.Gear;
  // la riga in alto a sinistra
  const b = B.istanza('caccia', 6); b.have = 23;
  HUD.updateBounty({ bo: { k: b.k, h: b.have, n: b.n, i: b.icon, c: b.color, t: b.testo } });
  const hud = document.getElementById('bountyHud');
  ok(!hud.classList.contains('hidden'), 'la taglia in corso si vede in partita');
  ok(String(hud.innerHTML).indexOf(String(b.n)) > 0, 'e mostra il bersaglio');
  ok(String(hud.innerHTML).indexOf('23/') > 0, 'e a che punto sei');
  HUD.updateBounty({});
  ok(hud.classList.contains('hidden'), 'senza taglia la riga sparisce');

  // --- il banco, senza taglia accettata ---
  const tre = [B.istanza('specie', 6, 'slime', 'Melma Corrosiva'), B.istanza('elite', 6), B.istanza('casse', 6)];
  let presa = null, assoldato = 0;
  const cbB = { take: (i) => { presa = i; }, hire: () => { assoldato++; } };
  HUD.showBandit({ coins: 180, near: 1, bounty: null,
    merc: { assunto: null, off: { nome: 'Ghisla', hero: 'guerriero', lvl: 4, costo: 170 }, motivo: null },
    offers: tre.map(o => ({ k: o.k, n: o.n, pay: o.pay, nome: o.nome, icon: o.icon, color: o.color, testo: o.testo })) }, cbB);
  const panel = document.getElementById('banditPanel');
  ok(!panel.classList.contains('hidden'), 'il banco si apre');
  ok(String(document.getElementById('banditHead').innerHTML).indexOf('180') > 0, 'e dice quante monete hai');
  const tg = document.getElementById('banditBounty').children[0];
  ok(tg.children.length === 3, 'tre taglie fra cui scegliere');
  ok(String(tg.children[0].innerHTML).indexOf('Melma Corrosiva') > 0, 'il contratto mirato nomina la specie');
  ok(String(tg.children[0].innerHTML).indexOf('alla consegna') > 0, 'e ognuna dice quanto paga');
  tg.children[2].onclick();
  ok(presa === 2, 'cliccarne una la accetta, per indice');

  // --- v1.82: il banco dei mercenari ---
  const bm = document.getElementById('banditMerc');
  ok(bm.children.length === 1, 'al banco c e un candidato per volta');
  const riga0 = bm.children[0].innerHTML;
  ok(String(riga0).indexOf('Ghisla') > 0, 'con il suo nome');
  ok(String(riga0).indexOf('livello 4') > 0, 'e il suo livello');
  ok(String(riga0).indexOf('170') > 0, 'e quanto vuole');
  ok(String(riga0).indexOf('abilit') > 0, 'e dice che non ha abilita');
  ok(String(riga0).indexOf('disabled') < 0, 'con 180 monete il bottone e attivo');
  ok(typeof bm.children[0].onclick === 'function', 'e la riga si puo cliccare');
  bm.children[0].onclick();
  ok(assoldato === 1, 'cliccare assolda');
  // senza monete il bottone e spento
  HUD._bndSig = null;
  HUD.showBandit({ coins: 30, near: 1, bounty: null, offers: [],
    merc: { assunto: null, off: { nome: 'Ghisla', hero: 'guerriero', lvl: 4, costo: 170 }, motivo: null } }, cbB);
  const bmPoco = document.getElementById('banditMerc');
  ok(String(bmPoco.children[0].innerHTML).indexOf('disabled') > 0, 'con 30 monete il bottone e spento');
  ok(typeof bmPoco.children[0].onclick !== 'function', 'e la riga non fa niente');
  // gia assunto: il banco lo ricorda e non ne offre un altro
  HUD._bndSig = null;
  HUD.showBandit({ coins: 900, near: 1, bounty: null, offers: [],
    merc: { assunto: { nome: 'Vesper', hero: 'mago', lvl: 7 }, off: null, motivo: null } }, cbB);
  const bm2 = document.getElementById('banditMerc');
  ok(String(bm2.children[0].innerHTML).indexOf('Vesper') > 0, 'con uno gia al soldo il banco mostra lui');
  ok(String(bm2.children[0].innerHTML).indexOf('assolda') < 0, 'e non se ne puo assoldare un secondo');
  // in multiplayer il banco lo dice e basta
  HUD._bndSig = null;
  HUD.showBandit({ coins: 900, near: 1, bounty: null, offers: [], merc: { assunto: null, off: null, motivo: 'solo' } }, cbB);
  ok(document.getElementById('banditMerc').children.length === 0, 'in multiplayer non si assolda nessuno');
  ok(String(document.getElementById('mercSub').textContent).indexOf('singola') > 0, 'e il banco spiega perche');

  // --- il banco, con la taglia gia accettata ---
  const att = B.istanza('caccia', 6); att.have = 12;
  HUD._bndSig = null;
  HUD.showBandit({ coins: 400, near: 1, offers: [], merc: { assunto: null, off: null, motivo: null },
    bounty: { k: att.k, n: att.n, have: att.have, pay: att.pay, nome: att.nome, icon: att.icon, color: att.color, testo: att.testo } },
    { take: () => {}, hire: () => {} });
  const riga = document.getElementById('banditBounty').children[0];
  ok(String(riga.className).indexOf('att') >= 0, 'con una taglia aperta il banco mostra quella, non le offerte');
  ok(String(riga.innerHTML).indexOf('12 / ') > 0, 'con il conteggio');
  HUD.hideBandit();
  ok(panel.classList.contains('hidden'), 'e si chiude quando ti allontani');

  // --- v1.82 FIX: due personaggi della STESSA classe con tinte diverse non si spartiscono i colori ---
  // La cache dei gradienti era chiusa su 'h_torso|lad|<raggio>': il secondo ladro disegnato riusava il
  // gradiente del primo, cioe' i suoi colori. Con i mercenari il giocatore si e' ritrovato addosso la
  // tinta del compagno. La chiave adesso porta la firma della palette.
  {
    const M = require('../shared/mercenari.js');
    const RR = window.Renderer;
    const pk = (p) => RR._palKey(p);
    ok(pk(null) === '', 'chi non ha tinta ha firma vuota: continua a condividere il gradiente di sempre');
    const tinte = M.TINTE.ladro.map(pk);
    ok(new Set(tinte).size === tinte.length, 'le quattro tinte del ladro hanno quattro firme diverse');
    ok(tinte.every(x => x !== ''), 'e nessuna e vuota: non si confondono con chi non ha tinta');
    for (const cl of ['guerriero', 'mago', 'ladro']) {
      const f = M.TINTE[cl].map(pk);
      ok(new Set(f).size === f.length, cl + ': tinte tutte distinguibili');
      ok(!f.includes(''), cl + ': nessuna tinta produce la chiave di "nessuna tinta"');
    }
    // la chiave completa, quella che finisce davvero nella cache
    const chiave = (cl, r, p) => 'h_torso|' + cl + '|' + r + '|' + pk(p);
    ok(chiave('lad', 16, null) !== chiave('lad', 16, M.TINTE.ladro[0]), 'giocatore e mercenario della stessa classe: due chiavi diverse');
    ok(chiave('lad', 16, M.TINTE.ladro[0]) !== chiave('lad', 16, M.TINTE.ladro[1]), 'due mercenari di tinta diversa: due chiavi diverse');
    ok(chiave('lad', 16, null) === chiave('lad', 16, null), 'e senza tinta la chiave resta stabile');
  }

  // --- il Fabbro deve dire cosa e gia tuo ---
  const card = HUD._gearCard({ id: 'gue_spadone', name: 'Spadone', desc: 'x', color: '#e0a52c', rank: 2, cost: 230,
    rarity: 'uncommon', owned: 0, have: 1 }, 0, () => {});
  ok(String(card.innerHTML).indexOf('GIÀ TUO') > 0, 'un oggetto in magazzino si riequipaggia gratis, e il Fabbro lo scrive');
  ok(String(card.className).indexOf('disabled') < 0, 'e non e spento anche se non hai monete');
})();


// ===== v1.73 — IL BOX DEL PERSONAGGIO E IL TAVOLO DELLA CARTOMANTE =====
(function () {
  const L = window.GAME.Loot, MAXC = window.GAME.Constants.MAX_CARDS;
  const carta = (id, n, on) => { const b = L.BOON_BY_ID[id]; return { id, icon: b.icon, name: b.name, rarity: b.rarity, n, desc: b.desc, on }; };
  // --- il box ---
  HUD.setActiveBoons([carta('ricochet', 3, 1), carta('crit', 2, 1), carta('execute', 1, 1)]);
  HUD.updateHeroBox({ n: 'Paolo', h: 'guerriero', lvl: 12, prg: 0.62, sp: null });
  const box = document.getElementById('heroBox');
  ok(!box.classList.contains('hidden'), 'il box del personaggio si vede');
  ok(String(document.getElementById('heroBoxName').textContent) === 'Paolo', 'con il nome, che non sta piu sopra la testa');
  ok(String(document.getElementById('heroBoxLv').innerHTML).indexOf('Lv.12') >= 0, 'con il livello');
  ok(String(document.getElementById('heroBoxLv').innerHTML).indexOf('Signore delle Lame') > 0, 'e il rango di quel livello (v1.79: al 12 e il quinto titolo)');
  const cards = document.getElementById('heroCards');
  ok((String(cards.innerHTML).match(/cchip/g) || []).length === MAXC, 'e ' + MAXC + ' caselle: anche quelle vuote si vedono');
  ok((String(cards.innerHTML).match(/empty/g) || []).length === 2, 'due caselle libere con tre carte accese');
  ok(String(cards.innerHTML).indexOf('×3') > 0, 'gli esemplari multipli si vedono');
  HUD.updateHeroBox(null);
  ok(box.classList.contains('hidden'), 'senza giocatore il box sparisce');
  // le carte spente NON entrano nel box
  HUD.setActiveBoons([carta('ricochet', 1, 1), carta('giant', 1, 0)]);
  HUD.updateHeroBox({ n: 'Paolo', h: 'guerriero', lvl: 3, prg: 0.1 });
  ok((String(document.getElementById('heroCards').innerHTML).match(/empty/g) || []).length === MAXC - 1,
     'una carta spenta non occupa una casella del box');

  // --- il tavolo ---
  let toccata = null;
  const tutte = [carta('ricochet', 3, 1), carta('crit', 2, 1), carta('execute', 1, 1), carta('spalle', 1, 1), carta('lamasporca', 1, 1), carta('giant', 1, 0)];
  HUD.showSeer({ near: 1, max: MAXC, active: 5, cards: tutte, syn: [{ id: 's', icon: '🔗', name: 'Tempesta', desc: 'x' }] }, (id) => { toccata = id; });
  const panel = document.getElementById('seerPanel');
  ok(!panel.classList.contains('hidden'), 'il tavolo si apre');
  ok(String(document.getElementById('seerHead').innerHTML).indexOf('5') > 0, 'e dice quante ne hai accese');
  ok(String(document.getElementById('seerSub').textContent).indexOf('limite') > 0, 'al limite lo dichiara');
  const w = document.getElementById('seerCards');
  ok(w.children.length === 6, 'elenca tutte le carte, accese e spente');
  ok(String(w.children[0].className).indexOf('on') >= 0, 'le accese sono in cima e marcate');
  const spenta = Array.prototype.slice.call(w.children).find(el => String(el.className).indexOf('lock') >= 0);
  ok(!!spenta, 'con il tetto pieno la spenta e bloccata');
  ok(!spenta.onclick, 'e non si puo cliccare');
  const rim = Array.prototype.slice.call(w.children).find(el => String(el.innerHTML).indexOf('Rimbalzo') > 0);
  ok(!!rim, 'le carte si trovano per nome');
  rim.onclick();
  ok(toccata === 'ricochet', 'cliccare una accesa la manda a spegnere');
  ok(!document.getElementById('seerSyn').classList.contains('hidden'), 'le sinergie attive si vedono');
  // con un posto libero la spenta torna cliccabile
  HUD._seerSig = null;
  HUD.showSeer({ near: 1, max: MAXC, active: 4, cards: tutte, syn: [] }, (id) => { toccata = id; });
  const w2 = document.getElementById('seerCards');
  const libera = Array.prototype.slice.call(w2.children).find(el => String(el.className).indexOf('lock') >= 0);
  ok(!libera, 'con un posto libero nessuna carta e bloccata');
  ok(String(document.getElementById('seerSub').textContent).indexOf('ancora 1') > 0, 'e dice quante ne puoi ancora accendere');
  HUD.hideSeer();
  ok(panel.classList.contains('hidden'), 'e si chiude quando ti allontani');
})();


// ===== v1.74 — IL FOCOLARE DELL'OSTESSA =====
(function () {
  const C = window.GAME.Constants;
  const mostra = (hp, mx, coins) => {
    const manca = Math.max(0, mx - hp), pieno = Math.ceil(manca * C.INN_PER_HP);
    const curabili = Math.min(manca, Math.floor(coins / C.INN_PER_HP));
    HUD._innSig = null;
    HUD.showInn({ near: 1, coins, hp, mx, manca, pieno, curabili, spesa: Math.ceil(curabili * C.INN_PER_HP), perHp: C.INN_PER_HP }, () => { chiesto = true; });
  };
  let chiesto = false;
  // ferito, monete a sufficienza
  mostra(100, 275, 430);
  const panel = document.getElementById('innPanel'), btn = document.getElementById('innBtn');
  ok(!panel.classList.contains('hidden'), 'il focolare si apre');
  ok(String(document.getElementById('innHp').innerHTML).indexOf('100') >= 0, 'mostra la vita che hai');
  ok(String(document.getElementById('innText').innerHTML).indexOf('175') > 0, 'e quanti PV ti mancano');
  ok(String(btn.innerHTML).indexOf('70') > 0, 'il bottone dice quanto costa la cura piena');
  ok(String(btn.className).indexOf('off') < 0, 'ed e cliccabile');
  btn.onclick(); ok(chiesto, 'cliccarlo chiede il riposo');
  // monete corte: cura parziale
  mostra(100, 275, 28);
  ok(String(document.getElementById('innBtn').innerHTML).indexOf('+70 PV') > 0, 'con poche monete offre la cura parziale');
  ok(String(document.getElementById('innBtn').className).indexOf('parz') >= 0, 'e si vede che e parziale');
  // nessuna moneta
  mostra(100, 275, 0);
  ok(String(document.getElementById('innBtn').className).indexOf('off') >= 0, 'senza monete il bottone e spento');
  ok(!document.getElementById('innBtn').onclick, 'e non risponde al clic');
  ok(String(document.getElementById('innText').innerHTML).indexOf('70') > 0, 'ma dice comunque quanto servirebbe');
  // gia al massimo
  mostra(275, 275, 430);
  ok(String(document.getElementById('innBtn').className).indexOf('off') >= 0, 'a PV pieni non c e niente da comprare');
  ok(String(document.getElementById('innText').textContent).indexOf('niente da farti curare') > 0, 'e lo dice chiaramente');
  HUD.hideInn();
  ok(panel.classList.contains('hidden'), 'e si chiude quando ti allontani');
})();


// ===== v1.78 — USCITA DALLA MAPPA RIPULITA, RIEPILOGO, CARTE DAI LIVELLI ====================
(function () {
  console.log('\n-- v1.84: la faglia d uscita (il pulsante EXIT non c e piu), riepilogo di fine livello');
  const top = document.getElementById('clearTop'), sub = document.getElementById('clearSub');
  const snap = (o) => Object.assign({ wave: 3, mcount: 0, pend: 0, phase: 'combat', wt: 30, wp: 60 }, o);
  // il DOM finto crea al volo qualunque id gli si chieda, quindi interrogarlo non prova niente: si
  // guarda la PAGINA VERA, che e' l unico posto dove il pulsante poteva restare per sbaglio.
  ok(fs.readFileSync(ROOT + 'public/index.html', 'utf8').indexOf('exitBtn') < 0, 'il pulsante EXIT e stato tolto dalla pagina');

  // v1.90 — la musica: il brano c'e', ed e' UNA la funzione che decide dove suona
  {
    const au = fs.readFileSync(ROOT + 'public/js/audio.js', 'utf8');
    ok(fs.existsSync(ROOT + 'public/assets/audio/theme_loop.ogg'), 'il brano e nel progetto (ogg)');
    ok(fs.existsSync(ROOT + 'public/assets/audio/theme_loop.m4a'), 'con l m4a per Safari');
    ok(au.indexOf('scene(kind)') > 0, 'e A.scene() e il punto unico che decide cosa si sente');
    ok(/TRACCIA: false/.test(au), 'v1.90.1 — il brano e spento: si torna alla musica procedurale');
    ok(au.indexOf('this.startMusic(kind === \'boss\')') > 0, 'ed e il sintetizzatore a suonare');
    const mn = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
    ok(mn.indexOf("C.PHASE_MARKET ? 'village'") > 0, 'il mercato chiede la scena villaggio');
  }

  // v1.97.1 — L'ELSE DI _bakeCaverna DEVE RESTARE ATTACCATO AL SUO IF.
  // Storia vera, e costata cara: la chiamata a _dipingiCimitero era stata infilata FRA l'if e l'else,
  //     if (_nuova) this._bakeCaverna(...);
  //     if (_nuova && m.muri) this._dipingiCimitero(...);     <-- qui
  //     else { riempi tutto di pavimento piatto }
  // e cosi' l'else, che serviva al villaggio, e' finito attaccato alla riga nuova: su OGNI mappa senza
  // cimitero — cioe' dalla terza ondata in poi — partiva il riempimento e cancellava la caverna appena
  // cotta. Il gioco restava giocabile e nessun test se ne accorgeva: erano sparite solo le rocce.
  {
    const rd = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8').split('\n');
    const i = rd.findIndex(r => r.indexOf('if (_nuova) this._bakeCaverna(') >= 0);
    ok(i > 0, 'la cottura della caverna e al suo posto');
    ok(/^\s*else \{/.test(rd[i + 1] || ''), 'e la riga SUBITO DOPO e il suo else: non infilare niente in mezzo');
    ok(rd.some(r => r.indexOf('this._dipingiCimitero(') >= 0 && r.indexOf('m.muri') >= 0), 'il cimitero si dipinge solo quando la mappa ha le sue tessere');
  }

  // v2.8.2 — la modalita' di prova e' di nuovo NASCOSTA nel menu (lo era in v1.96.1, poi resa visibile in
  // v1.99). Nascosta, non tolta: e' uno strumento di sviluppo, non una voce del gioco, e in una schermata
  // d'avvio che deve invogliare a giocare un pannello che dice "parti dall'ondata 14" e' rumore.
  // Le due scorciatoie che la riaprono sono l'unico modo per arrivarci, quindi qui si controllano tutte
  // e tre le cose insieme: che sia nascosta, che ci sia ancora, e che le scorciatoie funzionino.
  {
    const html = fs.readFileSync(ROOT + 'public/index.html', 'utf8');
    const mn = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
    ok(/<details class="help prova hidden" id="provaBox">/.test(html), 'il pannello di prova nasce nascosto');
    ok(html.indexOf('id="provaGrid"') > 0, 'ma c e ancora, con la sua griglia di ondate');
    ok(/\[\?&#\]test/.test(mn), 'e le scorciatoie che lo riaprono: ?test nell indirizzo');
    ok(mn.indexOf("e.key !== 't' && e.key !== 'T'") > 0, 'e il tasto T stando nel menu');
    ok(/prova\.classList\.remove\('hidden'\)/.test(mn), 'e sono loro a togliergli il "hidden"');
    // il tasto T resta scritto nei comandi: e' l'unico modo per sapere che quella scorciatoia esiste
    ok(html.indexOf('Modalità di prova') > 0, 'e il tasto T resta documentato fra i comandi');
  }

  // v2.2 — LA SCHERMATA PRINCIPALE A DUE COLONNE. Il titolo fuori dal pannello, e la guida aperta di
  // fianco invece che chiusa in un accordion che nessuno apre. Tre cose vanno insieme, e si rompono
  // insieme: il titolo fuori, le due colonne, e il fatto che i tasti siano scritti DAVVERO tutti.
  {
    const html = fs.readFileSync(ROOT + 'public/index.html', 'utf8');
    const css = fs.readFileSync(ROOT + 'public/style.css', 'utf8');
    const men = html.slice(html.indexOf('<div id="menu">'), html.indexOf('<div id="lobby"'));
    ok(/<div id="titolone">[\s\S]*?<h1>/.test(men), 'il titolo sta fuori dal pannello, sullo sfondo');
    const card = men.slice(men.indexOf('<div class="menu-card">'), men.indexOf('</aside>'));
    ok(card.indexOf('<h1>') < 0, 'e dentro il pannello di sinistra non c e piu');
    ok(men.indexOf('id="menuColonne"') > 0 && men.indexOf('class="info-card"') > 0, 'e le due colonne ci sono: si entra a sinistra, si legge a destra');
    ok(/#menuColonne\{display:flex/.test(css), 'affiancate per davvero (flex)');
    ok(/@media \(max-width:1080px\)[\s\S]{0,220}#menuColonne\{flex-direction:column/.test(css), 'e sotto i 1080 px si impilano invece di schiacciarsi');
    // il pannello a destra non deve essere un accordion: in una schermata di avvio un accordion e' un
    // modo elegante di non far leggere niente a nessuno
    const info = men.slice(men.indexOf('<aside class="info-card"'), men.indexOf('</aside>'));
    ok(info.indexOf('<details') < 0, 'la guida e aperta, non chiusa in un accordion');
    // OGNI tasto che il gioco ascolta dev'essere scritto li'. Se un domani se ne aggiunge uno e ci si
    // dimentica di scriverlo, e' qui che ce lo si ricorda.
    for (const [k, chi] of [['W A S D', 'movimento'], ['Mouse', 'mira'], ['Spazio', 'sparo'], ['Shift', 'scatto'],
                            ['1 2 3', 'pozioni'], ['>Q<', 'abilita Q'], ['>E<', 'abilita E'], ['>L<', 'luce'],
                            ['>M<', 'musica'], ['Invio', 'chat'], ['>T<', 'prova']])
      ok(info.indexOf(k.replace(/[<>]/g, m => m === '>' ? '>' : '<')) > 0 || info.indexOf(k) > 0, 'nei comandi c e il tasto per ' + chi);
    ok(/accende e spegne la torcia/.test(info), 'e del tasto L si dice cosa fa');
    // v2.8.2 — IL RICHIAMO aveva preso il posto delle regole («Come funziona una run»).
    // v2.20.1 — il richiamo e' stato TOLTO (Paolo), e i controlli su di lui sono andati in
    // `simulate.js` (TEST 79) e non qui. Il motivo e' spiacevole ma va scritto: questo file si ferma
    // al primo errore e da due versioni non arrivava piu' in fondo, quindi un controllo messo qui non
    // sarebbe stato eseguito da nessuno. Qui resta solo cio' che il test sa ancora verificare.
    ok(!/info-h">\u{1F3AF} Come funziona/u.test(men) && !/class="info-lista"/.test(men),
      'e l elenco delle regole non e tornato nella colonna di destra');
  }

  // v1.99 — il menu NON ha piu' l'illustrazione di sfondo: e' tornato il fondo scuro di sempre.
  {
    const css = fs.readFileSync(ROOT + 'public/style.css', 'utf8');
    ok(css.indexOf('menu_key_art') < 0, 'nel menu non c e piu l artwork di sfondo');
    ok(css.indexOf('#menu::before') < 0 && css.indexOf('#menu::after') < 0, 'ne i due strati che lo reggevano');
    ok(css.indexOf('radial-gradient(1200px 800px at 50% -10%') > 0, 'e c e il fondo scuro: il gradiente radiale di sempre');


    // v1.93.5 — LA BARRA DELLE ABILITA NON DEVE ESSERE COPERTA. E centrata e larga 446 px con quattro
    // slot: occupa 223 px per lato dal centro. Cintura e riquadro dell eroe stavano a 120 e 116 px dal
    // centro e si mangiavano il primo slot (DX) e l ultimo (E) — quello della E era invisibile e
    // sembrava non esistere. Chi cambia questi margini deve accorgersi di romperlo.
    const marg = (re) => { const m = css.match(re); return m ? parseInt(m[1], 10) : -1; };
    const belt = marg(/#beltBar\{position:absolute;bottom:20px;right:calc\(50% \+ (\d+)px\)/);
    const eroe = marg(/#heroBox\{position:absolute;bottom:20px;left:calc\(50% \+ (\d+)px\)/);
    const ampolla = marg(/#vitals\{position:absolute;bottom:10px;left:calc\(50% \+ (\d+)px\)/);
    ok(belt >= 223, 'la cintura sta fuori dalla barra delle abilita (' + belt + ' px dal centro, servono 223)');
    ok(eroe >= 223, 'e il riquadro dell eroe pure (' + eroe + ' px): senza, lo slot della E sparisce sotto');
    ok(ampolla > eroe + 137, 'e l ampolla sta dopo il riquadro dell eroe (' + ampolla + ' > ' + (eroe + 137) + ')');
  }
  // in combattimento non si vede niente
  HUD.updateTop(snap({}), null);
  ok(top.classList.contains('hidden'), 'in combattimento l avviso di fine ondata non c e');
  // mappa ripulita, in singolo
  HUD.updateTop(snap({ phase: 'cleared', ex: { n: 0, tot: 1, t: 118 } }), null);
  ok(!top.classList.contains('hidden'), 'a mappa ripulita compare l avviso');
  ok(document.getElementById('hud').classList.contains('ripulita'), 'e gli annunci al centro si spostano per non coprire la scritta');
  ok(document.getElementById('boonTitle') !== null, 'il titolo del mazzo ha un id, per poterlo cambiare');
  ok(String(sub.innerHTML).indexOf('faglia') > 0, 'la scritta dice di attraversare la faglia');
  ok(String(sub.innerHTML).indexOf('118') > 0, 'dicendo anche fra quanto si esce da soli');
  // attraversata: la scritta cambia
  HUD.exitPremuto();
  HUD.updateTop(snap({ phase: 'cleared', ex: { n: 1, tot: 3, t: 90 } }), null);
  ok(String(sub.innerHTML).indexOf('1 su 3') > 0, 'in cooperativa dice a quanti si sta aspettando');
  // fase cambiata: tutto sparisce
  HUD.updateTop(snap({ phase: 'shop' }), null);
  ok(top.classList.contains('hidden'), 'finita l attesa sparisce');
  ok(!document.getElementById('hud').classList.contains('ripulita'), 'e gli annunci tornano al loro posto');
  HUD.updateTop(snap({ phase: 'cleared', ex: { n: 0, tot: 1, t: 120 } }), null);
  ok(String(sub.innerHTML).indexOf('faglia') > 0, 'e all ondata dopo l avviso torna quello di partenza');

  // e il contatore di combo non deve stare sopra alla scritta
  HUD.updateTop(snap({ phase: 'combat', ex: null }), { cmb: 9, cmx: 1.4, cmt: 0.5, hp: 10, mhp: 10, lv: 1, k: 0, xp: 0, co: 0, lives: 2, pot: [], cards: [] });
  ok(!document.getElementById('comboMeter').classList.contains('hidden'), 'in combattimento la combo si vede');
  HUD.updateTop(snap({ phase: 'cleared', ex: { n: 0, tot: 1, t: 100 } }), { cmb: 9, cmx: 1.4, cmt: 0.5, hp: 10, mhp: 10, lv: 1, k: 0, xp: 0, co: 0, lives: 2, pot: [], cards: [] });
  ok(document.getElementById('comboMeter').classList.contains('hidden'), 'a mappa ripulita sparisce, per non coprire la scritta');
  HUD.updateTop(snap({ phase: 'combat' }), null);

  // il riepilogo di fine livello
  const box = document.getElementById('waveStats');
  HUD.setWaveStats({ wave: 4, uccisi: 23, xp: 310, monete: 88, livelli: 2, durata: 71.4, par: 90, bonus: { xp: 57, monete: 24 }, carte: 2, livello: 6 });
  ok(!box.classList.contains('hidden'), 'il riepilogo di fine livello compare');
  const h = String(box.innerHTML);
  ok(h.indexOf('23') > 0 && h.indexOf('310') > 0 && h.indexOf('88') > 0, 'con nemici uccisi, esperienza e monete');
  ok(h.indexOf('1:11') > 0 && h.indexOf('1:30') > 0, 'con la durata e il tempo obiettivo in minuti');
  ok(h.indexOf('+57') > 0 && h.indexOf('+24') > 0, 'e il premio del cronometro quando c e');
  ok(h.indexOf('2') > 0 && h.indexOf('livelli') > 0, 'e i livelli guadagnati');
  HUD.setWaveStats({ wave: 5, uccisi: 9, xp: 40, monete: 12, livelli: 0, durata: 140, par: 90, bonus: null });
  ok(String(box.innerHTML).indexOf('nessun premio') > 0, 'fuori tempo lo dice invece di tacere');
  ok(String(box.innerHTML).indexOf('livelli') < 0, 'e senza livelli non mostra la casella dei livelli');

  // le carte: quando non se ne deve nessuna, il pannello spiega perche
  HUD.setBoons({ boons: [], resta: 0, liv: 4, manca: 140, prossimo: 6 }, () => {});
  const bsec = document.getElementById('boonSection'), bsub = document.getElementById('boonSub');
  ok(!bsec.classList.contains('hidden'), 'senza scelte in sospeso la sezione resta visibile');
  ok(String(document.getElementById('boonTitle').textContent).indexOf('NESSUNA') > 0, 'e il titolo non promette una scelta che non c e');
  ok(String(bsub.innerHTML).indexOf('140') > 0 && String(bsub.innerHTML).indexOf('livello 6') > 0, 'e dice a che livello arriva la prossima e quanta XP manca');
  HUD.setBoons({ boons: [], resta: 0, liv: 15, cap: 1, max: 15 }, () => {});
  ok(String(bsub.innerHTML).indexOf('massimo') > 0, 'al tetto dice che la crescita finisce li');
  HUD.setBoons({ boons: [{ id: 'pierce', name: 'Perforazione', icon: '🏹', rarity: 'rare', hero: 'ladro', desc: 'passa attraverso' }], tier: 'rare', tierName: 'Raro', tierColor: '#3aa0ff', scaglione: 2, tot: 4, resta: 1, liv: 6 }, () => {});
  ok(String(bsub.innerHTML).indexOf('2 di 4') > 0, 'a scelta aperta dice a quale scaglione sei');
  // v2.8.1 — "CONCEDIGLI", non "SCEGLI": dopo il colpo di scena la carta non se la prende lui,
  // gliela dai tu. La parola e' la meta' del lavoro che fa questa schermata.
  ok(String(document.getElementById('boonTitle').textContent).indexOf('CONCEDIGLI') > 0, 'e il titolo torna quello del dono');
  ok(String((document.getElementById('boonCards').children[0] || {}).innerHTML).indexOf('DELLA TUA CLASSE') > 0, 'e marca quali sono le abilita della tua classe');
})();


// ===== v1.79 — IL MENU A SEZIONI ===========================================================
(function () {
  console.log('\n-- v1.79: menu a quattro sezioni, scelta in sospeso, inventario');
  const L2 = window.GAME.Loot;
  // le quattro sezioni si sfogliano e una sola resta accesa
  HUD.mostraSezione('personaggio');
  ok(document.getElementById('secPersonaggio').classList.contains('hidden') === false, 'la sezione Personaggio si apre');
  ok(document.getElementById('secRiepilogo').classList.contains('hidden'), 'e le altre si chiudono');
  ok(document.getElementById('tabPersonaggio').classList.contains('on'), 'il pulsante della sezione aperta e evidenziato');
  HUD.mostraSezione('riepilogo');
  ok(!document.getElementById('secRiepilogo').classList.contains('hidden'), 'si torna al riepilogo');

  // finche' c'e' una scelta in sospeso, la mappa successiva non parte
  const quattro = L2.offerteScaglione('mago', 'epic', {}).map(b => ({ id: b.id, name: b.name, icon: b.icon, rarity: b.rarity, hero: b.hero, desc: 'x' }));
  HUD.setBoons({ boons: quattro, tier: 'epic', tierName: 'Epico', tierColor: '#b061ff', scaglione: 3, tot: 4, resta: 1, liv: 9 }, () => {});
  ok(document.getElementById('nextWaveBtn').disabled === true, 'con una scelta aperta il pulsante della mappa e spento');
  ok(!document.getElementById('tabBadge').classList.contains('hidden'), 'e la sezione Abilita porta il richiamo');
  ok(String(document.getElementById('goNota').innerHTML).indexOf('ABILIT') > 0, 'con scritto perche');
  // scelta fatta: si riparte
  HUD.setBoons({ boons: [], resta: 0, liv: 9, prossimo: 12, manca: 500 }, () => {});
  ok(document.getElementById('nextWaveBtn').disabled === false, 'scelta l abilita, il pulsante si accende');
  ok(document.getElementById('tabBadge').classList.contains('hidden'), 'e il richiamo sparisce');

  // v1.87 — l'elenco ha SEI righe: le quattro passive (3, 6, 9, 12) e le due attive (8 e 14)
  HUD.setActiveBoons([{ id: 'crit', icon: '🎯', name: 'Occhio di Falco', rarity: 'uncommon', n: 1, desc: 'critico', on: 1 }]);
  const righe = document.getElementById('abilElenco').innerHTML;
  ok((righe.match(/ab-sc/g) || []).length === 6, 'l elenco ha una riga per ogni scelta della run');
  ok(righe.indexOf('Occhio di Falco') > 0, 'con dentro la passiva gia presa');
  ok(righe.indexOf('si sblocca al livello 14') > 0, 'e dice quando arrivano quelle che mancano');
  ok(righe.indexOf('attiva Q') > 0 && righe.indexOf('attiva E') > 0, 'e i due slot delle abilita attive sono in elenco');

  // v1.85 — LA BARRA DELLE ABILITA': quattro slot, e i due delle attive nascono col lucchetto
  HUD.buildAbilityBar('ladro');
  const barra = document.getElementById('abilityBar');
  ok(barra.children.length === 4, 'la barra ha quattro slot: scatto, arma, Q ed E');
  ok(String(barra.children[2].className).indexOf('locked') >= 0 && String(barra.children[3].className).indexOf('locked') >= 0,
    'Q ed E nascono chiusi');
  ok(String(barra.children[0].className).indexOf('locked') < 0, 'lo scatto no, quello c e da subito');
  ok(String(barra.children[2].innerHTML).indexOf('Livello 8') > 0 && String(barra.children[3].innerHTML).indexOf('Livello 14') > 0,
    'e dicono a che livello si aprono');
  HUD.updateAbilities({ cd: 0, aq: 'ab_velo', cq: 12.4, ae: null, ce: 0 });
  ok(true, 'la barra si aggiorna con l abilita presa senza rompersi');

  // l'inventario
  HUD.setStats({ points: 3, level: 9, rankName: 'Campione', wave: 9, stats: [], inv: {
    hp: 180, hpMax: 240, vite: 2, monete: 77, uccisi: 40, combo: 9,
    arma: { nome: 'Arco Corto', icona: '🏹', livello: 0, evo: '', scuola: 'ranged' },
    gear: [{ slot: 'weapon', slotName: 'Arma', icona: '⚔️', nome: 'Arco Corto', colore: '#8a6534', rango: 1, desc: 'perfora 1' }],
    belt: [{ id: 'p_cura', nome: 'Pozione di Cura', icona: '🧪', n: 2, max: 3 }, null, null],
  } }, () => {}, () => {});
  const inv = document.getElementById('inventario').innerHTML;
  ok(inv.indexOf('180 / 240 PV') > 0, 'l inventario mostra i PV');
  ok(inv.indexOf('Arco Corto') > 0, 'l equipaggiamento');
  ok(inv.indexOf('Pozione di Cura') > 0 && inv.indexOf('2/3') > 0, 'e la cintura con le cariche');
  ok((inv.match(/Arco Corto/g) || []).length === 1, 'e l arma non e scritta due volte');
  ok(inv.indexOf('slot 2 vuoto') > 0, 'gli slot vuoti si vedono');
})();

// ============================================================================
// CLIENT — v2.1: IL CAMPO VISIVO (la torcia)
// Si prova la funzione VERA del renderer, estratta dal file: se qualcuno la riscrive male, qui casca.
// ============================================================================
(function () {
  console.log('\n[CLIENT] Campo visivo v2.1 — la torcia: davanti lontano, dietro poco, e i muri fanno ombra');
  const src2 = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
  const C2 = window.GAME.Constants, T2 = C2.TILE;
  const mp = src2.match(/_fovPortata\(dc\) \{[\s\S]*?\n    \},/);
  const mu = src2.match(/_fovPunte\(px, py, aim, out, off, n\) \{[\s\S]*?\n    \},/);
  const mb = src2.match(/_fovBlocca\(m, i\) \{[\s\S]*?\n    \},/);
  const mc = src2.match(/_fovPortataCono\(dc\) \{[\s\S]*?\n    \},/);
  ok(!!mp && !!mu && !!mb && !!mc, 'le quattro funzioni del campo visivo esistono ancora');
  if (!mp || !mu || !mb || !mc) return;
  // mappa finta: una stanza con un pilastro di roccia a destra del giocatore
  const W2 = 26, H2 = 15, grid = new Uint8Array(W2 * H2).fill(C2.T_FLOOR);
  for (let y = 0; y < H2; y++) { grid[y * W2] = C2.T_WALL; grid[y * W2 + W2 - 1] = C2.T_WALL; }
  for (let x = 0; x < W2; x++) { grid[x] = C2.T_WALL; grid[(H2 - 1) * W2 + x] = C2.T_WALL; }
  for (let y = 5; y <= 9; y++) grid[y * W2 + 9] = C2.T_WALL;
  const mappa = { w: W2, h: H2, tile: T2, grid };
  const mk = (mappa2) => new Function('C', 'map', 'return { map: map, ' +
    mp[0].replace('_fovPortata(', '_fovPortata: function(') + ' ' +
    mc[0].replace('_fovPortataCono(', '_fovPortataCono: function(') + ' ' +
    mb[0].replace('_fovBlocca(', '_fovBlocca: function(') + ' ' +
    mu[0].replace('_fovPunte(', '_fovPunte: function(').replace(/\n    \},$/, '\n    }') + ' };')(C2, mappa2);
  const R2 = mk(mappa);

  // --- 1) LA FORMA A TORCIA: davanti molto piu' lontano che dietro ---
  const av = R2._fovPortata(1), lat = R2._fovPortata(0), di = R2._fovPortata(-1);
  ok(av > lat && lat > di, 'l alone cala girandosi: davanti ' + av.toFixed(0) + ' · di fianco ' + lat.toFixed(0) + ' · dietro ' + di.toFixed(0));
  ok(di > 60, 'e dietro non si e ciechi del tutto (' + di.toFixed(0) + ' px)');
  // v2.1.2 — il FASCIO: molto piu' lungo davanti e praticamente finito di fianco. E' la sua portata a
  // spegnersi da sola, non un ritaglio: e' per questo che non ha bordi da cucire con l'alone.
  const cAv = R2._fovPortataCono(1), c45 = R2._fovPortataCono(Math.SQRT1_2), cLat = R2._fovPortataCono(0), cDi = R2._fovPortataCono(-1);
  ok(cAv > av * 1.8, 'il fascio va molto piu lontano dell alone (' + cAv.toFixed(0) + ' contro ' + av.toFixed(0) + ')');
  ok(cAv > c45 && c45 > cLat, 'e si stringe girandosi: 0 gradi ' + cAv.toFixed(0) + ' · 45 ' + c45.toFixed(0) + ' · 90 ' + cLat.toFixed(0));
  ok(cLat < lat, 'di fianco comanda l alone: il fascio e gia sceso sotto (' + cLat.toFixed(0) + ' contro ' + lat.toFixed(0) + ')');
  ok(cLat < cAv * 0.15, 'e li il fascio ha perso almeno l 85% della sua portata (' + (100 * cLat / cAv).toFixed(0) + '%)');
  ok(cDi === 0 || cDi < 1, 'alle spalle il fascio non c e proprio (' + cDi.toFixed(1) + ')');
  // la continuita': la portata totale non fa salti: fra un grado e l'altro non cambia mai di piu' del 6%
  let salto = 0;
  for (let g = 0; g < 180; g++) {
    const t0 = Math.max(R2._fovPortata(Math.cos(g * Math.PI / 180)), R2._fovPortataCono(Math.cos(g * Math.PI / 180)));
    const t1 = Math.max(R2._fovPortata(Math.cos((g + 1) * Math.PI / 180)), R2._fovPortataCono(Math.cos((g + 1) * Math.PI / 180)));
    salto = Math.max(salto, Math.abs(t1 - t0) / t0);
  }
  ok(salto < 0.06, 'e le due luci si fondono senza gradini: il salto massimo di grado in grado e ' + (salto * 100).toFixed(1) + '%');

  // --- 2) L'OCCLUSIONE: dietro il pilastro non si vede niente ---
  const N2 = 512, buf = new Float32Array(N2 * 4);
  const px2 = 4.5 * T2, py2 = 7.5 * T2;
  R2._fovPunte(px2, py2, 0, buf, 0, N2);          // guarda a destra, verso il pilastro
  const poly = []; for (let i = 0; i < N2; i++) { const o = i * 5; poly.push([px2 + buf[o] * buf[o + 2], py2 + buf[o + 1] * buf[o + 2]]); }
  const dentro = (x, y) => { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    if (((poly[i][1] > y) !== (poly[j][1] > y)) && (x < (poly[j][0] - poly[i][0]) * (y - poly[i][1]) / (poly[j][1] - poly[i][1]) + poly[i][0])) c = !c; } return c; };
  let coperte = 0; for (let y = 6; y <= 8; y++) for (let x = 10; x <= 24; x++) if (dentro(x * T2 + T2 / 2, y * T2 + T2 / 2)) coperte++;
  ok(coperte === 0, 'dietro il pilastro resta buio: la roccia fa ombra (' + coperte + ' tessere passate)');
  let viste = 0; for (let y = 5; y <= 9; y++) for (let x = 5; x <= 8; x++) if (dentro(x * T2 + T2 / 2, y * T2 + T2 / 2)) viste++;
  ok(viste >= 10, 'ma davanti, prima del pilastro, si vede (' + viste + ' tessere su 20)');
  let corridoio = 0; for (let x = 5; x <= 8; x++) if (dentro(x * T2 + T2 / 2, 7 * T2 + T2 / 2)) corridoio++;
  ok(corridoio === 4, 'e dritto davanti si vede fino al pilastro, tessera per tessera (' + corridoio + '/4)');
  // alle spalle la portata e' ~2,5 tessere: la colonna subito dietro si vede, quella dopo no. E' la
  // differenza fra "non si e' ciechi dietro la nuca" e "si vede anche di la'".
  // sulla riga del giocatore: la tessera subito dietro si vede, quella dopo no. E' la differenza fra
  // "non si e' ciechi dietro la nuca" e "si vede anche di la'".
  ok(dentro(2 * T2 + T2 / 2, 7 * T2 + T2 / 2), 'subito dietro le spalle si vede ancora');
  ok(!dentro(1 * T2 + T2 / 2, 7 * T2 + T2 / 2), 'ma due passi piu in la no: alle spalle il buio arriva subito');

  // --- 3) NESSUN RAGGIO ATTRAVERSA UN MURO ---
  let bucati = 0;
  for (let i = 0; i < N2; i++) { const o = i * 5;
    const passi = Math.floor(buf[o + 2] / (T2 * 0.34));
    for (let k = 1; k < passi; k++) { const d = k * T2 * 0.34;
      const tx = ((px2 + buf[o] * d) / T2) | 0, ty = ((py2 + buf[o + 1] * d) / T2) | 0;
      if (grid[ty * W2 + tx] === C2.T_WALL) { bucati++; break; } } }
  ok(bucati === 0, 'nessuno dei ' + N2 + ' raggi attraversa la roccia (' + bucati + ' bucati)');

  // --- 3b) v2.1.1 — L'OMBRA LA FANNO SOLO I MURI. Nel cimitero la griglia e' binaria: una lapide e un
  //     masso sono la stessa tessera. Ma una lapide e' bassa: ci si vede sopra, e non deve proiettare
  //     un cono d'ombra (un campo di lapidi diventava una grattugia).
  {
    const W3 = 20, H3 = 11, g3 = new Uint8Array(W3 * H3).fill(C2.T_FLOOR), mu3 = new Uint8Array(W3 * H3);
    for (let y = 0; y < H3; y++) { g3[y * W3] = C2.T_WALL; g3[y * W3 + W3 - 1] = C2.T_WALL; }
    for (let x = 0; x < W3; x++) { g3[x] = C2.T_WALL; g3[(H3 - 1) * W3 + x] = C2.T_WALL; }
    const colonna = (x, tipo) => { for (let y = 3; y <= 7; y++) { g3[y * W3 + x] = C2.T_WALL; mu3[y * W3 + x] = tipo; } };
    colonna(8, 1);    // una fila di LAPIDI
    colonna(14, 3);   // e piu' in la' la CINTA del cimitero, che e' un muro vero
    const cim = { w: W3, h: H3, tile: T2, grid: g3, muri: mu3 };
    const R3 = mk(cim);
    ok(!R3._fovBlocca(cim, 5 * W3 + 8), 'una lapide non ferma la luce: e alta un ginocchio');
    ok(R3._fovBlocca(cim, 5 * W3 + 14), 'la cinta si');
    ok(R3._fovBlocca(cim, 0), 'e la roccia del bordo pure');
    // gli alberi secchi (4) sono ALTI, e fanno da bordo alla mappa: devono fermare la luce, se no si
    // vedrebbe fuori dal cimitero
    const iAlb = 2 * W3 + 5; g3[iAlb] = C2.T_WALL; mu3[iAlb] = 4;
    ok(R3._fovBlocca(cim, iAlb), 'e un albero secco pure: e alto, e fa da bordo alla mappa');
    const iPie = 2 * W3 + 6; g3[iPie] = C2.T_WALL; mu3[iPie] = 2;
    ok(R3._fovBlocca(cim, iPie), 'e la pietra squadrata delle cappelle');
    const N3 = 256, b3 = new Float32Array(N3 * 4);
    R3._fovPunte(3.5 * T2, 5.5 * T2, 0, b3, 0, N3);      // in fila con lapidi e cinta, guarda a destra
    let oltreLapide = 0, oltreCinta = 0;
    for (let i = 0; i < N3; i++) { const o = i * 5; if (b3[o] < 0.98) continue;
      const arriva = 3.5 + b3[o + 2] / T2;
      if (arriva > 9.5) oltreLapide++;                    // ha superato la fila di lapidi
      if (arriva > 14.5) oltreCinta++; }                  // avrebbe superato la cinta
    ok(oltreLapide > 0, 'e infatti lo sguardo passa SOPRA le lapidi (' + oltreLapide + ' raggi)');
    ok(oltreCinta === 0, 'ma si ferma alla cinta (' + oltreCinta + ' raggi passati)');
  }

  // --- 3c) v2.1.3 — LA PENOMBRA. Il velo si sfoca quando lo si appoggia, cosi' il bordo dell'ombra di un
  //     muro non e' un taglio netto. Due cose vanno insieme e si rompono insieme: la sfocatura, e il
  //     MARGINE della tela del velo — senza margine il bordo sfumato cadrebbe sul bordo dello schermo e
  //     si vedrebbe una cornice chiara tutt'attorno.
  ok((C2.FOV_SFUMA || 0) > 0, 'la sfumatura delle ombre e accesa (' + C2.FOV_SFUMA + ' px)');
  ok(/g\.filter = 'blur\('/.test(src2), 'e il renderer la applica sfocando il velo');
  ok(/_veloM: \d+/.test(src2), 'la tela del velo ha un margine oltre lo schermo');
  const mM = src2.match(/_veloM: (\d+)/);
  ok(mM && +mM[1] > (C2.FOV_SFUMA || 0) * 2, 'e il margine (' + (mM ? mM[1] : '?') + ' px) e piu largo del doppio della sfocatura: il bordo sfumato cade fuori dallo schermo');
  ok(/drawImage\(this\._veloCv, -M, -M/.test(src2), 'infatti il velo si appoggia partendo da -M, non da zero');

  // --- 3d) v2.1.4 — LA TORCIA PARTE ACCESA. Lo strato del tasto L completa il campo visivo, quindi e'
  //     acceso di suo. Chi l'aveva spento in passato aveva uno '0' salvato nel browser che comandava per
  //     sempre: la chiave ha cambiato nome, cosi' il vecchio valore non conta piu' e la scelta nuova
  //     resta comunque ricordata.
  ok(/torch: true/.test(src2), 'la torcia nasce accesa');
  ok(/localStorage\.getItem\('dr_torcia'\) !== '0'/.test(src2), 'e si spegne solo se e stata spenta DOPO questa versione (chiave nuova)');
  ok(!/'dr_torch'/.test(src2), 'la vecchia chiave non si legge piu: chi aveva spento riparte acceso, una volta');
  ok(/setItem\('dr_torcia'/.test(src2), 'ma il tasto L continua a ricordarsi la scelta');
  ok(/if \(this\.map\.lit\) return;/.test(src2), 'e nel villaggio lo strato non si applica comunque');

  // --- 3e) v2.3 — LE LANTERNE DEI GIROVAGHI SI SPENGONO USCENDO DAL VILLAGGIO. L'elenco delle loro
  //     posizioni si azzera a OGNI fotogramma, non quando si disegnano: se si azzerasse solo la' dentro,
  //     in mezzo alla grotta resterebbero accese delle lanterne senza nessuno che le porta.
  ok(/if \(this\._giroLuci\) this\._giroLuci\.length = 0;/.test(src2), 'le lanterne dei girovaghi si azzerano a ogni fotogramma');
  {
    const i1 = src2.indexOf('if (this._giroLuci) this._giroLuci.length = 0;');
    const i2 = src2.indexOf('village.girovaghi');
    ok(i1 > 0 && i2 > 0 && i1 < i2, 'e si azzerano PRIMA di ridisegnarli, non dopo');
  }


  // --- 3f) v2.4 — IL VILLAGGIO E' BUIO, E LA LUCE LA FANNO LE SORGENTI. Dalla v2.2 al v2.3 sopra al
  //     villaggio c'era una VELATURA: un rettangolo semitrasparente steso su tutto. Un velo uniforme non
  //     scurisce, SBIANCA — schiarisce i neri tanto quanto spegne i chiari — e il risultato era una patina
  //     grigia. Adesso il villaggio e' quasi nero e ogni sorgente ci scava dentro il suo buco.
  ok(!/VILL_OMBRA/.test(src2), 'la velatura del villaggio non c e piu (VILL_OMBRA sparito dal renderer)');
  ok((C2.VILL_BUIO || 0) >= 0.8, 'il villaggio e buio dove non arriva luce (' + C2.VILL_BUIO + ')');
  ok(/destination-out[\s\S]{0,2600}this\.campfires\) buco/.test(src2) || /const buco = \(/.test(src2),
    'e le sorgenti ci scavano dentro i loro buchi, invece di aggiungere grigio sopra');
  // "area doppia" e' RADICE DI DUE sul raggio, non due: al primo tentativo avevo raddoppiato il raggio,
  // che e' area quadrupla, e il villaggio si e' acceso tutto.
  const K = C2.VILL_LUCE || 1;
  ok(K > 1.2 && K < 1.7, 'ogni sorgente illumina il doppio di area (raggio x' + K + ' = area x' + (K * K).toFixed(2) + ')');
  ok(Math.abs(K * K - 2) < 0.3, 'e il conto torna: area x' + (K * K).toFixed(2) + ', non x4');
  ok(/const KL = this\.map\.lit \? \(C\.VILL_LUCE/.test(src2),
    'il moltiplicatore vale anche per il colore caldo, non solo per il buco: se no resta un alone grigio con un puntino in mezzo');
  ok((C2.VILL_EROE || 0) > 60, 'e ci si porta dietro un cerchietto, per non essere ciechi fra una luce e l altra');

  // --- 4) SOLO LE MAPPE DI COMBATTIMENTO. Il villaggio dichiara `lit` e non ha campo visivo ---
  const MG2 = window.GAME.MapGen;
  ok(!!MG2.generateMarket(1).lit, 'il villaggio e illuminato (lit)');
  for (const lv of [1, 5, 10, 20]) ok(!MG2.generate(31, lv).lit, 'l ondata ' + lv + ' no: li c e la torcia');
  ok(/if \(_lit \? null : this\._fovSagome/.test(src2) || /_lit \? null : this\._fovSagome/.test(src2),
    'e il renderer calcola il campo visivo SOLO quando la mappa non e illuminata');

  // --- 5) v2.5 — LA PATINA VERA ERA LA NEBBIA. In v2.4 avevo tolto la velatura e il villaggio era ancora
  //     appannato: `_drawFog` stende QUATTORDICI macchie grigio-azzurre sull'inquadratura a ogni
  //     fotogramma, e quelle nessuno le aveva toccate. Lezione: quando si toglie una cosa, si controlla
  //     anche quello che NON si e' toccato. Qui il controllo e' che la nebbia sia dietro un `if`.
  ok(/if \(!this\.map\.lit\) this\._drawFog\(/.test(src2),
    'la nebbia non entra nel villaggio: e LEI la patina che restava dopo la v2.4');
  {
    const iF = src2.indexOf('_drawFog(ctx');
    const chiama = src2.match(/this\._drawFog\(/g) || [];
    ok(chiama.length === 1, 'e si chiama da un posto solo (' + chiama.length + '), se no la guardia serve a poco');
    ok(iF > 0, 'la nebbia esiste ancora: nelle grotte ci va');
  }

  // --- 5b) v2.5 — I PAESANI NON SONO EROI RICOLORATI. Prima usavano tutti la sagoma del ladro e sembravano
  //     sette gemelli. Adesso hanno un disegno loro. Due tentativi sbagliati prima di arrivarci:
  //     un ovale con un pallino di fianco (sassi con la faccia), poi un cerchio con due moncherini dietro
  //     (Topolino). Quello che fa la differenza dall'alto e' la PROPORZIONE: corpo schiacciato davanti-
  //     dietro e largo di traverso (le spalle), testa che SPORGE, braccia ai lati con le mani in punta.
  const R5 = window.Renderer;
  ok(Array.isArray(R5._PAESANI) && R5._PAESANI.length >= 7, 'ci sono almeno sette tipi di paesano (' + (R5._PAESANI || []).length + ')');
  for (const tp of R5._PAESANI) ok(!!R5._paesaniPal[tp], 'il tipo ' + tp + ' ha una sua tavolozza');
  {
    // ogni tipo deve avere un COLORE DI VESTE diverso: se due sono uguali, da lontano sono lo stesso paesano
    const vesti = R5._PAESANI.map(t => R5._paesaniPal[t].veste);
    ok(new Set(vesti).size === vesti.length, 'e nessuno veste come un altro (' + new Set(vesti).size + '/' + vesti.length + ' colori distinti)');
    // la proporzione delle spalle: larghe di traverso, strette davanti-dietro. E' l'unica cosa che
    // separa una persona vista dall'alto da un sasso, e sta scritta nei due raggi dell'ellisse del busto.
    const mB = /g\.ellipse\(-rr \* 0\.08, 0, rr \* ([\d.]+), rr \* ([\d.]+)/.exec(src2);
    ok(!!mB, 'il busto e disegnato con un ellisse');
    if (mB) ok(+mB[2] > +mB[1] * 1.5, 'e le spalle sono larghe di traverso (' + mB[2] + ') molto piu che profonde (' + mB[1] + ')');
    // la testa sporge: il suo centro sta oltre il raggio del busto, se no e' una faccia dentro al corpo
    const mT = /const hx = rr \* ([\d.]+), hr = rr \* ([\d.]+)/.exec(src2);
    ok(!!mT, 'la testa ha una posizione dichiarata');
    if (mT && mB) ok(+mT[1] > +mB[1], 'e sporge davanti alle spalle (hx ' + mT[1] + ' > profondita busto ' + mB[1] + ')');
    ok(/g\.fillStyle = P\.pelle;\s*\n\s*g\.beginPath\(\); g\.arc\(rr \* 0\.44, 0, rr \* 0\.13/.test(src2),
      'e in punta alle braccia c e la mano: sono le mani che fanno leggere le braccia');
  }
  ok(/this\._ePaesano\(n\.kind\)\) this\._paesano\(/.test(src2), 'e chi e un paesano si disegna col disegno del paesano, non con quello dell eroe');
  for (const k of ['guerriero', 'ladro', 'mago', 'arciere']) ok(!R5._ePaesano(k), 'l eroe ' + k + ' resta col suo pattern (non toccato)');

  // --- 5c) v2.5 — LE BOTTEGHE DI CONTORNO. Un villaggio con cinque negozi usabili e cinque case non e' un
  //     villaggio: e' un menu. Le bancarelle servono a riempire, non a essere cliccate — quindi hanno un
  //     corpo solido (ci si gira attorno) ma NON sono mercanti: niente `kind` da negozio, niente dialogo.
  {
    const m5 = MG2.generateMarket(1);
    const banchi = (m5.props || []).filter(p => p.type === 'bancarella');
    ok(banchi.length >= 6, 'ci sono almeno sei bancarelle di contorno (' + banchi.length + ')');
    const mest = new Set(banchi.map(b => b.mest));
    ok(mest.size === banchi.length, 'e ognuna fa un mestiere diverso (' + [...mest].join(', ') + ')');
    // la prova che sono DI CONTORNO: non compaiono fra i mercanti, quindi non c'e' niente da cliccare
    const negozi = new Set((m5.village.npcs || []).map(n => n.kind));
    for (const b of banchi) ok(!negozi.has(b.mest), 'il banco ' + b.mest + ' non e un mercante: non si puo usare');
    const cart = (m5.props || []).filter(p => p.type === 'signpost' && p.txt);
    ok(cart.length >= banchi.length, 'e ognuna ha la sua insegna (' + cart.length + ' insegne)');
    // ma ingombra: per ogni banco ci deve essere un rettangolo solido sopra, se no ci si passa dentro
    const senza = banchi.filter(b => !(m5.solids || []).some(s => s.t === 'r' && Math.abs(s.x - b.x) < 2 && Math.abs(s.y - b.y) < 2));
    ok(senza.length === 0, 'e ognuna ingombra: ci si gira attorno (' + senza.length + ' banchi attraversabili)');
  }

  // --- 5d) v2.5 — IL MIMIC E' UNA RARITA'. Al 30% per cassa capitava tre volte per ondata e smetteva di
  //     essere una sorpresa: diventava una tassa. Il conto giusto si fa per ONDATA, non per cassa.
  ok((C2.MIMIC_PROB || 1) <= 0.10, 'un mimic e raro (' + ((C2.MIMIC_PROB || 0) * 100).toFixed(0) + '% a cassa)');
  {
    const casse = 4, p = C2.MIMIC_PROB;                 // la probabilita' che in un'ondata ce ne sia almeno uno
    const perOndata = 1 - Math.pow(1 - p, casse);
    ok(perOndata < 0.35, 'cioe meno di un ondata su tre (' + (perOndata * 100).toFixed(0) + '%), non tre a ondata');
  }

  // --- 6) v2.6 — LA PATINA ERA UNO SFASAMENTO. Dopo la v2.5 il villaggio era ancora velato, e stavolta
  //     non era uno strato di troppo: il buio si bucava con un raggio e il bagliore caldo si disegnava
  //     con un ALTRO. L'alone dell'eroe usciva a 190x1,45 = 275 px dentro un buco di 130: quei 145 px di
  //     differenza sono luce appoggiata sul buio, cioe' una patina, e ti seguiva perche' l'eroe sei tu.
  //     Il rimedio non e' limare un numero: e' che i due passaggi leggano LA STESSA LISTA.
  ok(/const VS = this\._villSrc \|\| \(this\._villSrc = \[\]\); VS\.length = 0;/.test(src2),
    'le sorgenti del villaggio si dichiarano in una lista sola');
  ok(/for \(const s of VS\) buco\(s\[0\], s\[1\], s\[2\], s\[5\]\);/.test(src2),
    'e il buio si buca leggendo quella');
  ok(/if \(_lit\) \{ for \(const s of this\._villSrc\) light\(s\[0\], s\[1\], s\[2\], s\[3\], s\[4\]\); \}/.test(src2),
    'e la luce calda si accende leggendo la stessa, con gli stessi raggi: nessun bagliore senza il suo buco');
  { // e la riga con l'alone da 190 vive solo nel ramo delle GROTTE, dopo l'else
    const iL = src2.indexOf("if (_lit) { for (const s of this._villSrc) light(");
    const i190 = src2.indexOf("light(p.x, p.y, 190,");
    ok(iL > 0 && i190 > iL, 'e l alone da 190 resta nel ramo delle grotte, dopo l else');
  }

  // --- 6b) v2.6 — LA COTTURA. Il villaggio passa dalla stessa cottura delle grotte: pavimento di roccia,
  //     massi tondi, ombre proiettate. La cottura piatta era una tinta uniforme senza nero, ed e'
  //     esattamente quello che si vedeva come pellicola. I pavimenti delle stanze restano dipinti sopra.
  ok(/const _nuova = true;/.test(src2), 'anche il villaggio si cuoce come una grotta');
  ok(/if \(!m\.lit\) \{ const M = \(C\.EDGE_MARGIN/.test(src2),
    'e la fascia viola della faglia non si cuoce sul villaggio: li non c e nessuna faglia ai bordi');
  { const MG3 = window.GAME.MapGen, mv = MG3.generateMarket(7);
    ok(!!mv.muri, 'il villaggio dichiara il TIPO dei suoi muri');
    const t2 = new Set(Array.from(mv.muri)); t2.delete(0);
    ok(t2.size === 1 && t2.has(2), 'conci per le case (2), roccia di grotta per tutto il resto (0)');
    let conci = 0, roccia = 0;
    for (let i = 0; i < mv.muri.length; i++) if (mv.grid[i] === C2.T_WALL) { if (mv.muri[i] === 2) conci++; else roccia++; }
    ok(roccia > conci, 'e la roccia e piu dei conci: il paese e SCAVATO, non costruito (' + roccia + ' contro ' + conci + ')');
    // il perimetro esterno non e' mai concio: e' la montagna
    let bordoConcio = 0;
    for (let x = 0; x < mv.w; x++) { if (mv.muri[x] === 2) bordoConcio++; if (mv.muri[(mv.h - 1) * mv.w + x] === 2) bordoConcio++; }
    for (let y = 0; y < mv.h; y++) { if (mv.muri[y * mv.w] === 2) bordoConcio++; if (mv.muri[y * mv.w + mv.w - 1] === 2) bordoConcio++; }
    ok(bordoConcio === 0, 'il giro esterno e tutto roccia di grotta (' + bordoConcio + ' conci sul bordo)');
    // il pavimento: la piazza e' TERRA, le stanze tengono il loro, lo spiazzo non e' dipinto (resta grotta)
    const pav = mv.floors;
    ok(pav.filter(f => f.kind === 'terra').length >= 1, 'la piazza e terra battuta');
    const pz2 = pav.find(f => f.kind === 'terra');
    ok(pz2.x0 === mv.piazza.x0 && pz2.y1 === mv.piazza.y1, 'e il battuto copre esattamente la piazza');
    ok(pav.some(f => f.kind === 'legno'), 'dentro le case il pavimento resta quello di prima (assi)');
    // lo spiazzo attorno alla piazza NON ha un pavimento dichiarato: li si vede la roccia cotta
    const coperto = (x, y) => pav.some(f => x >= f.x0 && x <= f.x1 && y >= f.y0 && y <= f.y1);
    ok(!coperto(mv.piazza.x0 - 3, mv.piazza.y0 - 3), 'e fuori dalla piazza il pavimento e quello della grotta');
  }
  ok((C2.VILL_PIAZZA || 1) < (C2.VILL_BUIO || 1), 'nella piazza il buio vale meno che fuori: piazza chiara, resto buio');
  ok((C2.VILL_PZ_ORLO || 0) > 0, 'e il passaggio fra i due sfuma invece di tagliare');

  // --- 6c) v2.6 — LA GUARDIA e L’ORACOLO. Due figure nuove, e nessuna delle due e' un eroe ricolorato.
  ok(R5._PAESANI.indexOf('guardia') >= 0, 'la guardia e un paesano, col suo disegno');
  ok(!!R5._paesaniPal.guardia, 'e la sua tavolozza');
  ok(!/seer:/.test(src2), 'della cartomante non resta traccia nel renderer');
  ok(/oracolo:/.test(src2), 'al suo posto c e l’oracolo');
  ok(/_vendorBase: \{[^}]*oracolo: 'mago'/.test(src2), 'l’oracolo ha la sua base');
  ok(/kind === 'oracolo'/.test(src2), 'e i suoi attrezzi: bastone, ossa, ciotola dei fumi');

  // --- 6d) v2.6 — I DODICI BANCHI. Ogni mestiere ha il suo disegno: chi arrivava al ramo finale senza
  //     un caso suo vendeva candele, e con dodici banchi me ne sarei accorto tardi.
  { const MG4 = window.GAME.MapGen, mv2 = MG4.generateMarket(3);
    const banchi = mv2.props.filter(p => p.type === 'bancarella');
    ok(banchi.length >= 10, 'attorno alla piazza ci sono almeno dieci banchi (' + banchi.length + ')');
    const mest = banchi.map(b => b.mest);
    ok(new Set(mest).size === mest.length, 'e nessun mestiere si ripete');
    for (const b of banchi) ok(new RegExp("me === '" + b.mest + "'").test(src2) || b.mest === 'vino',
      'il banco ' + b.mest + ' ha il suo disegno, non quello di ripiego');
    // e stanno TUTTI attorno alla piazza, non sparsi per il paese
    const PZ3 = mv2.piazza, T3 = C2.TILE;
    let lontani = 0;
    for (const b of banchi) { const tx = b.x / T3 - 0.5, ty = b.y / T3 - 0.5;
      if (tx < PZ3.x0 - 3 || tx > PZ3.x1 + 3 || ty < PZ3.y0 - 3 || ty > PZ3.y1 + 3) lontani++; }
    ok(lontani === 0, 'e fanno il giro della piazza (' + lontani + ' fuori dal giro)');
    const torce = mv2.props.filter(p => p.type === 'brazier' && Math.abs(p.x / T3 - 0.5 - (PZ3.x0 + PZ3.x1) / 2) <= (PZ3.x1 - PZ3.x0) / 2 + 2
      && Math.abs(p.y / T3 - 0.5 - (PZ3.y0 + PZ3.y1) / 2) <= (PZ3.y1 - PZ3.y0) / 2 + 2);
    ok(torce.length >= 8, 'e le torce fanno il giro con loro (' + torce.length + ')');
  }

  // --- 7) v2.7 — LA STORIA lato interfaccia. Il testo sta in shared/storia.js e il client lo legge da
  //     li': se un domani qualcuno lo riscrive dentro l'HTML, questo blocco se ne accorge.
  {
    const St = window.GAME.Storia;
    ok(!!St, 'il testo della storia arriva al client');
    ok(St.prologo.righe.every(q => q.chi !== 'oracolo'), 'nel risveglio l’oracolo non si presenta');
    ok(St.prologo.righe.some(q => q.chi === ''), 'la voce che parla non ha volto');
    ok(St.oracolo.righe.some(q => q.chi === 'tu'), 'e il discorso dell’oracolo e un dialogo');
    // i pezzi dell'interfaccia esistono, e sono quelli che il codice cerca per id
    const src3 = fs.readFileSync(ROOT + 'public/index.html', 'utf8');
    for (const id of ['dial', 'dialChi', 'dialTxt', 'dialHint', 'quest', 'questT', 'questD'])
      ok(new RegExp('id="' + id + '"').test(src3), 'la pagina ha #' + id);
    ok(/shared\/storia\.js/.test(src3), 'e carica il file della storia');
    const srcH = fs.readFileSync(ROOT + 'public/js/hud.js', 'utf8');
    ok(/mostraDialogo\(/.test(srcH) && /nascondiDialogo\(/.test(srcH), 'l HUD sa aprire e chiudere i sottotitoli');
    ok(/dialogoFretta\(/.test(srcH), 'e il primo Spazio finisce la riga invece di saltarla');
    // v2.9 — LE PAUSE: le didascalie del copione ("Pausa.", "l’oracolo sorride appena") non si stampano,
    // si sentono. Una riga marcata `p` aspetta in silenzio col volto a schermo prima di cominciare.
    ok(/PAUSA:/.test(srcH) && /pausa \? this\.PAUSA : 0/.test(srcH), 'e una riga marcata aspetta prima di scriversi');
    ok(St.oracolo.righe.some(q => q.p), 'e nel discorso dell’oracolo ci sono le pause');
    // v2.9.3 — le tre scene della guardia e il suo ritratto sono rimasti nel progetto ma NON LI USA
    // NESSUNO (vedi la nota su VILL_AVVISI in constants.js: Spazio spara ed e' anche il tasto che fa
    // scorrere i dialoghi). Si continua a controllare che il testo sia sano, cosi' non marcisce.
    for (const k of ['guardia1', 'guardia2', 'guardia3'])
      ok(St[k] && St[k].righe.length > 0 && St[k].righe.every(q => q.chi === 'guardia'), 'la scena ' + k + ' e ancora sana (ma spenta)');
    ok(/missione\(m\)/.test(srcH), 'e sa mostrare la missione');
    // v2.8 — il riquadro sta al centro, ha il ritratto di chi parla, e mentre parla non ci si muove
    ok(/ritratto\(chi, eroeId\)/.test(srcH), 'l HUD disegna il ritratto di chi parla');
    for (const k of ['guerriero', 'mago', 'ladro', 'oracolo', 'guardia'])
      ok(new RegExp(k + ':').test(srcH), 'e ha una tavolozza per ' + k);
    // v2.9.3 — il ritratto della guardia resta disegnato, per quando la regola del villaggio si rifara'.
    ok(/chi === 'guardia'/.test(srcH), 'e la guardia ha il suo ritratto, non quello del guerriero');
    ok(/if \(!chi\) \{ cv\.classList\.add\('vuoto'\); return; \}/.test(srcH),
      'ma la voce senza volto del risveglio non ne ha uno: e la scena, non una mancanza');
    // v2.7 — nella cella non si conta nessuna ondata: "ONDATA 0/20" sul risveglio e la cosa piu' stonata
    ok(/snap\.phase === 'prologo'/.test(srcH), 'e nella cella la barra delle ondate sparisce');
    const srcM = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
    ok(/storiaDaSnap\(snap\.st\)/.test(srcM), 'la riga in corso arriva dallo SNAPSHOT, non solo dagli eventi');
    ok(/if \(G\._st === k\) return;/.test(srcM), 'e non si riscrive venti volte al secondo la stessa riga');
    ok(/mostraDialogo\([^)]*!!r\.p\)/.test(srcM), 'e la pausa la decide il copione, non il codice');
    ok(/Net\.storiaAvanti\(true\)/.test(srcM), 'Esc salta');
    ok(/if \(!HUD\.dialogoFretta\(\) && G\.capo !== false\) Net\.storiaAvanti\(false\)/.test(srcM), 'Spazio prima finisce la riga, poi passa oltre');
    // il CSS: i due pezzi non devono rubare la scena
    const srcC = fs.readFileSync(ROOT + 'public/style.css', 'utf8');
    ok(/#dial\{/.test(srcC) && /#quest\{/.test(srcC), 'e hanno il loro stile');
    ok(/#dial[^}]*pointer-events:none/.test(srcC), 'il riquadro non intercetta il mouse: sotto c e il gioco');
    ok(/#dial\{[^}]*left:50%/.test(srcC) && /#dial\{[^}]*top:/.test(srcC), 'e sta al centro dello schermo, non ai piedi');
    ok(/#dialFaccia\{/.test(srcC), 'e il ritratto ha la sua cornice');
    ok(/#quest[^}]*pointer-events:none/.test(srcC), 'e nemmeno la missione');

    // --- v2.8.1 — LE RIGHE DEL DONO nel menu di fine ondata ---
    // Dopo il colpo di scena questa schermata diceva una cosa FALSA: "dove metti quello che hai
    // imparato". Lui non impara: riceve. Il testo sta in storia.js come tutto il resto del parlato.
    ok(!!St.menu, 'il menu di fine ondata ha i suoi testi, e stanno in storia.js');
    for (const k of ['cornice', 'patto', 'punti', 'emporio', 'abilita', 'rango', 'poteri', 'riparti'])
      ok(typeof St.menu[k] === 'string' && St.menu[k].length > 3, 'c e la riga "' + k + '"');
    // v2.8.2 — la parola che regge tutta la schermata: chi legge deve trovarci scritto AVATAR, se no
    // "dona" e "concedi" restano parole senza un soggetto e il colpo di scena non arriva fin qui.
    ok(/avatar/i.test(St.menu.abilita + St.menu.rango + St.menu.poteri), 'e la schermata nomina l avatar');
    ok(!/quello che hai imparato/.test(src3), 'e la frase vecchia ("quello che hai imparato") non c e piu: era falsa');
    ok(!/LE TUE ABILIT/.test(src3), 'e nemmeno "LE TUE ABILITA": adesso dice di chi sono e chi le ha date');
    ok(/CONCEDIGLI UN/.test(src3) && /CONCEDIGLI UN/.test(srcH), 'la carta si CONCEDE, non si sceglie');
    for (const id of ['menuCornice', 'menuPatto', 'notaPunti', 'notaEmporio', 'notaRango', 'notaAbilita', 'titoloPoteri'])
      ok(new RegExp('id="' + id + '"').test(src3), 'la pagina ha #' + id);
    ok(/_righeDono\(\)/.test(srcH), 'e l HUD le va a mettere al loro posto');
    // il PATTO si vede una volta sola: letto venti volte sarebbe rumore
    ok(/pat\.classList\.toggle\('hidden', w !== 1\)/.test(srcH), 'e il patto compare solo a fine ondata 1');
    // e nessuna di queste righe e' un paragrafo: si leggono di sfuggita fra un ondata e l altra
    const lungheM = Object.keys(St.menu).filter(k => k !== 'patto' && St.menu[k].length > 100);
    ok(lungheM.length === 0, 'e sono corte (la sola lunga e il patto, che si legge una volta)');
  }
})();

// --- v2.10 — IL MIRINO AL GUINZAGLIO ---------------------------------------------------------------
// Qui si prova la REGOLA, non il disegno: `input.js` e' caricato davvero e gli si fanno arrivare degli
// eventi di mouse finti, poi si guarda dove finisce il mirino. E' la parte che decide dove spari, quindi
// vale la pena provarla senza browser: cosi' un domani si rompe qui e non in mano a chi gioca.
(function () {
  const listeners = {};
  const fakeCanvas = {
    addEventListener(k, f) { (listeners[k] = listeners[k] || []).push(f); },
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 1000, height: 600 }),
    requestPointerLock() { this._chiesto = true; },
  };
  // la finestra finta e' ANCHE la sandbox: input.js si pubblica su `window.Input`, quindi deve essere
  // lo stesso oggetto che gli passiamo e su cui registra i suoi ascoltatori.
  const win = { addEventListener() {}, Input: null };
  const doc = { addEventListener() {}, pointerLockElement: null, activeElement: null, exitPointerLock() {} };
  new Function('window', 'document', fs.readFileSync(ROOT + 'public/js/input.js', 'utf8'))(win, doc);
  const I = win.Input;
  ok(!!I, 'input.js si carica e pubblica Input');
  I.init(fakeCanvas);
  const muovi = (x, y) => { for (const f of (listeners.mousemove || [])) f({ clientX: x, clientY: y, movementX: 0, movementY: 0 }); };
  const dist = () => Math.hypot(I.mira.x, I.mira.y);
  const gradi = () => Math.round(Math.atan2(I.mira.y, I.mira.x) * 180 / Math.PI);

  ok(I.MIRA_R === 200, 'il guinzaglio e 200px (' + I.MIRA_R + ')');
  // il centro del canvas finto e' (500, 300)
  muovi(590, 300);
  ok(Math.round(dist()) === 90, 'dentro il raggio il mirino segue il cursore (' + Math.round(dist()) + 'px)');
  ok(!I.alBordo, 'e non sta premendo contro il limite');
  muovi(999, 300);                       // 499px a destra: ben oltre
  ok(Math.round(dist()) === 200, 'oltre il raggio si ferma a 200 (' + Math.round(dist()) + 'px)');
  ok(I.alBordo, 'e sa di starci premendo contro');
  ok(gradi() === 0, 'ma la DIREZIONE resta quella del cursore (' + gradi() + ' gradi)');
  // l angolo si conserva anche in diagonale: e' la cosa che conta, perche' e' cio' che si manda al server
  // in alto a sinistra: il centro del canvas finto e' (500, 300), quindi lo scostamento e' (-500, -300)
  // e l'angolo vale atan2(-300, -500) = -149 gradi. Clampare accorcia il vettore, non lo ruota.
  muovi(0, 0);
  ok(Math.round(dist()) === 200, 'anche in diagonale si ferma a 200 (' + Math.round(dist()) + 'px)');
  ok(gradi() === -149, 'e punta sempre li: clampare accorcia, non ruota (' + gradi() + ' gradi)');
  // il centro esatto non ha un angolo: non deve produrre NaN, o la mira si rompe
  muovi(500, 300);
  const b = I.build(500, 300);
  ok(isFinite(b.aim), 'col cursore esattamente sul personaggio l angolo resta un numero (' + b.aim + ')');
  // e cio' che si manda al server e' l angolo del MIRINO, non piu' quello del cursore
  muovi(999, 300);
  ok(Math.abs(I.build(500, 300).aim) < 1e-9, 'l angolo mandato al server e quello del mirino clampato');
  // il pointer lock: accumula gli spostamenti invece di seguire una posizione
  doc.pointerLockElement = fakeCanvas; I.locked = true;
  I.mira.x = 0; I.mira.y = 0;
  for (const f of (listeners.mousemove || [])) f({ clientX: 0, clientY: 0, movementX: 40, movementY: 0 });
  ok(Math.round(I.mira.x) === 40, 'agganciato, il mirino si muove degli SPOSTAMENTI (' + Math.round(I.mira.x) + ')');
  for (let k = 0; k < 30; k++) for (const f of (listeners.mousemove || [])) f({ clientX: 0, clientY: 0, movementX: 40, movementY: 0 });
  ok(Math.round(dist()) === 200, 'e anche spingendo all infinito il guinzaglio tiene (' + Math.round(dist()) + 'px)');
  // il disegno c e, e il CSS non mostra piu' due puntatori
  const srcR = fs.readFileSync(ROOT + 'public/js/renderer.js', 'utf8');
  ok(/_drawMirino\(/.test(srcR), 'il renderer disegna il mirino');
  // v2.11.1 — l'anello a 200px e' stato TOLTO: si accendeva e si spegneva addosso al personaggio ed era
  // rumore. Il limite si capisce dal mirino che si ferma.
  ok(!/arc\(cx, cy, I\.MIRA_R/.test(srcR), 'ma non l anello del guinzaglio: era brutto ed e stato tolto');
  ok(/if \(!I\.guinzaglio\) return;/.test(srcR), 'e nel villaggio non disegna niente: li comanda il cursore del sistema');
  ok(/cursor:none/.test(fs.readFileSync(ROOT + 'public/style.css', 'utf8')), 'e il cursore del sistema sul canvas e nascosto: un puntatore solo');
  const srcMm = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
  ok(/Input\.aggancia\(\)/.test(srcMm), 'il clic aggancia il pointer lock');
  ok(/Input\.locked && \(inVillaggio \|\| !inPartita\(\)\)/.test(srcMm), 'e si sgancia coi pannelli aperti E nel villaggio, se no i pulsanti non si cliccano');
  // v2.11.1 — IL BUG: nel villaggio il mouse serve a cliccare i banchi, e col pointer lock il cursore
  // non esiste. Guinzaglio spento, cursore di sistema di nuovo visibile.
  ok(/Input\.setGuinzaglio\(!inVillaggio\)/.test(srcMm), 'nel villaggio il guinzaglio si spegne');
  ok(/classList\.toggle\('libero', inVillaggio \|\| !inPartita\(\)\)/.test(srcMm), 'e il cursore del sistema torna visibile');
  ok(/canvas#game\.libero\{cursor:crosshair\}/.test(fs.readFileSync(ROOT + 'public/style.css', 'utf8')), 'e il CSS glielo permette');
  // a guinzaglio spento il mirino va dove vuole: e' il cursore vero a comandare
  I.locked = false; doc.pointerLockElement = null;
  I.setGuinzaglio(false);
  muovi(999, 300);
  ok(Math.round(dist()) === 499, 'col guinzaglio spento il mirino segue il cursore ovunque (' + Math.round(dist()) + 'px)');
  ok(!I.alBordo, 'e non c e nessun bordo contro cui premere');
  fakeCanvas._chiesto = false; I.aggancia();
  ok(!fakeCanvas._chiesto, 'e non si aggancia nemmeno il pointer lock: il cursore serve per cliccare');
  // e riaccendendolo il mirino si riaccorcia SUBITO, senza aspettare il prossimo movimento del mouse
  I.setGuinzaglio(true);
  ok(Math.round(dist()) === 200, 'riaccendendolo il mirino rientra subito (' + Math.round(dist()) + 'px)');
})();

// --- v2.11.2 — LA CARTA CLICCATA MENTRE IL PANNELLO SI CHIUDE -------------------------------------
// `hideShop()` azzera `_boons`. Se il pannello si chiude nello stesso fotogramma in cui clicchi una carta
// — cambia la fase: parte l'ondata, o si va al villaggio — il gestore del clic scriveva su `null` e
// sollevava: la scelta arrivava al server ma il pannello NON si ridisegnava, e a schermo restava la carta
// come se il clic non fosse mai avvenuto. Visto in un controllo nel browser, non immaginato.
(function () {
  const srcH = fs.readFileSync(ROOT + 'public/js/hud.js', 'utf8');
  ok(/if \(this\._boons\) this\._boons\.picked = true;/.test(srcH), 'il clic su una carta regge anche se il pannello si e appena chiuso');
  ok(/if \(this\._rank\) this\._rank\.picked = true;/.test(srcH), 'e lo stesso vale per la carta di rango');
  // e la prova vera: si sceglie, poi si chiude il pannello, poi si riclicca la stessa carta
  HUD.setBoons({ tier: 'rare', boons: [{ id: 'ab_carica', name: 'Carica', icon: '\u26A1', rarity: 'rare', desc: 'x', owned: 0, max: 1 }], abil: 1, slot: 'q' }, () => {});
  HUD.hideShop();
  let esploso = false;
  try { const row = document.getElementById('boonCards'); const c = row.children[0]; if (c && c.onclick) c.onclick(); }
  catch (_) { esploso = true; }
  ok(!esploso, 'e non solleva nemmeno provandoci davvero');
})();

// --- v2.11 — IL SALVATAGGIO, lato interfaccia ------------------------------------------------------
(function () {
  const SV = window.GAME.Salvataggio;
  ok(!!SV, 'il modulo del salvataggio arriva anche al client');
  ok(/shared\/salvataggio\.js/.test(fs.readFileSync(ROOT + 'public/index.html', 'utf8')), 'e la pagina lo carica');
  // l'etichetta del pulsante: e' l'unica cosa che il menu deve saper leggere dal pacchetto
  const finto = { f: SV.FORMATO, heroId: 'ladro', level: 11, ondata: 7, nome: 'Tizio', quando: Date.now() };
  const e = SV.etichetta(finto);
  ok(e && e.ondata === 7 && e.classe === 'Ladro' && e.livello === 11, 'e sa dire a che punto sei senza aprire il pacchetto: ' + JSON.stringify(e));
  ok(SV.etichetta({ f: 999 }) === null, 'e di un pacchetto che non capisce non dice niente, invece di inventare');
  // il pulsante RIPRENDI sta nella PRIMA schermata, non nella sala d attesa: una partita salvata si
  // riprende prima di scegliere eroe e stanza, non dopo. (Ed era finito nel posto sbagliato al primo giro.)
  const html = fs.readFileSync(ROOT + 'public/index.html', 'utf8');
  const menu = html.slice(html.indexOf('<div id="menu">'), html.indexOf('<div id="lobby"'));
  ok(/id="riprendiBtn"/.test(menu), 'il pulsante RIPRENDI sta nella prima schermata');
  ok(/id="riprendiBtn"[^>]*hidden/.test(menu), 'e nasce nascosto: chi non ha salvato non deve vederlo');
  ok(/id="innSalva"/.test(html), 'e il salvataggio si compra dal pannello dell Ostessa');
  const srcM = fs.readFileSync(ROOT + 'public/js/main.js', 'utf8');
  ok(/localStorage\.setItem\(SV\.CHIAVE/.test(srcM), 'il pacchetto si tiene nel browser');
  ok(/catch \(_\) \{ return null; \}/.test(srcM), 'e le letture sono protette: localStorage SOLLEVA in finestra anonima');
  ok(/Net\.riprendi\(G\.riprendiDati\)/.test(srcM), 'e riprendere lo rimanda al server');
  // v2.11.3 — riprendendo comanda il SALVATAGGIO, non la casella selezionata nel menu: qui c'era
  // `G.meHero = HUD.selectedHero` secco, e cancellava la classe appena letta dal salvataggio.
  ok(/G\.meHero = \(G\.riprendiDati && G\.riprendiDati\.heroId\) \|\| HUD\.selectedHero;/.test(srcM),
    'e la classe la decide il salvataggio, non la casella rimasta selezionata nel menu');
  ok(!/removeItem\(SV\.CHIAVE/.test(srcM), 'e NESSUNO lo cancella: morire non toglie il salvataggio, e il punto di averlo');
  const srcH = fs.readFileSync(ROOT + 'public/js/hud.js', 'utf8');
  ok(/_renderSalva\(/.test(srcH), 'l HUD disegna il pulsante del salvataggio');
  // il pulsante dice sempre PERCHE non si puo: uno spento e muto si legge come un guasto
  for (const [v, cosa] of [['-1', 'in cooperativa'], ['0', 'senza monete'], ['1', 'si puo'], ['2', 'gia salvato qui']])
    ok(new RegExp('salvaOk === ' + v).test(srcH), 'e distingue il caso "' + cosa + '"');
})();

console.log('=================================================='); console.log(fails ? '  CLIENT: ' + fails + ' FALLITI' : '  CLIENT: tutti i controlli passati'); console.log('==================================================');


process.exit(fails ? 1 : 0);
