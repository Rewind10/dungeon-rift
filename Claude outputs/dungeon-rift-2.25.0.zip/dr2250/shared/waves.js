/* waves.js — direttore ondate / difficoltà / MODALITÀ (server) */
(function (root, factory) {
  const m = factory(
    (typeof module !== 'undefined' && module.exports) ? require('./monsters.js') : root.GAME.Monsters,
    (typeof module !== 'undefined' && module.exports) ? require('./mathutils.js') : root.GAME.Math,
    // v2.24 — servono i numeri dell'ondata (totale, tetto, soglia delle riserve): stavano gia' in
    // constants.js e non ha senso ricopiarli qui, dove domani nessuno li aggiornerebbe.
    (typeof module !== 'undefined' && module.exports) ? require('./constants.js') : root.GAME.Constants
  );
  if (typeof module !== 'undefined' && module.exports) module.exports = m;
  else { root.GAME = root.GAME || {}; root.GAME.Waves = m; }
})(typeof self !== 'undefined' ? self : this, function (Mon, MU, C) {
  'use strict';
  const MONSTERS = Mon.MONSTERS, BOSSES = Mon.BOSSES;
  // v1.89 — I BOSS SONO DUE: uno a META' STRADA (10) e quello finale (20). Erano quattro, uno ogni cinque
  // ondate: al quinto turno avevi visto tre nemici su dieci e ti arrivava gia' un boss, e al quindicesimo
  // il boss era diventato un appuntamento invece di un evento. Con due, la prima meta' e' una salita vera.
  const BOSS_EVERY = 10, FINAL_WAVE = 20;
  const BOSS_WAVES = [10, 20];

  // Modalità ondata (le ondate boss restano a parte)
  const MODES = {
    // v1.78 — resta solo questa: le altre quattro (Orda, Caccia, Sopravvivenza, Tesoro) sono state
    // tolte. Il nome non compare piu' da nessuna parte, ma la voce serve al motore per countMul/eliteMul.
    assault:  { id: 'assault', name: 'ONDATA', color: '#ff5252', desc: 'Ondata standard', countMul: 1.0, eliteMul: 1.0, survive: 0 },
  };
  // v1.78 — UNA MODALITA' SOLA. Orda, Caccia, Sopravvivenza e Tesoro sono state tolte: ogni ondata e'
  // un'ondata normale. Cambiavano il ritmo in modo che il giocatore non sceglieva e non poteva
  // prevedere — la Sopravvivenza per esempio durava un tempo fisso e non si poteva chiudere prima, il
  // Tesoro trasformava l'ondata in un inseguimento. Con una modalita' sola l'unica variabile che resta
  // e' l'ondata stessa, e il cronometro ha finalmente senso su tutte.
  // MODES resta una tabella perche' il resto del motore legge mode.countMul e mode.eliteMul, e perche'
  // se un domani si volesse rimettere una variante il posto e' questo — ma modeForWave risponde sempre
  // 'assault' e le altre voci sono sparite dalla tabella, cosi' non si possono raggiungere per sbaglio.
  function modeForWave(wave, rng) {
    return MODES.assault;
  }

  // v1.50 — CURVA DI INTRODUZIONE ripristinata. Un archetipo nuovo ogni 1-2 ondate, secondo i tre pilastri
  // del roster (sciame -> blob -> caster -> tank -> debuffer). Le comparse "dal primo stage" introdotte in
  // v1.44 (slime, cave_brute) e v1.49 (occhio) erano TEMPORANEE, servivano a valutare i nuovi sprite: erano
  // rimaste nel codice appiattendo la rampa di difficolta'.
  function poolForWave(w) {
    const p = []; const add = (id, x) => { if (MONSTERS[id]) p.push({ id, weight: x }); };
    // v1.79.2 — IL TROLL DELLE CAVERNE E' USCITO dal pool. Era il tank con lo slam ad area
    // dall'ondata 4: tolto per scelta. Gli archetipi che venivano dopo si fanno avanti di un'ondata
    // ciascuno, cosi' la rampa non lascia un buco dove c'era lui e ogni ondata continua a portare
    // qualcosa di nuovo. La definizione resta in monsters.js ma non e' piu' raggiungibile da qui.
    add('skeleton', 40);                  // sciame mischia — sempre presente
    // v2.22 — LA LAMA ENTRA PRESTO, ed e' voluto: e' il primo nemico che TELEGRAFA il colpo, quindi
    // deve arrivare quando c'e' ancora da imparare a schivare. Alla seconda ondata, non alla decima.
    if (w >= 2) add('lama', 14);          // galleggia, si carica mezzo secondo, scatta dritta
    if (w >= 2) add('slime', 16);         // blob acido, si divide alla morte
    if (w >= 3) add('darkmage', 12);      // caster / evocatore
    // v2.25 — I SEMPLICI VENGONO AVANTI. Paolo: *«alla terza ondata ci sono solo 3 tipologie, direi
    // troppo poco; magari quelli piu' semplici falli entrare leggermente prima»*. Aveva ragione, e il
    // motivo e' la v2.24: finche' un'ondata ne portava quaranta, quattro tipi bastavano a riempirla di
    // roba diversa. Con venti, quattro tipi sono quattro mucchi. Il tetto piu' basso non ha cambiato
    // solo quanti nemici arrivano: ha cambiato quanti tipi SERVONO per non far sembrare l'ondata
    // sempre uguale, e la rampa era ancora tarata sui numeri vecchi.
    // Si fanno avanti i piu' semplici da leggere — uno sciame che ondeggia, una cosa immobile, una
    // che carica dritto — non quelli che chiedono una risposta nuova. Nessuno viene RITARDATO: le
    // ondate alte hanno esattamente il bestiario di prima.
    if (w >= 3) add('spore_fungus', 10);  // immobile: nega il terreno, punisce chi sta fermo   (era 4)
    if (w >= 3) add('bat_swarm', 10);     // sciame volante: ondeggia — insegna a guidare il tiro (era 5)
    if (w >= 4) add('bone_roller', 9);    // carica in linea retta: obbliga a schivare di lato  (era 6)
    if (w >= 5) add('wisp', 8);           // attraversa i muri: toglie il riparo come risposta  (era 7)
    // v2.22 — IL CUBO alla 6: arriva quando il giocatore ha gia' imparato a sparare a distanza e
    // a tenere la linea di tiro, perche' il suo mestiere e' togliergli proprio quella.
    if (w >= 6) add('cubo', 7);           // muro che si muove: ferma i proiettili, va aggirato
    if (w >= 6) add('larva', 12);         // Larva Fetida — scoppia quando la uccidi            (era 9)
    // v1.81 — LA RAMPA ANTICIPATA. Prima il gioco smetteva di presentare cose all'ondata 7: dopo
    // arrivavano solo i tre Beholder (9, 12, 15) e le ondate 8, 10, 11, 13, 14 e dalla 16 in poi non
    // portavano NIENTE di nuovo. All'ondata 19 la composizione era identica a quella della 15. Adesso
    // ogni ondata dalla 1 alla 12 mette in campo un archetipo che prima non c'era, e i Beholder si
    // fanno avanti: il Viola alla 8, quello di Carne alla 10, lo Spettrale alla 12 — cosi' il piu'
    // lavorato dei tre non compare a cinque ondate dalla fine.
    if (w >= 7) add('ragno', 10);           // Vedova delle Volte — tesse tele che rallentano       (era 8)
    if (w >= 8) add('occhio', 9);           // Occhio Viola — il primo dei tre, tetto di 8 vivi   (era 9)
    if (w >= 9) add('ragno_cripta', 8);     // Ragno della Cripta — la seconda tessitrice         (era 10)
    if (w >= 10) add('occhio_carne', 7);    // Occhio di Carne — piu' duro e piu' vicino          (era 12)
    if (w >= 11) add('ragno_veleno', 6);    // Tessitrice Verde — la terza, tele piu' larghe       (nuovo)
    if (w >= 12) add('occhio_spettro', 5);  // Occhio Spettrale — attraversa i muri, raggio lungo (era 15)
    // v2.23 — IL PADRONE alla 15. Le ondate dalla 13 alla 19 non portavano piu' niente di nuovo:
    // sette ondate di seguito con solo numeri piu' grandi. Lui arriva in mezzo a quel vuoto, ed e'
    // il primo nemico che rende piu' forti gli ALTRI — a quel punto il giocatore conosce tutto il
    // bestiario, quindi accorgersi che l'ondata picchia piu' del solito vuol dire qualcosa.
    // Peso basso e tetto di 2 vivi: due Padroni in campo sono gia' un'ondata diversa, tre sarebbero
    // una moltiplicazione.
    if (w >= 15) add('padrone', 5);         // comanda i vicini, frusta da presso, condanna da lontano
    return p;
  }

  // v1.79.1 — QUANTI NEMICI. Era `5 + 1,8·ondata`: sette mostri alla prima ondata, nove alla seconda.
  // Alla prova sul campo le prime ondate erano una passeggiata, e siccome l'esperienza viene da li', erano
  // anche una carestia: l'ondata 1 metteva a terra 60 XP contro i 400 che allora costava il livello 2.
  // Adesso e' `10 + 1,6·ondata`: la base parte alta e la pendenza scende, cosi' le PRIME ondate quasi
  // raddoppiano (7 → 12, 9 → 13, 10 → 15) e le ULTIME restano dov'erano (39 → 40 alla diciannovesima), che
  // erano gia' tarate bene. Il numero di mostri VIVI insieme non cambia: quello lo decide MAX_ALIVE_CURVE,
  // e i mostri in eccesso restano in coda.
  function scaling(w, players) { const p = Math.max(1, players); return { hp: 1 + w * 0.15 + (p - 1) * 0.14, dmg: 1 + w * 0.055, speed: 1 + Math.min(0.30, w * 0.015), count: Math.round((10 + w * 1.6) * (0.78 + p * 0.22)), eliteChance: Math.min(0.26, 0.03 + w * 0.019) }; }
  function isBossWave(w) { return w >= FINAL_WAVE || BOSS_WAVES.indexOf(w) >= 0; }
  function bossForWave(w, players) {
    // v1.89 — due boss, due identita': il COLOSSO a meta' strada (un muro che si apre solo quando si
    // sfalda) e AZ'GAROTH alla fine (potenza pura). Il Signore della Guerra e il Re Lich restano scritti
    // in monsters.js ma non compaiono piu': erano gli ultimi due nemici disegnati DI LATO in un gioco
    // visto dall'alto, ed e' per quello che stonavano.
    const def = w >= FINAL_WAVE ? BOSSES.mega_dragon : BOSSES.rift_colossus;
    const p = Math.max(1, players);
    // la curva e' tarata perche' AZ'GAROTH alla 20ª resti esattamente quello di prima (x2,5): togliere due
    // boss non doveva rendere il finale piu' facile.
    return { def, hpMul: 1 + Math.max(0, w - 10) * 0.15 + (p - 1) * 0.5, dmgMul: 1 + w * 0.03 };
  }
  function buildWave(w, players, mode) {
    const s = scaling(w, players); const pool = poolForWave(w);
    // v2.24 — IL TOTALE DELL'ONDATA. Dalla settima in poi e' FISSO (20 in solitario, +4 per ogni
    // giocatore in piu'): non cresce piu' con l'ondata. Prima la 20 ne aveva 42 e la partita si
    // allungava senza diventare piu' interessante. Fino alla sesta resta la curva di prima, ma
    // tagliata allo stesso tetto, se no in due giocatori la sesta ne avrebbe piu' della settima.
    const gio = Math.max(1, players | 0);
    const TOT = (C.ONDATA_TOT || 20) + (C.ONDATA_TOT_GIOC || 4) * (gio - 1);
    let count = Math.max(3, Math.round(s.count * (mode ? mode.countMul : 1)));
    count = (w >= (C.ONDATA_TOT_DA || 7)) ? Math.round(TOT * (mode ? mode.countMul : 1)) : Math.min(count, TOT);
    const eliteChance = Math.min(0.6, s.eliteChance * (mode ? mode.eliteMul : 1));
    const list = [];
    // v2.24 — LA VARIETA' NON PUO' PAGARE IL TAGLIO. Paolo: *«nei livelli avanzati voglio varieta',
    // quindi devono entrare tutti i nemici»*. Con venti posti e una sorte pesata, i tipi rari
    // (Padrone, Cubo, lo Spettrale) sarebbero usciti una volta su tre ondate. Quindi: se il mazzo
    // ci sta, prima UNO DI OGNI TIPO, poi il resto a sorte pesata. Cosi' il bestiario si vede tutto
    // e i pesi decidono solo chi si ripete.
    const semi = [];
    if (pool.length && pool.length <= count - 3) for (const p of pool) semi.push(p.id);
    for (let i = 0; i < count; i++) {
      const id = i < semi.length ? semi[i] : MU.weighted(pool).id;
      list.push({ type: id, elite: MU.chance(eliteChance) && !MONSTERS[id].boss });
    }
    // mescolata: i "semi" sono in ordine di pool, e senza questa riga i primi che entrano in campo
    // sarebbero sempre gli stessi nello stesso ordine, ondata dopo ondata
    for (let z = list.length - 1; z > 0; z--) { const j = (Math.random() * (z + 1)) | 0; const t = list[z]; list[z] = list[j]; list[j] = t; }
    return { list, scaling: s, mode };
  }
  // v1.50 — moltiplicatore PV degli elite reso PER-NEMICO (def.eliteHp, default ELITE_HP). Il 2.4x fisso
  // era tarato sui nemici da ~80-100 PV: applicato ai tank produceva mostri fuori scala nelle prime ondate
  // (Troll elite ~845 PV all'ondata 4, contro l'arma iniziale).
  const ELITE_HP = 2.4;
  function applyScaling(mon, s, elite) {
    const eh = (mon.def.eliteHp != null) ? mon.def.eliteHp : ELITE_HP;
    mon.maxHp = Math.round(mon.def.hp * s.hp * (elite ? eh : 1)); mon.hp = mon.maxHp;
    mon.dmg = Math.round(mon.def.dmg * s.dmg * (elite ? 1.5 : 1));
    mon.radius = mon.def.radius * (elite ? 1.28 : 1);
    const sizeFactor = MU.clamp(16 / mon.radius, 0.6, 1.45);
    mon.speed = mon.def.speed * s.speed * (elite ? 1.12 : 1) * sizeFactor;
    mon.xp = Math.round(mon.def.xp * (elite ? 2.5 : 1)); mon.elite = !!elite;
    if (elite && MU.chance(0.5)) mon.def = Object.assign({}, mon.def, { regen: (mon.def.regen || 0) + 8 });
  }
  return { BOSS_EVERY, BOSS_WAVES, FINAL_WAVE, MODES, modeForWave, poolForWave, scaling, isBossWave, bossForWave, buildWave, applyScaling };
});
